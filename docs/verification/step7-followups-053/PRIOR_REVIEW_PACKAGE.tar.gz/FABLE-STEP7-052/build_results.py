"""Assemble RESULTS.json (probe index) for FABLE-STEP7-052 from the workflow journals and lead probes.

Run: python3 build_results.py <verify_journal.jsonl or ''>
Reads: results/workflow_attacks_raw.json, results/workflow_verify_partial_raw.json, results/findings_merged.json,
       probes/lead/*.log, the second verify workflow journal (if given) for fresh votes and the critic.
Writes: results/workflow_verify_merged_raw.json, results/critic.json, RESULTS.json
"""
import json, os, sys, glob

R = '/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052'
attacks = json.load(open(R + '/results/workflow_attacks_raw.json'))
partial = json.load(open(R + '/results/workflow_verify_partial_raw.json'))
merged = json.load(open(R + '/results/findings_merged.json'))['merged']

fresh, critic = [], None
if len(sys.argv) > 1 and sys.argv[1] and os.path.exists(sys.argv[1]):
    for line in open(sys.argv[1]):
        try:
            e = json.loads(line)
        except Exception:
            continue
        if e.get('type') != 'result':
            continue
        r = e.get('result')
        if isinstance(r, str):
            try:
                r = json.loads(r)
            except Exception:
                pass
        if isinstance(r, dict) and 'finding_id' in r:
            fresh.append(r)
        elif isinstance(r, dict) and 'approval_or_wrong_notice_path_demonstrated' in r:
            critic = r
json.dump(fresh, open(R + '/results/workflow_verify_merged_raw.json', 'w'), indent=1)
if critic is not None:
    json.dump(critic, open(R + '/results/critic.json', 'w'), indent=1)

probes = []
for a in attacks:
    for p in a['probes']:
        probes.append({'dimension': a['dimension'][:60], 'name': p['name'], 'status': p['status'],
                       'script': p['script'], 'log': p['log'], 'observed': p['observed'],
                       'script_is_file': os.path.exists(p['script']), 'log_is_file': os.path.exists(p['log'])})
for log in sorted(glob.glob(R + '/probes/lead/*.log')):
    try:
        d = json.load(open(log))
        probes.append({'dimension': 'lead reviewer', 'name': d.get('probe'), 'status': d.get('status'),
                       'script': log[:-4] + '.py', 'log': log, 'observed': json.dumps(d.get('observed'))[:600],
                       'script_is_file': True, 'log_is_file': True})
    except Exception as exc:
        probes.append({'dimension': 'lead reviewer', 'name': os.path.basename(log), 'status': 'INFO', 'script': log[:-4] + '.py',
                       'log': log, 'observed': f'unparsed: {exc}', 'script_is_file': True, 'log_is_file': True})
if critic:
    for p in critic.get('extra_probes', []):
        probes.append({'dimension': 'critic', 'name': p['name'], 'status': p['status'], 'script': p['script'], 'log': p['log'],
                       'observed': p['observed'], 'script_is_file': os.path.exists(p['script']), 'log_is_file': os.path.exists(p['log'])})

votes_by_merged = {}
for m in merged:
    members = set(m['members'])
    votes = [v for v in partial if v['finding_id'] in members] + [v for v in fresh if v['finding_id'] == m['id'] or v['finding_id'] in members]
    votes_by_merged[m['id']] = [{k: v.get(k) for k in ('finding_id', 'lens', 'verdict', 'severity_recommendation', 'kind_recommendation', 'reasoning', 'repro_script', 'repro_log')} for v in votes]

from collections import Counter
out = {
    'schema': 'fable.step7.results.v1', 'work_id': 'FABLE-STEP7-052',
    'exact_tested_sha': '67f644bc31bf19eadec628b738855e7b6c152a4e', 'tested_code_commit': '6b51f005c001d2d99a535e4a302370f9ad80c6ea',
    'accepted_base': '2d522f0362e656e029986344d47e2e06b86a58f8',
    'probe_counts': dict(Counter(p['status'] for p in probes)), 'probe_total': len(probes),
    'attack_dimensions': [{'dimension': a['dimension'], 'probes': len(a['probes']), 'findings': [f['id'] for f in a['findings']],
                           'limits': a.get('limits', []), 'checkout_clean_at_end': a.get('checkout_clean_at_end')} for a in attacks],
    'probes': probes,
    'raw_findings_total': sum(len(a['findings']) for a in attacks),
    'merged_findings': [{'id': m['id'], 'title': m['title'], 'members': m['members'], 'votes': votes_by_merged[m['id']]} for m in merged],
    'critic': critic,
    'votes_total': len(partial) + len(fresh),
}
json.dump(out, open(R + '/RESULTS.json', 'w'), indent=1)
print('probes', len(probes), out['probe_counts'], 'raw findings', out['raw_findings_total'], 'votes', out['votes_total'], 'critic', bool(critic))
for m in out['merged_findings']:
    print(m['id'], [(v['lens'][:5], v['verdict'], v['severity_recommendation'], v['kind_recommendation']) for v in m['votes']])
