# FABLE-STEP7-052 shared probe context

Independent adversarial review of LILA Step7 (evidence collection). Review only.

## Exact objects
- Repo clone (review checkout, MUST stay pristine): `/Users/wtjohnson/lila-step7-052`
- Candidate SHA (checked out): `67f644bc31bf19eadec628b738855e7b6c152a4e` (publication child)
- Tested code commit: `6b51f005c001d2d99a535e4a302370f9ad80c6ea` (verified: child adds only docs/verification/step7-052/*)
- Accepted Step6 base: `2d522f0362e656e029986344d47e2e06b86a58f8` (verified merge-base)
- Python: `/Users/wtjohnson/lila-step7-052/.venv/bin/python` (3.14.5, httpx 0.28.1, pdfplumber 0.11.10, pytest 9.1.1)
- Review package root (write here only): `/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/`
  - `probes/<dimension>/` your scripts, logs, JSON results
  - `extracted/source-proof/` unpacked SOURCE_PROOF (61 files, manifest verified)
  - `extracted/producer-proof/` unpacked PRODUCER_PROOF (21 files, manifest verified)

## Delta under review (base..6b51f00)
Production files: `agents/decisions/dossier.py` (+43), `run_searches.py` (`_enrich_sam_public_attachments`, +53/-?),
`tools/api/_http.py` (+32: optional `response_observer`, `max_response_bytes` streaming capture),
`tools/api/sam_attachment_text.py` (+87: raw/text capture, `collection_status`, `_text_capture_valid`),
`tools/api/sam_capture.py` (new: `retain_bytes`, `read_retained`, content-addressed `objects/<sha256>.bin`),
`tools/api/sam_notice_detail.py` (+80: `_resource_identity_matches`, `_resource_capture_valid`, collection_status, raw_capture).
Tests: `tests/test_step7_evidence_collection.py` (new, 179 lines). Docs: CONTRACT_SURFACES.md, CONVENTIONS.md (Step7 sections).
Use `git -C /Users/wtjohnson/lila-step7-052 diff 2d522f0..6b51f00 -- <file>` to see exact changes, and
`git -C /Users/wtjohnson/lila-step7-052 show 2d522f0:<path>` to read the BASE version of a file (for base vs candidate comparison, write the base file into your probe dir; never check out or modify the review clone).

## Key env seams
- `LILA_NOTICE_CACHE_DIR` : inventory cache dir (`<id>.resources.json`, `objects/`). ALWAYS set to a probe-local temp dir.
- `LILA_SAM_ATTACHMENT_TEXT_DIR` : attachment text cache dir (`<resource_id>.json`, `objects/`). ALWAYS set to a probe-local temp dir.
- `LILA_SAM_ATTACHMENT_TEXT_CHARS` (default 50000), `LILA_SAM_ATTACHMENT_PDF_PAGES` (100), `LILA_SAM_ATTACHMENT_MAX_BYTES` (5 MiB), `LILA_SAM_ATTACHMENT_STAGE_SECONDS` (120).
- Network isolation: monkeypatch `tools.api._http._client` to `lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))`; for file downloads monkeypatch `tools.api.sam_attachment_text._download_bytes`. Consider also blocking `socket.socket.connect`. NEVER make a real network call. NEVER call sam.gov.
- Quota: monkeypatch `tools.api.sam_quota.calls_today` to `lambda: 0` when calling `run_searches._enrich_sam_public_attachments`.
- Suite env for pytest: `PYTHONDONTWRITEBYTECODE=1 LILA_SUITE_OFFLINE=1 LILA_SUITE_STRICT=1 ... -p no:cacheprovider`. Note: under LILA_SUITE_OFFLINE the conftest autouse fixture wraps `_http._request` and raises on ANY call (even mocked). The Step7 test captures the native `_request` at import and restores it inside its fixture; see `tests/test_step7_evidence_collection.py::http_fixture`.
- Useful helpers: `tests/test_assess_ledger.py::_sweep, _build` (strict Assess build from a sweep dict); `tests/test_step7_evidence_collection.py::native_collection` (synthetic native enrichment producing a row with `attachment_collection_v1`).

## Producer claims to challenge (from docs/verification/step7-052/)
- Inventory states: `confirmed_empty | unrecognized_inventory | identity_mismatch | lookup_failed | inventory_captured | stale_inventory`.
- File states: `captured_discovery_only | lookup_failed | unreadable | inaccessible | identity_mismatch | not_fetched`.
- "Recognized inventories must reject any conflicting original notice ID" (identity check only reads keys `opportunityId`, `noticeId`, `notice_id`; `_links.self.href` is NOT checked).
- "Successful caches bind the original resource metadata, raw bytes, text bytes and aware acquisition clock" (`_text_capture_valid` verifies raw hash and text hash independently; it does NOT re-derive text from raw).
- "Legacy/unbound/changed cache entries require a new bounded attempt; failed refresh cannot return their text as freshly collected."
- Combined text: up to 3 files joined with "\n\n", capped at 150000 chars; per-file `combined_text_locator` in unicode characters; dossier includes at most 14000 chars, `file_passages` carry `truncated`.
- Dossier `_attachment_research_context` returns `unavailable` on ANY binding failure (whole research context dropped, not per file).
- Collected text is `discovery_only`; must never grant strict Assess requirement approval (`LiveClassification.BID_NOW`, `requirement_reviewed_at`) nor populate `source_depth` / `full_description`.

## Hypotheses already formed by the lead reviewer (verify or refute, do not assume)
H1. Coherent text-cache rewrite (rewrite `text`, `text_sha256`, and place a new `objects/<sha>.bin` for the new text) passes `_text_capture_valid` because text is never re-derived from raw bytes. The producer test only tampers `text` alone.
H2. Cache clocks (`retrieved_at`, `raw_capture.received_at`) are unauthenticated; a local writer can move them to any past aware time and keep a stale inventory "fresh".
H3. Wrong-notice body that omits explicit `opportunityId/noticeId/notice_id` keys (only `_links.self.href` names the other notice) is accepted as this notice's inventory.
H4. Real SAM zero-attachment shape appears to be `{"_links":{...}}` with no `_embedded` (4 of 21 captured bodies); code classifies it `unrecognized_inventory` (conservative, not a defect, but a yield residual).
H5. Degenerate locator: if `LILA_SAM_ATTACHMENT_TEXT_CHARS` is raised so the first two files fill the 150000 cap, the third file gets `file_text=""` with `start == end`, and the dossier then rejects the WHOLE research context ("locator does not match retained text"), dropping two perfectly bound files. Not reachable with defaults (3 x 50000 + 4 = 150004).
H6. Time-budget exhaustion mid-loop leaves later files with reason "outside file/type budget" although they were eligible and merely unattempted.
H7. `retain_bytes` requires hardlink support (`os.link`); on a filesystem without it every download becomes `lookup_failed` and the downloaded bytes are dropped.
H8. Legacy caches (no `raw_capture`) are all invalidated by the upgrade; a fresh sweep refetches every inventory/file once (keyless endpoint, bounded by 120 s stage budget), and if the refetch fails within 7 days the legacy inventory becomes `stale_inventory` and is excluded from relevance. Operator machine census: 6 legacy inventory caches, 14 legacy text caches.
H9. Test harness: the new test module restores the native `_request`, bypassing the suite offline observer; safe only because `_client` is mocked in the same fixture.

## Hard rules for every agent
- Never modify, add, or delete any file inside `/Users/wtjohnson/lila-step7-052` (tracked or untracked) except that pytest may write nothing there either (`-p no:cacheprovider`, `PYTHONDONTWRITEBYTECODE=1`). Confirm `git -C /Users/wtjohnson/lila-step7-052 status --porcelain` is empty when you finish. No git checkout, reset, stash, commit, branch, worktree, or prune.
- Write only under `/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/<your-dimension>/`.
- Do not touch `/Users/wtjohnson/Lila`, `/Users/wtjohnson/federal-sales-os`, or anything under `/Users/wtjohnson/Documents/Codex` except READ-ONLY reads of handoff files. No file copies out of LaCie/Desktop/iCloud.
- No live network. No pkill. No LLM calls (no `anthropic`, no `claude` CLI, no DecisionEngine deliberate).
- Never write the banned FSOS house term that sits on the REPORT_CONTRACT L7 banned-vocabulary list (the eight-letter word for a passage between rooms) and never use em-dash characters in any file or in your return.
- Every probe is a runnable script `probe_<name>.py` that prints one JSON object with `status` in {PASS, FAIL, INFO} and `observed` details; run it as `cd /Users/wtjohnson/lila-step7-052 && PYTHONDONTWRITEBYTECODE=1 .venv/bin/python <script> > <log> 2>&1; echo "exit=$?"`. Never pipe a gate through `tail`; read the log after.
- PASS means the candidate behaved as the producer claims; FAIL means you demonstrated a defect or an overstated claim; INFO means a measured limit that is already disclosed.
- Distinguish: `new_defect` (introduced or not fixed by the Step7 delta), `pre_existing` (present at base 2d522f0 too; prove by running against the base file), `disclosed_residual` (matches a producer/prior residual statement), `doc_overstatement` (code is safe but a doc claim is broader than the code), `harness` (test design issue).
- Severity: Critical (trusted approval or wrong-notice evidence reaches Assess/LeadRow), High (silent wrong evidence/identity/bytes in research or receipts), Medium (undetected tampering within local trust boundary, misleading receipts, yield loss), Low (edge, non-default config), Info.
