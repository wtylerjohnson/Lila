# FABLE-STEP7-052

Independent adversarial review of the LILA Step7 evidence-collection candidate.

- Repository: github.com/wtylerjohnson/Lila, branch `codex/step7-evidence-collection`
- Exact tested SHA: `67f644bc31bf19eadec628b738855e7b6c152a4e` (publication child of code commit `6b51f005c001d2d99a535e4a302370f9ad80c6ea`)
- Accepted Step6 base: `2d522f0362e656e029986344d47e2e06b86a58f8`
- Verdict and findings: `FABLE_STEP7_REPORT.md` (human) and `FINDINGS_AND_RESIDUALS.json` (machine-readable)
- Review only. No production merge, no automatic acceptance, no seller-ready claim, no frozen rescore, no live acquisition, no cloud run.

## Files

| Path | Purpose |
| --- | --- |
| `FABLE_STEP7_REPORT.md` | verdict, severity-ranked findings, retained residuals, non-claims |
| `FINDINGS_AND_RESIDUALS.json` | canonical register of merged findings with member ids, votes, dispositions |
| `RESULTS.json` | index of every probe (dimension, status, script, log, observation) and every refuter vote |
| `CUSTODY_CHECKS.json` | 15 custody checks (SHA, publication equality, archives, manifests, fixtures, replay, suite parity) |
| `ENVIRONMENT.json` | review host, interpreter, library versions, independence statement |
| `COMMANDS.json` | every command run by the lead reviewer with its log path |
| `CONTEXT.md` | the shared brief handed to every probe agent (rules, seams, hypotheses) |
| `logs/` | focused and full suite logs and exit codes, replay and boundary probe logs, fixture-dependency logs |
| `results/` | junit XML, suite comparison, blob inventory, preservation re-hash, cross-hash, fixture receipts, replay and boundary outputs, IHS re-extraction, raw and merged findings, refuter votes, critic |
| `probes/lead/` | three lead-reviewer probes (coherent cache rewrite, links-only wrong notice, degenerate locator) |
| `probes/<dimension>/` | one directory per attack dimension: probe scripts, logs, JSON results, base-file copies from `git show 2d522f0` |
| `probes/verify/<finding>/<lens>/` | independent refuter probes and logs per finding and lens |
| `probes/critic/` | completeness critic probes |
| `extracted/source-proof/`, `extracted/producer-proof/` | hash-verified unpacked copies of the two producer archives |

## How the evidence was produced

1. Fresh clone, exact SHA checkout, merge-base verification, publication-child equality check.
2. Fresh Python 3.14.5 venv from `requirements.txt` (not the producer venv).
3. Producer archives extracted into owned directories and verified against their manifests and `LOCAL_VERIFICATION.json`.
4. Focused suite (201) and full offline strict suite (5864 passed, 40 skipped) with the 31 ignored fixtures staged byte-exact; junit compared case by case with the producer junit.
5. Packaged replay and boundary drivers rerun; IHS PDFs independently re-extracted and compared page by page.
6. Twelve adversarial probe agents, one per dimension, each writing runnable probes against the real production functions with mocked network; 86 raw findings merged into 22 canonical findings.
7. Independent refuters (reproduce, scope, impact lenses) voted on every finding; a completeness critic looked for gaps and contradictions.

## Notes on package hygiene

- Files named `base_*.py` or under `base/` and `base_stack/` are verbatim `git show 2d522f0:<path>` copies of repository files kept for base-versus-candidate comparison; a few agents replaced the repository's own em-dash characters in comments with hyphens and say so in their LIMITS lines. Nothing authored by the reviewer contains an em-dash or the banned house term.
- `results/full-01.xml` and `extracted/producer-proof/full-01.xml` contain repository test names verbatim, including the repository's own banned-vocabulary test names.
- Probe scratch caches were created under the probe directories only; the review clone stayed clean (`git status --porcelain` empty) apart from one gitignored `data/cache/links/` entry written by a pre-existing repository test during the full suite (recorded as an informational observation in the report).
