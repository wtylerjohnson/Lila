"""Edges where a GOOD 200 recognized response is downgraded to a failure:
 1. Uppercase notice_id vs lowercase body opportunityId -> identity_mismatch? (regex admits uppercase)
 2. Custody failure (os.link unsupported, H7) -> recognized 200 body becomes lookup_failed
 3. Read-only cache dir -> recognized 200 body becomes lookup_failed
 4. Base comparison for 1 (base had no identity check) and 2/3 (base retained nothing before parse)
 5. Wrong-notice body with only _links.self.href naming another notice (H3) -> accepted (identity check reads 3 keys only)
"""
import json
import os
import stat
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

base = H.load_base_detail()
LOWER = "0caab6e53d8b47d7850692b7684610bf"
UPPER = LOWER.upper()
BODY = (H.INVENTORY_DIR / f"{LOWER}.body").read_bytes()  # real body, 5 attachments, opportunityId lowercase

observed = {}

# 1. uppercase id
d = H.fresh_cache_dir("case")
calls = H.install_transport(lambda r: httpx.Response(200, content=BODY))
r = H.detail.fetch_notice_resources(UPPER)
s = H.summarize(r); s["requested_url"] = calls[0]["url"]
rb = base.fetch_notice_resources(UPPER)
s["base_status"] = {"resources_checked": rb.get("resources_checked"), "count": rb.get("attachment_inventory_count"), "errors": rb.get("errors")}
observed["1_uppercase_id_vs_lowercase_body"] = s

# 2. os.link unsupported (simulate a filesystem without hardlinks)
d = H.fresh_cache_dir("nolink")
import tools.api.sam_capture as cap
real_link = os.link


def no_link(*a, **k):
    raise OSError(1, "Operation not permitted (no hardlink support)")


cap.os.link = no_link
try:
    calls = H.install_transport(lambda r: httpx.Response(200, content=BODY))
    r = H.detail.fetch_notice_resources(LOWER)
    s = H.summarize(r); s["cache_written"] = bool(H.cache_listing(d)["resources_json"])
    s["leftover_files"] = H.cache_listing(d)["files"]
finally:
    cap.os.link = real_link
observed["2_no_hardlink_support_H7"] = s

# 3. read-only cache dir
d = H.fresh_cache_dir("ro")
d.chmod(stat.S_IRUSR | stat.S_IXUSR)
try:
    calls = H.install_transport(lambda r: httpx.Response(200, content=BODY))
    r = H.detail.fetch_notice_resources(LOWER)
    s = H.summarize(r)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d)
    rb = base.fetch_notice_resources(LOWER)
    s["base_status"] = {"resources_checked": rb.get("resources_checked"), "count": rb.get("attachment_inventory_count"),
                        "errors": rb.get("errors")}
finally:
    d.chmod(stat.S_IRWXU)
observed["3_readonly_cache_dir"] = s

# 5. H3: wrong-notice body, only _links names the other notice
other = "213a2fe3a447465e8f30699c9f056ec4"
wrong = json.loads((H.INVENTORY_DIR / f"{other}.body").read_bytes())
for row in wrong["_embedded"]["opportunityAttachmentList"]:
    row.pop("opportunityId", None)
d = H.fresh_cache_dir("h3")
calls = H.install_transport(lambda r: httpx.Response(200, content=json.dumps(wrong).encode()))
r = H.detail.fetch_notice_resources(LOWER)
s = H.summarize(r); s["links_self"] = wrong["_links"]["self"]["href"][:120]
s["cache_written"] = bool(H.cache_listing(d)["resources_json"])
observed["5_wrong_notice_only_links_H3"] = s

H.emit({
    "probe": "identity_case_and_custody",
    "status": "INFO",
    "observed": observed,
})
