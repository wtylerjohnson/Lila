"""Replay all 21 captured public-inventory bodies through the REAL
fetch_notice_resources via MockTransport with their recorded http_status.
Compare collection_status, raw sha256/bytes and projected attachments to the
producer's per-receipt JSON and FAMILY_COLLECTION_DISPOSITIONS.json.
Also census the real bodies for soft-deleted / missing-file rows and foreign
notice IDs, which bear on EMPTY vs NONEMPTY correctness."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

receipts = {}
for path in sorted(H.INVENTORY_DIR.glob("*.json")):
    if path.name in {"ATTEMPT_PLAN.json", "RESULTS.json"}:
        continue
    receipts[path.stem] = json.loads(path.read_text())

dispositions = json.loads((H.SOURCE_PROOF / "FAMILY_COLLECTION_DISPOSITIONS.json").read_text())
disposition_status = {}
for family in dispositions:
    for attempt in family.get("inventory_attempts", []):
        disposition_status[attempt["notice_id"]] = attempt["status"]

results_json = {r["notice_id"]: r for r in json.loads((H.INVENTORY_DIR / "RESULTS.json").read_text())}

rows = {}
mismatches = []
status_census = {}
deleted_rows = {}
foreign_ids = {}
for nid, receipt in receipts.items():
    body = (H.INVENTORY_DIR / f"{nid}.body").read_bytes()
    cache = H.fresh_cache_dir("replay")
    calls = H.install_transport(lambda r, body=body, st=receipt["http_status"]: httpx.Response(
        st, content=body, headers={"content-type": "application/hal+json"}))
    result = H.detail.fetch_notice_resources(nid)
    s = H.summarize(result)
    listing = H.cache_listing(cache)
    s["cache_written"] = f"{nid}.resources.json" in listing["resources_json"]
    s["receipt_status"] = receipt["status"]
    s["disposition_status"] = disposition_status.get(nid)
    s["results_json_status"] = results_json.get(nid, {}).get("status")
    s["receipt_sha256"] = receipt["raw_sha256"]
    s["receipt_bytes"] = receipt["raw_bytes"]
    s["attachments_equal_receipt"] = (result.get("attachments") == receipt.get("attachments"))
    s["count_equal_receipt"] = (len(result.get("attachments") or []) == len(receipt.get("attachments") or []))
    s["url_requested"] = calls[0]["url"] if calls else None
    s["accept_header"] = calls[0]["headers"].get("accept") if calls else None
    rows[nid] = s
    status_census[s["collection_status"]] = status_census.get(s["collection_status"], 0) + 1
    ok = (s["collection_status"] == receipt["status"] == (disposition_status.get(nid) or receipt["status"])
          and s["raw_sha256"] == receipt["raw_sha256"] and s["raw_bytes"] == receipt["raw_bytes"]
          and s["attachments_equal_receipt"] and s["raw_complete"] is True and s["raw_http_status"] == receipt["http_status"]
          and s["cache_written"] is (receipt["status"] in {"inventory_captured", "confirmed_empty"}))
    if not ok:
        mismatches.append(nid)
    # Census of soft-deleted / non-existent rows and foreign IDs in the body.
    payload = json.loads(body)
    stack = [payload]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            if cur.get("deletedFlag") not in (None, "0", 0, False) or cur.get("fileExists") in ("0", 0, False):
                deleted_rows.setdefault(nid, []).append({"name": cur.get("name"), "deletedFlag": cur.get("deletedFlag"),
                                                         "fileExists": cur.get("fileExists")})
            for key in ("opportunityId", "noticeId", "notice_id"):
                if key in cur and cur[key] != nid:
                    foreign_ids.setdefault(nid, []).append({key: cur[key]})
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)

# Whole-corpus key census: which container keys does real SAM actually use?
key_census = {}
for nid in receipts:
    payload = json.loads((H.INVENTORY_DIR / f"{nid}.body").read_bytes())
    top = tuple(sorted(payload.keys()))
    emb = tuple(sorted((payload.get("_embedded") or {}).keys())) if isinstance(payload.get("_embedded"), dict) else None
    key_census[f"top={top} embedded={emb}"] = key_census.get(f"top={top} embedded={emb}", 0) + 1

H.emit({
    "probe": "inventory_replay_21",
    "status": "PASS" if not mismatches else "FAIL",
    "observed": {
        "bodies": len(receipts),
        "status_census": status_census,
        "mismatches": mismatches,
        "confirmed_empty_count": status_census.get("confirmed_empty", 0),
        "unrecognized_ids": [n for n, s in rows.items() if s["collection_status"] == "unrecognized_inventory"],
        "soft_deleted_or_missing_rows": deleted_rows,
        "foreign_notice_ids_in_bodies": foreign_ids,
        "real_shape_key_census": key_census,
        "rows": {n: {k: s[k] for k in ("collection_status", "receipt_status", "disposition_status", "results_json_status",
                                          "raw_http_status", "raw_bytes", "receipt_bytes", "attachments_equal_receipt",
                                          "attachment_inventory_count", "cache_written", "accept_header")}
                 for n, s in rows.items()},
    },
})
