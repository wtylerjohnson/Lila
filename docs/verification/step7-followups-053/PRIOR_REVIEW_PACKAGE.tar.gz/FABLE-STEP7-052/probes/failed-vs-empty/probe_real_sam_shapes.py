"""Real SAM shapes: the observed zero-file body {"_links":...} (H4) and the
plausible wrapper shape _embedded.opportunityAttachmentList[{opportunityId,
attachments:[]}]. Compare candidate vs BASE _attachment_inventory."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

NID = "00c39d451a234f5eb95f6ca717fb9bf6"
base = H.load_base_detail()

# Exact observed zero-file body from the 21 captures (4 of 21 have this shape).
real_links_only = (H.INVENTORY_DIR / f"{NID}.body").read_bytes()
real_receipt = json.loads((H.INVENTORY_DIR / f"{NID}.json").read_text())

# Real nonempty body, mutated ONLY by emptying its attachments array.
real_nonempty = json.loads((H.INVENTORY_DIR / "213a2fe3a447465e8f30699c9f056ec4.body").read_bytes())
wrapper_empty = json.loads(json.dumps(real_nonempty))
wrapper_empty["_embedded"]["opportunityAttachmentList"][0]["attachments"] = []
wrapper_empty["_embedded"]["opportunityAttachmentList"][0]["opportunityId"] = NID
for link in wrapper_empty["_links"].values():
    link["href"] = link["href"].replace("213a2fe3a447465e8f30699c9f056ec4", NID)

# Wrapper row with matching id and all attachments soft-deleted (deletedFlag=1).
wrapper_deleted = json.loads(json.dumps(real_nonempty))
wrapper_deleted["_embedded"]["opportunityAttachmentList"][0]["opportunityId"] = NID
for att in wrapper_deleted["_embedded"]["opportunityAttachmentList"][0]["attachments"]:
    att["deletedFlag"] = "1"
    att["fileExists"] = "0"

# Wrapper list with NO rows at all.
wrapper_no_rows = {"_embedded": {"opportunityAttachmentList": []},
                   "_links": real_nonempty["_links"]}

shapes = {
    "H4_links_only_real": real_links_only,
    "wrapper_attachments_empty": json.dumps(wrapper_empty).encode(),
    "wrapper_attachments_all_deleted": json.dumps(wrapper_deleted).encode(),
    "wrapper_list_no_rows": json.dumps(wrapper_no_rows).encode(),
}

observed = {}
for name, body in shapes.items():
    cache = H.fresh_cache_dir("shape")
    calls = H.install_transport(lambda request, body=body: httpx.Response(
        200, content=body, headers={"content-type": "application/hal+json"}))
    result = H.detail.fetch_notice_resources(NID)
    summary = H.summarize(result)
    listing = H.cache_listing(cache)
    summary["cache_written"] = f"{NID}.resources.json" in listing["resources_json"]
    payload = json.loads(body)
    cand_items, cand_recognized = H.detail._attachment_inventory(payload, NID)
    base_items, base_recognized = base._attachment_inventory(payload)
    summary["candidate_inventory_fn"] = {"items": cand_items, "recognized": cand_recognized}
    summary["base_inventory_fn"] = {"items": base_items, "recognized": base_recognized}
    summary["same_as_base"] = (cand_items, cand_recognized) == (base_items, base_recognized)
    observed[name] = summary

h4 = observed["H4_links_only_real"]
h4_matches_receipt = (h4["collection_status"] == real_receipt["status"]
                      and h4["raw_sha256"] == real_receipt["raw_sha256"]
                      and h4["raw_bytes"] == real_receipt["raw_bytes"])

wrapper = observed["wrapper_attachments_empty"]
# Finding: the wrapper shape carries a recognized key ("attachments") whose
# list is empty and a matching opportunityId, yet it is classified
# unrecognized_inventory. Same result at base, so pre_existing yield residual.
confirmed_empty_reachable_by_real_shape = any(
    o["collection_status"] == "confirmed_empty" for o in observed.values())

H.emit({
    "probe": "real_sam_shapes",
    "status": "INFO",
    "observed": {
        "shapes": observed,
        "H4_matches_producer_receipt": h4_matches_receipt,
        "producer_receipt_status": real_receipt["status"],
        "confirmed_empty_reachable_by_any_real_derived_shape": confirmed_empty_reachable_by_real_shape,
        "wrapper_empty_same_as_base": wrapper["same_as_base"],
        "note": ("Every zero-file shape derived from real SAM bodies classifies as "
                 "unrecognized_inventory in both base and candidate. confirmed_empty "
                 "is reachable only by synthetic top-level/_embedded empty lists."),
    },
})
