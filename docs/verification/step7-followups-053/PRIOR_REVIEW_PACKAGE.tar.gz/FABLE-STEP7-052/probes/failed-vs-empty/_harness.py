"""Shared probe harness: network block, MockTransport install, base-module loader.

Every probe imports this first. It never touches the review clone; all
writes land under the probe directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
SOURCE_PROOF = PROBE_DIR.parents[1] / "extracted" / "source-proof"
INVENTORY_DIR = SOURCE_PROOF / "public-inventory-001"

if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

# Hard network block: any real socket connect is a probe failure.
_real_connect = socket.socket.connect


def _blocked_connect(self, *args, **kwargs):  # noqa: D401
    raise RuntimeError(f"NETWORK BLOCKED: attempted connect {args!r}")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]
socket.socket.connect_ex = _blocked_connect  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

_NATIVE_REQUEST = _http._request
_SLEEPS: list[float] = []
REAL_SLEEP = time.sleep  # probes that need real delay use this


def no_sleep(seconds):
    _SLEEPS.append(seconds)


# _http.time IS the global time module, so this records backoff sleeps
# instead of waiting. Probe streams must call REAL_SLEEP for real delay.
_http.time.sleep = no_sleep


def sleeps():
    return list(_SLEEPS)


def install_transport(handler):
    """Bind httpx.MockTransport(handler) as the ONLY client factory."""
    calls: list[dict] = []

    def wrapped(request):
        calls.append({"url": str(request.url), "method": request.method,
                      "headers": {k: v for k, v in request.headers.items()
                                  if k.lower() in {"accept", "user-agent"}}})
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(wrapped), follow_redirects=True)
    _http._request = _NATIVE_REQUEST
    return calls


def fresh_cache_dir(tag: str) -> Path:
    root = PROBE_DIR / "tmp"
    root.mkdir(exist_ok=True)
    path = Path(tempfile.mkdtemp(prefix=f"{tag}-", dir=root))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(path / "text")
    return path


def cache_listing(path: Path) -> dict:
    files = sorted(str(p.relative_to(path)) for p in path.rglob("*") if p.is_file())
    return {"files": files, "resources_json": [f for f in files if f.endswith(".resources.json")],
            "objects": [f for f in files if f.startswith("objects/")]}


def load_base_detail():
    """Import the BASE (2d522f0) sam_notice_detail as an isolated module."""
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", PROBE_DIR / "base" / "sam_notice_detail_base.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def summarize(result: dict) -> dict:
    capture = result.get("raw_capture")
    return {
        "collection_status": result.get("collection_status"),
        "resources_checked": result.get("resources_checked"),
        "attachments": result.get("attachments"),
        "attachment_inventory_count": result.get("attachment_inventory_count"),
        "errors": result.get("errors"),
        "from_cache": result.get("from_cache"),
        "stale_cache": result.get("stale_cache"),
        "has_raw_capture": capture is not None,
        "raw_complete": capture.get("complete") if isinstance(capture, dict) else None,
        "raw_http_status": capture.get("http_status") if isinstance(capture, dict) else None,
        "raw_bytes": capture.get("bytes") if isinstance(capture, dict) else None,
        "raw_sha256": capture.get("sha256") if isinstance(capture, dict) else None,
        "has_refresh_attempt": "refresh_attempt" in result,
    }


def emit(obj: dict) -> None:
    print(json.dumps(obj, indent=1, sort_keys=True, default=str))


def monotonic_now():
    return time.monotonic()
