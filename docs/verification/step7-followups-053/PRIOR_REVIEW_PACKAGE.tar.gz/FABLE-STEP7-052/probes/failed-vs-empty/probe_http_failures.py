"""FAILED retrieval matrix through the REAL fetch_notice_resources via
MockTransport. Every case must be lookup_failed (never confirmed_empty),
resources_checked False, attachments None, errors non-empty, NO
<id>.resources.json written, and a follow-up good fetch must go to network
(nothing failed was cached). Records raw_capture complete/http_status."""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

NID = "a" * 32
GOOD = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32,
                                    "mimeType": ".pdf", "accessLevel": "public"}]}).encode()
TWO_MIB = 2 * 1024 * 1024


class SlowStream(httpx.SyncByteStream):
    def __init__(self, chunks, delay, fail_after=None, exc=None):
        self.chunks, self.delay, self.fail_after, self.exc = chunks, delay, fail_after, exc

    def __iter__(self):
        for index, chunk in enumerate(self.chunks):
            if self.fail_after is not None and index == self.fail_after:
                raise self.exc
            if self.delay:
                H.REAL_SLEEP(self.delay)
            yield chunk


def resp(status, body=b"", ctype="application/hal+json", stream=None):
    if stream is not None:
        return httpx.Response(status, stream=stream, headers={"content-type": ctype})
    return httpx.Response(status, content=body, headers={"content-type": ctype})


def connect_error(request):
    raise httpx.ConnectError("connection refused", request=request)


def read_timeout_mid_stream(request):
    return resp(200, stream=SlowStream(
        [b'{"attachments": [', b"]}"], 0, fail_after=1,
        exc=httpx.ReadTimeout("read timed out mid-stream", request=request)))


def remote_disconnect_mid_stream(request):
    return resp(200, stream=SlowStream(
        [b'{"attachments": [', b"]}"], 0, fail_after=1,
        exc=httpx.RemoteProtocolError("peer closed connection", request=request)))


cases = {
    "200_non_json": lambda r: resp(200, b"not json at all", "text/plain"),
    "200_html_error_page": lambda r: resp(200, b"<html><body><h1>Service Unavailable</h1></body></html>", "text/html"),
    "200_empty_body": lambda r: resp(200, b""),
    "204_no_content": lambda r: resp(204, b""),
    "404_json": lambda r: resp(404, b'{"error":"not found"}'),
    "404_html": lambda r: resp(404, b"<html>Not Found</html>", "text/html"),
    "403_forbidden": lambda r: resp(403, b"access denied", "text/plain"),
    "429_rate_limited": lambda r: resp(429, b'{"message":"rate limit"}'),
    "500_server_error": lambda r: resp(500, b"boom", "text/plain"),
    "502_bad_gateway": lambda r: resp(502, b"", "text/plain"),
    "connection_error": connect_error,
    "read_timeout_mid_stream": read_timeout_mid_stream,
    "remote_disconnect_mid_stream": remote_disconnect_mid_stream,
    # A recognized-looking empty inventory but at 4xx: must be lookup_failed.
    "404_with_empty_attachments_body": lambda r: resp(404, b'{"attachments": []}'),
    "500_with_empty_attachments_body": lambda r: resp(500, b'{"attachments": []}'),
    "200_body_over_2MiB": lambda r: resp(200, b'{"attachments": [], "pad": "' + b"x" * TWO_MIB + b'"}'),
    "200_body_exactly_2MiB": lambda r: resp(200, (lambda head: head + b"x" * (TWO_MIB - len(head) - 2) + b'"}')(b'{"attachments": [], "pad": "')),
    "200_slow_chunked_exceeds_time_boundary": lambda r: resp(200, stream=SlowStream(
        [b'{"attachments": [', b" ", b" ", b" ", b"]}"], 0.15)),
}
# The slow case uses timeout_seconds=0.3 (clamped floor 0.25) so 5 chunks at
# 0.15s exceed the capture time boundary while bytes are still arriving.
timeouts = {"200_slow_chunked_exceeds_time_boundary": 0.3}
expected_status = {name: "lookup_failed" for name in cases}
expected_status["200_body_exactly_2MiB"] = "confirmed_empty"

observed = {}
failures = []
for name, handler in cases.items():
    cache = H.fresh_cache_dir("fail")
    H._SLEEPS.clear()
    calls = H.install_transport(handler)
    started = time.monotonic()
    try:
        result = H.detail.fetch_notice_resources(NID, timeout_seconds=timeouts.get(name, 15.0))
        raised = None
    except Exception as exc:  # noqa: BLE001
        result, raised = {}, f"{type(exc).__name__}: {exc}"
    elapsed = round(time.monotonic() - started, 3)
    summary = H.summarize(result)
    listing = H.cache_listing(cache)
    summary.update({
        "raised": raised, "elapsed_s": elapsed, "http_calls": len(calls),
        "sleeps": list(H._SLEEPS), "cache_written": f"{NID}.resources.json" in listing["resources_json"],
        "objects_written": len(listing["objects"]), "expected": expected_status[name],
    })
    # Follow-up: a good body must be fetched from network (failure not cached).
    calls2 = H.install_transport(lambda r: resp(200, GOOD))
    follow = H.detail.fetch_notice_resources(NID)
    summary["followup_status"] = follow.get("collection_status")
    summary["followup_from_cache"] = follow.get("from_cache")
    summary["followup_http_calls"] = len(calls2)
    observed[name] = summary
    exp = expected_status[name]
    if exp == "lookup_failed":
        ok = (raised is None and summary["collection_status"] == "lookup_failed"
              and summary["resources_checked"] is False and summary["attachments"] is None
              and bool(summary["errors"]) and summary["cache_written"] is False
              and len(calls) == 1 and summary["sleeps"] == []
              and follow.get("collection_status") == "inventory_captured"
              and follow.get("from_cache") is False and len(calls2) == 1)
        # raw_capture expectations: absent for connect error, complete False for
        # mid-stream/boundary failures, complete True for full bodies.
        if name == "connection_error":
            ok = ok and summary["has_raw_capture"] is False
        elif name in {"read_timeout_mid_stream", "remote_disconnect_mid_stream",
                      "200_body_over_2MiB", "200_slow_chunked_exceeds_time_boundary"}:
            ok = ok and summary["raw_complete"] is False and summary["raw_http_status"] == 200
        else:
            ok = ok and summary["raw_complete"] is True
    else:
        ok = (summary["collection_status"] == "confirmed_empty" and summary["raw_complete"] is True
              and summary["raw_bytes"] == TWO_MIB and summary["cache_written"] is True)
    if not ok:
        failures.append({"case": name, "summary": summary})

over = observed["200_body_over_2MiB"]
H.emit({
    "probe": "http_failures",
    "status": "PASS" if not failures else "FAIL",
    "observed": {
        "cases": observed,
        "failures": failures,
        "over_cap_retained_bytes": over.get("raw_bytes"),
        "note_objects_for_failures": {
            n: o["objects_written"] for n, o in observed.items()},
    },
})
