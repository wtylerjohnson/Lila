"""Failed refresh vs cached inventory: which caches does a FAILED lookup fall
back to, and is the fallback ever written back or presented as fresh?

Scenarios (all via the real fetch_notice_resources):
 A. valid aged cache (> 6h TTL, < 7d) + 404 refresh -> stale_inventory, cache file byte-identical
 B. valid aged confirmed_empty cache + 500 refresh -> stale_inventory with attachments []
 C. TAMPERED aged cache (attachments rewritten, fails _resource_capture_valid) + failed refresh
    -> does the tampered inventory come back under stale_inventory?
 D. legacy base-format cache (no raw_capture), FRESH (< 6h) -> must refetch (H8)
 E. legacy base-format cache + failed refresh -> stale_inventory (H8)
 F. cache with future received_at + failed refresh
 G. cache > 7 days old + failed refresh -> lookup_failed, no fallback
 H. valid FRESH cache -> served from cache, zero HTTP calls
 I. cache id mismatch (file for a, id says b) + failed refresh -> no fallback
Base comparison for C: base never validated, so it served the tampered cache as FRESH.
"""
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

NID = "a" * 32
GOOD = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32,
                                    "mimeType": ".pdf", "accessLevel": "public"}]}).encode()
EMPTY = b'{"attachments": []}'
base = H.load_base_detail()


def good(body=GOOD):
    return lambda r: httpx.Response(200, content=body, headers={"content-type": "application/hal+json"})


def fail(status=404, body=b"gone"):
    return lambda r: httpx.Response(status, content=body)


def seed(cache_dir, body=GOOD):
    H.install_transport(good(body))
    first = H.detail.fetch_notice_resources(NID)
    assert first["collection_status"] in {"inventory_captured", "confirmed_empty"}, first
    return cache_dir / f"{NID}.resources.json"


def age(cache_file, seconds, touch_raw=True):
    saved = json.loads(cache_file.read_text())
    stamp = (datetime.now(timezone.utc) - timedelta(seconds=seconds)).isoformat()
    saved["retrieved_at"] = stamp
    if touch_raw and isinstance(saved.get("raw_capture"), dict):
        saved["raw_capture"]["received_at"] = stamp
    cache_file.write_text(json.dumps(saved))
    return saved


SIX_H_PLUS = 6 * 3600 + 60
observed = {}
failures = []


def check(name, cond, detail):
    observed[name] = detail
    if not cond:
        failures.append(name)


# A
d = H.fresh_cache_dir("stale-A"); f = seed(d); age(f, SIX_H_PLUS); before = f.read_bytes()
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls); s["cache_unchanged"] = f.read_bytes() == before
s["refresh_attempt_status"] = (r.get("refresh_attempt") or {}).get("collection_status")
s["refresh_attempt_http"] = ((r.get("refresh_attempt") or {}).get("raw_capture") or {}).get("http_status")
check("A_valid_aged_cache_failed_refresh", s["collection_status"] == "stale_inventory" and s["stale_cache"] is True
      and s["cache_unchanged"] and s["refresh_attempt_status"] == "lookup_failed" and s["refresh_attempt_http"] == 404
      and any("stale inventory" in e for e in s["errors"]), s)

# B
d = H.fresh_cache_dir("stale-B"); f = seed(d, EMPTY); age(f, SIX_H_PLUS)
calls = H.install_transport(fail(500, b"boom"))
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("B_aged_confirmed_empty_failed_refresh", s["collection_status"] == "stale_inventory" and s["attachments"] == []
      and s["stale_cache"] is True, s)

# C: tampered aged cache. Candidate: _resource_capture_valid False -> refetch -> fails -> stale fallback?
d = H.fresh_cache_dir("stale-C"); f = seed(d); saved = age(f, SIX_H_PLUS)
saved["attachments"] = [{"name": "INVENTED Requirements.pdf", "resource_id": "f" * 32,
                         "source_url": "https://sam.gov/api/prod/opps/v3/opportunities/resources/files/" + "f" * 32 + "/download",
                         "type": ".pdf", "access_level": "public", "access_status": "public",
                         "export_controlled": "0", "explicit_access": "0", "size": 1}]
f.write_text(json.dumps(saved))
valid_before = H.detail._resource_capture_valid(json.loads(f.read_text()))
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls); s["capture_valid_on_tampered"] = valid_before
s["returned_attachment_names"] = [a.get("name") for a in (r.get("attachments") or [])]
tampered_served = s["collection_status"] == "stale_inventory" and "INVENTED Requirements.pdf" in s["returned_attachment_names"]
s["tampered_inventory_served_as_stale"] = tampered_served
# Same tampered cache, FRESH (not aged): candidate must refetch (valid False) and, on failure, fall back?
d2 = H.fresh_cache_dir("stale-C2"); f2 = seed(d2); saved2 = json.loads(f2.read_text())
saved2["attachments"] = saved["attachments"]; f2.write_text(json.dumps(saved2))
calls2 = H.install_transport(fail())
r2 = H.detail.fetch_notice_resources(NID)
s["fresh_tampered"] = {**H.summarize(r2), "http_calls": len(calls2),
                       "names": [a.get("name") for a in (r2.get("attachments") or [])]}
# Base comparison on the same FRESH tampered cache: base has no validation.
import os
os.environ["LILA_NOTICE_CACHE_DIR"] = str(d2)
calls3 = H.install_transport(fail())
rb = base.fetch_notice_resources(NID)
s["base_fresh_tampered"] = {"from_cache": rb.get("from_cache"), "stale_cache": rb.get("stale_cache"),
                            "names": [a.get("name") for a in (rb.get("attachments") or [])], "http_calls": len(calls3)}
check("C_tampered_cache_failed_refresh", True, s)  # measured, judged in findings

# D: legacy base-format cache, fresh
d = H.fresh_cache_dir("stale-D")
legacy = {"id": NID, "attachments": json.loads(GOOD.decode())["attachments"] and
          [{"name": "SOW.pdf", "type": ".pdf", "resource_id": "b" * 32,
            "source_url": "https://sam.gov/api/prod/opps/v3/opportunities/resources/files/" + "b" * 32 + "/download",
            "size": None, "access_level": "public", "access_status": None, "export_controlled": None, "explicit_access": None}],
          "retrieved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
          "resources_checked": True, "resources_schema": "recognized_v1",
          "attachment_inventory_count": 1, "errors": []}
legacy["attachment_inventory_hash"] = H.detail._manifest_hash(legacy["attachments"])
(d / f"{NID}.resources.json").write_text(json.dumps(legacy))
calls = H.install_transport(good())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("D_legacy_fresh_cache_refetched", len(calls) == 1 and s["from_cache"] is False
      and s["collection_status"] == "inventory_captured" and s["has_raw_capture"], s)

# E: legacy + failed refresh
d = H.fresh_cache_dir("stale-E"); (d / f"{NID}.resources.json").write_text(json.dumps(legacy))
calls = H.install_transport(fail(503, b"maintenance"))
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("E_legacy_cache_failed_refresh_stale", s["collection_status"] == "stale_inventory" and s["stale_cache"] is True
      and s["has_raw_capture"] is False and s["has_refresh_attempt"], s)

# F: future received_at + failed refresh
d = H.fresh_cache_dir("stale-F"); f = seed(d); age(f, -3600)
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("F_future_clock_cache_failed_refresh", s["collection_status"] == "lookup_failed" and s["stale_cache"] is False
      and len(calls) == 1, s)

# G: > 7 days
d = H.fresh_cache_dir("stale-G"); f = seed(d); age(f, 8 * 86400)
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("G_over_7d_cache_failed_refresh_no_fallback", s["collection_status"] == "lookup_failed" and s["attachments"] is None, s)

# H: fresh valid cache
d = H.fresh_cache_dir("stale-H"); f = seed(d)
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("H_fresh_valid_cache_no_network", len(calls) == 0 and s["from_cache"] is True
      and s["collection_status"] == "inventory_captured" and s["stale_cache"] is False, s)

# I: id mismatch inside cache file
d = H.fresh_cache_dir("stale-I"); f = seed(d); saved = age(f, SIX_H_PLUS); saved["id"] = "b" * 32; f.write_text(json.dumps(saved))
calls = H.install_transport(fail())
r = H.detail.fetch_notice_resources(NID)
s = H.summarize(r); s["http_calls"] = len(calls)
check("I_cache_id_mismatch_failed_refresh_no_fallback", s["collection_status"] == "lookup_failed" and s["attachments"] is None, s)

# J: stale-inventory returned dict is NOT re-written to disk (no laundering)
d = H.fresh_cache_dir("stale-J"); f = seed(d); age(f, SIX_H_PLUS); before = f.read_bytes(); listing_before = H.cache_listing(d)
H.install_transport(fail(429, b"slow down"))
r = H.detail.fetch_notice_resources(NID)
listing_after = H.cache_listing(d)
s = {"cache_unchanged": f.read_bytes() == before, "new_objects": sorted(set(listing_after["objects"]) - set(listing_before["objects"])),
     "status": r.get("collection_status")}
check("J_stale_fallback_not_rewritten", s["cache_unchanged"] and s["status"] == "stale_inventory", s)

H.emit({
    "probe": "not_cached_stale",
    "status": "FAIL" if failures else ("INFO" if observed["C_tampered_cache_failed_refresh"]["tampered_inventory_served_as_stale"] else "PASS"),
    "observed": {"scenarios": observed, "failures": failures},
})
