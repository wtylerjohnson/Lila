"""EMPTY vs NONEMPTY correctness on real bodies: SAM marks withdrawn files
with deletedFlag "1" (and sometimes deletedDate). The candidate's
_attachments/_attachment_inventory ignore deletedFlag/fileExists, so
withdrawn files count as live public attachments. Measure across the 21
real bodies and check whether run_searches file selection (attachment_priority
+ supported extension + top 3) would pick a withdrawn file. Base comparison."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import os  # noqa: E402

from tools.api.sam_attachment_text import attachment_priority  # noqa: E402

base = H.load_base_detail()
supported = {".pdf", ".docx", ".txt", ".csv", ".md"}

per_notice = {}
totals = {"notices": 0, "rows": 0, "deleted_rows": 0, "notices_with_deleted": 0,
          "notices_all_deleted": 0, "deleted_in_top3_selection": 0}
for path in sorted(H.INVENTORY_DIR.glob("*.body")):
    nid = path.stem
    payload = json.loads(path.read_bytes())
    rows = []
    for wrapper in ((payload.get("_embedded") or {}).get("opportunityAttachmentList") or []):
        for att in wrapper.get("attachments") or []:
            rows.append(att)
    if not rows:
        continue
    totals["notices"] += 1
    totals["rows"] += len(rows)
    deleted = [a for a in rows if str(a.get("deletedFlag")) == "1"]
    deleted_ids = {a.get("resourceId") for a in deleted}
    totals["deleted_rows"] += len(deleted)
    items, recognized = H.detail._attachment_inventory(payload, nid)
    base_items, _ = base._attachment_inventory(payload)
    counted_deleted = [i for i in (items or []) if i.get("resource_id") in deleted_ids]
    ordered = sorted(items or [], key=attachment_priority)
    selected = [i for i in ordered if os.path.splitext(str(i.get("name") or ""))[1].lower() in supported][:3]
    selected_deleted = [i["name"] for i in selected if i.get("resource_id") in deleted_ids]
    if deleted:
        totals["notices_with_deleted"] += 1
    if deleted and len(deleted) == len(rows):
        totals["notices_all_deleted"] += 1
    if selected_deleted:
        totals["deleted_in_top3_selection"] += 1
    per_notice[nid] = {
        "rows": len(rows), "deleted_rows": len(deleted),
        "deleted_names": [a.get("name") for a in deleted],
        "deleted_dates": [a.get("deletedDate") for a in deleted],
        "candidate_count": len(items or []), "base_count": len(base_items or []),
        "candidate_counts_deleted_as_live": len(counted_deleted),
        "top3_selected": [i["name"] for i in selected],
        "top3_selected_deleted": selected_deleted,
    }

H.emit({
    "probe": "deleted_rows_census",
    "status": "FAIL" if totals["deleted_rows"] else "PASS",
    "observed": {
        "totals": totals,
        "per_notice": {n: p for n, p in per_notice.items() if p["deleted_rows"]},
        "same_as_base_everywhere": all(p["candidate_count"] == p["base_count"] for p in per_notice.values()),
        "note": ("deletedFlag=1 rows are withdrawn from the public notice; counting them "
                 "inflates attachment_inventory_count and can route the 3-file download "
                 "budget to a superseded document."),
    },
})
