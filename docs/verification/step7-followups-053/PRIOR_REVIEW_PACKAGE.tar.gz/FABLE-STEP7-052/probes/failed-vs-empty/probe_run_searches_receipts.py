"""run_searches._enrich_sam_public_attachments receipt mapping per inventory
state, through the REAL fetch_notice_resources (MockTransport per notice).

Candidates (one notice each, different bodies):
  n1 inventory_captured, only .xlsx  -> INVENTORY_CHECKED then TEXT_UNAVAILABLE
  n2 confirmed_empty                 -> VERIFIED_EMPTY_INVENTORY
  n3 unrecognized (real H4 body)     -> INVENTORY_UNAVAILABLE + error text
  n4 404                             -> INVENTORY_UNAVAILABLE + error text
  n5 identity_mismatch body          -> ? (IDENTITY_MISMATCH or INVENTORY_UNAVAILABLE)
  n6 stale (aged valid cache + 503)  -> STALE_INVENTORY
  n7 connection error                -> INVENTORY_UNAVAILABLE (no raw_capture)
  n8 non-hex source_id               -> FAILED (ValueError from fetch)
  n9 inventory_captured .pdf whose download fails -> TEXT_UNAVAILABLE + file lookup_failed
"""
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

cache = H.fresh_cache_dir("rs")
sam_quota.calls_today = lambda: 0

ids = {f"n{i}": f"{i:x}" * 32 for i in range(1, 10)}  # hex digits only
ids["n8"] = "NOT-A-PUBLIC-ID"
H4 = (H.INVENTORY_DIR / "00c39d451a234f5eb95f6ca717fb9bf6.body").read_bytes()


def att(name, rid):
    return {"name": name, "resourceId": rid, "mimeType": os.path.splitext(name)[1],
            "accessLevel": "public", "accessStatus": "public", "exportControlled": "0", "explicitAccess": "0"}


bodies = {
    ids["n1"]: (200, json.dumps({"attachments": [att("Pricing.xlsx", "1" * 32)]}).encode()),
    ids["n2"]: (200, b'{"attachments": []}'),
    ids["n3"]: (200, H4),
    ids["n4"]: (404, b'{"error":"not found"}'),
    ids["n5"]: (200, json.dumps({"opportunityId": "f" * 32, "attachments": [att("SOW.pdf", "2" * 32)]}).encode()),
    ids["n6"]: (503, b"maintenance"),
    ids["n9"]: (200, json.dumps({"attachments": [att("SOW.pdf", "3" * 32)]}).encode()),
}


def handler(request):
    url = str(request.url)
    for nid, (status, body) in bodies.items():
        if f"/opportunities/{nid}/resources" in url:
            return httpx.Response(status, content=body, headers={"content-type": "application/hal+json"})
    if f"/opportunities/{ids['n7']}/resources" in url:
        raise httpx.ConnectError("connection refused", request=request)
    raise AssertionError(f"unexpected url {url}")


# Seed n6 with a valid inventory then age it past the 6h TTL so the 503 refresh falls back to stale.
H.install_transport(lambda r: httpx.Response(200, content=json.dumps({"attachments": [att("Old SOW.pdf", "6" * 32)]}).encode()))
seeded = H.detail.fetch_notice_resources(ids["n6"])
assert seeded["collection_status"] == "inventory_captured"
f6 = cache / f"{ids['n6']}.resources.json"
saved = json.loads(f6.read_text())
stamp = (datetime.now(timezone.utc) - timedelta(hours=7)).isoformat()
saved["retrieved_at"] = stamp; saved["raw_capture"]["received_at"] = stamp
f6.write_text(json.dumps(saved))

calls = H.install_transport(handler)


def failing_download(*a, **k):
    raise httpx.ConnectError("download refused", request=httpx.Request("GET", "https://sam.gov/x"))


sat._download_bytes = failing_download

candidates = [RawOpportunity(source="sam.gov", source_id=ids[k], title=f"Notice {k}", agency="NASA",
                             raw_payload={"type": "Solicitation"}) for k in sorted(ids)]


class Source:
    last_attachment_census = {"selected": len(candidates)}

    def attachment_candidates(self, *a, **k):
        return candidates


os.environ["LILA_SAM_ATTACHMENT_CALL_CAP"] = "2"
taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term="packet capture")])
rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=12)

receipts = stats["attachment_record_receipts"]
expected = {
    "n1": "TEXT_UNAVAILABLE", "n2": "VERIFIED_EMPTY_INVENTORY", "n3": "INVENTORY_UNAVAILABLE",
    "n4": "INVENTORY_UNAVAILABLE", "n5": None, "n6": "STALE_INVENTORY", "n7": "INVENTORY_UNAVAILABLE",
    "n8": "FAILED", "n9": "TEXT_UNAVAILABLE",
}
observed = {}
failures = []
for k in sorted(ids):
    rec = receipts[str(ids[k])]
    inv = rec.get("inventory_receipt") or {}
    o = {
        "status": rec.get("status"), "errors": rec.get("errors"),
        "inventory_collection_status": inv.get("collection_status"),
        "inventory_raw_http": (inv.get("raw_capture") or {}).get("http_status"),
        "inventory_raw_complete": (inv.get("raw_capture") or {}).get("complete"),
        "has_refresh_attempt": inv.get("refresh_attempt") is not None,
        "inventory_count": rec.get("inventory_count"),
        "files": [{k2: fr.get(k2) for k2 in ("name", "status", "reason")} for fr in rec.get("files") or []],
        "expected": expected[k],
    }
    observed[k] = o
    if expected[k] is not None and o["status"] != expected[k]:
        failures.append(k)
    if expected[k] in {"INVENTORY_UNAVAILABLE", "STALE_INVENTORY", "FAILED"} and not o["errors"]:
        failures.append(f"{k}:no_errors")

n5 = observed["n5"]
identity_state_reachable = n5["status"] == "IDENTITY_MISMATCH"
sweep_errors = stats["attachment_errors"]

H.emit({
    "probe": "run_searches_receipts",
    "status": "FAIL" if failures else "INFO",
    "observed": {
        "receipts": observed,
        "failures": failures,
        "http_calls": len(calls),
        "n5_identity_mismatch_receipt_status": n5["status"],
        "IDENTITY_MISMATCH_receipt_state_reachable_via_fetch_notice_resources": identity_state_reachable,
        "attachment_errors_head": sweep_errors,
        "rows_returned": len(rows),
        "stats_keys": sorted(stats.keys()),
        "note": ("fetch_notice_resources always returns id == requested notice_id, so the "
                 "run_searches IDENTITY_MISMATCH branch cannot fire from it; body identity "
                 "conflicts surface as INVENTORY_UNAVAILABLE with collection_status identity_mismatch."),
    },
})
