"""Positive control: every recognized EMPTY container must be confirmed_empty,
cached, with a complete 200 raw_capture. Also hostile near-misses that must NOT
be confirmed_empty (non-list containers, null rows, scalar bodies)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _harness as H  # noqa: E402

import httpx  # noqa: E402

NID = "a" * 32
KEYS = ("resources", "attachments", "opportunityResources",
        "opportunityAttachmentList", "items", "results")

cases = {}
for key in KEYS:
    cases[f"top.{key}=[]"] = json.dumps({key: []}).encode()
    cases[f"_embedded.{key}=[]"] = json.dumps({"_embedded": {key: []}}).encode()
cases["body=[]"] = b"[]"
cases["_embedded=[]"] = b'{"_embedded": []}'
cases["_links+attachments=[]"] = json.dumps(
    {"_links": {"self": {"href": "x"}}, "attachments": []}).encode()
cases["two_empty_keys"] = json.dumps({"resources": [], "items": []}).encode()
cases["empty+matching_opportunityId"] = json.dumps(
    {"opportunityId": NID, "attachments": []}).encode()

# Hostile near-misses: must not be confirmed_empty.
hostile = {
    "attachments={}": (b'{"attachments": {}}', "unrecognized_inventory"),
    "attachments=[null]": (b'{"attachments": [null]}', "unrecognized_inventory"),
    "attachments=[{}]": (b'{"attachments": [{}]}', "unrecognized_inventory"),
    "attachments=[[]]": (b'{"attachments": [[]]}', "unrecognized_inventory"),
    "attachments=null": (b'{"attachments": null}', "unrecognized_inventory"),
    "body=null": (b"null", "unrecognized_inventory"),
    "body=string": (b'"no files"', "unrecognized_inventory"),
    "body=number": (b"0", "unrecognized_inventory"),
    "body=true": (b"true", "unrecognized_inventory"),
    "body={}": (b"{}", "unrecognized_inventory"),
    "_embedded={}": (b'{"_embedded": {}}', "unrecognized_inventory"),
    "_links_only(H4)": (json.dumps({"_links": {"self": {"href": "x"}}}).encode(),
                        "unrecognized_inventory"),
    "empty+other_opportunityId": (json.dumps(
        {"opportunityId": "b" * 32, "attachments": []}).encode(), "identity_mismatch"),
}

observed = {}
failures = []
for name, body in cases.items():
    cache = H.fresh_cache_dir("empty")
    calls = H.install_transport(lambda request, body=body: httpx.Response(
        200, content=body, headers={"content-type": "application/hal+json"}))
    result = H.detail.fetch_notice_resources(NID)
    summary = H.summarize(result)
    listing = H.cache_listing(cache)
    second = H.detail.fetch_notice_resources(NID)
    summary["second_call_from_cache"] = second.get("from_cache")
    summary["second_call_status"] = second.get("collection_status")
    summary["http_calls"] = len(calls)
    summary["cache_written"] = f"{NID}.resources.json" in listing["resources_json"]
    summary["objects_written"] = len(listing["objects"])
    observed[name] = summary
    ok = (summary["collection_status"] == "confirmed_empty"
          and summary["resources_checked"] is True
          and summary["attachments"] == []
          and summary["attachment_inventory_count"] == 0
          and summary["raw_complete"] is True
          and summary["raw_http_status"] == 200
          and summary["cache_written"] is True
          and second.get("from_cache") is True
          and len(calls) == 1)
    if not ok:
        failures.append({"case": name, "summary": summary})

hostile_observed = {}
for name, (body, expected) in hostile.items():
    cache = H.fresh_cache_dir("hostile")
    calls = H.install_transport(lambda request, body=body: httpx.Response(
        200, content=body, headers={"content-type": "application/hal+json"}))
    result = H.detail.fetch_notice_resources(NID)
    summary = H.summarize(result)
    listing = H.cache_listing(cache)
    summary["expected"] = expected
    summary["cache_written"] = f"{NID}.resources.json" in listing["resources_json"]
    summary["objects_written"] = len(listing["objects"])
    hostile_observed[name] = summary
    ok = (summary["collection_status"] == expected
          and summary["resources_checked"] is False
          and summary["attachments"] is None
          and summary["cache_written"] is False
          and summary["errors"])
    if not ok:
        failures.append({"case": name, "summary": summary})

H.emit({
    "probe": "empty_containers",
    "status": "PASS" if not failures else "FAIL",
    "observed": {
        "recognized_empty_cases": observed,
        "hostile_cases": hostile_observed,
        "failures": failures,
        "sleeps": H.sleeps(),
    },
})
