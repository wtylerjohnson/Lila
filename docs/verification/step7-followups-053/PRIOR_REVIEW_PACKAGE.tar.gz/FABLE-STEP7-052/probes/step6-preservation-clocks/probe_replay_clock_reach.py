"""Replay driver clock reach: does patch.object(sam_attachment_text, 'datetime',
ReplayClock) reach every datetime.now in the module (static AST scan + dynamic
run), and are the replayed request_started_at values the ORIGINAL observed ones
(as the driver docstring claims) or synthesized from the previous clock reading?

Read-only inputs: the candidate replay driver and the extracted producer/source
proof directories. One JSON object; status FAIL if a claim breaks.
"""
from __future__ import annotations

import ast
import json
import os
import shutil
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import CLONE, aware, block_network, fresh_dir, utc  # noqa: E402

block_network()
TEXT_DIR = fresh_dir("replay_reach_text")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted")

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

checks = []


def check(name, ok, **fields):
    checks.append({"name": name, "ok": bool(ok), **fields})


# ---- e1 static scan: datetime.now call sites and any function-local datetime import
def scan(path: Path):
    tree = ast.parse(path.read_text())
    now_sites, local_imports, other_clock = [], [], []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "now":
            base = node.func.value
            now_sites.append({"line": node.lineno, "receiver": ast.unparse(base)})
        if isinstance(node, (ast.Import, ast.ImportFrom)) and node.col_offset > 0:
            names = [a.name for a in node.names]
            mod = getattr(node, "module", None) or ",".join(names)
            if "datetime" in mod or "datetime" in names or mod == "time":
                local_imports.append({"line": node.lineno, "import": ast.unparse(node)})
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in (
                "utcnow", "time", "fromtimestamp", "utcfromtimestamp"):
            other_clock.append({"line": node.lineno, "call": ast.unparse(node.func)})
    return {"now_sites": now_sites, "local_datetime_imports": local_imports, "other_clock_calls": other_clock}


static = {name: scan(CLONE / name) for name in (
    "tools/api/sam_attachment_text.py", "tools/api/sam_capture.py", "tools/artifacts.py")}
sat_scan = static["tools/api/sam_attachment_text.py"]
check("e1_all_sat_now_sites_use_module_datetime",
      sat_scan["now_sites"] and all(s["receiver"] == "datetime" for s in sat_scan["now_sites"])
      and not sat_scan["local_datetime_imports"],
      now_sites=sat_scan["now_sites"], local_imports=sat_scan["local_datetime_imports"])
check("e1_helpers_have_no_wall_clock", not static["tools/api/sam_capture.py"]["now_sites"]
      and not static["tools/artifacts.py"]["now_sites"]
      and not static["tools/api/sam_capture.py"]["other_clock_calls"]
      and not static["tools/artifacts.py"]["other_clock_calls"], static=static)

# ---- e2 dynamic: the driver's ReplayClock pattern, exactly ---------------------
INV_DONE = utc(2026, 9, 1, 13, 54, 1)
FILE_CLOCKS = {"9" * 32: utc(2026, 9, 1, 13, 55, 14),    # 'Q and A' file: acquired FIRST originally
               "1" * 32: utc(2026, 9, 1, 13, 55, 40)}    # 'SOW' file: acquired LATER originally
replay_clock = {"now": INV_DONE}
loads = []


class ReplayClock(datetime):
    @classmethod
    def now(cls, tz=None):
        return replay_clock["now"].astimezone(tz) if tz else replay_clock["now"].replace(tzinfo=None)


def saved_bytes(rid, **kwargs):
    replay_clock["now"] = FILE_CLOCKS[rid]
    loads.append(rid)
    return f"Saved bytes for {rid}: packet capture".encode()


def public(rid, name):
    return {"resource_id": rid, "name": name, "type": None, "source_url": None, "size": 0,
            "access_level": "public", "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


wall_before = datetime.now().astimezone()
with patch.object(sat, "datetime", ReplayClock), patch.object(sat, "_download_bytes", saved_bytes):
    single = sat.extract_public_attachment_text(public("9" * 32, "Q and A.pdf".replace(".pdf", ".txt")))
stamps = {k: single.get(k) for k in ("request_started_at", "retrieved_at")}
check("e2_patch_reaches_request_started_and_retrieved",
      aware(single["request_started_at"]) == INV_DONE and aware(single["retrieved_at"]) == FILE_CLOCKS["9" * 32],
      stamps=stamps)
check("e2_no_wall_clock_leaked", all(aware(v) < wall_before - timedelta(days=1) for v in stamps.values()))

# cache-hit path: the validator's now() is the patched one. Freeze the clock BEFORE the cached
# retrieved_at and the validator must call the cache 'future' and refuse it.
replay_clock["now"] = INV_DONE
with patch.object(sat, "datetime", ReplayClock), patch.object(sat, "_download_bytes",
                                                             lambda *a, **k: (_ for _ in ()).throw(RuntimeError("denied"))):
    warm = sat.extract_public_attachment_text(public("9" * 32, "Q and A.txt"))
check("e2b_validator_now_is_patched_warm_cache_refused_under_earlier_clock",
      warm["from_cache"] is False and warm["collection_status"] == "lookup_failed",
      from_cache=warm["from_cache"], status=warm["collection_status"],
      note="proves _text_capture_valid reads the patched clock; a replay against a warm text cache refuses it")

# ---- e3 driver pattern through run_searches: priority order != acquisition order
shutil.rmtree(TEXT_DIR, ignore_errors=True)
TEXT_DIR.mkdir()
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

NOTICE = "a" * 32
files = [public("1" * 32, "B01- SOW Revenue.txt"), public("9" * 32, "Q and A.txt")]
inventory = {"id": NOTICE, "attachments": files, "attachment_inventory_hash": detail._manifest_hash(files),
             "resources_checked": True, "retrieved_at": INV_DONE.isoformat(),
             "collection_status": "inventory_captured", "authority": "discovery_only"}
candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="HHS",
                           raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


replay_clock["now"] = INV_DONE
loads.clear()
with patch.object(sat, "datetime", ReplayClock), patch.object(sat, "_download_bytes", saved_bytes), \
        patch.object(detail, "fetch_notice_resources", lambda *a, **k: inventory), \
        patch("tools.api.sam_quota.calls_today", return_value=0):
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), CapabilityTaxonomy(
        client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term="packet capture")]),
        None, limit=8)
receipts = stats["attachment_record_receipts"][NOTICE]["files"]
order = [r["resource_id"] for r in receipts]
per_file = {r["resource_id"]: {k: r.get(k) for k in ("name", "request_started_at", "retrieved_at")} for r in receipts}
inverted = [rid for rid, r in per_file.items()
            if r["request_started_at"] and r["retrieved_at"] and aware(r["request_started_at"]) > aware(r["retrieved_at"])]
check("e3_replay_request_started_at_never_after_retrieved_at", not inverted,
      processing_order=order, per_file=per_file, inverted=inverted,
      note="driver synthesizes request_started_at from the previous clock reading; priority order beat acquisition order")
evidence = rows[0]["raw_payload"]["attachment_evidence"] if rows else []
check("e3b_evidence_retrieved_at_are_original_file_clocks",
      {e["resource_id"]: aware(e["retrieved_at"]) for e in evidence} == {rid: FILE_CLOCKS[rid] for rid in loads})

# ---- e4 producer replay RECEIPT vs source-proof RESULTS.json (original observed) ----
results = json.loads((REVIEW / "source-proof/ihs-files-001/RESULTS.json").read_text())
original = {r["attachment"]["resource_id"]: {"request_started_at": r.get("started_at") or r.get("request_started_at"),
                                             "retrieved_at": r.get("retrieved_at")} for r in results}
receipt = json.loads((REVIEW / "producer-proof/native-ihs-replay-002/RECEIPT.json").read_text())
inv_receipt = receipt["attachment_record_receipts"]["0caab6e53d8b47d7850692b7684610bf"]
replayed = {r["resource_id"]: {"status": r.get("status"), "request_started_at": r.get("request_started_at"),
                               "retrieved_at": r.get("retrieved_at")} for r in inv_receipt["files"]}
comparison = {}
for rid, orig in original.items():
    rep = replayed.get(rid, {})
    comparison[rid] = {"original": orig, "replayed": rep,
                       "retrieved_at_matches": rep.get("retrieved_at") == orig["retrieved_at"],
                       "request_started_at_matches": rep.get("request_started_at") == orig["request_started_at"]}
unfetched = {rid: r for rid, r in replayed.items() if rid not in original}
check("e4_producer_replay_retrieved_at_equals_original",
      all(c["retrieved_at_matches"] for c in comparison.values()), comparison=comparison)
check("e4b_producer_replay_request_started_at_equals_original",
      all(c["request_started_at_matches"] for c in comparison.values()),
      comparison=comparison, unfetched_files_with_synthesized_clock=unfetched,
      docstring_claim="This driver freezes file acquisition clocks at their original observed values")
check("e4c_producer_replay_request_before_retrieved_holds_for_this_data",
      all(aware(r["request_started_at"]) <= aware(r["retrieved_at"])
          for r in replayed.values() if r.get("retrieved_at")))

failures = [c["name"] for c in checks if not c["ok"]]
out = {"probe": "replay_clock_reach", "checks": checks, "failures": failures,
       "status": "PASS" if not failures else "FAIL",
       "observed": ("patch reaches all three datetime.now sites in sam_attachment_text (no local imports; "
                    "helpers carry no clock); replay retrieved_at values are original; "
                    f"request_started_at is synthesized from the previous reading: inverted in synthetic ordering={inverted}, "
                    f"producer RECEIPT request_started_at differs from RESULTS.json for "
                    f"{[rid for rid, c in comparison.items() if not c['request_started_at_matches']]}")}
print(json.dumps(out, indent=2, default=str))
shutil.rmtree(TEXT_DIR, ignore_errors=True)
sys.exit(0 if not failures else 1)
