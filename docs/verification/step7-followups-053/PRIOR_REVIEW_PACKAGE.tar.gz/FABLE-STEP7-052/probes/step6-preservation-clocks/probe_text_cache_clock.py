"""Text-cache clocks: a cache HIT must return the ORIGINAL retrieved_at (not now),
request_started_at <= retrieved_at, run_searches evidence must carry the original
clock, and future / naive cache clocks must be rejected. Base (2d522f0) is run on
the same hostile caches to classify.

One JSON object. status PASS = every candidate claim held; FAIL otherwise.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import Clock, aware, block_network, fresh_dir, load_base, utc  # noqa: E402

block_network()
CAND_DIR = fresh_dir("text_cache_clock_cand")
BASE_CACHE = fresh_dir("text_cache_clock_base")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(CAND_DIR)

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

RID = "b" * 32
NOTICE = "a" * 32
ATTACHMENT = {"resource_id": RID, "name": "SOW.txt", "type": None, "source_url": None,
              "size": 0, "access_level": "public", "access_status": "public",
              "export_controlled": "0", "explicit_access": "0"}
PAYLOAD = "Buyer requires packet capture. Café Δ.".encode("utf-8")
T1 = utc(2026, 9, 1, 10, 0, 0)
T2 = utc(2026, 9, 4, 10, 0, 0)
CACHE = CAND_DIR / f"{RID}.json"

checks = []


def check(name, ok, **detail_fields):
    checks.append({"name": name, "ok": bool(ok), **detail_fields})


def denied(*a, **k):
    raise RuntimeError("source unavailable (probe denies download)")


def rewrite(mutator):
    saved = json.loads(CACHE.read_text())
    mutator(saved)
    CACHE.write_text(json.dumps(saved))
    return saved


def run_enrichment(clock_value, download):
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    inventory = detail._manifest_hash([ATTACHMENT])
    resources = {"id": NOTICE, "resources_checked": True, "attachments": [dict(ATTACHMENT)],
                 "attachment_inventory_hash": inventory, "retrieved_at": T1.isoformat(),
                 "collection_status": "inventory_captured"}
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    clock = Clock(clock_value, step_seconds=1)
    with patch.object(sat, "datetime", clock.make()), \
            patch.object(sat, "_download_bytes", download), \
            patch.object(detail, "fetch_notice_resources", lambda *a, **k: json.loads(json.dumps(resources))), \
            patch("tools.api.sam_quota.calls_today", return_value=0):
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(),
            CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                               core=[TaxonomyTerm(term="packet capture")]), None, limit=8)
    return rows, stats


# ---- c1 fresh collection at T1 with a 1 s auto-advancing clock -----------------
clock1 = Clock(T1, step_seconds=1)
with patch.object(sat, "datetime", clock1.make()), \
        patch.object(sat, "_download_bytes", lambda rid, **k: PAYLOAD):
    first = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c1_fresh_captured", first["collection_status"] == "captured_discovery_only"
      and first["from_cache"] is False, status=first["collection_status"])
check("c1_request_started_before_retrieved",
      aware(first["request_started_at"]) < aware(first["retrieved_at"])
      and aware(first["request_started_at"]) == T1,
      request_started_at=first["request_started_at"], retrieved_at=first["retrieved_at"])
check("c1_clocks_aware", aware(first["retrieved_at"]).utcoffset() is not None
      and aware(first["request_started_at"]).utcoffset() is not None)
check("c1_bytes_retained", read_retained(CAND_DIR, first["raw_capture"]) == PAYLOAD)
original_cache = CACHE.read_text()

# ---- c2 cache HIT three days later, download denied ---------------------------
clock2 = Clock(T2, step_seconds=1)
with patch.object(sat, "datetime", clock2.make()), patch.object(sat, "_download_bytes", denied):
    hit = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c2_hit_from_cache", hit["from_cache"] is True and hit["text"] == first["text"],
      from_cache=hit["from_cache"])
check("c2_hit_keeps_original_retrieved_at", hit["retrieved_at"] == first["retrieved_at"]
      and aware(hit["retrieved_at"]) < T2, hit_retrieved_at=hit["retrieved_at"], now=T2.isoformat())
check("c2_hit_keeps_original_request_started_at",
      hit["request_started_at"] == first["request_started_at"])
check("c2_validator_consulted_now", clock2.calls >= 1, validator_now_calls=clock2.calls)

# ---- c3 run_searches evidence carries the ORIGINAL clock on a cache hit --------
rows, stats = run_enrichment(T2, denied)
receipt = stats["attachment_record_receipts"][NOTICE]
evidence = rows[0]["raw_payload"]["attachment_evidence"] if rows else []
file_receipt = receipt["files"][0] if receipt.get("files") else {}
check("c3_evidence_retrieved_at_is_original",
      len(evidence) == 1 and evidence[0]["retrieved_at"] == first["retrieved_at"],
      evidence_retrieved_at=[e.get("retrieved_at") for e in evidence], receipt_status=receipt.get("status"))
check("c3_file_receipt_marks_cache_hit", file_receipt.get("from_cache") is True
      and file_receipt.get("status") == "captured_discovery_only"
      and file_receipt.get("retrieved_at") == first["retrieved_at"]
      and file_receipt.get("request_started_at") == first["request_started_at"],
      file_receipt={k: file_receipt.get(k) for k in ("from_cache", "status", "retrieved_at", "request_started_at")})
collection = rows[0]["raw_payload"]["attachment_collection_v1"] if rows else {}
check("c3_collection_binds_original_clock",
      collection.get("files", [{}])[0].get("retrieved_at") == first["retrieved_at"])

# ---- c4 future retrieved_at is rejected --------------------------------------
future = (T2 + timedelta(days=400)).isoformat()
rewrite(lambda s: s.update(retrieved_at=future))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c4_future_clock_rejected", res["collection_status"] == "lookup_failed"
      and res["from_cache"] is False and res["text"] == "",
      status=res["collection_status"], from_cache=res["from_cache"])

# ---- c5 naive retrieved_at is rejected ---------------------------------------
CACHE.write_text(original_cache)
rewrite(lambda s: s.update(retrieved_at=aware(s["retrieved_at"]).replace(tzinfo=None).isoformat()))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c5_naive_clock_rejected", res["collection_status"] == "lookup_failed"
      and res["from_cache"] is False and res["text"] == "", status=res["collection_status"])

# ---- c6 'Z' suffix and non-UTC offset of the same past instant are accepted ---
CACHE.write_text(original_cache)
rewrite(lambda s: s.update(retrieved_at=aware(s["retrieved_at"]).strftime("%Y-%m-%dT%H:%M:%S.%fZ")))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res_z = sat.extract_public_attachment_text(dict(ATTACHMENT))
CACHE.write_text(original_cache)
from datetime import timezone as _tz  # noqa: E402
rewrite(lambda s: s.update(retrieved_at=aware(s["retrieved_at"]).astimezone(
    _tz(timedelta(hours=5))).isoformat()))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res_off = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c6_z_and_offset_representations_accepted",
      res_z["from_cache"] is True and res_off["from_cache"] is True,
      z=res_z["from_cache"], plus5=res_off["from_cache"])

# ---- c7 future retrieved_at that is 'past' only under naive reading ----------
# instant T1 expressed with -12:00 offset is 12 h later in UTC; still < T2 so accepted;
# an offset trick that lands AFTER now must be rejected even if the wall-clock digits look past.
CACHE.write_text(original_cache)
trick = (T2 + timedelta(hours=1)).astimezone(_tz(timedelta(hours=-11))).isoformat()
rewrite(lambda s: s.update(retrieved_at=trick))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c7_offset_disguised_future_rejected", res["from_cache"] is False
      and res["collection_status"] == "lookup_failed", retrieved_at_written=trick)

# ---- c8 request_started_at after retrieved_at is NOT checked (measured limit) --
CACHE.write_text(original_cache)
rewrite(lambda s: s.update(request_started_at=(aware(s["retrieved_at"]) + timedelta(days=1)).isoformat()))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c8_request_started_after_retrieved_accepted_INFO", True,
      accepted_from_cache=res["from_cache"], note="validator does not check request_started_at ordering")
request_order_unchecked = res["from_cache"] is True

# ---- c9 legacy base-shaped cache cannot be returned as freshly collected -------
CACHE.write_text(json.dumps({"resource_id": RID, "name": "SOW.txt", "text": "Legacy text",
                             "sha256": hashlib.sha256(b"x").hexdigest(),
                             "retrieved_at": T1.isoformat(timespec="seconds"),
                             "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID),
                             "error": ""}))
with patch.object(sat, "datetime", Clock(T2).make()), patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c9_legacy_cache_refresh_failure_returns_no_text", res["collection_status"] == "lookup_failed"
      and res["text"] == "" and res["from_cache"] is False, status=res["collection_status"])

# ---- c10 a warm cache read with a clock EARLIER than its retrieved_at ---------
CACHE.write_text(original_cache)
with patch.object(sat, "datetime", Clock(T1 - timedelta(hours=1)).make()), \
        patch.object(sat, "_download_bytes", denied):
    res = sat.extract_public_attachment_text(dict(ATTACHMENT))
check("c10_earlier_now_treats_cache_as_future_INFO", True, from_cache=res["from_cache"],
      status=res["collection_status"],
      note="a replay clock frozen before a cached retrieved_at refuses that cache (relevant to replay drivers)")

# ---- BASE comparison: base returned any cache unconditionally ----------------
base_sat = load_base("tools/api/sam_attachment_text.py", "base_sam_attachment_text")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(BASE_CACHE)
base_cache = BASE_CACHE / f"{RID}.json"
base_results = {}
for label, stamp in (("future", future), ("naive", T1.replace(tzinfo=None).isoformat()),
                     ("original", T1.isoformat())):
    base_cache.write_text(json.dumps({"resource_id": RID, "name": "SOW.txt", "text": "Base cached text",
                                      "sha256": "0" * 64, "retrieved_at": stamp,
                                      "source_url": "x", "error": ""}))
    with patch.object(base_sat, "datetime", Clock(T2).make()), patch.object(base_sat, "_download_bytes", denied):
        base_res = base_sat.extract_public_attachment_text(dict(ATTACHMENT))
    base_results[label] = {"from_cache": base_res.get("from_cache"), "retrieved_at": base_res.get("retrieved_at"),
                           "text": base_res.get("text")}
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(CAND_DIR)
check("base_hit_keeps_original_retrieved_at", base_results["original"]["retrieved_at"] == T1.isoformat()
      and base_results["original"]["from_cache"] is True)
check("base_accepted_future_and_naive_INFO", True, base=base_results,
      note="pre-existing: base validated nothing; candidate rejects future/naive (improvement)")

failures = [c["name"] for c in checks if not c["ok"]]
out = {"probe": "text_cache_clock", "checks": checks, "failures": failures,
       "request_started_at_ordering_unchecked": request_order_unchecked,
       "status": "PASS" if not failures else "FAIL",
       "observed": ("cache hit returns original retrieved_at/request_started_at; evidence + receipts carry it; "
                    "future/naive/offset-disguised-future rejected; legacy cache never returned on failed refresh; "
                    f"request_started_at ordering unchecked={request_order_unchecked}; failures={failures}")}
print(json.dumps(out, indent=2, default=str))
shutil.rmtree(CAND_DIR, ignore_errors=True)
shutil.rmtree(BASE_CACHE, ignore_errors=True)
sys.exit(0 if not failures else 1)
