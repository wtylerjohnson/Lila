"""Run the recovered Step6 hostile driver (path-adapted only) against the Step7
candidate clone and compare every case result to the Step6 original results.

Prints one JSON object. status PASS = every case result identical to the Step6
original (verdicts, failures, and inspected fields); FAIL = any drift.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
CLONE = Path("/Users/wtjohnson/lila-step7-052")
PYTHON = CLONE / ".venv/bin/python"
ORIGINAL_RESULTS = Path(
    "/Users/wtjohnson/Documents/Codex/LILA-Competitive-Benchmark/handoffs/"
    "FABLE-STEP6-051/recovered/probe-results.original.json")
DELTA_FILES = {
    "agents/decisions/dossier.py", "run_searches.py", "tools/api/_http.py",
    "tools/api/sam_attachment_text.py", "tools/api/sam_capture.py",
    "tools/api/sam_notice_detail.py", "tests/test_step7_evidence_collection.py",
}


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = PROBE_DIR / "step6-runs" / f"run-{stamp}"
    run_dir.parent.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, "NEW_ABSOLUTE_RUN": str(run_dir),
           "PYTHONDONTWRITEBYTECODE": "1"}
    completed = subprocess.run(
        [str(PYTHON), str(PROBE_DIR / "hostile_step6_probes.adapted.py")],
        cwd=str(CLONE), env=env, capture_output=True, text=True, timeout=900)
    # The driver creates run_dir itself (exist_ok=False); keep the logs beside it
    # so a driver that dies before mkdir still leaves its stderr on disk.
    (run_dir.parent / f"{run_dir.name}.driver.stdout.txt").write_text(completed.stdout)
    (run_dir.parent / f"{run_dir.name}.driver.stderr.txt").write_text(completed.stderr)
    out = {"probe": "step6_driver_compare", "run_dir": str(run_dir),
           "driver_exit": completed.returncode, "edits": json.loads(
               (PROBE_DIR / "driver_edits.json").read_text())["edits"]}
    results_path = run_dir / "results.json"
    receipt_path = run_dir / "run_receipt.json"
    if not results_path.exists():
        out.update(status="FAIL", observed="driver produced no results.json",
                   stderr_tail=completed.stderr[-3000:])
        print(json.dumps(out, indent=2, default=str))
        return 1
    new = {r["case"]: r for r in json.loads(results_path.read_text())}
    old = {r["case"]: r for r in json.loads(ORIGINAL_RESULTS.read_text())}
    receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}

    def diff(a, b, path=""):
        found = []
        if isinstance(a, dict) and isinstance(b, dict):
            for key in sorted(set(a) | set(b)):
                if key not in a or key not in b:
                    found.append({"path": f"{path}/{key}", "original": a.get(key, "<absent>"),
                                  "candidate": b.get(key, "<absent>")})
                else:
                    found.extend(diff(a[key], b[key], f"{path}/{key}"))
        elif isinstance(a, list) and isinstance(b, list):
            if len(a) != len(b):
                found.append({"path": path, "original": a, "candidate": b})
            else:
                for index, (x, y) in enumerate(zip(a, b)):
                    found.extend(diff(x, y, f"{path}[{index}]"))
        elif a != b:
            found.append({"path": path, "original": a, "candidate": b})
        return found

    cases = {}
    drift = []
    for case in sorted(set(old) | set(new)):
        o, n = old.get(case), new.get(case)
        if o is None or n is None:
            cases[case] = {"original": o and o.get("verdict"), "candidate": n and n.get("verdict"),
                           "missing": True}
            drift.append(case)
            continue
        differences = diff(o, n)
        cases[case] = {
            "original_verdict": o.get("verdict"), "candidate_verdict": n.get("verdict"),
            "original_execution": o.get("execution"), "candidate_execution": n.get("execution"),
            "original_failures": o.get("failures"), "candidate_failures": n.get("failures"),
            "field_differences": differences,
        }
        if differences:
            drift.append(case)
    mismatches = receipt.get("hash_mismatches") or {}
    outside_delta = sorted(p for p in mismatches if p not in DELTA_FILES)
    out.update(
        exact_sha=receipt.get("exact_sha"), case_count=receipt.get("case_count"),
        all_completed=receipt.get("all_completed"), loaded_hash_count=receipt.get("loaded_hash_count"),
        step6_bound_hash_mismatches=sorted(mismatches),
        mismatches_outside_step7_delta=outside_delta,
        cases=cases, drifted_cases=drift,
        status="PASS" if not drift and not outside_delta else "FAIL",
        observed=(f"{len(cases)} cases compared; drift in {drift or 'none'}; "
                  f"Step6-bound hash mismatches {sorted(mismatches) or 'none'} "
                  f"(outside Step7 delta: {outside_delta or 'none'})"),
    )
    print(json.dumps(out, indent=2, default=str))
    return 0 if out["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
