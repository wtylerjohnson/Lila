"""Shared probe scaffolding: clone path, network block, controllable clocks.

Every probe imports the REAL production modules from the review clone. Only
network (socket + httpx client) and clocks (module-level ``datetime`` names) are
monkeypatched. Nothing here writes outside the probe directory.
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import socket
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

CLONE = Path("/Users/wtjohnson/lila-step7-052")
PROBE_DIR = Path(__file__).resolve().parent
BASE_DIR = PROBE_DIR / "base"
TMP_ROOT = PROBE_DIR / "tmp"
BASE_SHA = "2d522f0362e656e029986344d47e2e06b86a58f8"

if str(CLONE) not in sys.path:
    sys.path.insert(0, str(CLONE))
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True


def fresh_dir(name: str) -> Path:
    path = TMP_ROOT / name
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True)
    return path


def block_network() -> None:
    def deny(*args, **kwargs):
        raise AssertionError("probe attempted a real network connection")
    socket.socket.connect = deny  # type: ignore[assignment]
    socket.create_connection = deny  # type: ignore[assignment]


def load_base(relative: str, name: str):
    """Import a BASE (2d522f0) module copy from the probe dir under a new name."""
    path = BASE_DIR / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class Clock:
    """Settable, optionally auto-advancing replacement for ``datetime``."""

    def __init__(self, start: datetime, step_seconds: float = 0.0):
        self.value = start
        self.step = timedelta(seconds=step_seconds)
        self.calls = 0

    def make(self):
        clock = self

        class FakeDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                clock.calls += 1
                value = clock.value
                clock.value = clock.value + clock.step
                return value.astimezone(tz) if tz else value.replace(tzinfo=None)

        return FakeDatetime


def aware(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def utc(*args) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)
