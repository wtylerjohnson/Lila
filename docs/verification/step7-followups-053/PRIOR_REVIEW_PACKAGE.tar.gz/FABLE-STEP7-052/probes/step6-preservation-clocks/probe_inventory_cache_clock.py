"""Inventory-cache clocks for fetch_notice_resources: cache hits keep the original
retrieved_at and raw_capture.received_at; _resource_cache_fresh uses received_at
when present and retrieved_at otherwise; future clocks are rejected; naive clocks
are rejected on the fresh path. The stale fallback path is probed separately and
the same hostile caches are run against BASE (2d522f0) to classify.

Network: tools.api._http._client -> httpx.MockTransport; sockets blocked.
One JSON object. status FAIL if any candidate claim breaks.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import Clock, aware, block_network, fresh_dir, load_base, utc  # noqa: E402

block_network()
CAND_DIR = fresh_dir("inventory_clock_cand")
BASE_DIR = fresh_dir("inventory_clock_base")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(CAND_DIR)

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

NOTICE = "a" * 32
BODY = json.dumps({"attachments": [{"name": "SOW.txt", "resourceId": "b" * 32}]}).encode()
T1 = utc(2026, 9, 1, 10, 0, 0)
T2 = T1 + timedelta(hours=1)          # inside the 6 h TTL
T_STALE = T1 + timedelta(days=2)      # outside TTL, inside 7 d max-stale
CACHE = CAND_DIR / f"{NOTICE}.resources.json"
state = {"status": 200, "body": BODY, "calls": 0}
checks = []


def check(name, ok, **fields):
    checks.append({"name": name, "ok": bool(ok), **fields})


def handler(request):
    state["calls"] += 1
    return httpx.Response(state["status"], content=state["body"])


mock_client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))  # noqa: E731


def fetch(now, step=1):
    with patch.object(_http, "_client", mock_client), patch.object(detail, "datetime", Clock(now, step).make()):
        return detail.fetch_notice_resources(NOTICE)


def rewrite(mutator):
    saved = json.loads(CACHE.read_text())
    mutator(saved)
    CACHE.write_text(json.dumps(saved))
    return saved


# ---- d1 fresh fetch at T1 ----------------------------------------------------
first = fetch(T1)
check("d1_inventory_captured", first["collection_status"] == "inventory_captured"
      and first["from_cache"] is False, status=first["collection_status"], http_calls=state["calls"])
check("d1_retrieved_at_before_received_at",
      aware(first["retrieved_at"]) <= aware(first["raw_capture"]["received_at"])
      and aware(first["retrieved_at"]) == T1,
      retrieved_at=first["retrieved_at"], received_at=first["raw_capture"]["received_at"])
check("d1_clocks_aware", aware(first["raw_capture"]["received_at"]).utcoffset() is not None)
check("d1_raw_retained", read_retained(CAND_DIR, first["raw_capture"]) == BODY)
original_cache = CACHE.read_text()
calls_after_first = state["calls"]

# ---- d2 cache HIT at T2 keeps original clocks, no HTTP ------------------------
hit = fetch(T2)
check("d2_hit_no_http", hit["from_cache"] is True and hit["stale_cache"] is False
      and state["calls"] == calls_after_first, from_cache=hit["from_cache"], http_calls=state["calls"])
check("d2_hit_keeps_original_clocks", hit["retrieved_at"] == first["retrieved_at"]
      and hit["raw_capture"]["received_at"] == first["raw_capture"]["received_at"],
      retrieved_at=hit["retrieved_at"], received_at=hit["raw_capture"]["received_at"])

# ---- d2b run_searches inventory_receipt carries the original clocks on a hit --
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402


def run_enrichment(now):
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    from tools.api import sam_attachment_text as sat
    with patch.object(_http, "_client", mock_client), patch.object(detail, "datetime", Clock(now, 1).make()), \
            patch.object(sat, "_download_bytes", lambda rid, **k: b"Buyer requires packet capture"), \
            patch("tools.api.sam_quota.calls_today", return_value=0), \
            patch.dict(os.environ, {"LILA_SAM_ATTACHMENT_TEXT_DIR": str(CAND_DIR / "text")}):
        return searches._enrich_sam_public_attachments(
            [], Source(), object(), CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                                        core=[TaxonomyTerm(term="packet capture")]), None, limit=8)


rows, stats = run_enrichment(T2)
inv_receipt = stats["attachment_record_receipts"][NOTICE].get("inventory_receipt", {})
check("d2b_run_searches_inventory_receipt_original_clocks",
      inv_receipt.get("retrieved_at") == first["retrieved_at"]
      and (inv_receipt.get("raw_capture") or {}).get("received_at") == first["raw_capture"]["received_at"]
      and state["calls"] == calls_after_first,
      inventory_receipt={k: inv_receipt.get(k) for k in ("retrieved_at", "collection_status")},
      received_at=(inv_receipt.get("raw_capture") or {}).get("received_at"), http_calls=state["calls"])

# ---- d3 _resource_cache_fresh semantics (pure function) ----------------------
with patch.object(detail, "datetime", Clock(T2).make()):
    recent = (T2 - timedelta(seconds=60)).isoformat()
    old = (T2 - timedelta(days=10)).isoformat()
    semantics = {
        "received_recent_retrieved_old": detail._resource_cache_fresh(
            {"raw_capture": {"received_at": recent}, "retrieved_at": old}),
        "received_old_retrieved_recent": detail._resource_cache_fresh(
            {"raw_capture": {"received_at": old}, "retrieved_at": recent}),
        "legacy_retrieved_recent": detail._resource_cache_fresh({"retrieved_at": recent}),
        "legacy_retrieved_old": detail._resource_cache_fresh({"retrieved_at": old}),
        "raw_capture_dict_without_received_at": detail._resource_cache_fresh(
            {"raw_capture": {"path": "objects/x.bin"}, "retrieved_at": recent}),
        "raw_capture_non_dict": detail._resource_cache_fresh(
            {"raw_capture": "corrupt", "retrieved_at": recent}),
        "received_future": detail._resource_cache_fresh(
            {"raw_capture": {"received_at": (T2 + timedelta(seconds=5)).isoformat()}}),
        "received_naive_recent": detail._resource_cache_fresh(
            {"raw_capture": {"received_at": (T2 - timedelta(seconds=60)).replace(tzinfo=None).isoformat()}}),
    }
check("d3_fresh_uses_received_at_when_present",
      semantics["received_recent_retrieved_old"] is True and semantics["received_old_retrieved_recent"] is False,
      semantics=semantics)
check("d3_fresh_uses_retrieved_at_otherwise",
      semantics["legacy_retrieved_recent"] is True and semantics["legacy_retrieved_old"] is False
      and semantics["raw_capture_non_dict"] is True)
check("d3_future_received_not_fresh", semantics["received_future"] is False)
check("d3_naive_received_counts_as_fresh_INFO", True, naive_fresh=semantics["received_naive_recent"],
      note="_timestamp coerces naive to UTC; awareness is enforced by _resource_capture_valid, not freshness")

# ---- d4 future received_at: refused on fresh path, and not used as stale ------
CACHE.write_text(original_cache)
rewrite(lambda s: s["raw_capture"].update(received_at=(T2 + timedelta(days=1)).isoformat()))
state.update(status=503, body=b"unavailable")
calls_before = state["calls"]
res = fetch(T2)
check("d4_future_received_rejected_and_not_stale", res["from_cache"] is False
      and res["collection_status"] == "lookup_failed" and state["calls"] > calls_before,
      status=res["collection_status"], from_cache=res["from_cache"], refetched=state["calls"] > calls_before)

# ---- d5 naive received_at: rejected on the fresh path ... ---------------------
CACHE.write_text(original_cache)
rewrite(lambda s: s["raw_capture"].update(
    received_at=aware(s["raw_capture"]["received_at"]).replace(tzinfo=None).isoformat()))
state.update(status=200, body=BODY)
calls_before = state["calls"]
res = fetch(T2)
check("d5_naive_received_forces_refetch", res["from_cache"] is False and state["calls"] > calls_before
      and res["collection_status"] == "inventory_captured",
      from_cache=res["from_cache"], refetched=state["calls"] > calls_before)
# ... but the STALE fallback returns the naive-clock cache when the refetch fails
CACHE.write_text(original_cache)
rewrite(lambda s: s["raw_capture"].update(
    received_at=aware(s["raw_capture"]["received_at"]).replace(tzinfo=None).isoformat()))
state.update(status=503, body=b"unavailable")
res = fetch(T2)
naive_stale = res.get("collection_status") == "stale_inventory"
check("d5b_naive_clock_cache_returned_as_stale_inventory", not naive_stale,
      status=res.get("collection_status"), from_cache=res.get("from_cache"),
      received_at=(res.get("raw_capture") or {}).get("received_at"),
      note="claim: caches bind an aware acquisition clock; the stale fallback accepts a naive one")

# ---- d6 tampered projection + failed refresh -> stale_inventory unvalidated ---
CACHE.write_text(original_cache)
tampered = rewrite(lambda s: s.update(attachments=[{"name": "Invented SOW.txt", "resource_id": "f" * 32}],
                                      attachment_inventory_hash="0" * 64))
state.update(status=503, body=b"unavailable")
res = fetch(T2)
tampered_stale = (res.get("collection_status") == "stale_inventory"
                  and res.get("attachments") == tampered["attachments"]
                  and res.get("attachment_inventory_hash") == "0" * 64)
check("d6_tampered_projection_returned_as_stale_inventory", not tampered_stale,
      status=res.get("collection_status"), attachments=res.get("attachments"),
      inventory_hash=res.get("attachment_inventory_hash"),
      capture_valid=detail._resource_capture_valid(json.loads(CACHE.read_text())))
# and what run_searches records from it
rows, stats = run_enrichment(T2)
rec = stats["attachment_record_receipts"][NOTICE]
check("d6b_run_searches_excludes_stale_from_relevance", rec.get("status") == "STALE_INVENTORY"
      and stats.get("attachment_relevant", 0) == 0 and "files" not in rec,
      record_status=rec.get("status"), relevant=stats.get("attachment_relevant"))
check("d6c_receipt_carries_tampered_hash_INFO", True,
      receipt_inventory_hash=(rec.get("inventory_receipt") or {}).get("attachment_inventory_hash"),
      receipt_status=(rec.get("inventory_receipt") or {}).get("collection_status"))

# ---- d7 legacy (no raw_capture) cache + failed refresh -> stale_inventory (H8) --
legacy = {"id": NOTICE, "attachments": [{"name": "Legacy SOW.txt", "resource_id": "c" * 32}],
          "retrieved_at": T1.isoformat(timespec="seconds"), "resources_checked": True,
          "resources_schema": "recognized_v1", "errors": [], "attachment_inventory_count": 1,
          "attachment_inventory_hash": detail._manifest_hash([{"name": "Legacy SOW.txt", "resource_id": "c" * 32}])}
CACHE.write_text(json.dumps(legacy))
state.update(status=503, body=b"unavailable")
res = fetch(T2)
check("d7_legacy_cache_failed_refresh_is_stale_not_fresh", res.get("collection_status") == "stale_inventory"
      and res.get("stale_cache") is True and res.get("from_cache") is True,
      status=res.get("collection_status"), note="disclosed H8 behavior")
# legacy + successful refresh -> fresh capture
CACHE.write_text(json.dumps(legacy))
state.update(status=200, body=BODY)
res = fetch(T2)
check("d8_legacy_cache_refreshed_with_capture", res.get("from_cache") is False
      and res.get("collection_status") == "inventory_captured" and "raw_capture" in res)

# ---- d9 retrieved_at is not consulted once raw_capture exists ---------------
CACHE.write_text(original_cache)
rewrite(lambda s: s.update(retrieved_at=(T2 + timedelta(days=30)).isoformat()))
res = fetch(T2)
check("d9_future_retrieved_at_ignored_when_received_at_present_INFO", True,
      from_cache=res.get("from_cache"), retrieved_at=res.get("retrieved_at"),
      note="freshness/validity bind received_at only; a tampered retrieved_at rides through a cache hit")
future_retrieved_hit = res.get("from_cache") is True

# ---- d10 stale fallback with a FUTURE clock is refused ------------------------
CACHE.write_text(original_cache)
rewrite(lambda s: s["raw_capture"].update(received_at=(T2 + timedelta(days=1)).isoformat()))
state.update(status=503, body=b"unavailable")
res = fetch(T2)
check("d10_future_clock_never_stale_inventory", res.get("collection_status") == "lookup_failed"
      and res.get("from_cache") is False)

# ---- BASE comparison ---------------------------------------------------------
base_detail = load_base("tools/api/sam_notice_detail.py", "base_sam_notice_detail")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(BASE_DIR)
base_cache = BASE_DIR / f"{NOTICE}.resources.json"
base_results = {}
for label, stamp, status in (("naive_recent_fresh_path", T2 - timedelta(seconds=60), 200),
                             ("naive_recent_refresh_503", T2 - timedelta(seconds=60), 503),
                             ("naive_stale_refresh_503", T1 - timedelta(days=1), 503),
                             ("future", T2 + timedelta(days=1), 503),
                             ("tampered_aware_stale_503", T1 - timedelta(days=1), 503)):
    row = dict(legacy)
    row["retrieved_at"] = stamp.replace(tzinfo=None).isoformat() if "naive" in label else stamp.isoformat()
    if label.startswith("tampered"):
        row["attachments"] = [{"name": "Invented"}]
    base_cache.write_text(json.dumps(row))
    state.update(status=status, body=BODY)
    with patch.object(_http, "_client", mock_client), patch.object(base_detail, "datetime", Clock(T2).make()):
        b = base_detail.fetch_notice_resources(NOTICE)
    base_results[label] = {"from_cache": b.get("from_cache"), "stale_cache": b.get("stale_cache"),
                           "attachments": b.get("attachments")}
os.environ["LILA_NOTICE_CACHE_DIR"] = str(CAND_DIR)
check("base_naive_recent_served_as_FRESH_hit", True, base=base_results,
      note="pre-existing: base served a naive recent clock as a fresh hit and any stale cache unvalidated")

failures = [c["name"] for c in checks if not c["ok"]]
out = {"probe": "inventory_cache_clock", "checks": checks, "failures": failures,
       "naive_clock_served_as_stale_inventory": naive_stale,
       "tampered_projection_served_as_stale_inventory": tampered_stale,
       "future_retrieved_at_rides_cache_hit": future_retrieved_hit,
       "base": base_results,
       "status": "PASS" if not failures else "FAIL",
       "observed": (f"cache hit keeps original retrieved_at/received_at with zero HTTP; fresh path rejects future and naive; "
                    f"stale fallback accepts naive clock={naive_stale} and unvalidated projection={tampered_stale} "
                    f"(both pre-existing at base, excluded from relevance by run_searches); failures={failures}")}
print(json.dumps(out, indent=2, default=str))
shutil.rmtree(CAND_DIR, ignore_errors=True)
shutil.rmtree(BASE_DIR, ignore_errors=True)
sys.exit(0 if not failures else 1)
