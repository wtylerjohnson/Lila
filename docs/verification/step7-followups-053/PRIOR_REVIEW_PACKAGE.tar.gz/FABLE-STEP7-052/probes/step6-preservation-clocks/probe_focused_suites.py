"""Run the producer's focused command, the Step6 focused eight-file command, and
the wider Step4/5/6/7 + Assess + collector authority modules with the review venv.

Prints one JSON object with per-run counts parsed from junit XML written under
the probe dir. status PASS = every run has zero failures and zero errors and the
producer focused count (201) reproduces; FAIL otherwise.
"""
from __future__ import annotations

import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
CLONE = Path("/Users/wtjohnson/lila-step7-052")
PYTHON = CLONE / ".venv/bin/python"
ENV = {"PYTHONDONTWRITEBYTECODE": "1", "LILA_SUITE_OFFLINE": "1", "LILA_SUITE_STRICT": "1",
       "PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": "/Users/wtjohnson",
       "TMPDIR": str(PROBE_DIR / "tmp" / "pytest-tmp")}

PRODUCER_FOCUSED = [
    "tests/test_step7_evidence_collection.py", "tests/test_sam_attachment_text.py",
    "tests/test_dossiers.py", "tests/test_native_notice_bridge.py",
    "tests/test_native_surface_contract.py", "tests/test_assess_source_clock.py",
    "tests/test_assess_ledger.py", "tests/test_external_notice_authority.py",
    "tests/test_step6_material_source.py", "tests/test_triage_prefilter.py",
]
STEP6_FOCUSED = [
    "tests/test_native_notice_bridge.py", "tests/test_native_surface_contract.py",
    "tests/test_external_notice_authority.py", "tests/test_step6_material_source.py",
    "tests/test_triage_prefilter.py", "tests/test_assess_source_clock.py",
    "tests/test_assessment_output_retention.py", "tests/test_evidence_route.py",
]
WIDER = [
    "tests/test_step4_temporal_evidence.py", "tests/test_step6_material_source.py",
    "tests/test_step7_evidence_collection.py",
    "tests/test_assess_approval.py", "tests/test_assess_contracts.py", "tests/test_assess_ledger.py",
    "tests/test_assess_reapproval_identity.py", "tests/test_assess_refresh.py",
    "tests/test_assess_report_compat.py", "tests/test_assess_run_identity.py",
    "tests/test_assess_source_clock.py", "tests/test_assessment_arbiters.py",
    "tests/test_assessment_chain.py", "tests/test_assessment_document.py",
    "tests/test_assessment_output_retention.py", "tests/test_assessment_radar.py",
    "tests/test_dossiers.py", "tests/test_leadgen_export_assess.py", "tests/test_leadgen_from_assess.py",
    "tests/test_sam_attachment_text.py", "tests/test_evidence_route.py",
]


def run(name: str, modules: list[str]) -> dict:
    (PROBE_DIR / "tmp" / "pytest-tmp").mkdir(parents=True, exist_ok=True)
    junit = PROBE_DIR / f"junit-{name}.xml"
    log = PROBE_DIR / f"pytest-{name}.log"
    cmd = [str(PYTHON), "-m", "pytest", *modules, "-q", "-rs", "-p", "no:cacheprovider",
           f"--junitxml={junit}"]
    completed = subprocess.run(cmd, cwd=str(CLONE), env=ENV, capture_output=True,
                               text=True, timeout=1800)
    log.write_text(completed.stdout + "\n--- stderr ---\n" + completed.stderr)
    counts = {"tests": None, "failures": None, "errors": None, "skipped": None}
    if junit.exists():
        root = ET.parse(junit).getroot()
        suite = root if root.tag == "testsuite" else root.find("testsuite")
        counts = {k: int(suite.get(k)) for k in counts}
    summary = [line for line in completed.stdout.splitlines() if " in " in line and (
        "passed" in line or "failed" in line or "error" in line)]
    return {"modules": modules, "exit": completed.returncode, "counts": counts,
            "passed": (counts["tests"] - counts["failures"] - counts["errors"] - counts["skipped"])
            if counts["tests"] is not None else None,
            "summary_line": summary[-1] if summary else None, "log": str(log)}


def main() -> int:
    runs = {
        "producer_focused": run("producer-focused", PRODUCER_FOCUSED),
        "step6_focused_eight": run("step6-focused", STEP6_FOCUSED),
        "wider_step4_6_7_assess": run("wider", WIDER),
    }
    problems = []
    for name, result in runs.items():
        counts = result["counts"]
        if counts["tests"] is None or result["exit"] != 0 or counts["failures"] or counts["errors"]:
            problems.append(f"{name}: exit={result['exit']} counts={counts}")
    if runs["producer_focused"]["passed"] != 201:
        problems.append(f"producer focused passed={runs['producer_focused']['passed']} (claimed 201)")
    if runs["step6_focused_eight"]["passed"] != 105:
        problems.append(f"step6 focused passed={runs['step6_focused_eight']['passed']} (Step6 review saw 105)")
    out = {"probe": "focused_suites", "runs": runs, "problems": problems,
           "status": "PASS" if not problems else "FAIL",
           "observed": "; ".join(f"{n}: passed={r['passed']} failed={r['counts']['failures']} "
                                 f"errors={r['counts']['errors']} skipped={r['counts']['skipped']}"
                                 for n, r in runs.items())}
    print(json.dumps(out, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
