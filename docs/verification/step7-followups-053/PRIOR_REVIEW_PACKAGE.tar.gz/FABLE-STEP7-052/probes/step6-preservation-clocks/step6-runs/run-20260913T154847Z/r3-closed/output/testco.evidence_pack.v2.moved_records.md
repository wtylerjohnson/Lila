# Testco evidence classification moves

## Before and after by class

| Evidence class | Before | After |
| --- | ---: | ---: |
| ambiguous | 0 | 1 |
| current_opportunity | 1 | 0 |

## Moved records

| Record | Prior class | New class | Commercial route | Reason |
| --- | --- | --- | --- | --- |
| N1 | current_opportunity | ambiguous | unknown | Notice is superseded or family chronology is unresolved; No current bound Assess BID_NOW/PURSUE requirement approval |
