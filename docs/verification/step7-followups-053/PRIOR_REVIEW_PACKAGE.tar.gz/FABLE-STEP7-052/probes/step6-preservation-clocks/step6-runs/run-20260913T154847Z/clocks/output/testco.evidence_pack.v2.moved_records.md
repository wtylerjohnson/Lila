# Testco evidence classification moves

## Before and after by class

| Evidence class | Before | After |
| --- | ---: | ---: |
| current_opportunity | 1 | 1 |

## Moved records

| Record | Prior class | New class | Commercial route | Reason |
| --- | --- | --- | --- | --- |
| None |  |  |  | No pre-v2 records changed class. |
