"""Downstream clocks: does the dossier research context accept a FUTURE attachment
retrieved_at (it requires aware, but does it require <= now?), does it reject a
naive one, and does the attachment clock ever become strict Assess source
acquisition or grant BID_NOW / requirement_reviewed_at? BASE dossier is run on
the same rows to classify.

One JSON object. status FAIL if a strict Assess clock or approval leaks; the
dossier future-clock acceptance is reported with its own flag.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import Clock, aware, block_network, fresh_dir, load_base, utc  # noqa: E402

block_network()
TEXT_DIR = fresh_dir("dossier_assess_text")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)
os.environ["LILA_SUITE_OFFLINE"] = "1"
os.environ["LILA_SUITE_STRICT"] = "1"

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

T_ATT = utc(2026, 7, 9, 9, 30, 0)   # attachment acquisition clock, distinct from every fixture clock
checks = []


def check(name, ok, **fields):
    checks.append({"name": name, "ok": bool(ok), **fields})


def public(rid, name):
    return {"resource_id": rid, "name": name, "type": None, "source_url": None, "size": 0,
            "access_level": "public", "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


def collect(notice_id, term):
    files = [public("b" * 32, "SOW 1.txt"), public("c" * 32, "SOW 2.txt")]
    inventory = detail._manifest_hash(files)
    texts = {"b" * 32: f"Buyer requires {term}. Café data.", "c" * 32: f"Further {term} deliverables: Δ."}
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    with patch.object(sat, "datetime", Clock(T_ATT, 1).make()), \
            patch.object(sat, "_download_bytes", lambda rid, **k: texts[rid].encode()), \
            patch.object(detail, "fetch_notice_resources", lambda *a, **k: {
                "id": notice_id, "resources_checked": True, "attachments": files,
                "attachment_inventory_hash": inventory}), \
            patch("tools.api.sam_quota.calls_today", return_value=0):
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(), CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                                        core=[TaxonomyTerm(term=term)]), None, limit=8)
    return rows[0], stats, inventory


def rebind(row, mutate):
    raw = row["raw_payload"]
    for item in raw["attachment_evidence"]:
        mutate(item)
    for item in raw["attachment_collection_v1"]["files"]:
        mutate(item)
    raw["attachment_collection_sha256"] = hashlib.sha256(json.dumps(
        raw["attachment_collection_v1"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return row


row, stats, inventory = collect("a" * 32, "network visibility")
depth = {"id": "a" * 32, "resources_checked": True, "attachment_inventory_hash": inventory}
positive = _attachment_research_context(json.loads(json.dumps(row)), depth)
check("f0_positive_control_discovery_only", positive["status"] == "discovery_only"
      and len(positive["file_passages"]) == 2
      and all(aware(f["retrieved_at"]) >= T_ATT for f in positive["files"]),
      status=positive["status"], retrieved=[f["retrieved_at"] for f in positive["files"]])

# f1 future retrieved_at (rebound so every hash still matches)
future = (utc(2031, 1, 1, 0, 0, 0)).isoformat()
future_row = rebind(json.loads(json.dumps(row)), lambda item: item.update(retrieved_at=future))
ctx_future = _attachment_research_context(future_row, depth)
future_accepted = ctx_future["status"] == "discovery_only"
check("f1_dossier_future_retrieved_at_accepted", True, accepted=future_accepted, status=ctx_future["status"],
      reason=ctx_future.get("reason"), note="provenance check requires aware, not <= now")

# f2 naive retrieved_at rejected
naive_row = rebind(json.loads(json.dumps(row)), lambda item: item.update(
    retrieved_at=aware(item["retrieved_at"]).replace(tzinfo=None).isoformat()))
ctx_naive = _attachment_research_context(naive_row, depth)
check("f2_dossier_naive_retrieved_at_rejected", ctx_naive["status"] == "unavailable",
      status=ctx_naive["status"], reason=ctx_naive.get("reason"))

# f3 offset-disguised: instant in the future but digits look past under naive reading
from datetime import timezone as _tz  # noqa: E402
disguised = (utc(2031, 1, 1, 0, 0, 0)).astimezone(_tz(timedelta(hours=-11))).isoformat()
disg_row = rebind(json.loads(json.dumps(row)), lambda item: item.update(retrieved_at=disguised))
ctx_disg = _attachment_research_context(disg_row, depth)
check("f3_dossier_offset_future_accepted_INFO", True, accepted=ctx_disg["status"] == "discovery_only")

# BASE dossier on the same rows (base has no collection block; strip it so base reads the legacy shape)
base_dossier = load_base("agents/decisions/dossier.py", "base_dossier")
base_results = {}
for label, candidate_row in (("future", future_row), ("naive", naive_row), ("positive", row)):
    legacy = json.loads(json.dumps(candidate_row))
    legacy["raw_payload"].pop("attachment_collection_v1", None)
    legacy["raw_payload"].pop("attachment_collection_sha256", None)
    ctx = base_dossier._attachment_research_context(legacy, depth)
    base_results[label] = {"status": ctx["status"], "reason": ctx.get("reason")}
check("base_dossier_same_future_acceptance", base_results["future"]["status"] == ("discovery_only" if future_accepted else "unavailable")
      and base_results["naive"]["status"] == "unavailable" and base_results["positive"]["status"] == "discovery_only",
      base=base_results)

# ---- f4 strict Assess: attachment clock never becomes source acquisition -------
from agents.assess.contracts import LiveClassification  # noqa: E402
from agents.assess.source_clock import acquired_at, acquisition_summary  # noqa: E402
from tests.test_assess_ledger import _sweep, _build  # noqa: E402

row_n1, stats_n1, inv_n1 = collect("N1", "packet capture")
sweep = _sweep()
original = sweep["results"]["sam.gov"][0]
original["source_id"] = row_n1["source_id"]
original["raw_payload"].update(row_n1["raw_payload"])
run, diagnostics, index = _build(sweep)
parent = next(r for r in run.live.records if r.notice_id == "N1")
attachment_instants = {aware(e["retrieved_at"]) for e in row_n1["raw_payload"]["attachment_evidence"]}
evidence_clocks = [(e.evidence_id, e.retrieved_at.isoformat() if e.retrieved_at else None,
                    (acquired_at(e).isoformat() if acquired_at(e) else None))
                   for e in parent.authoritative_evidence]
leaked = [c for c in evidence_clocks if c[1] and aware(c[1]) in attachment_instants]
check("f4_attachment_clock_not_assess_acquisition", not leaked,
      attachment_instants=sorted(i.isoformat() for i in attachment_instants), evidence_clocks=evidence_clocks,
      acquisition_summary=acquisition_summary(parent.authoritative_evidence))
check("f4b_no_bid_now_no_requirement_review",
      parent.classification != LiveClassification.BID_NOW and parent.requirement_reviewed_at is None
      and bool(parent.attachment_gap), classification=str(parent.classification),
      requirement_reviewed_at=parent.requirement_reviewed_at, attachment_gap=parent.attachment_gap)
run_blob = run.model_dump_json()
check("f4c_run_json_carries_no_attachment_instant",
      not any(i.isoformat() in run_blob or i.isoformat().replace("+00:00", "Z") in run_blob
              for i in attachment_instants))

failures = [c["name"] for c in checks if not c["ok"]]
out = {"probe": "dossier_assess_clock", "checks": checks, "failures": failures,
       "dossier_accepts_future_retrieved_at": future_accepted,
       "base_dossier_accepts_future_retrieved_at": base_results["future"]["status"] == "discovery_only",
       "status": "PASS" if not failures else "FAIL",
       "observed": (f"dossier accepts future attachment retrieved_at={future_accepted} (base same={base_results['future']['status'] == 'discovery_only'}), "
                    f"rejects naive; strict Assess: attachment clock never becomes acquisition, "
                    f"classification={parent.classification}, requirement_reviewed_at=None; failures={failures}")}
print(json.dumps(out, indent=2, default=str))
shutil.rmtree(TEXT_DIR, ignore_errors=True)
sys.exit(0 if not failures else 1)
