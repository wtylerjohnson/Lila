"""Independent FABLE-STEP6-051 hostile probes.

Author-owned checks. Do not treat producer exit-0 or producer strings as proof.
Synthetic original-shaped inputs only. No live search, paid enrichment, or
frozen-case mutation.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import traceback
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

SRC = Path("/workspace")
OUT = Path(os.environ.get("NEW_ABSOLUTE_RUN", "/tmp/fable-step6-051/probes/run-01"))
OUT.mkdir(parents=True, exist_ok=False)
os.environ.update(
    PYTHONDONTWRITEBYTECODE="1",
    LILA_SUITE_OFFLINE="1",
    LILA_SUITE_STRICT="1",
    TMPDIR=str(OUT),
)
sys.dont_write_bytecode = True
sys.path.insert(0, str(SRC))
os.chdir(OUT)

from tests.test_native_notice_bridge import graph_fixture, original_fixture, write, NOW  # noqa: E402
from agents.golden_press.retrieval import run_l1_from_sweep  # noqa: E402
from agents.golden_press.notice_bridge import NoticeReadContext  # noqa: E402
from agents.golden_press.evidence_pack_v2 import build_corrected_pack  # noqa: E402
from agents.golden_press.market_map_projection import attach_v2_targets  # noqa: E402
from agents.golden_press.external_product_projection import build_external_product_document  # noqa: E402
from agents.leadgen.press import PressLeadGenReceipt, run_press  # noqa: E402
from agents.decisions.triage import deterministic_prefilter  # noqa: E402
from agents.reports.facts import _buyer_map_facts, _funded_demand_facts, _Counter  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from agents.assess import ledger  # noqa: E402


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, default=str) + "\n")


def document(root, context, graph, companion=None):
    return build_external_product_document(
        market_map={},
        graph_payload=graph,
        evidence_pack=json.loads((root / "pack.json").read_text()),
        profile={},
        client_name="Testco",
        slug="testco",
        as_of=NOW.isoformat(),
        notice_context=context,
        leadgen=companion,
    ).to_dict()


def slots(doc):
    return {s["slot_id"]: s for s in doc["slots"]}


def full_companion(context, tier="LEAD_T1"):
    run = context.current_assess_run
    payload = run_press(assess=run).model_dump(mode="json")
    payload["leads"][0].update(lead_tier=tier, readiness="actionable")
    payload["leads"][0]["seller_path"].update(kind="channel_reseller", holder="Probe-only holder")
    PressLeadGenReceipt.model_validate(payload)
    return dict(
        status="complete",
        assess_run_id=run.run_id,
        assessment={"run": run.model_dump(mode="json")},
        receipt=payload,
    )


def inactivate(root):
    path = root / "data/cleaned/searches_testco.json"
    sweep = json.loads(path.read_text())
    sweep["results"]["sam.gov"][0]["raw_payload"]["active"] = "No"
    write(path, sweep)


results = []


def case(name, fn):
    try:
        detail = fn()
        results.append(dict(case=name, execution="completed", **detail))
    except Exception:
        results.append(dict(case=name, execution="error", traceback=traceback.format_exc()))
    dump("results.json", results)


def r1_current_full_companion_positive():
    root = OUT / "r1-positive"
    context, graph = graph_fixture(root)
    saved = full_companion(context, "LEAD_T2")
    doc = document(root, context, graph, saved)
    pri = slots(doc)["priority-pursuits"]["records"]
    row = slots(doc)["federal-opportunities"]["records"][0]
    dump("r1-positive.document.json", doc)
    return dict(
        verdict="HOLD" if not (len(pri) == 1 and row["lead_status"] == "LEAD_T2" and row["targets"]) else "PASS",
        priority_count=len(pri),
        lead_status=row.get("lead_status"),
        target_count=len(row.get("targets") or []),
        current_notice_admitted=row.get("current_notice_admitted"),
        notes="Current full T2 companion must retain priority and target authority.",
    )


def r1_stale_and_missing_and_unbound():
    root = OUT / "r1-stale"
    context, graph = graph_fixture(root)
    saved = full_companion(context, "LEAD_T1")
    before = document(root, context, graph, saved)
    inactivate(root)
    stale = document(root, context, graph, saved)
    missing = document(root, None, graph, saved)
    # string-id match only, mutated parent title
    unbound = deepcopy(saved)
    unbound["assessment"]["run"]["live"]["records"][0]["title"] = "Hostile retitled assessment"
    unbound_doc = document(root, context, graph, unbound)
    # different assessment id string
    wrong = deepcopy(saved)
    wrong["receipt"]["assess_run_id"] = "hostile-other-run"
    wrong["assess_run_id"] = "hostile-other-run"
    # restore source so context can accept graph, then use wrong companion
    # (source is already inactive; rebuild a fresh current graph for wrong-run)
    fresh = OUT / "r1-wrong-run"
    ctx2, graph2 = graph_fixture(fresh)
    saved2 = full_companion(ctx2, "LEAD_T1")
    saved2["receipt"]["assess_run_id"] = "hostile-other-run"
    saved2["assess_run_id"] = "hostile-other-run"
    wrong_current = document(fresh, ctx2, graph2, saved2)

    def withheld(doc):
        pri = slots(doc)["priority-pursuits"]["records"]
        row = slots(doc)["federal-opportunities"]["records"][0]
        return dict(
            priority_count=len(pri),
            lead_rows=len(row.get("lead_rows") or []),
            targets=len(row.get("targets") or []),
            saved_lead_rows=len(row.get("saved_lead_rows") or []),
            current_notice_admitted=row.get("current_notice_admitted"),
            service_fit=row.get("service_fit"),
            commercial_route=row.get("commercial_route"),
            window_state=row.get("window_state"),
            lead_status=row.get("lead_status"),
        )

    out = dict(
        before=withheld(before),
        stale=withheld(stale),
        missing=withheld(missing),
        mutated_parent_on_inactive=withheld(unbound_doc),
        wrong_run_on_current_source=withheld(wrong_current),
    )
    dump("r1-stale.summary.json", out)
    fail = []
    if out["before"]["priority_count"] != 1:
        fail.append("current companion lost positive priority")
    for key in ("stale", "missing"):
        snap = out[key]
        if snap["priority_count"] or snap["lead_rows"] or snap["targets"]:
            fail.append(f"{key} retained current authority")
        if not snap["saved_lead_rows"]:
            fail.append(f"{key} dropped saved history")
        if snap["service_fit"] != "Unverified":
            fail.append(f"{key} kept live service_fit")
    if (
        out["wrong_run_on_current_source"]["priority_count"]
        or out["wrong_run_on_current_source"]["lead_rows"]
        or out["wrong_run_on_current_source"]["targets"]
    ):
        fail.append("wrong-run companion authorized current targets")
    if not out["wrong_run_on_current_source"]["saved_lead_rows"]:
        fail.append("wrong-run dropped saved history")
    return dict(verdict="FAIL" if fail else "PASS", failures=fail, **out)


def r2_constructor_injection_and_original_pocs():
    forged = {
        "contact_name": "FABLE-INJECTED-POC",
        "contact_title": "FABLE-INJECTED-TITLE",
        "contact_email": "hostile.inject@not-a-source.test",
        "contact_phone": "424-000-9999",
        "contact_secondary_email": "hostile.second@not-a-source.test",
        "small_business_poc": "FABLE-INJECTED-SBPOC",
        "source_notice_contacts": [
            dict(name="FABLE-INJECTED-POC", email="hostile.inject@not-a-source.test")
        ],
        "sub_agency": "BUYER-COMPONENT-FORGED",
        "ceiling_dollars": 42424242,
        "estimated_value_range": "FORGED-RANGE",
        "recipient": "INCUMBENT-FORGED",
        "obligated_dollars": 42424242,
        "vehicle": "ROUTE-VEHICLE-FORGED",
        "parent_award_id": "ROUTE-AWARD-FORGED",
        "competition": "FORGED-ACCESS-OPEN",
        "incumbent_name": "INCUMBENT-FORGED",
        "incumbent_basis": "INCUMBENT-BASIS-FORGED",
        "route_organization": "ROUTE-ORG-FORGED",
        "relationship_provenance": {"commercial_route": {"evidence": "FORGED-ROUTE-EVIDENCE"}},
    }
    tokens = [
        "FABLE-INJECTED-POC",
        "hostile.inject@not-a-source.test",
        "hostile.second@not-a-source.test",
        "BUYER-COMPONENT-FORGED",
        "INCUMBENT-FORGED",
        "42424242",
        "ROUTE-VEHICLE-FORGED",
        "FORGED-ACCESS-OPEN",
        "FORGED-ROUTE-EVIDENCE",
        "FABLE-INJECTED-SBPOC",
    ]
    root = OUT / "r2-inject"
    sweep = original_fixture(root)
    records, _ = run_l1_from_sweep(sweep, ["packet capture"])
    pack = dict(client_name="Testco", generated_at=NOW.isoformat(), records=[records[0].model_dump(mode="json")])
    pack["records"][0].update(forged)
    write(root / "pack.json", pack)
    context = NoticeReadContext(root, "Testco", "testco", NOW)
    _, graph = build_corrected_pack(
        "testco",
        "Testco",
        root=root,
        pressed_pack_path=root / "pack.json",
        pack_dir=root / "output",
        notice_context=context,
    )
    mm = [asdict(r) for r in attach_v2_targets((), graph, notice_context=context)]
    doc = document(root, context, graph)
    blob = json.dumps(dict(graph=graph, market_map=mm, doc=doc), default=str)
    original_blob = json.dumps(sweep)
    leaked = [t for t in tokens if t in blob]
    original_had = [t for t in tokens if t.casefold() in original_blob.casefold()]
    facts = graph["qualified_opportunity_records"][0] if graph["qualified_opportunity_records"] else {}
    dump("r2-inject.market_map.json", mm)
    dump("r2-inject.document.json", doc)
    fail = []
    if original_had:
        fail.append("original sweep unexpectedly contained forged tokens")
    if leaked:
        fail.append("forged constructor tokens survived products")
    if facts.get("published_value") is not None:
        fail.append("constructor value became published_value")
    if facts.get("sub_agency"):
        fail.append("constructor buyer became sub_agency")
    if any(t.get("source_kind") == "published_contact" for t in facts.get("linked_targets") or []):
        fail.append("constructor contact labeled published_contact")
    if graph.get("qualified_opportunities") != ["N1"]:
        fail.append("positive admission lost after constructor mutation")

    def with_source(sweep):
        row = sweep["results"]["sam.gov"][0]
        row.update(
            sub_agency="Published Component Office",
            ceiling_dollars=0,
            small_business_poc="Published SB Office",
            contacts=[dict(name="Mapped Primary", email="mapped.primary@example.gov", contact_type="primary")],
            poc_email="mapped.primary@example.gov",
            poc_title="Published Contracting Officer",
        )
        row["raw_payload"]["pointOfContact"] = [
            dict(fullName="Mapped Primary", email="mapped.primary@example.gov", phone="202-555-1001", type="primary"),
            dict(fullName="Raw Secondary", email="raw.secondary@example.gov", title="Program Analyst", type="secondary"),
            dict(fullName="Phone Only", phone="202-555-1003", type="secondary"),
        ]

    pos = OUT / "r2-poc-positive"
    context2, graph2 = graph_fixture(pos, with_source)
    facts2 = graph2["qualified_opportunity_records"][0]
    contacts = [t for t in facts2["linked_targets"] if t["source_kind"] == "published_contact"]
    mm2 = [asdict(r) for r in attach_v2_targets((), graph2, notice_context=context2)]
    serialized = json.dumps(dict(facts=facts2, map=mm2), default=str)
    needed = (
        "mapped.primary@example.gov",
        "raw.secondary@example.gov",
        "202-555-1003",
        "Published SB Office",
        "Published Component Office",
    )
    missing = [t for t in needed if t not in serialized]
    if facts2.get("published_value") != 0:
        fail.append("published zero did not survive")
    if len(contacts) < 4:
        fail.append(f"expected >=4 published contacts, got {len(contacts)}")
    if missing:
        fail.append(f"original POC tokens missing: {missing}")
    titles = {c["name"]: c.get("title") for c in contacts}
    if titles.get("Phone Only") not in (None, ""):
        fail.append("phone-only POC invented a title")
    return dict(
        verdict="FAIL" if fail else "PASS",
        failures=fail,
        leaked_tokens=leaked,
        original_had_forged=original_had,
        published_value=facts.get("published_value"),
        positive_published_value=facts2.get("published_value"),
        positive_contact_count=len(contacts),
        positive_titles=titles,
        native_map_after_inject=len(mm),
        native_map_positive=len(mm2),
    )


def r3_closed_representative_and_history():
    def amended(sweep):
        old = sweep["results"]["sam.gov"][0]
        old["raw_payload"].update(solicitation="HOSTILE-FULL-ID-1", office="Office")
        latest = deepcopy(old)
        latest.update(
            source_id="N2",
            title="Hostile closed successor",
            posted_date="2026-07-09",
            api_url="https://sam.gov/opp/N2/view",
        )
        latest["raw_payload"].update(
            notice_id="N2",
            active="No",
            description_snippet="Hostile closed successor",
        )
        sweep["results"]["sam.gov"].append(latest)
        sweep["results"]["sam_census"]["matched"] = 2

    root = OUT / "r3-closed"
    context, graph = graph_fixture(root, amended)
    doc = document(root, context, graph)
    dump("r3-closed.document.json", doc)
    opp = slots(doc)["federal-opportunities"]["records"]
    pri = slots(doc)["priority-pursuits"]["records"]
    row = opp[0] if opp else {}
    fail = []
    if graph.get("qualified_opportunities"):
        fail.append("closed successor did not suppress qualification")
    if [r["source_id"] for r in opp] != ["N1"]:
        fail.append(f"selected-row order/backfill changed: {[r['source_id'] for r in opp]}")
    if pri:
        fail.append("closed family produced a priority")
    if (row.get("current_representative") or {}).get("source_id") != "N2":
        fail.append("current representative is not N2")
    if (row.get("current_representative") or {}).get("title") != "Hostile closed successor":
        fail.append("N2 title missing from representative")
    if (row.get("current_representative") or {}).get("source_url") != "https://sam.gov/opp/N2/view":
        fail.append("N2 link missing")
    if (row.get("current_representative") or {}).get("source_status") != "inactive or closed":
        fail.append("N2 status not closed")
    if row.get("family_member_ids") != ["N1", "N2"]:
        fail.append(f"lineage ids {row.get('family_member_ids')}")
    members = row.get("family_members") or []
    if not members or members[0].get("superseded_by") != "N2":
        fail.append("N1 suppression edge missing")
    if row.get("response_date") not in ("", None) and row.get("current_notice_admitted"):
        fail.append("stale live response advertised as current")
    if not row.get("selected_response_date"):
        fail.append("selected-row historical deadline dropped")
    return dict(
        verdict="FAIL" if fail else "PASS",
        failures=fail,
        qualified=graph.get("qualified_opportunities"),
        selected_ids=[r["source_id"] for r in opp],
        representative=row.get("current_representative"),
        family_member_ids=row.get("family_member_ids"),
        window_state=row.get("window_state"),
        response_date=row.get("response_date"),
        selected_response_date=row.get("selected_response_date"),
    )


def triage_independent_full_ids():
    taxonomy = CapabilityTaxonomy(
        client_name="Synthetic",
        version=1,
        updated="2026-09-13",
        core=[TaxonomyTerm(term="packet capture")],
    )

    def row(sid, solicitation, posted, text, agency="Agency One", office="Office A"):
        return {
            "source": "sam.gov",
            "source_id": sid,
            "title": "Network support",
            "description": text,
            "posted_date": posted,
            "notice_type": "Solicitation",
            "raw_payload": {"solicitation": solicitation, "agency": agency, "office": office},
        }

    independent = [
        row("A1", "ALPHA-CALL-7781", "2026-07-01", "The contractor shall provide packet capture."),
        row("A2", "ALPHA-CALL-7782", "2026-07-02", "The contractor shall provide packet capture."),
    ]
    cands, ruled, receipt = deterministic_prefilter(independent, taxonomy)
    amendment = [
        row("B1", "BETA-CALL-9001", "2026-07-01", "The contractor shall provide packet capture."),
        row("B2", "BETA-CALL-9001", "2026-07-03", "The contractor shall provide packet capture and monthly reports."),
        row("C1", "BETA-CALL-9002", "2026-07-02", "The contractor shall provide packet capture."),
    ]
    cands2, ruled2, receipt2 = deterministic_prefilter(amendment, taxonomy)
    fail = []
    if [r["source_id"] for r in cands] != ["A1", "A2"]:
        fail.append(f"independent IDs collapsed: {[r['source_id'] for r in cands]}")
    if ruled:
        fail.append(f"independent IDs produced ruled rows: {list(ruled)}")
    if receipt.get("cross_post_duplicates"):
        fail.append("independent IDs counted as cross-post duplicates")
    if [r["source_id"] for r in cands2] != ["B2", "C1"]:
        fail.append(f"amendment/independent mix wrong: {[r['source_id'] for r in cands2]}")
    if ruled2.get("B1", {}).get("superseded_by") != "B2":
        fail.append("genuine amendment did not group")
    if "C1" in ruled2:
        fail.append("independent sibling collapsed into amendment thread")
    return dict(
        verdict="FAIL" if fail else "PASS",
        failures=fail,
        independent_ids=[r["source_id"] for r in cands],
        mix_ids=[r["source_id"] for r in cands2],
        mix_ruled={k: v.get("superseded_by") for k, v in ruled2.items()},
        independent_cross_posts=receipt.get("cross_post_duplicates"),
        mix_superseded=receipt2.get("superseded_revisions"),
    )


def non_c1_unsupported_action_copy():
    source = {
        "funded_demand": {
            "hits": {
                "packet capture": [
                    {
                        "title": "Budget context",
                        "collection": "BILLS",
                        "date": "2026-09-01",
                        "url": "https://www.govinfo.gov/context",
                    }
                ]
            }
        },
        "incumbent_buyer_map": {
            "buyers": [
                {
                    "buyer": "Agency",
                    "products": ["Tools"],
                    "total": 100,
                    "next_pop_end": "2026-09-14",
                    "displacement_window": True,
                    "records": [
                        {
                            "recipient": "Supplier",
                            "amount": 100,
                            "description": "Historical tools",
                            "url": "https://example.gov/award",
                        }
                    ],
                }
            ]
        },
    }
    facts = _funded_demand_facts(source, _Counter()) + _buyer_map_facts(source, {}, _Counter())
    text = " ".join(f.text for f in facts)
    banned = (
        "FUNDED-DEMAND SIGNAL",
        "DISPLACEMENT WINDOW",
        "currently funds",
        "DISPLACEMENT TARGET",
        "eligible to bid",
        "seller-ready",
    )
    present_banned = [t for t in banned if t in text]
    fail = []
    if present_banned:
        fail.append(f"invented action copy: {present_banned}")
    if "packet capture" not in text or "2026-09-14" not in text:
        fail.append("source mention/date dropped")
    if "Confirm any follow-on purchase" not in text:
        fail.append("investigation-only follow-on language dropped")
    return dict(verdict="FAIL" if fail else "PASS", failures=fail, text=text, banned_hits=present_banned)


def clocks_and_warm_inputs():
    root = OUT / "clocks"
    context, graph = graph_fixture(root)
    saved = full_companion(context)
    expected = document(root, context, graph, saved)["slots"][4]["records"][0]["source_as_of"]
    saved["evidence_clocks"] = {
        "N1": dict(source_as_of="2030-01-01T00:00:00Z", status="complete", known=1, total=1)
    }
    row = document(root, context, graph, saved)["slots"][4]["records"][0]
    missing = document(root, None, graph, saved)["slots"][4]["records"][0]
    fail = []
    if row["source_as_of"] == "2030-01-01T00:00:00Z":
        fail.append("companion clock replaced native acquisition")
    if row["source_as_of"] != expected:
        fail.append("native acquisition drifted after companion clock injection")
    if missing.get("source_as_of") is not None:
        fail.append("missing context still published source_as_of")
    if missing.get("source_clock_status") != "unverified source acquisition":
        fail.append(f"missing-context clock status {missing.get('source_clock_status')}")

    warm = OUT / "warm-source"
    context2, graph2 = graph_fixture(warm)
    assert graph2["qualified_opportunities"] == ["N1"]
    inactivate(warm)
    after = attach_v2_targets((), graph2, notice_context=context2)
    if after:
        fail.append("warm source inactivation kept market-map authority")
    if context2.unchanged():
        fail.append("warm source inactivation still reports unchanged()")

    reference_root = OUT / "warm-reference-root"
    from unittest.mock import patch

    write(reference_root / "data/reference/vehicles.json", {"vehicles": []})
    with patch.object(ledger, "_ROOT", reference_root):
        client = OUT / "warm-reference-client"
        context3, graph3 = graph_fixture(client)
        if not context3.unchanged():
            fail.append("fresh reference context not unchanged")
        write(reference_root / "data/reference/vehicles.json", {"vehicles": [{"name": "Changed reference"}]})
        if context3.unchanged():
            fail.append("warm reference change still reports unchanged()")
        if attach_v2_targets((), graph3, notice_context=context3):
            fail.append("warm reference change kept market-map authority")

    return dict(
        verdict="FAIL" if fail else "PASS",
        failures=fail,
        native_source_as_of=expected,
        after_companion_clock=row.get("source_as_of"),
        missing_context_source_as_of=missing.get("source_as_of"),
        missing_clock_status=missing.get("source_clock_status"),
        slot_count=len(document(root, context, graph)["slots"]),
    )


case("R1_current_full_companion_positive", r1_current_full_companion_positive)
case("R1_stale_missing_unbound_companion", r1_stale_and_missing_and_unbound)
case("R2_constructor_injection_and_original_pocs", r2_constructor_injection_and_original_pocs)
case("R3_closed_representative_and_history", r3_closed_representative_and_history)
case("S6_independent_full_id_triage", triage_independent_full_ids)
case("S3_SURFACE_005_non_c1_copy", non_c1_unsupported_action_copy)
case("clocks_and_warm_inputs", clocks_and_warm_inputs)

modules = {}
for name, module in list(sys.modules.items()):
    path = getattr(module, "__file__", None)
    if path:
        p = Path(path).resolve()
        try:
            if p.is_relative_to(SRC):
                modules[str(p.relative_to(SRC))] = hashlib.sha256(p.read_bytes()).hexdigest()
        except (OSError, ValueError):
            continue
lv = json.loads((SRC / "docs/verification/step6-051/root-recovery/LOCAL_VERIFICATION.json").read_text())
bound = lv["non_doc_blob_sha256"]
hash_mismatches = {
    rel: {"loaded": digest, "bound": bound.get(rel)}
    for rel, digest in modules.items()
    if rel in bound and bound[rel] != digest
}
receipt = dict(
    at_utc=datetime.now(timezone.utc).isoformat(),
    python=sys.version,
    executable=sys.executable,
    exact_sha=os.popen("git -C /workspace rev-parse HEAD").read().strip(),
    source_root=str(SRC),
    write_root=str(OUT),
    loaded_source_hashes=modules,
    loaded_hash_count=len(modules),
    hash_mismatches=hash_mismatches,
    case_count=len(results),
    all_completed=all(r.get("execution") == "completed" for r in results),
    verdicts={r["case"]: r.get("verdict") for r in results},
)
dump("run_receipt.json", receipt)
print(json.dumps({k: receipt[k] for k in ("exact_sha", "case_count", "all_completed", "verdicts", "hash_mismatches", "loaded_hash_count")}, indent=2))
print(json.dumps([{k: r[k] for k in r if k in {"case", "execution", "verdict", "failures"}} for r in results], indent=2))
