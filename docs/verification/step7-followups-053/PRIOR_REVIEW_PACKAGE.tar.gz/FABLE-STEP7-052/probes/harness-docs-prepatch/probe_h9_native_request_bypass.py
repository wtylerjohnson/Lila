"""H9: the Step7 test module restores the native _http._request inside its
http_fixture, bypassing conftest's autouse live-network observer. Measure:
 A. why it is needed: observer + mocked _client still raises under OFFLINE.
 B. restored native + mocked _client: works, and the LIVE_HTTP receipt is EMPTY.
 C. restored native + _client patch FAILED (simulated): the call reaches the
    socket layer (NETGUARD trips) and the receipt is STILL empty: an escape
    would be invisible to conftest and to LILA_SUITE_STRICT.
 D. control: observer intact + _client patch failed: receipt records it and
    OFFLINE raises before any socket.
Uses the REAL http_fixture from the test module with a minimal monkeypatch."""
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import _http  # noqa: E402
import tests.test_step7_evidence_collection as t7  # noqa: E402

NATIVE = _http._request
NATIVE_CLIENT = _http._client
LIVE = []


class MP:  # minimal monkeypatch stand-in: setattr only, manual undo
    def __init__(self):
        self.undo = []

    def setattr(self, obj, name, value):
        self.undo.append((obj, name, getattr(obj, name)))
        setattr(obj, name, value)

    def restore(self):
        for obj, name, value in reversed(self.undo):
            setattr(obj, name, value)
        self.undo.clear()


def install_observer(offline=True):
    """Replica of tests/conftest.py::_observe_live_http for _request only."""
    real = _http._request

    def _note(url):
        LIVE.append(urlsplit(str(url)).netloc)
        if offline:
            raise RuntimeError(f"offline suite: tried to reach {urlsplit(str(url)).netloc}")

    def watched(method, url, **kw):
        _note(url)
        return real(method, url, **kw)
    _http._request = watched


def attempt(label):
    try:
        out = _http.get_json("https://sam.gov/api/prod/opps/v3/opportunities/" + "a" * 32 + "/resources", retries=1)
        return {"case": label, "outcome": "returned", "value": out, "receipt": list(LIVE)}
    except Exception as exc:  # noqa: BLE001
        return {"case": label, "outcome": f"{type(exc).__name__}: {str(exc)[:160]}", "receipt": list(LIVE)}


obs = {}
# A: observer active, _client mocked via the real http_fixture minus its _request restore
LIVE.clear(); _http._request = NATIVE; _http._client = NATIVE_CLIENT
install_observer(offline=True)
mp = MP()
t7.http_fixture(mp, b'{"attachments":[]}')          # real fixture: mocks _client AND restores native
_http._request = _http._request                       # no-op; keep to show state
# undo only the _request restore so the observer is back in front
_http._request = [u for u in mp.undo if u[1] == "_request"][0][2] if any(u[1] == "_request" for u in mp.undo) else _http._request
obs["A_observer_active_client_mocked"] = attempt("A")
mp.restore(); _http._request = NATIVE; _http._client = NATIVE_CLIENT

# B: the real fixture as written (native restored + mocked client)
LIVE.clear()
install_observer(offline=True)
mp = MP()
t7.http_fixture(mp, b'{"attachments":[]}')
obs["B_fixture_as_written"] = {**attempt("B"), "request_is_native": _http._request is t7._NATIVE_REQUEST}
mp.restore(); _http._request = NATIVE; _http._client = NATIVE_CLIENT

# C: fixture restores native, but the _client patch is lost (simulated failure)
LIVE.clear()
install_observer(offline=True)
mp = MP()
t7.http_fixture(mp, b'{"attachments":[]}')
_http._client = NATIVE_CLIENT                          # simulate a failed/undone _client patch
obs["C_native_restored_client_patch_failed"] = attempt("C")
mp.restore(); _http._request = NATIVE; _http._client = NATIVE_CLIENT

# D: control, observer intact and _client patch failed
LIVE.clear()
install_observer(offline=True)
obs["D_observer_intact_client_patch_failed"] = attempt("D")
_http._request = NATIVE; _http._client = NATIVE_CLIENT

# E: observer intact, OFFLINE unset (receipt-only mode), _client patch failed
LIVE.clear()
install_observer(offline=False)
obs["E_observer_receipt_only_client_patch_failed"] = attempt("E")
_http._request = NATIVE; _http._client = NATIVE_CLIENT

escape_invisible = (obs["C_native_restored_client_patch_failed"]["receipt"] == []
                    and "NETGUARD" in obs["C_native_restored_client_patch_failed"]["outcome"])
control_visible = obs["D_observer_intact_client_patch_failed"]["receipt"] == ["sam.gov"]
pc.emit({
    "probe": "H9 native _request bypass of the suite offline observer",
    "status": "INFO" if escape_invisible and control_visible else "FAIL",
    "observed": {**obs,
                 "escape_invisible_to_conftest_receipt": escape_invisible,
                 "control_observer_would_have_caught_it": control_visible,
                 "conftest_LIVE_HTTP_records_step7_tests": False,
                 "note": "harness finding: safety rests entirely on the _client mock in the same fixture; a future edit that drops or reorders that setattr, or a code path building its own client, leaves the offline observer blind for these tests. Suite-level exposure today is nil because every Step7 test mocks _client and the module passes under a socket guard."},
})
