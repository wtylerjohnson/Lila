"""S7-LOCATOR-003: native enrichment joins up to three file texts with no
per-file positions; unsupported/restricted/unreadable/not-fetched files collapse.
Base: run BASE run_searches._enrich_sam_public_attachments with BASE
extract_public_attachment_text; Candidate: real candidate functions.
Then ask each version's dossier _attachment_research_context to attribute."""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

import tools.api.sam_quota as sam_quota  # noqa: E402
from tools.api import sam_attachment_text as cand_sat, sam_notice_detail as detail  # noqa: E402
import run_searches as cand_searches  # noqa: E402
from agents.decisions import dossier as cand_dossier  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

CAND_EXTRACT = cand_sat.extract_public_attachment_text
CAND_PRIORITY = cand_sat.attachment_priority
base_sat = pc.load_base("tools/api/sam_attachment_text.py", "base_sat")
base_searches = pc.load_base("run_searches.py", "base_run_searches")
base_dossier = pc.load_base("agents/decisions/dossier.py", "base_dossier")

sam_quota.calls_today = lambda: 0
NOTICE = "a" * 32
TERM = "network visibility"


def public_file(rid, name, **extra):
    return {"resource_id": rid, "name": name, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0", **extra}


FILES = [public_file("b" * 32, "SOW 1.txt"), public_file("c" * 32, "SOW 2.txt"),
         public_file("e" * 32, "Other.xlsx"), public_file("f" * 32, "SOW 3 Broken.pdf")]
INVENTORY = detail._manifest_hash(FILES)
TEXTS = {"b" * 32: f"Buyer requires {TERM}. Café data.", "c" * 32: f"Further {TERM} deliverables: Δ."}


def download(rid, **k):
    if rid in TEXTS:
        return TEXTS[rid].encode()
    return b"%PDF broken"


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})]


def run(searches, sat, dossier, label):
    tmp = Path(tempfile.mkdtemp(prefix=f"loc003-{label}-", dir=pc.PROBE_DIR / "out"))
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)
    detail.fetch_notice_resources = lambda *a, **k: {"id": NOTICE, "resources_checked": True,
                                                    "attachments": FILES, "attachment_inventory_hash": INVENTORY}
    sat._download_bytes = download
    sat._pdf_text = lambda *a, **k: (_ for _ in ()).throw(ValueError("PDF text extraction failed: synthetic"))
    # run_searches does `from tools.api.sam_attachment_text import extract_public_attachment_text`
    # inside the function, so point the candidate module attribute at the version under test.
    cand_sat.extract_public_attachment_text = CAND_EXTRACT if sat is cand_sat else sat.extract_public_attachment_text
    cand_sat.attachment_priority = CAND_PRIORITY if sat is cand_sat else sat.attachment_priority
    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
    raw = rows[0]["raw_payload"]
    receipt = stats["attachment_record_receipts"][NOTICE]
    ctx = dossier._attachment_research_context(rows[0], {"id": NOTICE, "resources_checked": True,
                                                         "attachment_inventory_hash": INVENTORY})
    evidence = raw.get("attachment_evidence") or []
    return {
        "receipt_status": receipt.get("status"),
        "receipt_has_files_list": "files" in receipt,
        "per_file_states": {r["resource_id"]: (r["status"], r["reason"]) for r in receipt.get("files", [])},
        "receipt_errors": receipt.get("errors"),
        "combined_text": raw.get("text"),
        "evidence_keys": sorted(evidence[0].keys()) if evidence else [],
        "has_combined_text_locator": all("combined_text_locator" in e for e in evidence) if evidence else False,
        "has_attachment_collection_v1": "attachment_collection_v1" in raw,
        "dossier_status": ctx.get("status") if ctx else None,
        "dossier_has_file_passages": bool(ctx and ctx.get("file_passages")),
        "dossier_passage_attribution": [(p["resource_id"], p["text"]) for p in (ctx or {}).get("file_passages", [])],
    }


base = run(base_searches, base_sat, base_dossier, "base")
cand = run(cand_searches, cand_sat, cand_dossier, "cand")
present_at_base = (not base["has_combined_text_locator"] and not base["receipt_has_files_list"]
                   and not base["dossier_has_file_passages"])
closed = (cand["has_combined_text_locator"] and cand["receipt_has_files_list"]
          and cand["dossier_has_file_passages"]
          and cand["per_file_states"].get("e" * 32, ("",))[0] == "not_fetched"
          and cand["per_file_states"].get("f" * 32, ("",))[0] == "unreadable"
          and all(TEXTS[rid] == text for rid, text in cand["dossier_passage_attribution"]))
pc.emit({
    "probe": "S7-LOCATOR-003 per-file locators and file states",
    "status": "PASS" if present_at_base and closed else "FAIL",
    "observed": {"base_2d522f0": base, "candidate_6b51f00": cand,
                 "defect_present_at_base": present_at_base, "closed_at_candidate": closed},
})
