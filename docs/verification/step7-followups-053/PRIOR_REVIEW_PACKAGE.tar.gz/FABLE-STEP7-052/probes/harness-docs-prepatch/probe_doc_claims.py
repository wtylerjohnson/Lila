"""Sentence-level checks of the Step7 CONVENTIONS / CONTRACT_SURFACES claims
against the real code paths (MockTransport only; sockets blocked):
 1. 'one attempt'                      : retryable 503 -> exactly one request
 2. '2MiB response cap'                : 2 MiB ok; 2 MiB + 1 -> lookup_failed, partial retained, complete=False
 3. 'retain partial/error bodies'      : 403 body retained; no cache json for either
 4. time boundary branch               : slow stream -> lookup_failed, partial, complete=False
 5. 'existing callers keep behavior'   : get_json / post_json without new kwargs unchanged
 6. 'including depth reconciliation'   : _attachment_inventory(res, id) refuses conflict
 7. real 21 captured bodies            : recognized/unrecognized census, identity live on real data
 8. six file states via REAL _download_bytes (httpx.Client swapped for MockTransport):
    403 -> inaccessible, 404 -> lookup_failed, oversize content-length -> lookup_failed,
    redirect to foreign host -> lookup_failed, empty text -> unreadable,
    unsupported type after download -> unreadable, size cap -> not_fetched,
    export-controlled -> inaccessible
 9. 'aware acquisition clock' + 'rebinds the original response': naive/future
    received_at and raw object tamper each refuse fresh inventory reuse
"""
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

A, B = "a" * 32, "b" * 32
SRC = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001")
obs = {}


def mock(handler):
    calls = []

    def wrapped(request):
        calls.append(request)
        return handler(request)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(wrapped))
    return calls


def newinv(label):
    tmp = Path(tempfile.mkdtemp(prefix=f"doc-{label}-", dir=pc.PROBE_DIR / "out"))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp)
    return tmp


def inv_summary(tmp, res):
    cap = res.get("raw_capture") or {}
    retained = None
    if cap:
        try:
            retained = len(read_retained(tmp, cap))
        except Exception as exc:  # noqa: BLE001
            retained = f"{type(exc).__name__}: {exc}"
    return {"collection_status": res.get("collection_status"), "complete": cap.get("complete"),
            "http_status": cap.get("http_status"), "captured_bytes": cap.get("bytes"),
            "retained_readable_bytes": retained, "errors": [e[:120] for e in res.get("errors", [])],
            "cache_json": sorted(p.name for p in tmp.glob("*.json"))}


# 1. one attempt
tmp = newinv("one-attempt")
calls = mock(lambda r: httpx.Response(503, content=b"busy"))
res = detail.fetch_notice_resources(A)
obs["1_one_attempt"] = {"requests_made": len(calls), **inv_summary(tmp, res)}

# 2. 2 MiB cap
CAP = 2 * 1024 * 1024
prefix, suffix = b'{"attachments":[],"pad":"', b'"}'
exact = prefix + b"x" * (CAP - len(prefix) - len(suffix)) + suffix
over = prefix + b"x" * (CAP + 1 - len(prefix) - len(suffix)) + suffix
assert len(exact) == CAP and len(over) == CAP + 1
tmp = newinv("cap-exact"); mock(lambda r: httpx.Response(200, content=exact))
obs["2_exactly_2MiB"] = inv_summary(tmp, detail.fetch_notice_resources(A))
tmp = newinv("cap-over"); mock(lambda r: httpx.Response(200, content=over))
obs["2_2MiB_plus_1"] = inv_summary(tmp, detail.fetch_notice_resources(A))

# 3. error body retained separately (no cache json)
tmp = newinv("err403"); mock(lambda r: httpx.Response(403, content=b"access denied body"))
obs["3_403_body"] = inv_summary(tmp, detail.fetch_notice_resources(A))


# 4. time boundary
class SlowStream(httpx.SyncByteStream):
    def __iter__(self):
        yield b'{"attachments":[],'
        time.sleep(0.6)
        yield b'"x":1}'


tmp = newinv("slow"); mock(lambda r: httpx.Response(200, stream=SlowStream()))
obs["4_time_boundary"] = inv_summary(tmp, detail.fetch_notice_resources(A, timeout_seconds=0.25))

# 5. existing callers unchanged
calls = mock(lambda r: httpx.Response(200, content=b'{"ok":true}'))
obs["5_existing_callers"] = {"get_json": _http.get_json("https://sam.gov/x", retries=1),
                             "post_json": _http.post_json("https://sam.gov/x", json={"a": 1}, retries=1),
                             "requests": len(calls)}

# 6. depth reconciliation refuses explicit conflict
obs["6_depth_reconciliation"] = {
    "conflict": detail._attachment_inventory({"attachments": [{"name": "x.txt", "resourceId": "d" * 32}], "opportunityId": B}, A),
    "match": detail._attachment_inventory({"attachments": [{"name": "x.txt", "resourceId": "d" * 32}], "opportunityId": A}, A)[1],
}

# 7. real bodies
census = {"recognized": 0, "unrecognized": 0, "unrecognized_ids": [], "identity_match_own_id": 0,
          "identity_refuses_other_id": 0, "no_explicit_id_bodies": []}
for body_path in sorted(SRC.glob("*.body")):
    nid = body_path.stem
    payload = json.loads(body_path.read_bytes())
    items, recognized = detail._attachment_inventory(payload, nid)
    census["recognized" if recognized else "unrecognized"] += 1
    if not recognized:
        census["unrecognized_ids"].append(nid)
    census["identity_match_own_id"] += int(detail._resource_identity_matches(payload, nid))
    other = detail._resource_identity_matches(payload, B)
    census["identity_refuses_other_id"] += int(not other)
    if other:
        census["no_explicit_id_bodies"].append(nid)
obs["7_real_bodies"] = census

# 8. six file states through the REAL _download_bytes
REAL_CLIENT = httpx.Client
EVIL = "https://evil.example.com/file"


def file_handler(request):
    url = str(request.url)
    rid = url.rsplit("/files/", 1)[-1].split("/")[0]
    if rid == "1" * 32:
        return httpx.Response(403, content=b"denied")
    if rid == "2" * 32:
        return httpx.Response(404, content=b"missing")
    if rid == "3" * 32:
        return httpx.Response(200, headers={"content-length": str(sat.MAX_ATTACHMENT_BYTES + 1)}, content=b"x")
    if rid == "4" * 32:
        return httpx.Response(302, headers={"location": EVIL})
    if url.startswith(EVIL):
        return httpx.Response(200, content=b"foreign host bytes")
    if rid == "5" * 32:
        return httpx.Response(200, content=b"   \n  ")
    if rid == "6" * 32:
        return httpx.Response(200, content=b"cells")
    if rid == "9" * 32:
        return httpx.Response(200, content=b"Good requirement text")
    return httpx.Response(500, content=b"?")


def mock_client(**kw):
    kw.pop("transport", None)
    return REAL_CLIENT(transport=httpx.MockTransport(file_handler), **kw)


sat.httpx.Client = mock_client
tmp = Path(tempfile.mkdtemp(prefix="doc-files-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)


def pf(rid, name="SOW.txt", **extra):
    return {"resource_id": rid, "name": name, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0", **extra}


cases = {
    "http_403": pf("1" * 32), "http_404": pf("2" * 32), "oversize_content_length": pf("3" * 32),
    "redirect_to_foreign_host": pf("4" * 32), "empty_text_after_download": pf("5" * 32),
    "unsupported_type_after_download": pf("6" * 32, name="Sheet.xlsx"),
    "size_cap_before_fetch": pf("7" * 32, size=sat.MAX_ATTACHMENT_BYTES + 1),
    "export_controlled": pf("8" * 32, export_controlled="1"),
    "positive_control": pf("9" * 32),
}
states = {}
for label, att in cases.items():
    r = sat.extract_public_attachment_text(att)
    states[label] = {"collection_status": r.get("collection_status"), "error": (r.get("error") or "")[:90],
                     "raw_retained": "raw_capture" in r, "text": (r.get("text") or "")[:30]}
sat.httpx.Client = REAL_CLIENT
obs["8_file_states_real_download"] = states

# 9. inventory cache: naive/future clock and raw tamper refuse fresh reuse
tmp = newinv("clock"); calls = mock(lambda r: httpx.Response(200, content=b'{"attachments":[]}'))
detail.fetch_notice_resources(A)
cache = tmp / f"{A}.resources.json"
base_saved = json.loads(cache.read_text())
out = {}
for label, mutate in (
        ("naive_received_at", lambda s: s["raw_capture"].__setitem__("received_at", "2026-09-13T00:00:00")),
        ("future_received_at", lambda s: s["raw_capture"].__setitem__("received_at", "2099-01-01T00:00:00+00:00")),
        ("raw_object_tampered", lambda s: (tmp / s["raw_capture"]["path"]).write_bytes(b'{"attachments":[{"name":"Forged.txt","resourceId":"' + b"d" * 32 + b'"}]}')),
        ("untouched_control", lambda s: None)):
    saved = json.loads(json.dumps(base_saved)); mutate(saved); cache.write_text(json.dumps(saved))
    before = len(calls)
    res = detail.fetch_notice_resources(A)
    out[label] = {"from_cache": res.get("from_cache"), "refetched": len(calls) > before,
                  "collection_status": res.get("collection_status")}
    if label == "raw_object_tampered":
        # restore a clean object for the control case
        (tmp / saved["raw_capture"]["path"]).write_bytes(b'{"attachments":[]}')
obs["9_inventory_cache_rebinding"] = out

checks = {
    "one_attempt": obs["1_one_attempt"]["requests_made"] == 1,
    "cap_exact_ok": obs["2_exactly_2MiB"]["collection_status"] == "confirmed_empty" and obs["2_exactly_2MiB"]["complete"] is True,
    "cap_over_partial": obs["2_2MiB_plus_1"]["collection_status"] == "lookup_failed" and obs["2_2MiB_plus_1"]["complete"] is False and obs["2_2MiB_plus_1"]["captured_bytes"] == CAP,
    "error_body_retained_no_cache": obs["3_403_body"]["retained_readable_bytes"] == len(b"access denied body") and obs["3_403_body"]["cache_json"] == [],
    "time_boundary_partial": obs["4_time_boundary"]["collection_status"] == "lookup_failed" and obs["4_time_boundary"]["complete"] is False,
    "existing_callers": obs["5_existing_callers"]["get_json"] == {"ok": True} and obs["5_existing_callers"]["requests"] == 2,
    "depth_refuses_conflict": obs["6_depth_reconciliation"]["conflict"] == (None, False),
    "real_census_17_4": (census["recognized"], census["unrecognized"]) == (17, 4),
    "file_states": (states["http_403"]["collection_status"] == "inaccessible"
                    and states["http_404"]["collection_status"] == "lookup_failed"
                    and states["oversize_content_length"]["collection_status"] == "lookup_failed"
                    and states["redirect_to_foreign_host"]["collection_status"] == "lookup_failed"
                    and states["empty_text_after_download"]["collection_status"] == "unreadable"
                    and states["size_cap_before_fetch"]["collection_status"] == "not_fetched"
                    and states["export_controlled"]["collection_status"] == "inaccessible"
                    and states["positive_control"]["collection_status"] == "captured_discovery_only"),
    "inventory_rebinding": all(v["refetched"] for k, v in out.items() if k != "untouched_control") and out["untouched_control"]["from_cache"] is True,
}
pc.emit({"probe": "Step7 doc sentence checks", "status": "PASS" if all(checks.values()) else "FAIL",
         "observed": {**obs, "checks": checks,
                      "notes": ["'unsupported type after download' is classified unreadable (bytes retained); reachable only by direct call since run_searches filters by extension first",
                                "partial/error bodies are retained as objects/<sha>.bin with the receipt only in the returned dict (and the sweep record receipt); no cache json names them, so an orphaned blob has no on-disk receipt outside the saved sweep"]}})
