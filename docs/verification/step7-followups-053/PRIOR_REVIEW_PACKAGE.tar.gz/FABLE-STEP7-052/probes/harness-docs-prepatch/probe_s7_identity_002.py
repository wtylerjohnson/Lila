"""S7-IDENTITY-002: resources body for requested notice a*32 explicitly names b*32.
Base claim: accepted, resources_checked=True. Candidate claim: identity_mismatch.
Also measures the SCOPE of the candidate check (doc: 'reject ANY conflicting
original notice ID'): href-only conflict, snake/lower-case key variants, and
a case-variant of the same id. Real fetch_notice_resources, MockTransport."""
import json
import os
import sys
import tempfile
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand_detail  # noqa: E402

base_detail = pc.load_base("tools/api/sam_notice_detail.py", "base_detail")

A, B = "a" * 32, "b" * 32
ROW = {"name": "Wrong notice SOW.txt", "resourceId": "d" * 32}


def serve(body: bytes, status=200):
    calls = []

    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=body)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def fetch(module, label, body, notice_id=A):
    tmp = Path(tempfile.mkdtemp(prefix=f"id002-{label}-", dir=pc.PROBE_DIR / "out"))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp)
    calls = serve(body)
    res = module.fetch_notice_resources(notice_id)
    return {"calls": len(calls), "resources_checked": res.get("resources_checked"),
            "collection_status": res.get("collection_status"),
            "attachment_names": [a.get("name") for a in (res.get("attachments") or [])],
            "errors": res.get("errors"), "cache_written": sorted(p.name for p in tmp.glob("*.json"))}


explicit = json.dumps({"attachments": [ROW], "opportunityId": B}).encode()
href_only = json.dumps({"_embedded": {"opportunityAttachmentList": [{"attachments": [ROW]}]},
                        "_links": {"self": {"href": f"https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources"}}}).encode()
snake_key = json.dumps({"attachments": [ROW], "opportunity_id": B}).encode()
lower_key = json.dumps({"attachments": [ROW], "noticeid": B}).encode()
nested_string = json.dumps({"attachments": [ROW], "meta": f"opportunityId={B}"}).encode()
same_id_upper = json.dumps({"attachments": [ROW], "opportunityId": A.upper()}).encode()

obs = {
    "explicit_conflict": {"base": fetch(base_detail, "base", explicit),
                          "candidate": fetch(cand_detail, "cand", explicit)},
    "href_only_conflict_candidate": fetch(cand_detail, "cand-href", href_only),
    "snake_key_conflict_candidate": fetch(cand_detail, "cand-snake", snake_key),
    "lowercase_key_conflict_candidate": fetch(cand_detail, "cand-lower", lower_key),
    "string_embedded_conflict_candidate": fetch(cand_detail, "cand-str", nested_string),
    "same_id_uppercase_candidate": fetch(cand_detail, "cand-upper", same_id_upper),
}
present_at_base = obs["explicit_conflict"]["base"]["resources_checked"] is True
closed = (obs["explicit_conflict"]["candidate"]["collection_status"] == "identity_mismatch"
          and obs["explicit_conflict"]["candidate"]["resources_checked"] is False
          and obs["explicit_conflict"]["candidate"]["cache_written"] == [])
scope_gaps = [k for k in ("href_only_conflict_candidate", "snake_key_conflict_candidate",
                          "lowercase_key_conflict_candidate", "string_embedded_conflict_candidate")
              if obs[k]["resources_checked"] is True]
pc.emit({
    "probe": "S7-IDENTITY-002 explicit wrong-notice inventory",
    "status": "PASS" if present_at_base and closed else "FAIL",
    "observed": {**obs, "defect_present_at_base": present_at_base, "closed_at_candidate": closed,
                 "identity_check_scope_gaps_accepted_as_this_notice": scope_gaps,
                 "same_id_case_variant_result": obs["same_id_uppercase_candidate"]["collection_status"],
                 "note": "scope gaps are doc_overstatement evidence for CONTRACT_SURFACES 'reject any conflicting original notice ID'; real SAM bodies (17/21) carry opportunityId so the explicit check is live on real data; the 4 remaining real bodies are _links-only"},
})
