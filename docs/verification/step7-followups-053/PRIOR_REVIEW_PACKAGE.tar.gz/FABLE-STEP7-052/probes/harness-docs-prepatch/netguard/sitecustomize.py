"""Probe-only network guard: any socket connect attempt raises loudly."""
import socket

_ORIG_CONNECT = socket.socket.connect
_ORIG_CONNECT_EX = socket.socket.connect_ex


def _blocked(self, address, *args, **kwargs):
    raise RuntimeError(f"NETGUARD: blocked socket connect to {address!r}")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
