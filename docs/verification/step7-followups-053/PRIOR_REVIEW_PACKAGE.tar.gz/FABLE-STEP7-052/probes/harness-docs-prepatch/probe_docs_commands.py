"""(d) Are the REVIEW.md / FABLE_HANDOFF.md / COMMANDS.json commands exactly
runnable from the review clone? Runs the focused pytest command (with the
review clone's own venv python, since bare `python` is absent on this host),
records the literal-interpreter availability, and folds in the exit codes of
the already-run full-suite and handoff driver logs in this probe dir."""
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

os.chdir(pc.REPO)
LOGS = pc.PROBE_DIR / "logs"
VENV = pc.REPO / ".venv/bin/python"
FOCUSED = ("tests/test_step7_evidence_collection.py tests/test_sam_attachment_text.py tests/test_dossiers.py "
           "tests/test_native_notice_bridge.py tests/test_native_surface_contract.py tests/test_assess_source_clock.py "
           "tests/test_assess_ledger.py tests/test_external_notice_authority.py tests/test_step6_material_source.py "
           "tests/test_triage_prefilter.py").split()
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "LILA_SUITE_OFFLINE": "1", "LILA_SUITE_STRICT": "1",
       "PYTHONPATH": str(pc.PROBE_DIR / "netguard")}
proc = subprocess.run([str(VENV), "-m", "pytest", *FOCUSED, "-q", "-p", "no:cacheprovider"],
                      capture_output=True, text=True, env=env, timeout=600)
(LOGS / "review_focused_command_netguard.log").write_text(proc.stdout + proc.stderr + f"\nexit={proc.returncode}\n")
summary = re.findall(r"(\d+) passed", proc.stdout)
focused_passed = int(summary[-1]) if summary else None


def tail_summary(name):
    text = (LOGS / name).read_text()
    m = re.findall(r"^(\d+ passed.*)$", text, flags=re.M)
    exit_code = re.findall(r"exit=(\d+)", text)
    return {"summary": m[-1] if m else None, "exit": int(exit_code[-1]) if exit_code else None}


commands = json.loads((pc.REPO / "docs/verification/step7-052/COMMANDS.json").read_text())
status = subprocess.run(["git", "-C", str(pc.REPO), "status", "--porcelain"], capture_output=True, text=True).stdout
obs = {
    "literal_python_on_PATH": shutil.which("python"),
    "python3_on_PATH": shutil.which("python3"),
    "review_clone_venv_python": str(VENV) if VENV.exists() else None,
    "COMMANDS_json_interpreter": commands["focused"]["command"].split(" -m pytest")[0].split()[-1],
    "COMMANDS_json_interpreter_is_review_clone_venv": commands["focused"]["command"].split(" -m pytest")[0].split()[-1] == str(VENV),
    "COMMANDS_json_full_cwd": commands["full"]["cwd"],
    "COMMANDS_json_junit_path_outside_review_clone": commands["full"]["command"].split("--junitxml=")[-1],
    "review_focused_passed": focused_passed, "producer_focused_passed": commands["focused"]["passed"],
    "review_focused_exit": proc.returncode,
    "review_full_suite_netguard": tail_summary("review_full_suite_netguard.log"),
    "producer_full_result": commands["full"]["result"],
    "handoff_replay_exit": int(re.findall(r"exit=(\d+)", (LOGS / "handoff_replay_ihs.log").read_text())[-1]) if re.findall(r"exit=(\d+)", (LOGS / "handoff_replay_ihs.log").read_text()) else "see log",
    "handoff_replay_result": json.loads((pc.PROBE_DIR / "out/handoff-native-replay/RESULT.json").read_text()) if (pc.PROBE_DIR / "out/handoff-native-replay/RESULT.json").exists() else None,
    "handoff_boundary_result": json.loads((pc.PROBE_DIR / "out/handoff-boundary-probe/RESULT.json").read_text()) if (pc.PROBE_DIR / "out/handoff-boundary-probe/RESULT.json").exists() else None,
    "review_clone_status_porcelain_empty": status.strip() == "",
}
ok = (focused_passed == 201 and proc.returncode == 0 and obs["review_full_suite_netguard"]["exit"] == 0
      and obs["review_clone_status_porcelain_empty"])
pc.emit({"probe": "docs command runnability", "status": "PASS" if ok else "FAIL", "observed": {**obs, "note": "REVIEW.md says 'local configured Python or equivalent'; bare `python` does not exist on this host, so the exact text is not runnable verbatim; with the clone's .venv it is. COMMANDS.json points at /Users/wtjohnson/Lila/.venv and a Codex cwd/junit path, both outside the review clone (record only; not executed)."}})
