"""Is test_collected_attachment_text_cannot_supply_strict_notice_requirement
discriminating? Build the untouched _sweep() and read the same three fields
the test asserts; if they already hold without any attachment text, the test
cannot fail on a regression that lets attachment text grant approval unless
that regression also changes the baseline. Also show which path DOES flip the
record (approved requirement review), to bound what the assertion guards."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)
import tempfile  # noqa: E402

from agents.assess.contracts import LiveClassification  # noqa: E402
from tests.test_assess_ledger import _sweep, _build, _build_with_requirement_review  # noqa: E402
import tests.test_step7_evidence_collection as t7  # noqa: E402


class MP:
    def setenv(self, k, v):
        os.environ[k] = v

    def setattr(self, obj, name, value=None):
        if isinstance(obj, str):  # pytest's dotted form: setattr("mod.attr", value)
            import importlib
            mod, attr = obj.rsplit(".", 1)
            setattr(importlib.import_module(mod), attr, name)
        else:
            setattr(obj, name, value)


def fields(run, notice_id="N1"):
    rec = next(r for r in run.live.records if r.notice_id == notice_id)
    return {"classification": str(rec.classification), "requirement_reviewed_at": rec.requirement_reviewed_at,
            "attachment_gap": rec.attachment_gap, "is_BID_NOW": rec.classification == LiveClassification.BID_NOW}


baseline_run, _, _ = _build(_sweep())
baseline = fields(baseline_run)

tmp = Path(tempfile.mkdtemp(prefix="vacuity-", dir=pc.PROBE_DIR / "out"))
row, stats, inventory, texts = t7.native_collection(tmp, MP(), notice_id="N1", term="packet capture")
sweep = _sweep(); original = sweep["results"]["sam.gov"][0]
original["source_id"] = row["source_id"]; original["raw_payload"].update(row["raw_payload"])
with_attachments = fields(_build(sweep)[0])

# what does flip the record: an approved human requirement review (Step6 path)
try:
    reviewed_run = _build_with_requirement_review(_sweep())
    reviewed_run = reviewed_run[0] if isinstance(reviewed_run, tuple) else reviewed_run
    reviewed = fields(reviewed_run)
except Exception as exc:  # noqa: BLE001
    reviewed = {"error": f"{type(exc).__name__}: {str(exc)[:200]}"}

asserts = ("is_BID_NOW", "requirement_reviewed_at", "attachment_gap")
baseline_already_satisfies = (not baseline["is_BID_NOW"] and baseline["requirement_reviewed_at"] is None
                              and bool(baseline["attachment_gap"]))
pc.emit({
    "probe": "strict-refusal test discriminating power",
    "status": "INFO",
    "observed": {
        "baseline_without_attachment_text": baseline,
        "with_step7_attachment_text": with_attachments,
        "with_approved_requirement_review_control": reviewed,
        "baseline_already_satisfies_all_three_asserts": baseline_already_satisfies,
        "attachment_text_changed_any_asserted_field": any(baseline[k] != with_attachments[k] for k in asserts),
        "verdict": ("test is a regression guard only: its three asserts hold on the untouched sweep, so it "
                    "cannot tell 'attachment text was refused' from 'nothing consumed attachment text'"
                    if baseline_already_satisfies else "test discriminates"),
    },
})
