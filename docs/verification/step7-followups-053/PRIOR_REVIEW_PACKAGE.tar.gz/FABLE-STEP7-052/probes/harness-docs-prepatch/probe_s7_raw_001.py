"""S7-RAW-001: parse failure after a successful download.
Base claim: bytes, hash and clock are discarded. Candidate claim: raw bytes are
retained content-addressed, sha256/clock survive, status is `unreadable`.
Runs the REAL extract_public_attachment_text of both versions."""
import hashlib
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import sam_attachment_text as cand_sat  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

base_sat = pc.load_base("tools/api/sam_attachment_text.py", "base_sat")

PAYLOAD = b"%PDF-1.4 broken original bytes"
ATTACHMENT = {"resource_id": "b" * 32, "name": "SOW.pdf", "access_level": "public",
              "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def parse_fail(*a, **k):
    raise ValueError("unreadable pdf")


def run(module, label):
    tmp = Path(tempfile.mkdtemp(prefix=f"raw001-{label}-", dir=pc.PROBE_DIR / "out"))
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)
    module._download_bytes = lambda *a, **k: PAYLOAD
    module._text_from_bytes = parse_fail
    result = module.extract_public_attachment_text(dict(ATTACHMENT))
    objects = sorted(p.name for p in (tmp / "objects").glob("*")) if (tmp / "objects").exists() else []
    cache_files = sorted(p.name for p in tmp.glob("*.json"))
    retained = None
    if result.get("raw_capture"):
        try:
            retained = read_retained(tmp, result["raw_capture"]) == PAYLOAD
        except Exception as exc:  # noqa: BLE001
            retained = f"read_retained failed: {exc}"
    return {
        "result_keys": sorted(result.keys()),
        "collection_status": result.get("collection_status"),
        "sha256_matches_payload": result.get("sha256") == hashlib.sha256(PAYLOAD).hexdigest(),
        "retrieved_at_present": bool(result.get("retrieved_at")),
        "error": result.get("error"),
        "text": result.get("text"),
        "objects_on_disk": objects,
        "cache_json_written": cache_files,
        "raw_bytes_readable_via_read_retained": retained,
    }


base = run(base_sat, "base")
cand = run(cand_sat, "cand")
defect_present_at_base = (not base["sha256_matches_payload"] and not base["objects_on_disk"]
                          and base["collection_status"] is None)
closed_at_candidate = (cand["collection_status"] == "unreadable" and cand["sha256_matches_payload"]
                       and cand["retrieved_at_present"] and cand["raw_bytes_readable_via_read_retained"] is True
                       and cand["cache_json_written"] == [])
pc.emit({
    "probe": "S7-RAW-001 parse failure keeps acquired bytes",
    "status": "PASS" if defect_present_at_base and closed_at_candidate else "FAIL",
    "observed": {"base_2d522f0": base, "candidate_6b51f00": cand,
                 "defect_present_at_base": defect_present_at_base,
                 "closed_at_candidate": closed_at_candidate,
                 "note": "candidate writes no <rid>.json for the failed parse (only the objects/ blob), so the unreadable state is not cached; every later sweep re-downloads and re-parses this file"},
})
