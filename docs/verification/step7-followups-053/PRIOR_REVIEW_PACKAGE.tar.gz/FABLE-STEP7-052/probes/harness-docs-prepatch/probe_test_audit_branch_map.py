"""Mechanical branch-to-test map for the Step7 delta. Every state literal,
receipt reason and refusal reason introduced by 2d522f0..6b51f00 is searched
across tests/*.py. Zero hits = no test names that branch. A literal hit is a
necessary, not sufficient, sign of coverage; semantic-only coverage is noted."""
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

os.chdir(pc.REPO)
TESTS = sorted((pc.REPO / "tests").glob("*.py"))
SOURCES = {p.name: p.read_text() for p in TESTS}

BRANCHES = {
    # inventory states (sam_notice_detail.fetch_notice_resources)
    "inv:confirmed_empty": "confirmed_empty",
    "inv:unrecognized_inventory": "unrecognized_inventory",
    "inv:identity_mismatch": "identity_mismatch",
    "inv:lookup_failed": "lookup_failed",
    "inv:inventory_captured": "inventory_captured",
    "inv:stale_inventory": "stale_inventory",
    "inv:refresh_attempt receipt": "refresh_attempt",
    "inv:cache id differs from filename": "cached.get(\"id\") != notice_id",
    "inv:corrupt cache json": ".resources.json",
    # _resource_capture_valid refusals (no literal reasons; keys)
    "inv:capture complete/http_status check": "http_status",
    "inv:capture source_url check": "source_url",
    "inv:capture received_at aware/future": "received_at",
    # _http streaming capture
    "http:byte boundary": "byte boundary",
    "http:time boundary": "time boundary",
    "http:observer on non-streaming path": "response_observer",
    # sam_capture
    "cap:retained SAM bytes changed": "retained SAM bytes changed",
    "cap:invalid retained SAM digest": "invalid retained SAM digest",
    "cap:invalid retained SAM locator": "invalid retained SAM locator",
    "cap:retained SAM object escaped cache": "escaped cache",
    # file states (sam_attachment_text)
    "file:captured_discovery_only": "captured_discovery_only",
    "file:unreadable": "unreadable",
    "file:inaccessible": "inaccessible",
    "file:not_fetched": "not_fetched",
    "file:not_fetched via size cap ('exceeds')": "attachment exceeds",
    "file:invalid attachment size": "invalid attachment size",
    "file:export-controlled -> inaccessible": "export-controlled",
    "file:explicit-access -> inaccessible": "explicit-access",
    "file:attachment yielded no readable text": "yielded no readable text",
    "file:text_capture object": "text_capture",
    "file:attachment_binding_sha256": "attachment_binding_sha256",
    "file:extraction_limits": "extraction_limits",
    "file:text_locator": "text_locator",
    "file:request_started_at": "request_started_at",
    # run_searches receipts
    "rs:IDENTITY_MISMATCH receipt": "IDENTITY_MISMATCH",
    "rs:inventory_receipt": "inventory_receipt",
    "rs:stage time budget exhausted": "stage time budget exhausted",
    "rs:outside file/type budget": "outside file/type budget",
    "rs:collected within declared budget": "collected within declared budget",
    "rs:text_unavailable fallback": "text_unavailable",
    "rs:file_text_truncated": "file_text_truncated",
    "rs:combined_text_locator": "combined_text_locator",
    "rs:attachment_collection_v1": "attachment_collection_v1",
    "rs:attachment_collection_sha256": "attachment_collection_sha256",
    # dossier refusals / outputs
    "doss:collection receipt is malformed": "collection receipt is malformed",
    "doss:does not bind this notice/text/inventory": "does not bind this notice",
    "doss:file locator is missing": "file locator is missing",
    "doss:file locator does not match retained text": "does not match retained text",
    "doss:file locators leave unbound text": "leave unbound text",
    "doss:file_passages": "file_passages",
    "doss:included_end": "included_end",
    "doss:collection_sha256 in result": "collection_sha256",
    "doss:truncated passage (14000 cap)": "14000",
}

result = {}
for label, needle in BRANCHES.items():
    hits = {name: len(re.findall(re.escape(needle), src)) for name, src in SOURCES.items()}
    hits = {k: v for k, v in hits.items() if v}
    result[label] = {"needle": needle, "hits": hits}

untested = sorted(k for k, v in result.items() if not v["hits"])
only_step7 = sorted(k for k, v in result.items() if v["hits"] and set(v["hits"]) == {"test_step7_evidence_collection.py"})
# state literal counts inside the Step7 module itself
t7 = SOURCES["test_step7_evidence_collection.py"]
inv_states = ["confirmed_empty", "unrecognized_inventory", "identity_mismatch", "lookup_failed", "inventory_captured", "stale_inventory"]
file_states = ["captured_discovery_only", "lookup_failed", "unreadable", "inaccessible", "identity_mismatch", "not_fetched"]
pc.emit({
    "probe": "branch-to-test map for the Step7 delta",
    "status": "INFO",
    "observed": {
        "branches_with_zero_test_hits": untested,
        "branches_hit_only_by_test_step7_evidence_collection": only_step7,
        "inventory_states_asserted_in_step7_module": [s for s in inv_states if f"'{s}'" in t7],
        "inventory_states_never_asserted_in_step7_module": [s for s in inv_states if f"'{s}'" not in t7],
        "file_states_asserted_in_step7_module": [s for s in file_states if f"'{s}'" in t7],
        "file_states_never_asserted_in_step7_module": [s for s in file_states if f"'{s}'" not in t7],
        "test_name_claim_check": {
            "test_native_unicode_file_locators_and_all_inventory_states_reach_dossier": {
                "asserts_inventory_states": False,
                "asserts_file_states": ["captured_discovery_only", "inaccessible", "not_fetched"],
                "file_states_absent": ["lookup_failed", "unreadable", "identity_mismatch"],
                "fetch_notice_resources_is_monkeypatched": True,
                "verdict": "name overstates: no inventory state is exercised; 3 of 6 file states are",
            },
            "test_text_cache_cannot_reuse_unbound_evidence": {
                "tampers": ["text", "raw", "identity", "metadata", "json"],
                "not_tampered": ["coherent text+text_sha256+text object rewrite (H1)", "retrieved_at moved to past (H2)", "future clock", "text_capture object removed"],
            },
            "test_inventory_cache_rebinds_raw_projection_and_changed_response": {
                "tampers": ["attachments projection"],
                "not_tampered": ["raw object bytes", "received_at", "http_status/complete", "source_url", "stale path after failed refresh"],
            },
        },
        "full_map": result,
    },
})
