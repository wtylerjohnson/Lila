"""S7-CACHE-004: attachment cache hits return unchecked JSON keyed only by
resource id. Base: a legacy <rid>.json with any text is returned from_cache.
Candidate: must refuse legacy/unbound entries and require a new attempt.
Extra cases on the candidate for the CONVENTIONS 'bind ... raw bytes, text
bytes' wording: (1) positive control: fresh capture then valid reuse;
(2) changed inventory metadata (name) refuses reuse; (3) coherent rewrite of
text + text_sha256 + new text object (H1); (4) clock moved to the past (H2);
(5) inventory cache: tampered projection + failed refresh returns as stale."""
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import _http, sam_attachment_text as cand_sat, sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402

base_sat = pc.load_base("tools/api/sam_attachment_text.py", "base_sat")

RID = "c" * 32
ATT = {"resource_id": RID, "name": "SOW.txt", "access_level": "public", "access_status": "public",
       "export_controlled": "0", "explicit_access": "0"}
LEGACY = {"resource_id": RID, "name": "SOW.txt", "text": "Historic cached requirement text.",
          "sha256": hashlib.sha256(b"old bytes").hexdigest(), "retrieved_at": "2026-07-01T00:00:00+00:00",
          "source_url": f"https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{RID}/download",
          "error": "", "from_cache": False}


def no_network(*a, **k):
    raise RuntimeError("source unavailable")


def newdir(label):
    tmp = Path(tempfile.mkdtemp(prefix=f"cache004-{label}-", dir=pc.PROBE_DIR / "out"))
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)
    return tmp


def summarize(r):
    return {"from_cache": r.get("from_cache"), "text": r.get("text"), "collection_status": r.get("collection_status"),
            "error": r.get("error")}


obs = {}
# Legacy unbound cache at base vs candidate
for label, module in (("base", base_sat), ("candidate", cand_sat)):
    tmp = newdir(label)
    (tmp / f"{RID}.json").write_text(json.dumps(LEGACY))
    module._download_bytes = no_network
    obs[f"legacy_cache_{label}"] = summarize(module.extract_public_attachment_text(dict(ATT)))

# Candidate positive control + hostile reuse cases
tmp = newdir("cand-cases")
cand_sat._download_bytes = lambda *a, **k: b"Original requirement text"
first = cand_sat.extract_public_attachment_text(dict(ATT))
cand_sat._download_bytes = no_network
obs["candidate_fresh_capture"] = summarize(first)
obs["candidate_valid_reuse"] = summarize(cand_sat.extract_public_attachment_text(dict(ATT)))
obs["candidate_changed_name_metadata"] = summarize(
    cand_sat.extract_public_attachment_text({**ATT, "name": "Changed SOW.txt"}))
cache = tmp / f"{RID}.json"
saved = json.loads(cache.read_text())
# H1 coherent rewrite: new text, new text object, new text hash; raw untouched
forged = "Invented requirement: buyer shall procure accounts payable recovery audit."
saved["text"] = forged
saved["text_capture"] = retain_bytes(tmp, forged.encode())
saved["text_sha256"] = hashlib.sha256(forged.encode()).hexdigest()
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": len(forged)}
cache.write_text(json.dumps(saved))
obs["candidate_coherent_text_rewrite_H1"] = summarize(cand_sat.extract_public_attachment_text(dict(ATT)))
# H2 clock moved to the past
saved = json.loads(cache.read_text())
saved["retrieved_at"] = "2020-01-01T00:00:00+00:00"
cache.write_text(json.dumps(saved))
obs["candidate_clock_moved_to_past_H2"] = summarize(cand_sat.extract_public_attachment_text(dict(ATT)))
# naive clock refused (positive control for 'aware acquisition clock')
saved["retrieved_at"] = "2020-01-01T00:00:00"
cache.write_text(json.dumps(saved))
obs["candidate_naive_clock"] = summarize(cand_sat.extract_public_attachment_text(dict(ATT)))

# Inventory cache: tampered projection fails validation, refresh fails -> stale path
inv = Path(tempfile.mkdtemp(prefix="cache004-inv-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(inv)
N = "a" * 32
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
    lambda req: httpx.Response(200, content=b'{"attachments":[]}')))
detail.fetch_notice_resources(N)
saved = json.loads((inv / f"{N}.resources.json").read_text())
saved["attachments"] = [{"name": "Invented SOW.txt", "resource_id": "9" * 32}]
saved["attachment_inventory_count"] = 1
(inv / f"{N}.resources.json").write_text(json.dumps(saved))
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
    lambda req: httpx.Response(503, content=b"down")))
stale = detail.fetch_notice_resources(N)
obs["candidate_inventory_tampered_projection_failed_refresh"] = {
    "from_cache": stale.get("from_cache"), "stale_cache": stale.get("stale_cache"),
    "collection_status": stale.get("collection_status"),
    "attachments_returned": [a.get("name") for a in (stale.get("attachments") or [])],
    "refresh_attempt_status": (stale.get("refresh_attempt") or {}).get("collection_status"),
    "capture_valid_now": detail._resource_capture_valid(json.loads((inv / f"{N}.resources.json").read_text())),
}

present_at_base = obs["legacy_cache_base"]["from_cache"] is True and obs["legacy_cache_base"]["text"] == LEGACY["text"]
closed = (obs["legacy_cache_candidate"]["from_cache"] is False
          and obs["legacy_cache_candidate"]["collection_status"] == "lookup_failed"
          and obs["candidate_valid_reuse"]["from_cache"] is True
          and obs["candidate_changed_name_metadata"]["from_cache"] is False)
h1_accepted = obs["candidate_coherent_text_rewrite_H1"]["from_cache"] is True and \
    obs["candidate_coherent_text_rewrite_H1"]["text"] == forged
pc.emit({
    "probe": "S7-CACHE-004 unbound cache reuse",
    "status": "PASS" if present_at_base and closed else "FAIL",
    "observed": {**obs, "defect_present_at_base": present_at_base, "closed_at_candidate": closed,
                 "H1_coherent_rewrite_accepted_as_cached_evidence": h1_accepted,
                 "H2_past_clock_accepted": obs["candidate_clock_moved_to_past_H2"]["from_cache"] is True,
                 "note": "H1/H2 acceptance is within the local trust boundary; it bears on the CONVENTIONS wording 'bind ... raw bytes, text bytes' (text is never re-derived from raw). Inventory stale path returns the projection that just failed _resource_capture_valid, labelled stale_inventory."},
})
