"""Shared helpers for the harness-docs-prepatch probes. Loads BASE (2d522f0)
modules by file path under unique names so both versions coexist."""
import importlib.util
import json
import os
import socket
import sys
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
BASE_DIR = PROBE_DIR / "base"
REPO = Path("/Users/wtjohnson/lila-step7-052")


def block_network():
    def _blocked(self, address, *a, **k):
        raise RuntimeError(f"NETGUARD: blocked socket connect to {address!r}")
    socket.socket.connect = _blocked
    socket.socket.connect_ex = _blocked


def load_base(relpath: str, name: str):
    """Import a BASE file as module `name`; its own imports resolve to the
    candidate repo packages already on sys.path (tools.api._http etc.)."""
    path = BASE_DIR / relpath
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    before = list(sys.path)
    spec.loader.exec_module(module)
    # base run_searches inserts its own directory at sys.path[0]; undo that.
    sys.path[:] = [p for p in sys.path if Path(p).resolve() != BASE_DIR.resolve()] if len(sys.path) != len(before) else sys.path
    return module


def emit(obj):
    print(json.dumps(obj, indent=1, sort_keys=True, default=str))
