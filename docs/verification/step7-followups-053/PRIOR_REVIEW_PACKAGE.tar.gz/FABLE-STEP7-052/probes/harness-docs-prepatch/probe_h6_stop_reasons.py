"""H6 + deadline classification. CONVENTIONS: run_searches 'retains every
listed file's status and stop reason'. Stage budget = 1 s; the first file's
download sleeps past the deadline. Expected by the claim: file 1 named as a
time-budget stop, files 2 and 3 named as unattempted for time. Measured with
the REAL run_searches._enrich_sam_public_attachments and REAL
extract_public_attachment_text / _text_from_bytes (only _download_bytes and
fetch_notice_resources stubbed)."""
import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

import tools.api.sam_quota as sam_quota  # noqa: E402
from tools.api import sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0
NOTICE = "a" * 32


def pf(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0"}


FILES = [pf("b" * 32, "SOW 1.txt"), pf("c" * 32, "SOW 2.txt"), pf("d" * 32, "SOW 3.txt"), pf("e" * 32, "Other.xlsx")]
INV = detail._manifest_hash(FILES)
detail.fetch_notice_resources = lambda *a, **k: {"id": NOTICE, "resources_checked": True, "attachments": FILES,
                                                "attachment_inventory_hash": INV}


def slow_download(rid, **k):
    if rid == "b" * 32:
        time.sleep(1.3)
    return f"Buyer requires network visibility ({rid[:2]})".encode()


sat._download_bytes = slow_download


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})]


tmp = Path(tempfile.mkdtemp(prefix="h6-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "1"
tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term="network visibility")])
rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
receipt = stats["attachment_record_receipts"][NOTICE]
files = {r["resource_id"]: {"status": r["status"], "reason": r["reason"], "raw_retained": "raw_capture" in r}
         for r in receipt["files"]}
b, c, d, e = (files["b" * 32], files["c" * 32], files["d" * 32], files["e" * 32])
misclassified_deadline = b["status"] == "unreadable" and "deadline" in b["reason"] and b["raw_retained"]
unattempted_named_as_budget = c["reason"] == "stage time budget exhausted"
third_file_misattributed = d["status"] == "not_fetched" and d["reason"] == "outside file/type budget"
pc.emit({
    "probe": "H6 stop reasons under stage time exhaustion",
    "status": "FAIL" if (misclassified_deadline or third_file_misattributed) else "PASS",
    "observed": {
        "record_status": receipt["status"], "record_errors": receipt["errors"], "stage_errors": stats["attachment_errors"],
        "files": files,
        "file1_downloaded_bytes_but_deadline_hit_before_parse_is_labelled_unreadable": misclassified_deadline,
        "file2_named_as_time_stop": unattempted_named_as_budget,
        "file3_eligible_unattempted_named_outside_file_type_budget": third_file_misattributed,
        "file4_xlsx_legitimately_outside_type_budget": e,
        "note": "receipt vocabulary: 'unreadable' is documented as the parse-failure state; here the bytes were fine and the stage clock ran out between download and parse. Only the file at which the loop broke carries the time reason; later eligible files inherit the default 'outside file/type budget'.",
    },
})
