"""A content-addressed blob whose bytes no longer match its name makes
retain_bytes raise 'retained SAM bytes changed' on every future capture of the
SAME response bytes. Measure the consequence on the real paths:
 A. inventory: fresh cache, blob corrupted, server unchanged (HTTP 200 identical
    body) -> refetch happens but result is stale_inventory now and, once the
    7-day stale window is gone, lookup_failed forever while the blob is wrong.
 B. file: valid text cache, raw blob corrupted, server returns identical bytes
    -> lookup_failed with the freshly downloaded bytes dropped.
 C. base comparison: base had no blobs, so a re-download at base succeeds.
 D. legacy readability: a base-produced research row (no collection receipt)
    still yields discovery_only on the candidate dossier."""
import json
import os
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_common as pc  # noqa: E402

pc.block_network()
sys.path.insert(0, str(pc.REPO))
os.chdir(pc.REPO)

from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from agents.decisions import dossier as cand_dossier  # noqa: E402

base_sat = pc.load_base("tools/api/sam_attachment_text.py", "base_sat")
A = "a" * 32
BODY = b'{"attachments":[]}'
obs = {}

# A. inventory
inv = Path(tempfile.mkdtemp(prefix="blob-inv-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(inv)
calls = []
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
    lambda r: (calls.append(1), httpx.Response(200, content=BODY))[1]))
first = detail.fetch_notice_resources(A)
blob = inv / first["raw_capture"]["path"]
blob.write_bytes(b'{"attachments":[{"name":"Forged.txt","resourceId":"' + b"d" * 32 + b'"}]}')
second = detail.fetch_notice_resources(A)
# age the cache beyond the 7-day stale window and try again
cache = inv / f"{A}.resources.json"
saved = json.loads(cache.read_text())
old = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
saved["raw_capture"]["received_at"] = old; saved["retrieved_at"] = old
cache.write_text(json.dumps(saved))
third = detail.fetch_notice_resources(A)
obs["A_inventory"] = {
    "http_requests_made": len(calls),
    "after_blob_corruption_fresh_window": {"collection_status": second.get("collection_status"), "from_cache": second.get("from_cache"),
                                           "stale_cache": second.get("stale_cache"), "attachments": second.get("attachments"),
                                           "refresh_error": [e[:120] for e in (second.get("refresh_attempt") or {}).get("errors", [])]},
    "after_blob_corruption_stale_window_expired": {"collection_status": third.get("collection_status"), "resources_checked": third.get("resources_checked"),
                                                   "errors": [e[:120] for e in third.get("errors", [])]},
}

# B. file path (candidate) and C. base
RID = "c" * 32
ATT = {"resource_id": RID, "name": "SOW.txt", "access_level": "public", "access_status": "public",
       "export_controlled": "0", "explicit_access": "0"}
PAYLOAD = b"Buyer requires network visibility."
tmp = Path(tempfile.mkdtemp(prefix="blob-file-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp)
sat._download_bytes = lambda *a, **k: PAYLOAD
ok = sat.extract_public_attachment_text(dict(ATT))
(tmp / ok["raw_capture"]["path"]).write_bytes(b"corrupted on disk")
downloads = []
sat._download_bytes = lambda *a, **k: (downloads.append(1), PAYLOAD)[1]
again = sat.extract_public_attachment_text(dict(ATT))
obs["B_file_candidate"] = {"first": ok.get("collection_status"), "downloads_after_corruption": len(downloads),
                           "after_corruption": {"collection_status": again.get("collection_status"), "error": again.get("error"),
                                                "text": again.get("text"), "raw_capture_present": "raw_capture" in again}}
base_tmp = Path(tempfile.mkdtemp(prefix="blob-base-", dir=pc.PROBE_DIR / "out"))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base_tmp)
base_sat._download_bytes = lambda *a, **k: PAYLOAD
b1 = base_sat.extract_public_attachment_text(dict(ATT))
(base_tmp / f"{RID}.json").unlink()   # base has no blob to corrupt; a cache miss just re-downloads
b2 = base_sat.extract_public_attachment_text(dict(ATT))
obs["C_file_base"] = {"first_text": b1.get("text"), "redownload_text": b2.get("text"), "error": b2.get("error")}

# D. legacy readability on candidate dossier
legacy_row = {"source_id": A, "raw_payload": {
    "text": PAYLOAD.decode(), "attachment_evidence": [{"resource_id": RID, "name": "SOW.txt", "sha256": ok["sha256"],
                                                       "retrieved_at": ok["retrieved_at"], "source_url": ok["source_url"]}],
    "attachment_inventory_hash": "0" * 64}}
import hashlib  # noqa: E402
basis = {"files": [{"resource_id": RID, "sha256": ok["sha256"]}],
         "text_sha256": hashlib.sha256(PAYLOAD).hexdigest()}
legacy_row["raw_payload"]["attachment_evidence_sha256"] = hashlib.sha256(json.dumps(basis, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
ctx = cand_dossier._attachment_research_context(legacy_row, {"id": A, "attachment_inventory_hash": "0" * 64})
obs["D_legacy_row_on_candidate_dossier"] = {"status": ctx.get("status"), "has_file_passages": "file_passages" in ctx,
                                            "text_len": len(ctx.get("text", ""))}

blocked = (obs["A_inventory"]["after_blob_corruption_stale_window_expired"]["collection_status"] == "lookup_failed"
           and obs["B_file_candidate"]["after_corruption"]["collection_status"] == "lookup_failed"
           and obs["B_file_candidate"]["downloads_after_corruption"] == 1
           and obs["C_file_base"]["redownload_text"] == PAYLOAD.decode())
pc.emit({"probe": "corrupt content-addressed blob blocks every later capture of identical bytes",
         "status": "FAIL" if blocked else "PASS",
         "observed": {**obs, "new_defect_vs_base": blocked,
                      "note": "no-overwrite publication is honored, but the failure mode is to discard the fresh, correct bytes and fail the fetch; a one-time corruption of objects/<sha>.bin therefore poisons that notice/file until an operator repairs the blob. Errors are named in the receipt, so this is a yield/availability defect inside the local trust boundary, not silent wrong evidence."}})
