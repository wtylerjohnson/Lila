"""Extraction limits on the REAL candidate functions.

 1. 50000 chars per file (.txt 60000 chars): extracted text 50000, extraction_limits
    receipt present, text_locator end 50000; then through run_searches the
    per-file evidence flag file_text_truncated is inspected.
 2. 5 MiB: (a) inventory size over cap -> not_fetched, no download;
    (b) content-length over cap -> lookup_failed, no raw_capture;
    (c) streamed body over cap with no content-length -> lookup_failed;
    (d) exactly 5 MiB accepted (control).
 3. 100 PDF pages: a 120-page PDF yields text for pages 1..100 only, through the
    real child-process extractor.
 4. 20 s PDF parse budget: real _pdf_text timeout path (child swapped for a
    sleeper, budget lowered to 1 s) -> TimeoutError -> collection_status
    'unreadable' with raw bytes retained. Default constant checked == 20.
 5. Combined 150000 cap with defaults: third file cut by 4 chars, flagged.
 6. H5 non-default: LILA_SAM_ATTACHMENT_TEXT_CHARS raised so two files fill
    150000 -> third file locator degenerate -> dossier drops ALL research.
Base comparison: base sam_attachment_text run on the 60000-char file and on
the over-cap bodies (same truncation, no flag existed at base).
"""
import copy
import importlib.util
import io
import subprocess
import sys
import time
import types

import httpx

import _harness as H

base_dir = H.fresh_cache_dirs("limits")
from agents.decisions import dossier as dz  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

obs = {}
fails = []


def check(name, cond, detail_=None):
    obs[name] = {"ok": bool(cond), **({"detail": detail_} if detail_ is not None else {})}
    if not cond:
        fails.append(name)


REAL_DOWNLOAD = sat._download_bytes
REAL_HTTPX = sat.httpx


def mock_http(handler):
    """Route the REAL _download_bytes through a MockTransport; no socket."""
    sat._download_bytes = REAL_DOWNLOAD
    sat.httpx = types.SimpleNamespace(
        Timeout=httpx.Timeout, Client=httpx.Client,
        HTTPTransport=lambda **k: httpx.MockTransport(handler))


obs["constants"] = {"MAX_ATTACHMENT_BYTES": sat.MAX_ATTACHMENT_BYTES,
                    "MAX_ATTACHMENT_TEXT_CHARS": sat.MAX_ATTACHMENT_TEXT_CHARS,
                    "MAX_PDF_PAGES": sat.MAX_PDF_PAGES,
                    "MAX_PDF_PARSE_SECONDS": sat.MAX_PDF_PARSE_SECONDS}
check("constants_default", (sat.MAX_ATTACHMENT_BYTES, sat.MAX_ATTACHMENT_TEXT_CHARS,
                            sat.MAX_PDF_PAGES, sat.MAX_PDF_PARSE_SECONDS) == (5 * 1024 * 1024, 50000, 100, 20))

# ---- 1. per-file 50000 cap ------------------------------------------------
big = ("network visibility requirement " * 2500)[:60000]
mock_http(lambda request: httpx.Response(200, content=big.encode()))
r1 = sat.extract_public_attachment_text(H.public_file("b" * 32, "SOW.txt"))
check("1.text_capped_50000", len(r1["text"]) == 50000 and r1["collection_status"] == "captured_discovery_only",
      {"len": len(r1["text"]), "status": r1["collection_status"], "error": r1.get("error")})
check("1.extraction_limits_receipt", r1.get("extraction_limits") == {
    "max_text_characters": 50000, "max_pdf_pages": 100,
    "completeness": "bounded_extraction_not_full_document_proof"}, r1.get("extraction_limits"))
check("1.text_locator_end_50000", r1.get("text_locator") == {
    "surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": 50000})
check("1.raw_bytes_full_60000", read_retained(sat._cache_dir(), r1["raw_capture"]) == big.encode()
      and r1["raw_capture"]["bytes"] == 60000)
truncation_signal_keys = [k for k in r1 if "trunc" in k.lower()]
check("1.no_per_file_truncation_flag_in_extract_result", truncation_signal_keys == [],
      {"keys_with_trunc": truncation_signal_keys, "keys": sorted(r1)})

# through run_searches: file_text_truncated must reflect the 60000 -> 50000 cut
H.fresh_cache_dirs("limits-rs")
rows, stats, inventory = H.native_collection(
    notice_id="a" * 32, files=[H.public_file("b" * 32, "SOW.txt")], texts={"b" * 32: big})
ev = rows[0]["raw_payload"]["attachment_evidence"][0]
rc = stats["attachment_record_receipts"]["a" * 32]["files"][0]
obs["1.run_searches_evidence"] = {
    "file_text_truncated": ev["file_text_truncated"],
    "file_text_locator": ev["file_text_locator"],
    "raw_bytes": ev["raw_capture"]["bytes"],
    "text_capture_bytes": ev["text_capture"]["bytes"],
    "receipt_status": rc["status"], "receipt_reason": rc["reason"],
    "receipt_keys_with_trunc": [k for k in rc if "trunc" in k.lower()],
}
check("1.file_text_truncated_reports_extractor_cut", ev["file_text_truncated"] is True,
      "flag is False although 10000 of 60000 characters were dropped by the 50000 extractor cap")

# ---- 2. 5 MiB ---------------------------------------------------------------
H.fresh_cache_dirs("limits-5mib")
CAP = sat.MAX_ATTACHMENT_BYTES
calls = []
mock_http(lambda request: (calls.append(1), httpx.Response(200, content=b"x"))[1])
r2a = sat.extract_public_attachment_text(H.public_file("c" * 32, "Big.txt", size=str(CAP + 1)))
check("2a.size_over_cap_not_fetched", r2a["collection_status"] == "not_fetched" and not calls
      and "exceeds" in r2a["error"] and "raw_capture" not in r2a,
      {"status": r2a["collection_status"], "error": r2a["error"], "download_calls": len(calls)})
r2a2 = sat.extract_public_attachment_text(H.public_file("c" * 32, "Big.txt", size=str(CAP)))
check("2a2.size_equal_cap_fetched", r2a2["collection_status"] == "captured_discovery_only" and len(calls) == 1)

mock_http(lambda request: httpx.Response(
    200, headers={"content-length": str(CAP + 1)}, content=b"small body"))
r2b = sat.extract_public_attachment_text(H.public_file("d" * 32, "Declared.txt"))
check("2b.content_length_over_cap_lookup_failed", r2b["collection_status"] == "lookup_failed"
      and "declares" in r2b["error"] and "raw_capture" not in r2b,
      {"status": r2b["collection_status"], "error": r2b["error"]})

over = b"y" * (CAP + 1)
mock_http(lambda request: httpx.Response(200, stream=httpx.ByteStream(over)))
r2c = sat.extract_public_attachment_text(H.public_file("e" * 32, "Stream.txt"))
check("2c.streamed_over_cap_lookup_failed", r2c["collection_status"] == "lookup_failed"
      and "exceeded" in r2c["error"] and "raw_capture" not in r2c,
      {"status": r2c["collection_status"], "error": r2c["error"]})

exact = b"z" * CAP
mock_http(lambda request: httpx.Response(200, stream=httpx.ByteStream(exact)))
r2d = sat.extract_public_attachment_text(H.public_file("f" * 32, "Exact.txt"))
check("2d.exact_cap_accepted", r2d["collection_status"] == "captured_discovery_only"
      and r2d["raw_capture"]["bytes"] == CAP and len(r2d["text"]) == 50000,
      {"status": r2d["collection_status"], "raw_bytes": r2d.get("raw_capture", {}).get("bytes")})


# ---- 3. 100 pages -----------------------------------------------------------
def make_pdf(pages: int) -> bytes:
    objects = []  # list of bytes bodies, 1-indexed
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    kids = " ".join(f"{3 + 2 * i} 0 R" for i in range(pages))
    objects.append(f"<< /Type /Pages /Kids [{kids}] /Count {pages} >>".encode())
    font_obj = 3 + 2 * pages
    for i in range(pages):
        content = f"BT /F1 24 Tf 72 700 Td (Page {i + 1} marker) Tj ET".encode()
        objects.append(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 {font_obj} 0 R >> >> "
            f"/Contents {4 + 2 * i} 0 R >>".encode())
        objects.append(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for n, body in enumerate(objects, start=1):
        offsets.append(out.tell())
        out.write(f"{n} 0 obj\n".encode() + body + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objects) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


pdf120 = make_pdf(120)
t0 = time.monotonic()
pdf_text = sat._text_from_bytes("Spec.pdf", pdf120)
pdf_secs = time.monotonic() - t0
check("3.pdf_100_pages_only", "Page 100 marker" in pdf_text and "Page 101 marker" not in pdf_text
      and "Page 120 marker" not in pdf_text and "Page 1 marker" in pdf_text,
      {"len": len(pdf_text), "seconds": round(pdf_secs, 2),
       "has_p1": "Page 1 marker" in pdf_text, "has_p100": "Page 100 marker" in pdf_text,
       "has_p101": "Page 101 marker" in pdf_text})
H.fresh_cache_dirs("limits-pdf")
mock_http(lambda request: httpx.Response(200, content=pdf120))
r3 = sat.extract_public_attachment_text(H.public_file("a1" * 16, "Spec.pdf"))
check("3.pdf_capture_status", r3["collection_status"] == "captured_discovery_only"
      and "Page 101 marker" not in r3["text"] and r3["extraction_limits"]["max_pdf_pages"] == 100,
      {"status": r3["collection_status"], "error": r3.get("error")})
pages_signal = [k for k in r3 if "page" in k.lower() and k != "extraction_limits"]
obs["3.pdf_result_has_page_count_or_truncation_signal"] = pages_signal

# ---- 4. 20 s parse budget ---------------------------------------------------
H.fresh_cache_dirs("limits-timeout")
REAL_RUN = sat.subprocess.run
observed_timeout = {}


def sleepy_run(argv, **kwargs):
    observed_timeout["argv_tail"] = argv[-1]
    observed_timeout["timeout"] = kwargs.get("timeout")
    return REAL_RUN([sys.executable, "-c", "import time; time.sleep(5)"], **kwargs)


sat.MAX_PDF_PARSE_SECONDS = 1
sat.subprocess.run = sleepy_run
mock_http(lambda request: httpx.Response(200, content=pdf120))
t0 = time.monotonic()
r4 = sat.extract_public_attachment_text(H.public_file("a2" * 16, "Slow.pdf"))
elapsed = time.monotonic() - t0
sat.subprocess.run = REAL_RUN
sat.MAX_PDF_PARSE_SECONDS = 20
check("4.parse_timeout_unreadable_with_raw_retained",
      r4["collection_status"] == "unreadable" and "exceeded" in r4["error"]
      and read_retained(sat._cache_dir(), r4["raw_capture"]) == pdf120 and elapsed < 4,
      {"status": r4["collection_status"], "error": r4["error"], "elapsed": round(elapsed, 2),
       "child_timeout_passed": observed_timeout.get("timeout"), "argv_tail": observed_timeout.get("argv_tail")})
# deadline_monotonic wins when shorter than the parse budget
observed_timeout.clear()
sat.subprocess.run = sleepy_run
r4b = None
try:
    sat._pdf_text(pdf120, deadline_monotonic=time.monotonic() + 0.5)
except TimeoutError as exc:
    r4b = str(exc)
sat.subprocess.run = REAL_RUN
check("4b.stage_deadline_bounds_parse_budget", r4b is not None and observed_timeout.get("timeout", 99) <= 0.5,
      {"error": r4b, "child_timeout": observed_timeout.get("timeout")})
# not cached: a timed-out file must be retried next sweep
cache_file = sat._cache_dir() / ("a2" * 16 + ".json")
check("4c.timeout_result_not_cached", not cache_file.exists())

# ---- 5. combined 150000 with defaults --------------------------------------
sat.httpx = REAL_HTTPX
H.fresh_cache_dirs("limits-combined")
files3 = [H.public_file("b" * 32, "SOW 1.txt"), H.public_file("c" * 32, "PWS 2.txt"),
          H.public_file("d" * 32, "Spec 3.txt")]
texts3 = {"b" * 32: ("network visibility one " * 3000)[:50000],
          "c" * 32: ("two " * 20000)[:50000], "d" * 32: ("three " * 20000)[:50000]}
rows5, stats5, inv5 = H.native_collection(notice_id="a" * 32, files=files3, texts=texts3)
raw5 = rows5[0]["raw_payload"]
ev5 = raw5["attachment_evidence"]
obs["5.locators"] = [{"name": e["name"], **e["combined_text_locator"],
                      "file_text_truncated": e["file_text_truncated"],
                      "file_len": e["file_text_locator"]["end"]} for e in ev5]
len1 = len(sat._text_from_bytes("a.txt", texts3["b" * 32].encode()))
len2 = len(sat._text_from_bytes("a.txt", texts3["c" * 32].encode()))
exp_start3 = len1 + 2 + len2 + 2
check("5.combined_150000_third_cut_and_flagged", len(raw5["text"]) == 150000
      and ev5[1]["combined_text_locator"] == {"unit": "unicode_characters", "start": len1 + 2, "end": len1 + 2 + len2}
      and ev5[2]["combined_text_locator"] == {"unit": "unicode_characters", "start": exp_start3, "end": 150000}
      and ev5[2]["file_text_truncated"] is True and ev5[0]["file_text_truncated"] is False
      and ev5[1]["file_text_truncated"] is False
      and raw5["text"] == "\n\n".join(sat._text_from_bytes("a.txt", texts3[k].encode())
                                      for k in ("b" * 32, "c" * 32, "d" * 32))[:150000],
      {"len1": len1, "len2": len2, "exp_start3": exp_start3, "cut_chars": 50000 - (150000 - exp_start3)})
d5 = dz._attachment_research_context(rows5[0], {"id": "a" * 32, "resources_checked": True,
                                                "attachment_inventory_hash": inv5})
check("5.dossier_accepts_default_three_file_bundle", d5["status"] == "discovery_only"
      and len(d5["file_passages"]) == 3, d5.get("reason"))

# ---- 6. H5 non-default per-file cap ----------------------------------------
H.fresh_cache_dirs("limits-h5")
sat.MAX_ATTACHMENT_TEXT_CHARS = 80000
texts6 = {"b" * 32: ("network visibility one " * 4000)[:80000],
          "c" * 32: ("two " * 25000)[:80000], "d" * 32: ("three " * 20000)[:80000]}
rows6, stats6, inv6 = H.native_collection(notice_id="a" * 32, files=files3, texts=texts6)
sat.MAX_ATTACHMENT_TEXT_CHARS = 50000
raw6 = rows6[0]["raw_payload"]
ev6 = raw6["attachment_evidence"]
obs["6.locators"] = [{"name": e["name"], **e["combined_text_locator"],
                      "file_text_truncated": e["file_text_truncated"]} for e in ev6]
d6 = dz._attachment_research_context(rows6[0], {"id": "a" * 32, "resources_checked": True,
                                                "attachment_inventory_hash": inv6})
obs["6.dossier"] = {"status": d6["status"], "reason": d6.get("reason"), "len_text": len(raw6["text"]),
                    "third_receipt_status": stats6["attachment_record_receipts"]["a" * 32]["files"][2]["status"]}
check("6.H5_degenerate_locator_drops_whole_research", d6["status"] == "unavailable"
      and ev6[2]["combined_text_locator"]["start"] == ev6[2]["combined_text_locator"]["end"] == 150002
      and len(raw6["text"]) == 150000)
# and the legacy path (strip v1) still delivers the text: the loss is purely the new binding
legacy6 = copy.deepcopy(rows6[0])
legacy6["raw_payload"].pop("attachment_collection_v1")
legacy6["raw_payload"].pop("attachment_collection_sha256")
d6l = dz._attachment_research_context(legacy6, {"id": "a" * 32, "attachment_inventory_hash": inv6})
obs["6.legacy_path_status"] = d6l["status"]

# ---- base comparison --------------------------------------------------------
spec = importlib.util.spec_from_file_location("base_sat", str(H.PROBE_DIR / "base_sam_attachment_text.py"))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
H.fresh_cache_dirs("limits-base")
# The base copy lives in the probe dir, so its Path(__file__).parents[2] cwd for
# the PDF child points outside the repo; pin the child's cwd to the repo root.
base.subprocess.run = lambda argv, **kw: REAL_RUN(argv, **{**kw, "cwd": str(H.REPO)})
base._download_bytes = lambda rid, **k: big.encode()
b1 = base.extract_public_attachment_text(H.public_file("b" * 32, "SOW.txt"))
base._download_bytes = lambda rid, **k: pdf120
b3 = base.extract_public_attachment_text(H.public_file("a1" * 16, "Spec.pdf"))
obs["base"] = {"txt_len": len(b1["text"]), "txt_keys": sorted(b1), "pdf_error": b3.get("error"),
               "pdf_has_p101": "Page 101 marker" in b3["text"],
               "pdf_has_p100": "Page 100 marker" in b3["text"],
               "base_constants": (base.MAX_ATTACHMENT_BYTES, base.MAX_ATTACHMENT_TEXT_CHARS,
                                  base.MAX_PDF_PAGES, base.MAX_PDF_PARSE_SECONDS)}

obs["failed_checks"] = fails
H.emit("PASS" if not fails else "FAIL", obs, "extraction_limits")
