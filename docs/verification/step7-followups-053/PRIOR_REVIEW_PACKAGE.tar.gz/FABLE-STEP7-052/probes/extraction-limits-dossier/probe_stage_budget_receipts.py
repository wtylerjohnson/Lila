"""Stage time budget (LILA_SAM_ATTACHMENT_STAGE_SECONDS) receipts, real run_searches.

Scenario: budget 1 s; inventory has three supported files plus one .xlsx and one
oversized .pdf. File 1's download (mocked network) sleeps past the deadline, so
the REAL _text_from_bytes deadline check fires after bytes were acquired.
Expected per producer claims: every listed file has a status and a stop reason.
Hostile questions:
 H6. do files 2 and 3 (eligible, unattempted) report the time stop, or do they
     keep the generic "outside file/type budget" reason?
 T1. is file 1 (bytes acquired, deadline fired before parse) labelled
     'unreadable', which is the parse-failure state, although the file was
     never parsed?
 T2. do the unsupported .xlsx and over-cap .pdf keep truthful reasons?
Base comparison: base run_searches has no per-file receipts at all; the base
error list is reproduced for the record.
"""
import importlib.util
import os
import time

import _harness as H

H.fresh_cache_dirs("budget")
from tools.api import sam_attachment_text as sat  # noqa: E402

obs = {}
fails = []


def check(name, cond, detail=None):
    obs[name] = {"ok": bool(cond), **({"detail": detail} if detail is not None else {})}
    if not cond:
        fails.append(name)


NID = "a" * 32
files = [H.public_file("b" * 32, "SOW 1.txt"), H.public_file("c" * 32, "PWS 2.txt"),
         H.public_file("d" * 32, "Spec 3.txt"), H.public_file("e" * 32, "Prices.xlsx"),
         H.public_file("f" * 32, "Huge SOW.pdf", size=str(sat.MAX_ATTACHMENT_BYTES + 1))]
texts = {k * 32: f"network visibility text {k}" for k in "bcd"}
downloads = []


def slow_download(rid, **k):
    downloads.append(rid)
    time.sleep(1.2)
    return texts[rid].encode()


os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "1"
rows, stats, inventory = H.native_collection(notice_id=NID, files=files, texts=texts,
                                             download=slow_download)
os.environ.pop("LILA_SAM_ATTACHMENT_STAGE_SECONDS")
receipt = stats["attachment_record_receipts"][NID]
by_name = {r["name"]: r for r in receipt["files"]}
obs["record_status"] = receipt["status"]
obs["downloads_attempted"] = downloads
obs["stats_errors"] = stats["attachment_errors"]
obs["files"] = {name: {"status": r["status"], "reason": r.get("reason"), "error": r.get("error"),
                       "has_raw_capture": "raw_capture" in r, "retrieved_at": r.get("retrieved_at")}
                for name, r in by_name.items()}

f1 = by_name["SOW 1.txt"]
check("T1.file1_bytes_acquired_but_deadline_fired", f1.get("error") == "SAM attachment stage deadline reached"
      and "raw_capture" in f1, {"status": f1["status"], "error": f1.get("error")})
check("T1.file1_state_is_not_parse_failure", f1["status"] != "unreadable",
      "deadline stop after download is labelled 'unreadable' (the parse-failure state) "
      "although the parser never ran")
check("H6.file2_reports_time_stop", by_name["PWS 2.txt"]["status"] == "not_fetched"
      and by_name["PWS 2.txt"]["reason"] == "stage time budget exhausted", by_name["PWS 2.txt"]["reason"])
check("H6.file3_reports_time_stop", by_name["Spec 3.txt"]["reason"] == "stage time budget exhausted",
      {"reason": by_name["Spec 3.txt"]["reason"],
       "note": "eligible supported file never attempted; reason claims file/type budget"})
check("T2.xlsx_outside_type_budget", by_name["Prices.xlsx"]["status"] == "not_fetched"
      and by_name["Prices.xlsx"]["reason"] == "outside file/type budget")
check("T2.oversized_pdf_not_attempted_by_time", by_name["Huge SOW.pdf"]["status"] == "not_fetched",
      {"reason": by_name["Huge SOW.pdf"]["reason"],
       "note": "size over cap but the loop stopped first; the receipt cannot say the size reason"})
check("only_first_download_attempted", downloads == ["b" * 32])
check("record_status_text_unavailable", receipt["status"] == "TEXT_UNAVAILABLE", receipt["status"])

# T3: same shape with generous budget: control that the xlsx/oversize reasons are what
# the code CAN say when time is not the stopper.
H.fresh_cache_dirs("budget-control")
rows2, stats2, inv2 = H.native_collection(notice_id=NID, files=files, texts=texts)
r2 = {r["name"]: r for r in stats2["attachment_record_receipts"][NID]["files"]}
obs["control_files"] = {n: {"status": r["status"], "reason": r.get("reason")} for n, r in r2.items()}
check("control.three_text_files_captured", all(r2[n]["status"] == "captured_discovery_only"
                                                  for n in ("SOW 1.txt", "PWS 2.txt", "Spec 3.txt")),
      {"note": "the inventory-declared oversize 'Huge SOW.pdf' (rejected by _public_file before any "
               "download) still occupies one of the three file slots because the [:3] cut happens "
               "before size/access screening; the fetchable 'Spec 3.txt' is never attempted",
       "spec3": r2["Spec 3.txt"]})
check("control.oversized_pdf_reason_is_size", r2["Huge SOW.pdf"]["status"] == "not_fetched"
      and "exceeds" in (r2["Huge SOW.pdf"].get("reason") or ""), r2["Huge SOW.pdf"].get("reason"))
check("control.xlsx_never_attempted_reason", r2["Prices.xlsx"]["reason"] == "outside file/type budget")

# base comparison: run the base enrichment function for the record
spec = importlib.util.spec_from_file_location("base_run_searches", str(H.PROBE_DIR / "base_run_searches.py"))
base = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(base)
    H.fresh_cache_dirs("budget-base")
    import run_searches as cand
    saved = cand._enrich_sam_public_attachments
    cand._enrich_sam_public_attachments = base._enrich_sam_public_attachments
    os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "1"
    downloads.clear()
    brow, bstats, _ = H.native_collection(notice_id=NID, files=files, texts=texts, download=slow_download)
    os.environ.pop("LILA_SAM_ATTACHMENT_STAGE_SECONDS")
    cand._enrich_sam_public_attachments = saved
    obs["base"] = {"record_receipt": bstats["attachment_record_receipts"][NID],
                   "errors": bstats["attachment_errors"],
                   "has_file_receipts": "files" in bstats["attachment_record_receipts"][NID]}
except Exception as exc:  # noqa: BLE001
    obs["base"] = {"error": repr(exc)[:300]}

obs["failed_checks"] = fails
H.emit("PASS" if not fails else "FAIL", obs, "stage_budget_receipts")
