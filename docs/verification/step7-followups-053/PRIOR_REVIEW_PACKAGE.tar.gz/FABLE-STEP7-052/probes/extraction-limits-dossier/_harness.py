"""Shared harness for the extraction-limits / dossier probes.

Every probe imports this first. It blocks sockets, points both cache dirs at a
probe-local temp dir, and offers a builder that drives the REAL
run_searches._enrich_sam_public_attachments with only network and quota
monkeypatched. No LLM, no sam.gov, no writes outside the probe dir.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")


def _blocked(*args, **kwargs):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]


def fresh_cache_dirs(tag: str) -> Path:
    base = Path(tempfile.mkdtemp(prefix=f"probe-{tag}-", dir=str(PROBE_DIR / "tmp")))
    (base / "notice").mkdir()
    (base / "text").mkdir()
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(base / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base / "text")
    return base


(PROBE_DIR / "tmp").mkdir(exist_ok=True)


def public_file(resource_id: str, name: str, **extra) -> dict:
    row = {"resource_id": resource_id, "name": name, "access_level": "public",
           "access_status": "public", "export_controlled": "0",
           "explicit_access": "0"}
    row.update(extra)
    return row


def native_collection(*, notice_id: str, files: list[dict], texts: dict,
                      term: str = "network visibility", limit: int = 8,
                      download=None):
    """Run the production enrichment with mocked download/inventory/quota."""
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.api import sam_attachment_text as sat
    from tools.api import sam_notice_detail as detail
    from tools.api import sam_quota
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    sam_quota.calls_today = lambda: 0
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": notice_id, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}
    if download is None:
        def download(rid, **k):
            return texts[rid].encode("utf-8")
    sat._download_bytes = download
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id,
                               title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1,
                                  updated="2026-07-21",
                                  core=[TaxonomyTerm(term=term)])
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=limit)
    return rows, stats, inventory


class RecordingEngine:
    """Stands in for DecisionEngine; records the prompt, never calls a model."""

    def __init__(self):
        self.calls = []

    def deliberate(self, *, layer, system_prompt, context, schema, now=None):
        self.layer = layer
        self.system_prompt = system_prompt
        self.context = context
        self.calls.append((layer, system_prompt, context))
        return schema(
            id=context["notice"]["id"] or "x", title="t", scope_summary="s",
            evaluation_criteria=[], submission_requirements=[],
            incumbent_signals=[], fit_verdict="stretch", win_themes=["w"],
            red_flags=[], next_action="n")


def emit(status: str, observed: dict, name: str) -> None:
    print(json.dumps({"probe": name, "status": status, "observed": observed},
                     indent=2, default=str, sort_keys=True))
