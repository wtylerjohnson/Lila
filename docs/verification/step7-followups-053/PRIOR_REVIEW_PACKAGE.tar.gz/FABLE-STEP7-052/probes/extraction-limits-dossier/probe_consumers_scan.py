"""Who reads attachment_research / file_passages / attachment_collection_v1?

Static scan of agents/, pipeline/, tools/, run_*.py in the review clone (read-only)
plus a runtime check: research_evidence.py copies raw['attachment_research'] into
attachment_provenance when present. run_searches never writes that key; only the
dossier context carries it. Confirms no other consumer ingests file_passages.
"""
import re
from pathlib import Path

import _harness as H

REPO = H.REPO
keys = ["attachment_research", "file_passages", "attachment_collection_v1",
        "attachment_collection_sha256", "extraction_limits", "file_text_truncated",
        "combined_text_locator", "_ATTACHMENT_RESEARCH_MAX_CHARS"]
hits = {k: [] for k in keys}
targets = [p for d in ("agents", "pipeline", "tools") for p in (REPO / d).rglob("*.py")
           if (REPO / d).exists()] + sorted(REPO.glob("run_*.py"))
for path in targets:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        continue
    for n, line in enumerate(lines, 1):
        for k in keys:
            if k in line:
                hits[k].append(f"{path.relative_to(REPO)}:{n}: {line.strip()[:140]}")

# runtime: does any producer write raw['attachment_research']?
writers = [h for h in hits["attachment_research"] if re.search(r"\[\s*['\"]attachment_research['\"]\s*\]\s*=", h)]
readers_outside_dossier = [h for h in hits["attachment_research"] if not h.startswith("agents/decisions/dossier.py")]
passages_outside_dossier = [h for h in hits["file_passages"] if not h.startswith("agents/decisions/dossier.py")]
collection_readers = [h for h in hits["attachment_collection_v1"] if not h.startswith(("run_searches.py",))]

observed = {
    "scanned_files": len(targets),
    "hits": hits,
    "raw_attachment_research_writers": writers,
    "attachment_research_readers_outside_dossier": readers_outside_dossier,
    "file_passages_readers_outside_dossier": passages_outside_dossier,
    "attachment_collection_v1_readers_outside_run_searches": collection_readers,
    "note": ("research_evidence.py forwards raw['attachment_research'] into "
             "attachment_provenance if a stored row ever carries it; nothing in the "
             "candidate writes that raw key, so the only live consumer of file_passages "
             "is the dossier prompt context."),
}
H.emit("INFO", observed, "consumers_scan")
