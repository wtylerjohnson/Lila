"""Cross-process races on sam_capture.retain_bytes / read_retained (BR LIMITS gap).

The byte-retention dimension raced threads inside one process only. This probe
runs separate OS processes against one objects/ directory:
  1. many writers publishing the SAME payload concurrently;
  2. writers publishing DISTINCT payloads interleaved with the shared one;
  3. readers polling read_retained while writers publish the digest they wait for.
PASS requires: zero writer exceptions, exactly one blob per digest with the exact
bytes, no stray temp files left in objects/, and readers never observing a
"bytes changed" or partial-content error (only FileNotFoundError before publication).
"""
import hashlib
import json
import multiprocessing as mp
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

REPO = "/Users/wtjohnson/lila-step7-052"
PROBE_DIR = os.path.dirname(os.path.abspath(__file__))
TMP_ROOT = os.path.join(PROBE_DIR, "tmp")


def _writer(directory, payloads, iterations, out_q):
    sys.path.insert(0, REPO)
    from tools.api.sam_capture import retain_bytes
    errors = []
    receipts = {}
    for _ in range(iterations):
        for payload in payloads:
            try:
                receipt = retain_bytes(Path(directory), payload)
                receipts[receipt["sha256"]] = receipt
            except Exception as exc:  # noqa: BLE001 - recorded, never hidden
                errors.append(f"{type(exc).__name__}: {str(exc)[:160]}")
    out_q.put({"pid": os.getpid(), "errors": errors, "receipts": receipts})


def _reader(directory, receipt, seconds, out_q):
    sys.path.insert(0, REPO)
    from tools.api.sam_capture import read_retained
    end = time.monotonic() + seconds
    successes = not_found = 0
    other = []
    first_success_after_not_found = None
    while time.monotonic() < end:
        try:
            read_retained(Path(directory), receipt)
            successes += 1
            if first_success_after_not_found is None:
                first_success_after_not_found = not_found
        except FileNotFoundError:
            not_found += 1
        except Exception as exc:  # noqa: BLE001 - this is the failure we hunt
            other.append(f"{type(exc).__name__}: {str(exc)[:160]}")
    out_q.put({"pid": os.getpid(), "successes": successes, "not_found": not_found,
               "other_errors": other[:5], "other_error_count": len(other),
               "not_found_before_first_success": first_success_after_not_found})


def _receipt_for(payload):
    digest = hashlib.sha256(payload).hexdigest()
    return {"path": f"objects/{digest}.bin", "sha256": digest, "bytes": len(payload)}


def _inspect(directory, expected):
    objects = Path(directory) / "objects"
    names = sorted(p.name for p in objects.iterdir()) if objects.exists() else []
    blobs = [n for n in names if re.fullmatch(r"[0-9a-f]{64}\.bin", n)]
    stray = [n for n in names if n not in blobs]
    wrong = []
    for payload in expected:
        digest = hashlib.sha256(payload).hexdigest()
        path = objects / f"{digest}.bin"
        if not path.exists() or path.read_bytes() != payload:
            wrong.append(digest)
    return {"blob_count": len(blobs), "expected_blob_count": len({hashlib.sha256(p).hexdigest() for p in expected}),
            "stray_files": stray, "blobs_with_wrong_bytes": wrong}


def main():
    os.makedirs(TMP_ROOT, exist_ok=True)
    ctx = mp.get_context("spawn")
    observed = {}
    checks = {}

    # Case 1: same 512 KiB payload, 6 processes x 12 iterations.
    d1 = tempfile.mkdtemp(prefix="retain-same-", dir=TMP_ROOT)
    shared = os.urandom(512 * 1024)
    q = ctx.Queue()
    procs = [ctx.Process(target=_writer, args=(d1, [shared], 12, q)) for _ in range(6)]
    t0 = time.monotonic()
    for p in procs:
        p.start()
    results = [q.get(timeout=120) for _ in procs]
    for p in procs:
        p.join(30)
    errors = [e for r in results for e in r["errors"]]
    observed["case1_same_payload"] = {"writers": 6, "iterations_each": 12, "wall_s": round(time.monotonic() - t0, 3),
                                      "writer_errors": errors[:5], "writer_error_count": len(errors),
                                      **_inspect(d1, [shared])}
    c1 = observed["case1_same_payload"]
    checks["case1_no_writer_errors"] = c1["writer_error_count"] == 0
    checks["case1_single_exact_blob"] = c1["blob_count"] == 1 and not c1["blobs_with_wrong_bytes"]
    checks["case1_no_stray_temp_files"] = c1["stray_files"] == []

    # Case 2: distinct payloads per writer plus the shared one, interleaved.
    d2 = tempfile.mkdtemp(prefix="retain-distinct-", dir=TMP_ROOT)
    distinct = [os.urandom(64 * 1024) for _ in range(6)]
    q = ctx.Queue()
    procs = [ctx.Process(target=_writer, args=(d2, [distinct[i], shared, distinct[(i + 1) % 6]], 8, q))
             for i in range(6)]
    for p in procs:
        p.start()
    results = [q.get(timeout=120) for _ in procs]
    for p in procs:
        p.join(30)
    errors = [e for r in results for e in r["errors"]]
    observed["case2_distinct_payloads"] = {"writer_errors": errors[:5], "writer_error_count": len(errors),
                                           **_inspect(d2, distinct + [shared])}
    c2 = observed["case2_distinct_payloads"]
    checks["case2_no_writer_errors"] = c2["writer_error_count"] == 0
    checks["case2_every_blob_exact"] = c2["blob_count"] == 7 and not c2["blobs_with_wrong_bytes"]
    checks["case2_no_stray_temp_files"] = c2["stray_files"] == []

    # Case 3: readers poll read_retained while writers publish that digest.
    d3 = tempfile.mkdtemp(prefix="retain-readers-", dir=TMP_ROOT)
    target = os.urandom(1024 * 1024)
    receipt = _receipt_for(target)
    q_r = ctx.Queue()
    q_w = ctx.Queue()
    readers = [ctx.Process(target=_reader, args=(d3, receipt, 2.5, q_r)) for _ in range(4)]
    for p in readers:
        p.start()
    time.sleep(0.6)  # readers spin on FileNotFoundError first
    writers = [ctx.Process(target=_writer, args=(d3, [target], 6, q_w)) for _ in range(4)]
    for p in writers:
        p.start()
    reader_results = [q_r.get(timeout=120) for _ in readers]
    writer_results = [q_w.get(timeout=120) for _ in writers]
    for p in readers + writers:
        p.join(30)
    other = [e for r in reader_results for e in r["other_errors"]]
    observed["case3_reader_race"] = {
        "readers": [{k: v for k, v in r.items() if k != "pid"} for r in reader_results],
        "writer_error_count": sum(len(r["errors"]) for r in writer_results),
        **_inspect(d3, [target])}
    c3 = observed["case3_reader_race"]
    checks["case3_readers_saw_not_found_then_success"] = all(
        r["successes"] > 0 and r["not_found"] > 0 for r in reader_results)
    checks["case3_readers_never_saw_partial_or_changed_bytes"] = all(
        r["other_error_count"] == 0 for r in reader_results)
    checks["case3_no_writer_errors_single_blob"] = c3["writer_error_count"] == 0 and c3["blob_count"] == 1

    # Case 4 (semantics, single process): differing bytes under the true digest name are refused,
    # and a retained blob whose bytes were altered is refused on read (custody invariants hold cross-case).
    sys.path.insert(0, REPO)
    from tools.api.sam_capture import read_retained, retain_bytes
    d4 = tempfile.mkdtemp(prefix="retain-semantics-", dir=TMP_ROOT)
    good = b"inventory bytes"
    rec = retain_bytes(Path(d4), good)
    (Path(d4) / rec["path"]).write_bytes(b"inventory bytez")
    try:
        retain_bytes(Path(d4), good)
        refused = None
    except ValueError as exc:
        refused = str(exc)
    try:
        read_retained(Path(d4), rec)
        read_refused = None
    except ValueError as exc:
        read_refused = str(exc)
    observed["case4_semantics"] = {"republish_over_altered_blob": refused, "read_altered_blob": read_refused}
    checks["case4_altered_blob_refused_both_ways"] = refused == "retained SAM bytes changed" and read_refused == "retained SAM bytes changed"

    status = "PASS" if all(checks.values()) else "FAIL"
    print(json.dumps({"status": status, "checks": checks, "observed": observed,
                      "note": ("PASS = cross-process publication is atomic and exact; closes the byte-retention "
                               "LIMITS line 'cross-process races on the same objects/ dir were not exercised'. "
                               "Case 4 restates the known F-01 poisoned-blob behaviour as the custody invariant.")},
                     indent=2, default=str))
    for d in (d1, d2, d3, d4):
        shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    main()
