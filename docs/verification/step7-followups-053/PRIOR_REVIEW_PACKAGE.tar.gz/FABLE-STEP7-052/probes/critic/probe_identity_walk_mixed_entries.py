"""Identity walk breadth: conflicting explicit notice-ID keys at ANY depth (positive control).

WNI/FVE/HDP proved the walk ignores _links hrefs (H3). Nobody recorded whether a
conflict buried inside one attachment entry, a nested wrapper, or a list-valued
id key is refused, which is the half of "reject any conflicting original notice
ID" that the code does claim. Real SAM HAL shape is used, network via MockTransport.
PASS = every explicit-key conflict at any depth is identity_mismatch (no cache
written, raw bytes retained) and the all-matching control is inventory_captured.
The H3 boundary (explicit null id plus a foreign _links href) is recorded as the
already-known accepted case, not judged here.
"""
import json
import os
import shutil
import tempfile
from pathlib import Path

import _critic_harness as H
import httpx

A, B = H.NOTICE, H.OTHER


def entry(opp_id, rid, name):
    return {"opportunityId": opp_id, "attachments": [
        {"resourceId": rid, "name": name, "accessLevel": "public", "mimeType": "text/plain",
         "size": 12, "uri": f"https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{rid}/download"}]}


def hal(entries, self_id=A, extra=None):
    body = {"_embedded": {"opportunityAttachmentList": entries},
            "_links": {"self": {"href": f"https://sam.gov/api/prod/opps/v3/opportunities/{self_id}/resources"}}}
    if extra:
        body.update(extra)
    return body


CASES = {
    "control_all_entries_match": hal([entry(A, "c" * 32, "SOW.txt"), entry(A, "d" * 32, "PWS.txt")]),
    "second_wrapper_entry_names_B": hal([entry(A, "c" * 32, "SOW.txt"), entry(B, "d" * 32, "PWS.txt")]),
    "conflict_inside_attachment_row": (lambda e: (e[0]["attachments"][0].__setitem__("opportunityId", B), hal(e))[1])(
        [entry(A, "c" * 32, "SOW.txt")]),
    "conflict_in_unrelated_nested_list": hal([entry(A, "c" * 32, "SOW.txt")],
                                             extra={"related": [{"kind": "amendment", "noticeId": B}]}),
    "list_valued_opportunityId": hal([{"opportunityId": [A, B], "attachments": entry(A, "c" * 32, "SOW.txt")["attachments"]}]),
    "snake_case_notice_id_conflict_deep": hal([entry(A, "c" * 32, "SOW.txt")],
                                              extra={"meta": {"source": {"notice_id": B}}}),
    "same_id_with_trailing_space": hal([entry(A + " ", "c" * 32, "SOW.txt")]),
    "known_h3_boundary_null_id_foreign_href": hal([{"opportunityId": None, "attachments": entry(A, "c" * 32, "SOW.txt")["attachments"]}],
                                                  self_id=B),
}

observed = {}
checks = {}
for name, body in CASES.items():
    cache_dir = tempfile.mkdtemp(prefix=f"idwalk-{name[:12]}-", dir=H.TMP_ROOT)
    os.environ["LILA_NOTICE_CACHE_DIR"] = cache_dir
    payload = json.dumps(body).encode()
    seen = H.mock_http(lambda request, payload=payload: httpx.Response(200, content=payload))
    result = H.detail.fetch_notice_resources(A)
    cache_file = Path(cache_dir) / f"{A}.resources.json"
    objects = sorted(p.name for p in (Path(cache_dir) / "objects").iterdir()) if (Path(cache_dir) / "objects").exists() else []
    row = {
        "collection_status": result.get("collection_status"),
        "resources_checked": result.get("resources_checked"),
        "attachment_count": len(result.get("attachments") or []) if result.get("attachments") else 0,
        "errors": result.get("errors"),
        "cache_written": cache_file.exists(),
        "raw_retained": bool(result.get("raw_capture")) and len(objects) == 1,
        "requests": len(seen),
        "identity_matches": H.detail._resource_identity_matches(body, A),
    }
    observed[name] = row
    shutil.rmtree(cache_dir, ignore_errors=True)

checks["control_captured_and_cached"] = (
    observed["control_all_entries_match"]["collection_status"] == "inventory_captured"
    and observed["control_all_entries_match"]["attachment_count"] == 2
    and observed["control_all_entries_match"]["cache_written"])
for name in ("second_wrapper_entry_names_B", "conflict_inside_attachment_row",
             "conflict_in_unrelated_nested_list", "list_valued_opportunityId",
             "snake_case_notice_id_conflict_deep"):
    checks[f"{name}_refused"] = (
        observed[name]["collection_status"] == "identity_mismatch"
        and observed[name]["resources_checked"] is False
        and not observed[name]["cache_written"]
        and observed[name]["raw_retained"])
# Conservative edge: exact compare refuses a padded copy of the right id (yield only, consistent with WNI-6/FVE-6).
checks["trailing_space_refused_conservatively"] = observed["same_id_with_trailing_space"]["collection_status"] == "identity_mismatch"

os.environ["LILA_NOTICE_CACHE_DIR"] = H.NOTICE_CACHE
status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, observed, checks=checks, note=(
    "Explicit-key conflicts at every depth tested are refused with raw bytes retained and no cache; "
    "known_h3_boundary_null_id_foreign_href is the F-03 boundary (explicit null passes, _links ignored) and is "
    f"observed as {observed['known_h3_boundary_null_id_foreign_href']['collection_status']}, not judged here."))
H.cleanup()
