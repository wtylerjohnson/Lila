"""DOCX extractor under non-ASCII text through the production locator chain (UO LIMITS gap).

The unicode-offsets dimension exercised only the .txt branch of _text_from_bytes.
Here a real .docx (zip + word/document.xml) carrying Latin-1, Greek, CJK, a ZWJ
emoji sequence, a flag pair, an astral letter and a combining mark runs through
run_searches._enrich_sam_public_attachments (real _docx_text, real cache write),
then the candidate dossier binds every combined_text_locator, then the text cache
is reused with the network dead. PASS = text survives byte-exact (no mojibake),
every locator slice re-hashes to its text_sha256, the dossier returns
discovery_only with two passages that equal the retained slices after both JSON
round-trips, and the cache hit returns the identical text.
"""
import io
import json
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import _critic_harness as H

CT = ('<?xml version="1.0" encoding="UTF-8"?>'
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
      '<Default Extension="xml" ContentType="application/xml"/>'
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-'
      'officedocument.wordprocessingml.document.main+xml"/></Types>')


def build_docx(paragraphs):
    body = "".join(f'<w:p><w:r><w:t xml:space="preserve">{escape(p)}</w:t></w:r></w:p>' for p in paragraphs)
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           f'<w:body>{body}</w:body></w:document>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", CT)
        archive.writestr("word/document.xml", doc.encode("utf-8"))
    return buf.getvalue()


paragraphs = [
    f"Buyer requires {H.TERM} across the enterprise.",
    "Café Δ 中文 naïve ß",
    "Emoji \U0001F469‍\U0001F4BB flag \U0001F1FA\U0001F1F8 astral \U0001D518",
    "Combining é and precomposed é end.",
]
expected_docx_text = " ".join(paragraphs)
txt_payload = f"Further {H.TERM} deliverables: Δ 中 \U0001F469‍\U0001F4BB tail".encode("utf-8")
docx_payload = build_docx(paragraphs)

observed = {}
checks = {}

# Direct extractor check first (isolates the DOCX branch).
direct = H.sat._text_from_bytes("SOW 1.docx", docx_payload)
observed["direct_docx_text_equals_expected"] = direct == expected_docx_text
observed["direct_docx_codepoints_vs_utf8_bytes"] = [len(direct), len(direct.encode("utf-8"))]
checks["docx_branch_preserves_unicode_exactly"] = direct == expected_docx_text

# Production chain: run_searches -> evidence locators -> dossier.
specs = [("b" * 32, "SOW 1.docx", docx_payload), ("c" * 32, "SOW 2.txt", txt_payload)]
rows, stats, inventory, cache_dir = H.run_pipeline(specs)
checks["row_returned"] = len(rows) == 1
raw = rows[0]["raw_payload"]
text = raw["text"]
evidence = raw["attachment_evidence"]
receipt = stats["attachment_record_receipts"][H.NOTICE]
observed["record_status"] = receipt["status"]
observed["file_receipt_statuses"] = {r["name"]: r["status"] for r in receipt["files"]}
observed["locators"] = [(e["combined_text_locator"]["start"], e["combined_text_locator"]["end"]) for e in evidence]
slices = [text[e["combined_text_locator"]["start"]:e["combined_text_locator"]["end"]] for e in evidence]
observed["file1_slice_equals_docx_text"] = slices[0] == expected_docx_text
observed["file2_slice_equals_txt"] = slices[1] == txt_payload.decode("utf-8")
checks["slices_are_the_extracted_texts"] = observed["file1_slice_equals_docx_text"] and observed["file2_slice_equals_txt"]
checks["every_locator_slice_rehashes"] = all(
    H.sha(s) == e["text_sha256"] and e["file_text_locator"]["end"] == len(s) for s, e in zip(slices, evidence))
checks["separator_exact"] = text[len(slices[0]):len(slices[0]) + 2] == "\n\n"
checks["unit_is_codepoints_not_bytes"] = all(len(s) != len(s.encode("utf-8")) for s in slices)

ctx = H.context(rows[0], inventory)
observed["dossier"] = {"status": ctx["status"], "reason": ctx.get("reason"), "passages": len(ctx.get("file_passages") or [])}
checks["dossier_discovery_only_two_passages"] = ctx["status"] == "discovery_only" and len(ctx["file_passages"]) == 2
checks["passages_equal_retained_slices"] = ctx["status"] == "discovery_only" and all(
    p["text"] == text[p["locator"]["start"]:p["included_end"]] and p["text"] == s
    for p, s in zip(ctx["file_passages"], slices))

for label, rt in (("ascii_roundtrip", H.roundtrip_ascii), ("atomic_roundtrip", H.roundtrip_atomic)):
    row_rt = rt(rows[0])
    ctx_rt = H.context(row_rt, inventory)
    observed[label] = {"status": ctx_rt["status"], "text_identical": row_rt["raw_payload"]["text"] == text}
    checks[f"{label}_still_bound"] = ctx_rt["status"] == "discovery_only" and row_rt["raw_payload"]["text"] == text

# Cache reuse with the network dead: identical text, from_cache, no download.
saved = H.sat._download_bytes
H.sat._download_bytes = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("source unavailable"))
try:
    hit = H.sat.extract_public_attachment_text(H.public_file("b" * 32, "SOW 1.docx"))
finally:
    H.sat._download_bytes = saved
observed["cache_hit"] = {"from_cache": hit.get("from_cache"), "status": hit.get("collection_status"),
                         "text_identical": hit.get("text") == expected_docx_text}
checks["docx_cache_hit_returns_identical_text"] = hit.get("from_cache") is True and hit.get("text") == expected_docx_text
from tools.api.sam_capture import read_retained  # noqa: E402

retained_text = read_retained(Path(cache_dir), hit["text_capture"]).decode("utf-8") if hit.get("text_capture") else None
checks["retained_text_object_decodes_to_same_text"] = retained_text == expected_docx_text

status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, observed, checks=checks, note=(
    "Closes the unicode-offsets LIMITS line for the DOCX branch: real _docx_text, real cache, real dossier binding. "
    "PDF branch (pdfplumber) remains covered only by the dimension's lone-surrogate monkeypatch."))
H.cleanup()
