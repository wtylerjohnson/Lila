"""Per-hit revalidation cost of the candidate cache (bytes re-read and re-hashed on every hit)."""
from __future__ import annotations

import json
import os
import subprocess
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from _common import CLONE, HERE, PYTHON, fresh_dir  # noqa: E402


def measure(variant: str) -> dict:
    cmd = [PYTHON, os.path.join(HERE, "hit_cost.py"), "--variant", variant,
           "--notice-cache", fresh_dir(f"hit-{variant}-n"), "--text-cache", fresh_dir(f"hit-{variant}-t")]
    completed = subprocess.run(cmd, cwd=CLONE, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                               capture_output=True, text=True, timeout=600)
    if completed.returncode != 0:
        raise RuntimeError(f"{variant}: {completed.stderr[-3000:]}")
    return json.loads(completed.stdout.strip().splitlines()[-1])


def main() -> int:
    base = measure("base")
    cand = measure("candidate")
    per_sweep_worst = round(12 * (cand["inventory_cache_hit_ms"] + 3 * cand["text_cache_hit_ms"]) / 1000, 3)
    observed = {
        "base": base, "candidate": cand,
        "text_hit_ratio": round(cand["text_cache_hit_ms"] / max(base["text_cache_hit_ms"], 1e-6), 1),
        "inventory_hit_ratio": round(cand["inventory_cache_hit_ms"] / max(base["inventory_cache_hit_ms"], 1e-6), 1),
        "worst_case_all_cache_hit_sweep_seconds_12x3_files_at_caps": per_sweep_worst,
        "reading": "Candidate re-reads and re-hashes the retained raw bytes and text bytes on every text "
                   "cache hit, and re-parses/re-normalizes the retained inventory body on every inventory "
                   "hit. Cost is bounded by the caps; compare against the 120 s stage budget.",
    }
    status = "INFO" if per_sweep_worst < 10 else "FAIL"
    print(json.dumps({"probe": "cache_hit_cost", "status": status, "observed": observed}, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
