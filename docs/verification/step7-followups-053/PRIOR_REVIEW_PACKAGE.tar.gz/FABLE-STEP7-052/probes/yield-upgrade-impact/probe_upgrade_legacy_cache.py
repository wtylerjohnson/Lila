"""Upgrade model (H8): legacy base-schema caches driven through the candidate.

Seeds caches by running the BASE code, then runs the CANDIDATE against copies
with the network available, failing, and inventory-only. Measures refetch
counts, stale_inventory / INVENTORY_UNAVAILABLE outcomes and relevant rows lost.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from _common import copy_cache, fresh_dir, relevant_ids, run_variant, statuses  # noqa: E402


def age_inventories(notice_cache: str, delta: timedelta) -> int:
    stamp = (datetime.now(timezone.utc) - delta).isoformat(timespec="seconds")
    touched = 0
    for name in os.listdir(notice_cache):
        if not name.endswith(".resources.json"):
            continue
        path = os.path.join(notice_cache, name)
        data = json.load(open(path))
        data["retrieved_at"] = stamp
        with open(path, "w") as handle:
            json.dump(data, handle)
        touched += 1
    return touched


def summarize(result: dict) -> dict:
    return {
        "rows": [r[-2:] for r in result["row_ids"]],
        "relevant": [r[-2:] for r in relevant_ids(result)],
        "statuses": statuses(result),
        "inventory_states": {cid[-2:]: rec.get("inventory_collection_status")
                             for cid, rec in sorted(result["receipts"].items())},
        "inventory_calls": result["inventory_calls"],
        "download_calls": result["download_calls"],
        "wall_seconds": result["wall_seconds"],
        "errors": result["stats"]["attachment_errors"],
    }


def main() -> int:
    # 1. Seed LEGACY caches with the base code (network available).
    legacy_n = fresh_dir("legacy-n")
    legacy_t = fresh_dir("legacy-t")
    seed = run_variant("base", legacy_n, legacy_t, label="seed")
    inv_file = next(f for f in sorted(os.listdir(legacy_n)) if f.endswith(".resources.json"))
    txt_file = next(f for f in sorted(os.listdir(legacy_t)) if f.endswith(".json"))
    legacy_inventory_keys = sorted(json.load(open(os.path.join(legacy_n, inv_file))).keys())
    legacy_text_keys = sorted(json.load(open(os.path.join(legacy_t, txt_file))).keys())
    legacy_counts = {
        "inventory_caches": sum(f.endswith(".resources.json") for f in os.listdir(legacy_n)),
        "text_caches": sum(f.endswith(".json") for f in os.listdir(legacy_t)),
        "objects_dir_present": {"notice": os.path.isdir(os.path.join(legacy_n, "objects")),
                                "text": os.path.isdir(os.path.join(legacy_t, "objects"))},
    }

    # 2. Control: base against its own legacy cache with the network down (within TTL).
    base_fail = run_variant("base", copy_cache(legacy_n, "bf-n"), copy_cache(legacy_t, "bf-t"),
                            network="fail", label="base-fail")

    # 3. Candidate, network available: one-time refetch storm, then upgraded caches.
    up_n, up_t = copy_cache(legacy_n, "up-n"), copy_cache(legacy_t, "up-t")
    cand_ok = run_variant("candidate", up_n, up_t, network="ok", label="cand-ok")
    cand_ok_then_fail = run_variant("candidate", up_n, up_t, network="fail", label="cand-ok-then-fail")
    upgraded_inventory_keys = sorted(json.load(open(os.path.join(up_n, inv_file))).keys())
    upgraded_text_keys = sorted(json.load(open(os.path.join(up_t, txt_file))).keys())

    # 4. Candidate, network failing, legacy cache within TTL.
    cand_fail = run_variant("candidate", copy_cache(legacy_n, "cf-n"), copy_cache(legacy_t, "cf-t"),
                            network="fail", label="cand-fail")

    # 5. Candidate, inventory endpoint up but file downloads failing.
    cand_inv_only = run_variant("candidate", copy_cache(legacy_n, "ci-n"), copy_cache(legacy_t, "ci-t"),
                                network="inventory-only", label="cand-invonly")

    # 6. Aged legacy inventories (7 h, past the 6 h TTL but inside 7 d), network down.
    aged_b_n = copy_cache(legacy_n, "aged7h-b-n"); age_inventories(aged_b_n, timedelta(hours=7))
    base_aged_fail = run_variant("base", aged_b_n, copy_cache(legacy_t, "aged7h-b-t"),
                                 network="fail", label="base-aged-fail")
    aged_c_n = copy_cache(legacy_n, "aged7h-c-n"); age_inventories(aged_c_n, timedelta(hours=7))
    cand_aged_fail = run_variant("candidate", aged_c_n, copy_cache(legacy_t, "aged7h-c-t"),
                                 network="fail", label="cand-aged-fail")
    # 6b. Aged inventories, inventory endpoint up, downloads failing: base keeps its
    # never-expiring legacy text cache, candidate must re-download.
    aged_b2_n = copy_cache(legacy_n, "aged7h-b2-n"); age_inventories(aged_b2_n, timedelta(hours=7))
    base_aged_invonly = run_variant("base", aged_b2_n, copy_cache(legacy_t, "aged7h-b2-t"),
                                    network="inventory-only", label="base-aged-invonly")
    aged_c2_n = copy_cache(legacy_n, "aged7h-c2-n"); age_inventories(aged_c2_n, timedelta(hours=7))
    cand_aged_invonly = run_variant("candidate", aged_c2_n, copy_cache(legacy_t, "aged7h-c2-t"),
                                    network="inventory-only", label="cand-aged-invonly")

    # 7. Aged beyond 7 days, network down.
    old_c_n = copy_cache(legacy_n, "aged8d-c-n"); age_inventories(old_c_n, timedelta(days=8))
    cand_old_fail = run_variant("candidate", old_c_n, copy_cache(legacy_t, "aged8d-c-t"),
                                network="fail", label="cand-old-fail")

    control_relevant = set(relevant_ids(base_fail))
    wrong_notice = {r for r in control_relevant if r.endswith("05")}
    legit_relevant = control_relevant - wrong_notice
    def lost(result):
        return sorted(r[-2:] for r in legit_relevant - set(relevant_ids(result)))

    runs = {
        "seed_base_network_ok": summarize(seed),
        "control_base_legacy_cache_network_fail": summarize(base_fail),
        "candidate_legacy_cache_network_ok": summarize(cand_ok),
        "candidate_after_upgrade_network_fail": summarize(cand_ok_then_fail),
        "candidate_legacy_cache_network_fail": summarize(cand_fail),
        "candidate_legacy_cache_inventory_only": summarize(cand_inv_only),
        "base_aged7h_network_fail": summarize(base_aged_fail),
        "candidate_aged7h_network_fail": summarize(cand_aged_fail),
        "base_aged7h_inventory_only": summarize(base_aged_invonly),
        "candidate_aged7h_inventory_only": summarize(cand_aged_invonly),
        "candidate_aged8d_network_fail": summarize(cand_old_fail),
    }
    loss_table = {name: lost(r) for name, r in (
        ("candidate_legacy_cache_network_ok", cand_ok),
        ("candidate_after_upgrade_network_fail", cand_ok_then_fail),
        ("candidate_legacy_cache_network_fail", cand_fail),
        ("candidate_legacy_cache_inventory_only", cand_inv_only),
        ("base_aged7h_network_fail", base_aged_fail),
        ("candidate_aged7h_network_fail", cand_aged_fail),
        ("base_aged7h_inventory_only", base_aged_invonly),
        ("candidate_aged7h_inventory_only", cand_aged_invonly),
        ("candidate_aged8d_network_fail", cand_old_fail),
    )}
    refetch = {
        "legacy_inventory_caches": legacy_counts["inventory_caches"],
        "legacy_text_caches": legacy_counts["text_caches"],
        "base_network_fail_inventory_calls": base_fail["inventory_calls"],
        "base_network_fail_download_calls": base_fail["download_calls"],
        "candidate_network_ok_inventory_calls": cand_ok["inventory_calls"],
        "candidate_network_ok_download_calls": cand_ok["download_calls"],
        "candidate_second_run_inventory_calls": cand_ok_then_fail["inventory_calls"],
        "candidate_second_run_download_calls": cand_ok_then_fail["download_calls"],
    }
    stale_count = sum(1 for s in statuses(cand_fail).values() if s == "STALE_INVENTORY")
    unavailable_old = sum(1 for s in statuses(cand_old_fail).values() if s == "INVENTORY_UNAVAILABLE")

    # H8 as stated: every legacy cache refetched once; failure inside 7 d = stale_inventory;
    # previously-relevant rows lost while the network is down. Confirmed if the numbers say so.
    uncacheable = {cid for cid, st in statuses(seed).items() if st == "INVENTORY_UNAVAILABLE"}  # 04, 06
    second_inv_calls_expected = len(uncacheable) + 1  # plus 05 whose identity refresh keeps failing
    second_dl_calls_expected = 1  # 07: download always fails, never cached
    h8_confirmed = (
        cand_ok["inventory_calls"] == seed["inventory_calls"]
        and cand_ok["download_calls"] >= legacy_counts["text_caches"]
        and stale_count == legacy_counts["inventory_caches"]
        and loss_table["candidate_legacy_cache_network_fail"] == sorted(r[-2:] for r in legit_relevant)
        and not loss_table["candidate_legacy_cache_network_ok"]
        and not loss_table["candidate_after_upgrade_network_fail"]
        and cand_ok_then_fail["inventory_calls"] == second_inv_calls_expected
        and cand_ok_then_fail["download_calls"] == second_dl_calls_expected
        and not loss_table["base_aged7h_inventory_only"]
        and loss_table["candidate_aged7h_inventory_only"] == sorted(r[-2:] for r in legit_relevant)
    )
    status = "INFO" if h8_confirmed else "FAIL"
    observed = {
        "legacy_schema": {"inventory_keys": legacy_inventory_keys, "text_keys": legacy_text_keys,
                          **legacy_counts},
        "upgraded_schema": {"inventory_keys": upgraded_inventory_keys, "text_keys": upgraded_text_keys},
        "refetch": refetch,
        "stale_inventory_count_network_fail": stale_count,
        "inventory_unavailable_count_aged8d": unavailable_old,
        "relevant_rows_lost_vs_control": loss_table,
        "control_relevant": sorted(r[-2:] for r in control_relevant),
        "control_relevant_wrong_notice_excluded": sorted(r[-2:] for r in wrong_notice),
        "legit_relevant": sorted(r[-2:] for r in legit_relevant),
        "second_run_expected_calls": {"inventory": second_inv_calls_expected, "download": second_dl_calls_expected},
        "runs": runs,
        "h8_confirmed": h8_confirmed,
        "reading": "The first candidate sweep re-spends one keyless inventory call per legacy inventory "
                   "and one download per legacy text cache. With the network down inside the 6 h TTL "
                   "the base served every relevant row from cache; the candidate marks every legacy "
                   "inventory stale_inventory and yields zero rows. With only downloads failing, the "
                   "candidate also yields zero because legacy text caches (which never expired under "
                   "base) are invalidated. Both losses are one-time and heal on the next successful sweep.",
    }
    print(json.dumps({"probe": "upgrade_legacy_cache", "status": status, "observed": observed},
                     indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
