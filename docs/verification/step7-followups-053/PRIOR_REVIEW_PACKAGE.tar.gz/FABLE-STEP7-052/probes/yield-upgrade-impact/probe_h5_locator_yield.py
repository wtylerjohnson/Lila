"""H5: degenerate third-file locator drops the whole dossier research context.

When LILA_SAM_ATTACHMENT_TEXT_CHARS is raised so two files fill the 150000
combined cap, the candidate emits a third file with an empty text and
start == end. The candidate dossier then rejects the entire research context,
including the two correctly bound files. Also measures that lowering the text
cap after caching invalidates every text cache (refetch, not a cache hit).

Child mode runs the real run_searches enrichment on one stack; parent mode
aggregates. Prints one JSON object.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CLONE = "/Users/wtjohnson/lila-step7-052"
PYTHON = os.path.join(CLONE, ".venv", "bin", "python")
sys.path.insert(0, HERE)
from _common import fresh_dir  # noqa: E402

NOTICE = "a" * 32
RIDS = ["b" * 32, "c" * 32, "d" * 32]


def child(args) -> dict:
    os.environ["LILA_SAM_ATTACHMENT_TEXT_CHARS"] = str(args.chars)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = args.text_cache
    os.environ["LILA_NOTICE_CACHE_DIR"] = fresh_dir("h5-n")
    os.environ["LILA_SAM_LEDGER"] = os.path.join(HERE, "tmp", "sam_calls.json")
    os.environ["LILA_SUITE_OFFLINE"] = "1"
    socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(AssertionError("connect"))
    if args.variant == "base":
        sys.path.insert(0, os.path.join(HERE, "base_stack"))
    sys.path.insert(1 if args.variant == "base" else 0, CLONE)
    os.chdir(CLONE)
    from tools.api import sam_attachment_text as sat, sam_notice_detail as detail, sam_quota
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    from agents.decisions.dossier import _attachment_research_context

    files = [{"resource_id": rid, "name": f"SOW {i}.txt", "access_level": "public",
              "access_status": "public", "export_controlled": "0", "explicit_access": "0",
              "size": 200000} for i, rid in enumerate(RIDS)]
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": NOTICE, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory, "collection_status": "inventory_captured"}
    body = ("Buyer requires network visibility. " * 6000).encode()  # ~210000 chars, capped by env
    downloads = []

    def download(rid, **k):
        downloads.append(rid)
        if args.network == "fail":
            raise RuntimeError("download network down")
        return body
    sat._download_bytes = download
    sam_quota.calls_today = lambda: 0
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]
    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term="network visibility")])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
    out = {"variant": args.variant, "chars": args.chars, "network": args.network,
           "module": sat.__file__, "max_chars_in_module": sat.MAX_ATTACHMENT_TEXT_CHARS,
           "rows": len(rows), "download_calls": len(downloads),
           "status": stats["attachment_record_receipts"][NOTICE]["status"],
           "relevant": stats["attachment_relevant"]}
    if rows:
        raw = rows[0]["raw_payload"]
        out["text_chars"] = len(raw["text"])
        out["evidence_files"] = len(raw["attachment_evidence"])
        out["locators"] = [e.get("combined_text_locator") for e in raw["attachment_evidence"]]
        out["file_text_truncated"] = [e.get("file_text_truncated") for e in raw["attachment_evidence"]]
        out["has_collection_v1"] = "attachment_collection_v1" in raw
        context = _attachment_research_context(rows[0], {"id": NOTICE, "resources_checked": True,
                                                         "attachment_inventory_hash": inventory})
        out["dossier_status"] = context.get("status")
        out["dossier_reason"] = context.get("reason")
        out["dossier_file_passages"] = len(context.get("file_passages") or [])
        out["dossier_included_chars"] = context.get("included_characters")
    return out


def run_child(variant: str, chars: int, text_cache: str, network: str = "ok") -> dict:
    cmd = [PYTHON, os.path.abspath(__file__), "--child", "--variant", variant, "--chars", str(chars),
           "--text-cache", text_cache, "--network", network]
    completed = subprocess.run(cmd, cwd=CLONE, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                               capture_output=True, text=True, timeout=300)
    if completed.returncode != 0:
        raise RuntimeError(f"child failed: {completed.stderr[-3000:]}")
    return json.loads(completed.stdout.strip().splitlines()[-1])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--child", action="store_true")
    ap.add_argument("--variant", default="candidate")
    ap.add_argument("--chars", type=int, default=50000)
    ap.add_argument("--text-cache", default=None)
    ap.add_argument("--network", default="ok")
    args = ap.parse_args()
    if args.child:
        print(json.dumps(child(args)))
        return 0

    cases = {}
    for chars in (50000, 74997, 74998, 100000):
        cases[f"candidate_chars_{chars}"] = run_child("candidate", chars, fresh_dir(f"h5-c{chars}"))
    cases["base_chars_100000_then_candidate_dossier"] = run_child("base", 100000, fresh_dir("h5-b100000"))

    # Config lowering after caching: seed at 50000, then read at 40000 with the network down.
    shared = fresh_dir("h5-shared")
    cases["seed_candidate_50000"] = run_child("candidate", 50000, shared)
    cases["candidate_50000_network_fail_cache_hit_control"] = run_child("candidate", 50000, shared, "fail")
    cases["candidate_40000_network_fail_after_50000_seed"] = run_child("candidate", 40000, shared, "fail")
    cases["candidate_60000_network_fail_after_50000_seed"] = run_child("candidate", 60000, shared, "fail")

    control_ok = cases["candidate_chars_50000"]["dossier_status"] == "discovery_only" \
        and cases["candidate_chars_50000"]["dossier_file_passages"] == 3
    boundary_ok = cases["candidate_chars_74997"]["dossier_status"] == "discovery_only"
    broken = [k for k in ("candidate_chars_74998", "candidate_chars_100000")
              if cases[k]["dossier_status"] == "unavailable"]
    base_row_survives = cases["base_chars_100000_then_candidate_dossier"]["dossier_status"] == "discovery_only"
    lowered_refetch = cases["candidate_40000_network_fail_after_50000_seed"]["status"] == "TEXT_UNAVAILABLE"
    raised_hit = cases["candidate_60000_network_fail_after_50000_seed"]["status"] == "DISCOVERY_TEXT_CAPTURED"
    hit_control = cases["candidate_50000_network_fail_cache_hit_control"]["status"] == "DISCOVERY_TEXT_CAPTURED"

    status = "FAIL" if (control_ok and boundary_ok and broken and base_row_survives) else "INFO"
    observed = {
        "cases": cases,
        "control_defaults_three_passages": control_ok,
        "boundary_74997_ok": boundary_ok,
        "configs_where_candidate_drops_whole_context": broken,
        "base_row_same_config_survives_candidate_dossier": base_row_survives,
        "text_cap_lowered_after_caching_forces_refetch": lowered_refetch,
        "text_cap_raised_after_caching_still_hits": raised_hit,
        "cache_hit_control": hit_control,
        "reading": "With LILA_SAM_ATTACHMENT_TEXT_CHARS >= 74998 and three public files, the candidate's "
                   "third file gets file_text '' with start == end; the candidate dossier rejects the WHOLE "
                   "research context (both correctly bound files lost). A base-shaped row from the same "
                   "config keeps its discovery_only context. Not reachable with the 50000 default.",
    }
    print(json.dumps({"probe": "h5_locator_yield", "status": status, "observed": observed}, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
