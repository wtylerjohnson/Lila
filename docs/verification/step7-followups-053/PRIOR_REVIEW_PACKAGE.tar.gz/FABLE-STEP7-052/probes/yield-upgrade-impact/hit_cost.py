"""Measure per-cache-hit revalidation cost (base vs candidate stack) at the byte caps.

Text cache: one 5 MiB raw payload whose extracted text is MAX_ATTACHMENT_TEXT_CHARS
characters. Inventory cache: a recognized inventory body near the 2 MiB capture cap.
Run as a subprocess per variant; prints one JSON object.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import time

CLONE = "/Users/wtjohnson/lila-step7-052"
HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", required=True)
    ap.add_argument("--notice-cache", required=True)
    ap.add_argument("--text-cache", required=True)
    args = ap.parse_args()
    os.environ["LILA_NOTICE_CACHE_DIR"] = args.notice_cache
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = args.text_cache
    os.environ["LILA_SUITE_OFFLINE"] = "1"
    socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(AssertionError("connect"))
    if args.variant == "base":
        sys.path.insert(0, os.path.join(HERE, "base_stack"))
    sys.path.insert(1 if args.variant == "base" else 0, CLONE)
    os.chdir(CLONE)

    import httpx
    from tools.api import _http
    from tools.api import sam_attachment_text as sat
    from tools.api import sam_notice_detail as detail

    # Text cache: 5 MiB txt payload; extracted text is capped at MAX chars.
    payload = (b"network visibility requirement line\n" * (5 * 1024 * 1024 // 36))[:5 * 1024 * 1024]
    sat._download_bytes = lambda rid, **k: payload
    attachment = {"resource_id": "b" * 32, "name": "SOW.txt", "access_level": "public",
                  "access_status": "public", "export_controlled": "0", "explicit_access": "0",
                  "size": len(payload)}
    first = sat.extract_public_attachment_text(attachment)
    assert first["text"] and first["from_cache"] is False
    sat._download_bytes = lambda rid, **k: (_ for _ in ()).throw(RuntimeError("no network"))
    samples = []
    for _ in range(5):
        t0 = time.perf_counter()
        hit = sat.extract_public_attachment_text(attachment)
        samples.append(time.perf_counter() - t0)
        assert hit["from_cache"] is True and hit["text"] == first["text"]
    text_hit_ms = round(1000 * min(samples), 3)

    # Inventory cache: ~1.9 MiB recognized body (many attachment rows).
    notice = "a" * 32
    rows = []
    i = 0
    while True:
        rows.append({"attachmentId": "1" * 32, "resourceId": f"{i:032x}", "name": f"Attachment {i}.pdf",
                     "type": "file", "accessLevel": "public", "exportControlled": "0",
                     "explicitAccess": "0", "mimeType": ".pdf", "size": 1000 + i, "accessStatus": "public"})
        i += 1
        if i % 500 == 0 and len(json.dumps(rows)) > 1_900_000:
            break
    body = json.dumps({"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": notice, "attachments": rows}]}}).encode()
    calls = []

    def handler(request):
        calls.append(1)
        return httpx.Response(200, content=body, request=request)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    first_inv = detail.fetch_notice_resources(notice)
    assert first_inv["resources_checked"] is True and len(calls) == 1
    samples = []
    for _ in range(5):
        t0 = time.perf_counter()
        hit = detail.fetch_notice_resources(notice)
        samples.append(time.perf_counter() - t0)
        assert hit["from_cache"] is True
    inv_hit_ms = round(1000 * min(samples), 3)
    print(json.dumps({"variant": args.variant, "raw_bytes": len(payload),
                      "text_chars": len(first["text"]), "text_cache_hit_ms": text_hit_ms,
                      "inventory_bytes": len(body), "inventory_rows": len(rows),
                      "inventory_cache_hit_ms": inv_hit_ms, "inventory_calls": len(calls)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
