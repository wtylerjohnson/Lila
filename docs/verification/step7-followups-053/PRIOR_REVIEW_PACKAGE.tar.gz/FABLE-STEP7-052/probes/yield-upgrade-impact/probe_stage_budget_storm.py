"""Refetch storm vs stage budget: legacy caches, slow network, small stage budget.

Eight candidates with two public files each (three relevant, at positions 3, 6
and 8). The base serves them from legacy caches in milliseconds. The candidate
must refetch every inventory and file, so with LILA_SAM_ATTACHMENT_STAGE_SECONDS
small and a slow mocked network the budget expires mid-sweep. Also records the
mid-loop file reason (H6) and per-candidate wall time.
"""
from __future__ import annotations

import json
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from _common import copy_cache, fresh_dir, relevant_ids, run_variant, statuses  # noqa: E402


def view(result: dict) -> dict:
    files = {}
    for cid, rec in sorted(result["receipts"].items()):
        if rec.get("files"):
            files[cid[-2:]] = {rid[-3:]: v for rid, v in rec["files"].items()}
    return {
        "relevant": [r[-2:] for r in relevant_ids(result)],
        "statuses": statuses(result),
        "file_receipts": files,
        "timings": {cid[-2:]: t for cid, t in sorted(result["timings"].items())},
        "inventory_calls": result["inventory_calls"],
        "download_calls": result["download_calls"],
        "wall_seconds": result["wall_seconds"],
        "errors": result["stats"]["attachment_errors"],
    }


def main() -> int:
    legacy_n, legacy_t = fresh_dir("storm-legacy-n"), fresh_dir("storm-legacy-t")
    seed = run_variant("base", legacy_n, legacy_t, scenario="storm8", label="storm-seed")
    delay = 0.3
    budget = 2
    base_slow = run_variant("base", copy_cache(legacy_n, "storm-b-n"), copy_cache(legacy_t, "storm-b-t"),
                            scenario="storm8", stage_seconds=budget, inv_delay=delay, dl_delay=delay,
                            label="storm-base")
    cand_slow = run_variant("candidate", copy_cache(legacy_n, "storm-c-n"), copy_cache(legacy_t, "storm-c-t"),
                            scenario="storm8", stage_seconds=budget, inv_delay=delay, dl_delay=delay,
                            label="storm-cand")
    cand_default = run_variant("candidate", copy_cache(legacy_n, "storm-cd-n"), copy_cache(legacy_t, "storm-cd-t"),
                               scenario="storm8", inv_delay=delay, dl_delay=delay, label="storm-cand-default")

    base_rel = set(relevant_ids(base_slow))
    cand_rel = set(relevant_ids(cand_slow))
    lost = sorted(r[-2:] for r in base_rel - cand_rel)
    not_attempted = sum(1 for s in statuses(cand_slow).values() if s == "NOT_ATTEMPTED")
    h6_reasons = {}
    for cid, rec in cand_slow["receipts"].items():
        for rid, (st, reason) in (rec.get("files") or {}).items():
            if st == "not_fetched":
                h6_reasons.setdefault(reason, []).append(f"{cid[-2:]}/{rid[-3:]}")
    exhausted_mid_loop = "stage time budget exhausted" in h6_reasons
    unattempted_labelled_outside_budget = [
        item for item in h6_reasons.get("outside file/type budget", [])
        if cand_slow["receipts"][next(c for c in cand_slow["receipts"] if c.endswith(item[:2]))]["status"]
        in ("TEXT_UNAVAILABLE", "DISCOVERY_TEXT_CAPTURED", "INVENTORY_CHECKED")]

    status = "INFO"
    if lost and base_slow["wall_seconds"] < budget and cand_slow["wall_seconds"] >= budget * 0.9:
        status = "INFO"  # measured, disclosed one-time cost
    if not lost:
        status = "FAIL"  # storm did not materialize; the probe design is wrong
    observed = {
        "stage_seconds": budget, "mock_delay_seconds_per_call": delay,
        "seed_base": {"inventory_calls": seed["inventory_calls"], "download_calls": seed["download_calls"],
                      "relevant": [r[-2:] for r in relevant_ids(seed)]},
        "base_legacy_cache_slow_network": view(base_slow),
        "candidate_legacy_cache_slow_network": view(cand_slow),
        "candidate_legacy_cache_default_budget": {
            "wall_seconds": cand_default["wall_seconds"], "inventory_calls": cand_default["inventory_calls"],
            "download_calls": cand_default["download_calls"],
            "relevant": [r[-2:] for r in relevant_ids(cand_default)], "statuses": statuses(cand_default)},
        "relevant_lost_under_budget": lost,
        "candidates_not_attempted_by_candidate": not_attempted,
        "h6_file_reasons": h6_reasons,
        "h6_mid_loop_exhaustion_seen": exhausted_mid_loop,
        "h6_eligible_but_unattempted_files_labelled_outside_budget": unattempted_labelled_outside_budget,
        "reading": "Per-candidate cost under the candidate is one inventory fetch plus one download per "
                   "eligible file (all previously cached). At 0.3 s per call the 2 s budget admits about "
                   "two candidates; the base finishes all eight from cache in milliseconds.",
    }
    print(json.dumps({"probe": "stage_budget_storm", "status": status, "observed": observed},
                     indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
