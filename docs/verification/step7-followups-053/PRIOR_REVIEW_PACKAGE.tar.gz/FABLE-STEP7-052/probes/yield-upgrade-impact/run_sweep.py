"""Synthetic multi-candidate attachment sweep driver (base or candidate stack).

Runs the REAL run_searches._enrich_sam_public_attachments with only network and
quota seams replaced. Prints one JSON object describing rows, receipts, network
calls and wall time. Invoked as a subprocess by the probe scripts so that the
base stack (git show 2d522f0) and the candidate stack never share a process.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import time

CLONE = "/Users/wtjohnson/lila-step7-052"
HERE = os.path.dirname(os.path.abspath(__file__))
BASE_STACK = os.path.join(HERE, "base_stack")

HEX = "0123456789abcdef"


def nid(n: int) -> str:
    return (HEX[n % 16] * 30 + f"{n:02d}")[:32]


def rid(n: int) -> str:
    assert 0 <= n < 1000
    return "f" * 29 + f"{n:03d}"


def real_shape(notice_id: str, attachments: list[dict]) -> bytes:
    body = {"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": notice_id, "attachments": attachments}]},
        "_links": {"self": {"href": f"https://sam.gov/opps/v3/opportunities/{notice_id}/resources"}}}
    return json.dumps(body).encode()


def att(resource_id: str, name: str, size: int = 1234, public: bool = True) -> dict:
    return {"attachmentId": "1" * 32, "resourceId": resource_id, "name": name,
            "type": "file", "accessLevel": "public" if public else "private",
            "exportControlled": "0", "explicitAccess": "0",
            "mimeType": os.path.splitext(name)[1], "size": size,
            "accessStatus": "public" if public else "private"}


RELEVANT = "Buyer requires network visibility. Café data. Δ deliverables."
IRRELEVANT = "Janitorial services for the building lobby and grounds."


def scenario(name: str):
    """Return (candidate_ids, inventories{id: (status, bytes)}, downloads{rid: bytes|Exception})."""
    inv: dict[str, tuple[int, bytes]] = {}
    dl: dict[str, object] = {}
    ids: list[str] = []
    if name == "mixed10":
        # N1 two relevant txt files
        n = nid(1); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(11), "SOW part 1.txt"), att(rid(12), "PWS part 2.txt")]))
        dl[rid(11)] = RELEVANT.encode(); dl[rid(12)] = ("Further " + RELEVANT).encode()
        # N2 one irrelevant md file
        n = nid(2); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(21), "requirements.md")]))
        dl[rid(21)] = IRRELEVANT.encode()
        # N3 irrelevant txt
        n = nid(3); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(31), "SOW.txt")]))
        dl[rid(31)] = IRRELEVANT.encode()
        # N4 links-only body (real zero-attachment shape, H4)
        n = nid(4); ids.append(n)
        inv[n] = (200, json.dumps({"_links": {"self": {"href": f"https://x/{n}/resources"}}}).encode())
        # N5 wrong-notice body naming another opportunityId
        n = nid(5); ids.append(n)
        inv[n] = (200, real_shape(nid(15), [att(rid(51), "SOW wrong notice.txt")]))
        dl[rid(51)] = RELEVANT.encode()
        # N6 HTTP 403
        n = nid(6); ids.append(n)
        inv[n] = (403, b"access denied")
        # N7 public txt but download fails
        n = nid(7); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(71), "SOW.txt")]))
        dl[rid(71)] = RuntimeError("download failed 502")
        # N8 private pdf + xlsx + one public irrelevant txt
        n = nid(8); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(81), "SOW.pdf", public=False),
                                      att(rid(82), "pricing.xlsx"),
                                      att(rid(83), "PWS.txt")]))
        dl[rid(83)] = IRRELEVANT.encode()
        # N9 confirmed empty
        n = nid(9); ids.append(n)
        inv[n] = (200, json.dumps({"_embedded": {"opportunityAttachmentList": []}}).encode())
        # N10 four public txt files, only three fetched, relevant
        n = nid(10); ids.append(n)
        inv[n] = (200, real_shape(n, [att(rid(101), "a.txt"), att(rid(102), "b.txt"),
                                      att(rid(103), "c.txt"), att(rid(104), "d.txt")]))
        for k in (101, 102, 103, 104):
            dl[rid(k)] = (IRRELEVANT if k != 103 else RELEVANT).encode()
    elif name == "storm8":
        for i in range(1, 9):
            n = nid(20 + i); ids.append(n)
            inv[n] = (200, real_shape(n, [att(rid(200 + 2 * i), f"SOW {i}.txt"),
                                          att(rid(201 + 2 * i), f"PWS {i}.txt")]))
            relevant = (i - 1) in (2, 5, 7)
            dl[rid(200 + 2 * i)] = (RELEVANT if relevant else IRRELEVANT).encode()
            dl[rid(201 + 2 * i)] = IRRELEVANT.encode()
    else:
        raise SystemExit(f"unknown scenario {name}")
    return ids, inv, dl


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", choices=("base", "candidate"), required=True)
    ap.add_argument("--scenario", default="mixed10")
    ap.add_argument("--notice-cache", required=True)
    ap.add_argument("--text-cache", required=True)
    ap.add_argument("--network", choices=("ok", "fail", "inventory-only"), default="ok")
    ap.add_argument("--stage-seconds", default=None)
    ap.add_argument("--inv-delay", type=float, default=0.0)
    ap.add_argument("--dl-delay", type=float, default=0.0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    os.environ["LILA_NOTICE_CACHE_DIR"] = args.notice_cache
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = args.text_cache
    os.environ["LILA_SAM_LEDGER"] = os.path.join(HERE, "tmp", "sam_calls.json")
    os.environ["LILA_SUITE_OFFLINE"] = "1"
    if args.stage_seconds is not None:
        os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = str(args.stage_seconds)
    else:
        os.environ.pop("LILA_SAM_ATTACHMENT_STAGE_SECONDS", None)

    def no_connect(*a, **k):
        raise AssertionError("real socket connect attempted")
    socket.socket.connect = no_connect  # type: ignore[assignment]

    if args.variant == "base":
        sys.path.insert(0, BASE_STACK)
    sys.path.insert(1 if args.variant == "base" else 0, CLONE)
    os.chdir(CLONE)

    import httpx
    from tools.api import _http, sam_quota
    from tools.api import sam_attachment_text as sat
    from tools.api import sam_notice_detail as detail
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    module_files = {
        "run_searches": searches.__file__,
        "sam_notice_detail": detail.__file__,
        "sam_attachment_text": sat.__file__,
        "_http": _http.__file__,
    }

    ids, inventories, downloads = scenario(args.scenario)
    inv_calls: list[str] = []
    dl_calls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        inv_calls.append(url)
        if args.inv_delay:
            time.sleep(args.inv_delay)
        if args.network == "fail":
            raise httpx.ConnectError("network down", request=request)
        notice_id = url.rstrip("/").split("/")[-2]
        status, body = inventories.get(notice_id, (404, b"{}"))
        return httpx.Response(status, content=body, request=request)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

    def fake_download(resource_id, *, deadline_monotonic=None):
        dl_calls.append(resource_id)
        if args.dl_delay:
            time.sleep(args.dl_delay)
        if args.network in ("fail", "inventory-only"):
            raise RuntimeError("download network down")
        payload = downloads.get(resource_id)
        if isinstance(payload, Exception):
            raise payload
        if payload is None:
            raise RuntimeError("unknown resource")
        return payload
    sat._download_bytes = fake_download
    sam_quota.calls_today = lambda: 0

    timings: dict[str, dict] = {}
    real_fetch = detail.fetch_notice_resources

    def timed_fetch(notice_id, **kw):
        t0 = time.monotonic()
        try:
            return real_fetch(notice_id, **kw)
        finally:
            timings.setdefault(notice_id, {})["inventory_seconds"] = round(time.monotonic() - t0, 4)
    detail.fetch_notice_resources = timed_fetch

    real_extract = sat.extract_public_attachment_text
    current: dict = {"id": None}

    def timed_extract(attachment, **kw):
        t0 = time.monotonic()
        try:
            return real_extract(attachment, **kw)
        finally:
            slot = timings.setdefault(current["id"] or "?", {})
            slot["file_seconds"] = round(slot.get("file_seconds", 0.0) + time.monotonic() - t0, 4)
    sat.extract_public_attachment_text = timed_extract

    candidates = [RawOpportunity(source="sam.gov", source_id=n, title=f"Requirement {n[-2:]}",
                                 agency="NASA", raw_payload={"type": "Solicitation"})
                  for n in ids]

    class Source:
        last_attachment_census = {"selected": len(candidates)}

        def attachment_candidates(self, *a, **k):
            return list(candidates)

    # track which candidate is being processed for file timing
    def tracking_fetch(notice_id, **kw):
        current["id"] = notice_id
        return timed_fetch(notice_id, **kw)
    detail.fetch_notice_resources = tracking_fetch

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term="network visibility")])
    t0 = time.monotonic()
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=12)
    wall = round(time.monotonic() - t0, 4)

    row_view = {}
    for row in rows:
        raw = row.get("raw_payload") or {}
        row_view[row["source_id"]] = {
            "raw_payload_keys": sorted(raw.keys()),
            "attachment_relevance": raw.get("attachment_relevance"),
            "text_chars": len(raw.get("text") or ""),
            "text_sha256_basis": raw.get("attachment_evidence_sha256"),
            "evidence_files": [e.get("resource_id") for e in (raw.get("attachment_evidence") or [])],
            "evidence_keys": sorted((raw.get("attachment_evidence") or [{}])[0].keys()),
        }
    receipts = {}
    for cid, rec in (stats.get("attachment_record_receipts") or {}).items():
        view = {"status": rec.get("status"), "errors": rec.get("errors")}
        if "files" in rec:
            view["files"] = {f["resource_id"]: [f.get("status"), f.get("reason")] for f in rec["files"]}
        if "inventory_receipt" in rec:
            ir = rec["inventory_receipt"] or {}
            view["inventory_collection_status"] = ir.get("collection_status")
            view["inventory_refresh_attempt_status"] = (ir.get("refresh_attempt") or {}).get("collection_status")
        if "discovery_evidence" in rec:
            view["retained_in_candidate"] = rec["discovery_evidence"].get("retained_in_candidate")
            view["screen_score"] = rec["discovery_evidence"].get("screen_score")
        receipts[cid] = view
    result = {
        "variant": args.variant, "scenario": args.scenario, "network": args.network,
        "module_files": module_files,
        "rows": row_view,
        "row_ids": sorted(row_view),
        "stats": {k: v for k, v in stats.items() if k not in ("attachment_record_receipts",)},
        "receipts": receipts,
        "inventory_calls": len(inv_calls),
        "inventory_calls_by_notice": {n: sum(1 for u in inv_calls if n in u) for n in ids},
        "download_calls": len(dl_calls),
        "download_calls_by_resource": {r: dl_calls.count(r) for r in sorted(set(dl_calls))},
        "timings": timings,
        "wall_seconds": wall,
        "notice_cache_files": sorted(f for f in os.listdir(args.notice_cache)
                                     if not f.startswith(".")) if os.path.isdir(args.notice_cache) else [],
        "text_cache_files": sorted(f for f in os.listdir(args.text_cache)
                                   if not f.startswith(".")) if os.path.isdir(args.text_cache) else [],
    }
    with open(args.out, "w") as handle:
        json.dump(result, handle, indent=1, sort_keys=True, default=str)
    print(json.dumps({"ok": True, "out": args.out, "rows": len(rows), "wall": wall}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
