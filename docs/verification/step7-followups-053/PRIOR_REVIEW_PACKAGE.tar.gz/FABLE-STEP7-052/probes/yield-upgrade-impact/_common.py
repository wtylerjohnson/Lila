"""Shared subprocess plumbing for the yield/upgrade probes."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
CLONE = "/Users/wtjohnson/lila-step7-052"
PYTHON = os.path.join(CLONE, ".venv", "bin", "python")
TMP = os.path.join(HERE, "tmp")


def fresh_dir(label: str) -> str:
    path = os.path.join(TMP, f"{label}-{uuid.uuid4().hex[:8]}")
    os.makedirs(path, exist_ok=True)
    return path


def copy_cache(src: str, label: str) -> str:
    dst = os.path.join(TMP, f"{label}-{uuid.uuid4().hex[:8]}")
    shutil.copytree(src, dst)
    return dst


def run_variant(variant: str, notice_cache: str, text_cache: str, *, scenario: str = "mixed10",
                network: str = "ok", stage_seconds=None, inv_delay: float = 0.0,
                dl_delay: float = 0.0, label: str = "run") -> dict:
    out = os.path.join(TMP, f"{label}-{variant}-{uuid.uuid4().hex[:8]}.json")
    cmd = [PYTHON, os.path.join(HERE, "run_sweep.py"), "--variant", variant,
           "--scenario", scenario, "--notice-cache", notice_cache, "--text-cache", text_cache,
           "--network", network, "--inv-delay", str(inv_delay), "--dl-delay", str(dl_delay),
           "--out", out]
    if stage_seconds is not None:
        cmd += ["--stage-seconds", str(stage_seconds)]
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    completed = subprocess.run(cmd, cwd=CLONE, env=env, capture_output=True, text=True, timeout=600)
    if completed.returncode != 0:
        raise RuntimeError(f"{variant} sweep failed rc={completed.returncode}\n"
                           f"STDOUT:{completed.stdout[-2000:]}\nSTDERR:{completed.stderr[-4000:]}")
    with open(out) as handle:
        return json.load(handle)


def relevant_ids(result: dict) -> list[str]:
    return sorted(sid for sid, row in result["rows"].items()
                  if (row.get("attachment_relevance") or {}).get("relevant"))


def statuses(result: dict) -> dict[str, str]:
    return {cid[-2:]: rec["status"] for cid, rec in sorted(result["receipts"].items())}
