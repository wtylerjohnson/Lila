# Shadow subpackage: base sam_notice_detail / sam_attachment_text / _http live
# here; the clone's remaining tools.api modules resolve via the extended path.
__path__.append("/Users/wtjohnson/lila-step7-052/tools/api")
_src = "/Users/wtjohnson/lila-step7-052/tools/api/__init__.py"
with open(_src) as _handle:
    exec(compile(_handle.read(), _src, "exec"))
