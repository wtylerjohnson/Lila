# Shadow package: base copies of the three Step7 modules sit here; every other
# tools.* module resolves from the review clone via the extended search path.
__path__.append("/Users/wtjohnson/lila-step7-052/tools")
