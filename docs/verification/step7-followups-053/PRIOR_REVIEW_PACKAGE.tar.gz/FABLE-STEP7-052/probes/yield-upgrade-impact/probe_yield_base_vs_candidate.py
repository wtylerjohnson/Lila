"""Yield table: identical synthetic sweep through base vs candidate on fresh caches.

Diffs rows returned, relevance, receipts, raw_payload keys and network calls.
"""
from __future__ import annotations

import json
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from _common import fresh_dir, relevant_ids, run_variant, statuses  # noqa: E402


def main() -> int:
    base = run_variant("base", fresh_dir("y-base-n"), fresh_dir("y-base-t"), label="yield")
    cand = run_variant("candidate", fresh_dir("y-cand-n"), fresh_dir("y-cand-t"), label="yield")

    table = {}
    for cid in sorted(set(base["receipts"]) | set(cand["receipts"])):
        b_row = base["rows"].get(cid) or {}
        c_row = cand["rows"].get(cid) or {}
        table[cid[-2:]] = {
            "base_status": base["receipts"][cid]["status"],
            "cand_status": cand["receipts"][cid]["status"],
            "cand_inventory_state": cand["receipts"][cid].get("inventory_collection_status"),
            "cand_file_states": cand["receipts"][cid].get("files"),
            "base_row": bool(b_row), "cand_row": bool(c_row),
            "base_score": (b_row.get("attachment_relevance") or {}).get("score"),
            "cand_score": (c_row.get("attachment_relevance") or {}).get("score"),
            "base_text_chars": b_row.get("text_chars"), "cand_text_chars": c_row.get("text_chars"),
            "same_evidence_fingerprint": (b_row.get("text_sha256_basis") == c_row.get("text_sha256_basis"))
            if b_row and c_row else None,
        }
    base_keys = {cid: r["raw_payload_keys"] for cid, r in base["rows"].items()}
    cand_keys = {cid: r["raw_payload_keys"] for cid, r in cand["rows"].items()}
    shared = sorted(set(base_keys) & set(cand_keys))
    key_delta = {cid[-2:]: {"added_by_candidate": sorted(set(cand_keys[cid]) - set(base_keys[cid])),
                            "removed_by_candidate": sorted(set(base_keys[cid]) - set(cand_keys[cid]))}
                 for cid in shared}
    evidence_key_delta = {cid[-2:]: {
        "added": sorted(set(cand["rows"][cid]["evidence_keys"]) - set(base["rows"][cid]["evidence_keys"])),
        "removed": sorted(set(base["rows"][cid]["evidence_keys"]) - set(cand["rows"][cid]["evidence_keys"]))}
        for cid in shared}

    base_rel = relevant_ids(base)
    cand_rel = relevant_ids(cand)
    lost = sorted(set(base_rel) - set(cand_rel))
    gained = sorted(set(cand_rel) - set(base_rel))
    wrong_notice = [cid for cid in lost if cid.endswith("05")]
    unexplained_loss = [cid for cid in lost if cid not in wrong_notice]
    removed_keys = any(v["removed_by_candidate"] for v in key_delta.values())
    fingerprints_same = all(v["same_evidence_fingerprint"] for v in table.values()
                            if v["same_evidence_fingerprint"] is not None)
    wrong_notice_downloads = sum(v for r, v in base["download_calls_by_resource"].items() if r.endswith("051"))
    same_calls = (base["inventory_calls"] == cand["inventory_calls"]
                  and base["download_calls"] - wrong_notice_downloads == cand["download_calls"])

    status = "PASS"
    if unexplained_loss or removed_keys or not fingerprints_same or not same_calls:
        status = "FAIL"
    observed = {
        "yield_table": table,
        "base_rows": base["row_ids"], "cand_rows": cand["row_ids"],
        "base_stats": {k: base["stats"][k] for k in ("matched", "attachment_enriched", "attachment_relevant", "attachment_added")},
        "cand_stats": {k: cand["stats"][k] for k in ("matched", "attachment_enriched", "attachment_relevant", "attachment_added")},
        "relevant_lost_by_candidate": lost,
        "relevant_gained_by_candidate": gained,
        "loss_explained_as_wrong_notice_rejection": wrong_notice,
        "unexplained_loss": unexplained_loss,
        "raw_payload_key_delta": key_delta,
        "attachment_evidence_key_delta": evidence_key_delta,
        "wrong_notice_downloads_spent_by_base": wrong_notice_downloads,
        "network_calls": {"base": [base["inventory_calls"], base["download_calls"]],
                          "candidate": [cand["inventory_calls"], cand["download_calls"]]},
        "base_errors": base["stats"]["attachment_errors"],
        "cand_errors": cand["stats"]["attachment_errors"],
        "base_receipts": statuses(base), "cand_receipts": statuses(cand),
        "wall_seconds": {"base": base["wall_seconds"], "candidate": cand["wall_seconds"]},
        "module_files": {"base": base["module_files"], "candidate": cand["module_files"]},
        "note": "base accepts the wrong-notice body (N5) as relevant evidence for the requested notice; "
                "the candidate rejects it (identity_mismatch). That is the only row difference.",
    }
    print(json.dumps({"probe": "yield_base_vs_candidate", "status": status, "observed": observed},
                     indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
