"""H5: with a raised per-file text cap, file 3 gets zero budget and the dossier drops the whole research context."""
import json, os, sys, tempfile
os.environ['LILA_SAM_ATTACHMENT_TEXT_CHARS'] = '75000'   # must precede import
tmp = tempfile.mkdtemp(prefix='h5-')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = tmp
sys.path.insert(0, '/Users/wtjohnson/lila-step7-052')
import run_searches as searches
from agents.decisions.dossier import _attachment_research_context
from agents.schemas import RawOpportunity
from tools.api import sam_attachment_text as sat, sam_notice_detail as detail
import tools.api.sam_quota as q
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
q.calls_today = lambda: 0
files = [{'resource_id': c*32, 'name': f'SOW {i}.txt', 'access_level': 'public', 'access_status': 'public',
          'export_controlled': '0', 'explicit_access': '0'} for i, c in enumerate('bcd')]
inv = detail._manifest_hash(files)
detail.fetch_notice_resources = lambda *a, **k: {'id': 'a'*32, 'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv}
content = {f['resource_id']: ('network visibility ' + 'x'*80000)[:75000] for f in files}
sat._download_bytes = lambda rid, **k: content[rid].encode()
cand = RawOpportunity(source='sam.gov', source_id='a'*32, title='T', agency='NASA', raw_payload={'type': 'Solicitation'})
class Source:
    last_attachment_census = {'selected': 1}
    def attachment_candidates(self, *a, **k): return [cand]
rows, stats = searches._enrich_sam_public_attachments([], Source(), object(),
    CapabilityTaxonomy(client_name='T', version=1, updated='2026-07-21', core=[TaxonomyTerm(term='network visibility')]), None, limit=1)
raw = rows[0]['raw_payload']
locs = [(e['combined_text_locator']['start'], e['combined_text_locator']['end'], e['file_text_truncated']) for e in raw['attachment_evidence']]
receipts = {r['resource_id'][:1]: r['status'] for r in stats['attachment_record_receipts']['a'*32]['files']}
ctx = _attachment_research_context(rows[0], {'id': 'a'*32, 'resources_checked': True, 'attachment_inventory_hash': inv})
degenerate = any(s == e for s, e, _ in locs)
print(json.dumps({'probe': 'H5 zero-budget third file', 'status': 'FAIL' if (degenerate and ctx.get('status') == 'unavailable') else ('INFO' if degenerate else 'PASS'),
                  'observed': {'combined_len': len(raw['text']), 'locators': locs, 'file_receipt_status': receipts,
                               'dossier_status': ctx.get('status'), 'dossier_reason': ctx.get('reason'),
                               'note': 'requires LILA_SAM_ATTACHMENT_TEXT_CHARS above the default 50000; with defaults 3x50000+4 fits under 150000'}}, indent=1))
