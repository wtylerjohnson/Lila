"""Concurrent retain_bytes writers of the same digest and of many digests.

16 threads x 40 rounds race on one payload; then 16 threads each retain 40 distinct
payloads. Expect: every call returns the identical receipt, the object bytes are
exact, no temp litter, no exceptions, single hardlink count.
"""
import _harness as H
import hashlib
import os
import threading

from tools.api.sam_capture import read_retained, retain_bytes

root = H.fresh_dir("concurrent")
payload = b"racing bytes " * 5000
errors = []
receipts = []
lock = threading.Lock()
barrier = threading.Barrier(16)


def same_digest_worker():
    barrier.wait()
    for _ in range(40):
        try:
            rec = retain_bytes(root, payload)
            with lock:
                receipts.append(rec)
        except Exception as exc:  # noqa: BLE001
            with lock:
                errors.append(repr(exc))


threads = [threading.Thread(target=same_digest_worker) for _ in range(16)]
for t in threads:
    t.start()
for t in threads:
    t.join()

digest = hashlib.sha256(payload).hexdigest()
observed = {"same_digest": {"calls": len(receipts), "errors": errors[:5], "error_count": len(errors),
                            "distinct_receipts": len({tuple(sorted(r.items())) for r in receipts}),
                            "nlink": os.stat(root / "objects" / f"{digest}.bin").st_nlink}}
checks = {
    "same_digest_no_errors": not errors,
    "same_digest_single_receipt": len({tuple(sorted(r.items())) for r in receipts}) == 1 and len(receipts) == 640,
    "same_digest_bytes_exact": read_retained(root, receipts[0]) == payload,
    "same_digest_nlink_one": os.stat(root / "objects" / f"{digest}.bin").st_nlink == 1,
}

# Distinct payloads in parallel.
errors2 = []
all_receipts = {}
barrier2 = threading.Barrier(16)


def distinct_worker(index):
    barrier2.wait()
    for round_ in range(40):
        body = f"thread {index} round {round_}".encode() * 100
        try:
            rec = retain_bytes(root, body)
            with lock:
                all_receipts[rec["sha256"]] = (rec, body)
        except Exception as exc:  # noqa: BLE001
            with lock:
                errors2.append(repr(exc))


threads = [threading.Thread(target=distinct_worker, args=(i,)) for i in range(16)]
for t in threads:
    t.start()
for t in threads:
    t.join()
verify = all(read_retained(root, rec) == body for rec, body in all_receipts.values())
listing = H.listing(root / "objects")
observed["distinct"] = {"objects": len(listing), "errors": errors2[:5], "error_count": len(errors2),
                        "non_bin_entries": [n for n in listing if not n.endswith(".bin")]}
checks["distinct_no_errors"] = not errors2
checks["distinct_all_verified"] = verify and len(all_receipts) == 640
checks["no_temp_litter"] = all(n.endswith(".bin") for n in listing) and len(listing) == 641

H.emit("concurrent_writers", H.verdict(checks), observed, checks)
H.cleanup(root)
