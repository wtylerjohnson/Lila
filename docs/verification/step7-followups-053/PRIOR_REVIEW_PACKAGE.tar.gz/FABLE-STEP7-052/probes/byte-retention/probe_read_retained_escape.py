"""read_retained resists supplied-path escapes and inconsistent receipts.

Hostile receipts: ../ traversal, absolute path, non-hex digest, uppercase hex,
digest/path mismatch, wrong bytes length, bytes as string, symlink object pointing
outside, symlink object pointing at a sibling object, missing object, objects/ dir
itself a symlink (INFO), receipt not a dict-like. Positive control: valid receipt.
"""
import _harness as H
import hashlib
import os

from tools.api.sam_capture import read_retained, retain_bytes

root = H.fresh_dir("read-escape")
payload = b"retained payload bytes"
receipt = retain_bytes(root, payload)
digest = receipt["sha256"]
secret = root / "secret.txt"
secret.write_bytes(b"SECRET OUTSIDE OBJECTS")
observed = {}
checks = {}


def attempt(label, rec, directory=root):
    try:
        out = read_retained(directory, rec)
        observed[label] = {"result": "returned", "bytes": len(out)}
        return "returned"
    except Exception as exc:  # noqa: BLE001
        observed[label] = {"result": repr(exc)}
        return repr(exc)


checks["positive_valid_receipt"] = attempt("positive", receipt) == "returned"
checks["traversal_path_rejected"] = "locator" in attempt(
    "traversal", {**receipt, "path": f"objects/../secret.txt"})
checks["absolute_path_rejected"] = "locator" in attempt(
    "absolute", {**receipt, "path": str(secret)})
checks["nonhex_digest_rejected"] = "digest" in attempt(
    "nonhex", {**receipt, "sha256": "zz" * 32})
checks["uppercase_digest_rejected"] = "digest" in attempt(
    "uppercase", {**receipt, "sha256": digest.upper(), "path": f"objects/{digest.upper()}.bin"})
checks["short_digest_rejected"] = "digest" in attempt("short", {**receipt, "sha256": digest[:63]})
checks["digest_path_mismatch_rejected"] = "locator" in attempt(
    "mismatch", {**receipt, "sha256": hashlib.sha256(b"other").hexdigest()})
checks["wrong_length_rejected"] = "changed" in attempt("wrong_len", {**receipt, "bytes": len(payload) + 1})
checks["bytes_as_string_rejected"] = "changed" in attempt("bytes_str", {**receipt, "bytes": str(len(payload))})
checks["missing_bytes_rejected"] = "changed" in attempt("no_bytes", {k: v for k, v in receipt.items() if k != "bytes"})
checks["non_dict_receipt_raises"] = attempt("non_dict", ["list"]) != "returned"

# Symlink object -> outside file whose bytes hash to the receipt digest.
outside_digest = hashlib.sha256(secret.read_bytes()).hexdigest()
os.symlink(secret, root / "objects" / f"{outside_digest}.bin")
sym_out = {"path": f"objects/{outside_digest}.bin", "sha256": outside_digest, "bytes": len(secret.read_bytes())}
checks["symlink_to_outside_rejected"] = "escaped" in attempt("symlink_outside", sym_out)

# Symlink object -> sibling object (digest slot lies about its content).
fake_digest = hashlib.sha256(b"claimed content").hexdigest()
os.symlink(root / "objects" / f"{digest}.bin", root / "objects" / f"{fake_digest}.bin")
checks["symlink_to_sibling_rejected_by_hash"] = "changed" in attempt(
    "symlink_sibling", {"path": f"objects/{fake_digest}.bin", "sha256": fake_digest, "bytes": len(payload)})

# Missing object.
missing_digest = hashlib.sha256(b"never stored").hexdigest()
checks["missing_object_raises_oserror"] = "FileNotFound" in attempt(
    "missing", {"path": f"objects/{missing_digest}.bin", "sha256": missing_digest, "bytes": 12})

# Corrupted object (bit flip) with correct receipt.
flipped_digest = hashlib.sha256(b"good content").hexdigest()
(root / "objects" / f"{flipped_digest}.bin").write_bytes(b"good_content")
checks["corrupted_object_rejected"] = "changed" in attempt(
    "corrupted", {"path": f"objects/{flipped_digest}.bin", "sha256": flipped_digest, "bytes": 12})

# INFO: objects/ directory itself is a symlink to elsewhere; both sides resolve equal.
root2 = H.fresh_dir("read-escape-objdir")
elsewhere = H.fresh_dir("read-escape-elsewhere")
os.symlink(elsewhere, root2 / "objects")
rec2 = retain_bytes(root2, payload)
info_objdir = attempt("objects_dir_symlink", rec2, root2)
observed["objects_dir_symlink"]["note"] = ("objects/ as a symlink is followed on both sides of the "
                                          "parent comparison; cache root relocation is permitted")
observed["objects_dir_symlink"]["stored_at"] = str(elsewhere / f"{digest}.bin")

status = H.verdict(checks)
H.emit("read_retained_escape", status, observed, checks)
H.cleanup(root)
H.cleanup(root2)
H.cleanup(elsewhere)
