"""Error (4xx/5xx) and partial/truncated inventory bodies are retained with honest flags.

Cases: 404 body, 500 body, 429 body (retries=1), body exceeding the 2 MiB cap
(complete=false, exactly 2 MiB kept), transport error mid-stream (complete=false,
partial kept), timeout boundary. INFO: observer called once per attempt when a
generic caller passes retries>1 (production inventory caller uses retries=1).
"""
import _harness as H
import hashlib

import httpx

from tools.api import _http
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained

NOTICE = "a" * 32
root = H.fresh_dir("inv-err")
H.set_cache_dirs(root)
cache_dir = root / "notice"
observed = {}
checks = {}


def run(handler, label):
    H.bind_mock(handler)
    res = detail.fetch_notice_resources(NOTICE)
    rc = res.get("raw_capture")
    observed[label] = {"collection_status": res["collection_status"],
                       "errors": res["errors"], "raw_capture": rc,
                       "cache_file": (cache_dir / f"{NOTICE}.resources.json").exists()}
    return res, rc


for status in (404, 500, 429):
    body = f"error body for {status}".encode()
    res, rc = run(lambda request, body=body, status=status: httpx.Response(status, content=body), f"http_{status}")
    checks[f"http_{status}_lookup_failed"] = res["collection_status"] == "lookup_failed"
    checks[f"http_{status}_body_retained_complete"] = (
        rc is not None and rc["complete"] is True and rc["http_status"] == status
        and read_retained(cache_dir, rc) == body)
    checks[f"http_{status}_no_cache_file"] = not (cache_dir / f"{NOTICE}.resources.json").exists()

# Oversize: 2 MiB + 1 byte body.
big = b"x" * (2 * 1024 * 1024 + 1)
res, rc = run(lambda request: httpx.Response(200, content=big), "oversize")
checks["oversize_lookup_failed"] = res["collection_status"] == "lookup_failed"
checks["oversize_partial_flagged"] = rc is not None and rc["complete"] is False and rc["bytes"] == 2 * 1024 * 1024
checks["oversize_bytes_exact_prefix"] = read_retained(cache_dir, rc) == big[: 2 * 1024 * 1024]
checks["oversize_error_named"] = any("byte boundary" in e for e in res["errors"])

# Exactly 2 MiB body: must be complete.
exact = b'{"attachments": []}' + b" " * (2 * 1024 * 1024 - 19)
res, rc = run(lambda request: httpx.Response(200, content=exact), "exact_cap")
checks["exact_cap_complete_and_recognized"] = (
    rc["complete"] is True and rc["bytes"] == 2 * 1024 * 1024
    and res["collection_status"] == "confirmed_empty")
(cache_dir / f"{NOTICE}.resources.json").unlink()


# Transport error mid-body: stream yields a chunk then raises ReadError.
class Broken(httpx.SyncByteStream):
    def __iter__(self):
        yield b'{"attachments": [{"name": "partial'
        raise httpx.ReadError("connection reset mid-body")

    def close(self):
        pass


res, rc = run(lambda request: httpx.Response(200, stream=Broken()), "midstream_reset")
checks["midstream_lookup_failed"] = res["collection_status"] == "lookup_failed"
checks["midstream_partial_retained_incomplete"] = (
    rc is not None and rc["complete"] is False
    and read_retained(cache_dir, rc) == b'{"attachments": [{"name": "partial')
checks["midstream_error_named"] = any("reset" in e for e in res["errors"])
observed["midstream_reset"]["retained_bytes_vs_received"] = {
    "received_before_reset": len(b'{"attachments": [{"name": "partial'),
    "retained": rc["bytes"] if rc else None}


# Larger partial body: 70000 bytes received before the reset.
class BrokenLarge(httpx.SyncByteStream):
    def __iter__(self):
        yield b"y" * 70000
        raise httpx.ReadError("connection reset after 70000 bytes")

    def close(self):
        pass


res, rc = run(lambda request: httpx.Response(200, stream=BrokenLarge()), "midstream_reset_70000")
observed["midstream_reset_70000"]["retained_bytes_vs_received"] = {
    "received_before_reset": 70000, "retained": rc["bytes"] if rc else None}
checks["midstream_70000_all_received_bytes_retained"] = rc is not None and rc["bytes"] == 70000


# Slow body beyond the capture time boundary (monotonic patched forward).
class Slow(httpx.SyncByteStream):
    def __iter__(self):
        yield b"abc"
        _http.time.monotonic = lambda: real_mono() + 10_000
        yield b"def"

    def close(self):
        pass


real_mono = _http.time.monotonic
res, rc = run(lambda request: httpx.Response(200, stream=Slow()), "time_boundary")
_http.time.monotonic = real_mono
checks["time_boundary_partial_retained"] = (
    rc is not None and rc["complete"] is False and read_retained(cache_dir, rc) == b"abcdef")
checks["time_boundary_error_named"] = any("time boundary" in e for e in res["errors"])

# INFO: generic caller with retries=2 and a 503 then 200; observer called per attempt.
seen = []
sequence = [httpx.Response(503, content=b"busy"), httpx.Response(200, content=b'{"ok": 1}')]
H.bind_mock(lambda request: sequence.pop(0))
payload = _http.get_json("https://sam.gov/example", retries=2, max_response_bytes=1024,
                         response_observer=lambda r, raw, complete: seen.append((r.status_code, raw, complete)))
observed["retry_observer_calls"] = [(s, raw.decode(), c) for s, raw, c in seen]
observed["retry_payload"] = payload
checks["retry_observer_sees_each_attempt"] = seen == [(503, b"busy", True), (200, b'{"ok": 1}', True)]

observed["objects"] = H.listing(cache_dir / "objects")
checks["no_temp_litter"] = all(name.endswith(".bin") for name in observed["objects"])
H.emit("inventory_error_partial_bodies", H.verdict(checks), observed, checks)
H.cleanup(root)
