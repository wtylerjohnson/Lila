"""The observer (retain_bytes) raising inside the HTTP finally block (disk full).

Cases through fetch_notice_resources:
 a. complete body, retain raises ENOSPC -> what status/error is recorded, is the cache
    written, is the parsed payload lost;
 b. same with an existing valid fresh-but-expired (stale) cache -> stale_inventory
    fallback and refresh_attempt content;
 c. truncation ValueError in flight AND retain raises -> which error survives;
Through extract_public_attachment_text:
 d. raw retain raises -> status/error;
 e. raw retain ok, TEXT retain raises -> status is 'unreadable' although text parsed.
"""
import _harness as H
import errno
import json
import os
from datetime import datetime, timedelta, timezone

import httpx

from tools.api import sam_attachment_text as sat
from tools.api import sam_capture
from tools.api import sam_notice_detail as detail

NOTICE = "a" * 32
RID = "b" * 32
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
root = H.fresh_dir("observer")
H.set_cache_dirs(root)
cache_dir = root / "notice"
observed = {}
checks = {}
real_retain = sam_capture.retain_bytes


def enospc(directory, payload):
    raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(directory))


good = b'{"attachments": [{"name": "SOW.pdf", "resourceId": "' + RID.encode() + b'", "mimeType": "application/pdf"}]}'

# a. complete body, retain fails.
sam_capture.retain_bytes = enospc
H.bind_mock(lambda request: httpx.Response(200, content=good))
res_a = detail.fetch_notice_resources(NOTICE)
observed["a_disk_full_complete_body"] = {k: res_a.get(k) for k in (
    "collection_status", "errors", "resources_checked", "attachments", "raw_capture")}
observed["a_disk_full_complete_body"]["cache_written"] = (cache_dir / f"{NOTICE}.resources.json").exists()
checks["a_status_lookup_failed_inventory_dropped"] = (
    res_a["collection_status"] == "lookup_failed" and res_a["attachments"] is None
    and "raw_capture" not in res_a and any("No space left" in e for e in res_a["errors"]))
sam_capture.retain_bytes = real_retain

# b. an earlier valid cache, aged past TTL (6h) but under 7d, then disk-full refresh.
res_ok = detail.fetch_notice_resources(NOTICE)
cache_file = cache_dir / f"{NOTICE}.resources.json"
saved = json.loads(cache_file.read_text())
old = (datetime.now(timezone.utc) - timedelta(hours=8)).isoformat()
saved["raw_capture"]["received_at"] = old
saved["retrieved_at"] = old
cache_file.write_text(json.dumps(saved))
sam_capture.retain_bytes = enospc
res_b = detail.fetch_notice_resources(NOTICE)
sam_capture.retain_bytes = real_retain
observed["b_stale_fallback_on_disk_full"] = {"collection_status": res_b.get("collection_status"),
                                             "stale_cache": res_b.get("stale_cache"),
                                             "errors": res_b.get("errors"),
                                             "refresh_attempt": res_b.get("refresh_attempt")}
checks["b_stale_inventory_with_refresh_attempt_lacking_raw_capture"] = (
    res_b.get("collection_status") == "stale_inventory"
    and "raw_capture" not in (res_b.get("refresh_attempt") or {}))
cache_file.unlink()

# c. truncation in flight and retain fails: which error is recorded?
sam_capture.retain_bytes = enospc
H.bind_mock(lambda request: httpx.Response(200, content=b"x" * (2 * 1024 * 1024 + 5)))
res_c = detail.fetch_notice_resources(NOTICE)
sam_capture.retain_bytes = real_retain
observed["c_truncation_plus_disk_full"] = {"collection_status": res_c["collection_status"], "errors": res_c["errors"]}
checks["c_truncation_reason_survives"] = any("byte boundary" in e for e in res_c["errors"])

# d. file: raw retain fails.
sat._download_bytes = lambda rid, **k: b"Statement of work text"
sam_capture.retain_bytes = enospc
res_d = sat.extract_public_attachment_text(PUBLIC)
sam_capture.retain_bytes = real_retain
observed["d_file_raw_retain_fails"] = {k: res_d.get(k) for k in ("collection_status", "error", "text", "sha256")}
checks["d_file_labeled_lookup_failed_despite_successful_download"] = (
    res_d["collection_status"] == "lookup_failed" and res_d["text"] == "")

# e. file: raw retain ok, text retain fails.
calls = {"n": 0}


def second_fails(directory, payload):
    calls["n"] += 1
    if calls["n"] == 2:
        raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(directory))
    return real_retain(directory, payload)


sam_capture.retain_bytes = second_fails
res_e = sat.extract_public_attachment_text(PUBLIC)
sam_capture.retain_bytes = real_retain
observed["e_file_text_retain_fails"] = {k: res_e.get(k) for k in (
    "collection_status", "error", "text", "sha256", "raw_capture", "text_capture")}
observed["e_file_text_retain_fails"]["cache_written"] = (root / "text" / f"{RID}.json").exists()
checks["e_file_labeled_unreadable_although_text_parsed"] = (
    res_e["collection_status"] == "unreadable" and res_e["text"] == "" and "No space left" in res_e["error"])

# The checks named *_despite_* and *_although_* are demonstrated misleading receipts.
misleading = [k for k, v in checks.items() if v and ("despite" in k or "although" in k or "lacking" in k)]
observed["misleading_receipts_demonstrated"] = misleading
status = "FAIL" if misleading else H.verdict(checks)
H.emit("observer_raises", status, observed, checks)
H.cleanup(root)
