"""H7 base comparison for the INVENTORY route.

BASE 2d522f0 fetch_notice_resources (no byte retention) under the same os.link
failure and the same 200 recognized body: base returns the inventory, candidate returns
lookup_failed (measured in probe_hardlink_semantics). Also: base behavior when the
digest slot is poisoned is irrelevant (no objects); shown for the record.
"""
import _harness as H
import errno
import os

import httpx

from tools.api import sam_notice_detail as detail

NOTICE = "a" * 32
body = b'{"attachments": [{"name": "SOW.pdf", "resourceId": "' + b"b" * 32 + b'", "mimeType": "application/pdf"}]}'
observed = {}
checks = {}

root = H.fresh_dir("h7-base-inv")
H.set_cache_dirs(root)
base_detail = H.load_base("base_detail", "base_sam_notice_detail.py")
real_link = os.link


def failing_link(src, dst, *a, **k):
    raise OSError(errno.ENOTSUP, os.strerror(errno.ENOTSUP), str(dst))


os.link = failing_link
try:
    H.bind_mock(lambda request: httpx.Response(200, content=body))
    base_res = base_detail.fetch_notice_resources(NOTICE)
    (root / "notice" / f"{NOTICE}.resources.json").unlink(missing_ok=True)
    cand_res = detail.fetch_notice_resources(NOTICE)
finally:
    os.link = real_link

observed["base"] = {"resources_checked": base_res.get("resources_checked"),
                    "attachment_count": len(base_res.get("attachments") or []), "errors": base_res.get("errors")}
observed["candidate"] = {"collection_status": cand_res.get("collection_status"),
                         "resources_checked": cand_res.get("resources_checked"),
                         "attachments": cand_res.get("attachments"), "errors": cand_res.get("errors")}
checks["base_inventory_recognized_without_hardlinks"] = base_res.get("resources_checked") is True and len(base_res["attachments"]) == 1
checks["candidate_inventory_lost_without_hardlinks"] = cand_res.get("collection_status") == "lookup_failed" and cand_res.get("attachments") is None
status = "FAIL" if all(checks.values()) else "INFO"
observed["classification"] = "new_defect: candidate regresses inventory yield on filesystems without os.link; base unaffected"
H.emit("h7_base_inventory", status, observed, checks)
H.cleanup(root)
