"""Temporary file litter after exceptions inside retain_bytes.

Cases: fsync raises ENOSPC; os.link raises; write raises; a pre-existing stray temp
file in objects/ (simulating a process killed between create and unlink) is never
cleaned or mistaken for an object; KeyboardInterrupt during link still cleans up.
"""
import _harness as H
import errno
import os

from tools.api import sam_capture
from tools.api.sam_capture import retain_bytes

root = H.fresh_dir("litter")
payload = b"litter probe payload"
observed = {}
checks = {}


def run_case(label, patch_target, patch_value):
    original = getattr(patch_target[0], patch_target[1])
    setattr(patch_target[0], patch_target[1], patch_value)
    try:
        retain_bytes(root, payload)
        result = "returned"
    except BaseException as exc:  # noqa: BLE001
        result = repr(exc)
    finally:
        setattr(patch_target[0], patch_target[1], original)
    listing = H.listing(root / "objects")
    observed[label] = {"result": result, "objects_after": listing}
    checks[f"{label}_no_litter"] = all(n.endswith(".bin") for n in listing)
    return result


def raise_enospc(*a, **k):
    raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC))


run_case("fsync_enospc", (sam_capture.os, "fsync"), raise_enospc)
run_case("link_eperm", (sam_capture.os, "link"), lambda *a, **k: (_ for _ in ()).throw(PermissionError(errno.EPERM, "nope")))


def interrupt(*a, **k):
    raise KeyboardInterrupt()


run_case("link_keyboard_interrupt", (sam_capture.os, "link"), interrupt)
checks["object_not_published_after_failures"] = H.listing(root / "objects") == []

# Stray temp left by a killed process: does it break anything or get cleaned?
(root / "objects").mkdir(exist_ok=True)
stray = root / "objects" / "tmpstrayfile"
stray.write_bytes(b"half written")
receipt = retain_bytes(root, payload)
listing = H.listing(root / "objects")
observed["stray_temp"] = {"objects_after": listing, "stray_still_present": stray.exists()}
checks["stray_temp_left_in_place_no_gc"] = stray.exists()
checks["stray_temp_does_not_block_retention"] = receipt["path"].split("/")[1] in listing

# NamedTemporaryFile mode: object inherits 0600 from the temp file.
mode = oct(os.stat(root / receipt["path"]).st_mode & 0o777)
observed["published_object_mode"] = mode
checks["object_mode_recorded"] = True

status = "PASS" if all(v for k, v in checks.items() if k.endswith("_no_litter") or k == "object_not_published_after_failures") else "FAIL"
H.emit("temp_litter", status, observed, checks)
H.cleanup(root)
