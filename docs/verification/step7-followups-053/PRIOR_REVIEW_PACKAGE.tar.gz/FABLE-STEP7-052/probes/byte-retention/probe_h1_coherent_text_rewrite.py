"""H1: a coherent text-cache rewrite passes _text_capture_valid.

Rewrite the cached `text`, `text_sha256`, `text_locator`, and place a new
objects/<sha>.bin for the invented text while leaving raw_capture untouched. The
producer test only tampers `text` alone. Expect (hypothesis) the tampered text to be
served from cache with from_cache=True and no network attempt. Also: a fully coherent
rewrite of raw_capture+sha256 (different original bytes) passes too. Then compare with
BASE 2d522f0 which returned any cache blindly.
"""
import _harness as H
import hashlib
import json

from tools.api import sam_attachment_text as sat
from tools.api.sam_capture import retain_bytes

RID = "b" * 32
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
root = H.fresh_dir("h1")
H.set_cache_dirs(root)
text_dir = root / "text"
observed = {}
checks = {}

sat._download_bytes = lambda rid, **k: b"Original requirement: packet capture."
first = sat.extract_public_attachment_text(PUBLIC)
checks["positive_first_capture"] = first["collection_status"] == "captured_discovery_only"
cache = text_dir / f"{RID}.json"
saved = json.loads(cache.read_text())

# Coherent text rewrite.
invented = "Invented requirement: vendor X is mandatory."
saved["text"] = invented
saved["text_sha256"] = hashlib.sha256(invented.encode()).hexdigest()
saved["text_capture"] = retain_bytes(text_dir, invented.encode())
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": len(invented)}
cache.write_text(json.dumps(saved))


def network_must_not_be_called(rid, **k):
    raise AssertionError("network attempted")


sat._download_bytes = network_must_not_be_called
try:
    second = sat.extract_public_attachment_text(PUBLIC)
    observed["coherent_text_rewrite"] = {k: second.get(k) for k in (
        "collection_status", "from_cache", "text", "text_sha256", "sha256", "error")}
    valid = sat._text_capture_valid(saved, RID, saved["attachment_binding_sha256"])
except AssertionError as exc:
    observed["coherent_text_rewrite"] = {"network_attempted": True, "detail": str(exc)}
    valid = False
observed["text_capture_valid_on_rewrite"] = valid
checks["h1_tampered_text_served_from_cache"] = (
    valid and observed["coherent_text_rewrite"].get("from_cache") is True
    and observed["coherent_text_rewrite"].get("text") == invented)
checks["h1_raw_capture_still_original"] = second.get("sha256") == first["sha256"]

# Full coherent rewrite including raw bytes.
fake_raw = b"%PDF-1.4 fake original"
saved["raw_capture"] = retain_bytes(text_dir, fake_raw)
saved["sha256"] = hashlib.sha256(fake_raw).hexdigest()
cache.write_text(json.dumps(saved))
third = sat.extract_public_attachment_text(PUBLIC)
observed["coherent_full_rewrite"] = {k: third.get(k) for k in ("collection_status", "from_cache", "text", "sha256")}
checks["h1_full_rewrite_served_from_cache"] = third.get("from_cache") is True and third.get("text") == invented

# Producer-style single-field tamper is caught (control).
saved["text"] = "Only text changed"
cache.write_text(json.dumps(saved))
sat._download_bytes = lambda rid, **k: (_ for _ in ()).throw(RuntimeError("source unavailable"))
fourth = sat.extract_public_attachment_text(PUBLIC)
observed["text_only_tamper_control"] = {k: fourth.get(k) for k in ("collection_status", "from_cache", "text")}
checks["control_text_only_tamper_rejected"] = fourth["collection_status"] == "lookup_failed" and fourth["text"] == ""

# BASE comparison: base returned any cache dict blindly.
base_root = H.fresh_dir("h1-base")
import os
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base_root)
base_sat = H.load_base("base_sat_h1", "base_sam_attachment_text.py")
(base_root).mkdir(exist_ok=True)
(base_root / f"{RID}.json").write_text(json.dumps({"resource_id": RID, "name": "SOW.txt", "text": invented,
                                                   "sha256": "0" * 64, "error": ""}))
base_sat._download_bytes = network_must_not_be_called
base_res = base_sat.extract_public_attachment_text(PUBLIC)
observed["base_blind_cache"] = {"text": base_res.get("text"), "from_cache": base_res.get("from_cache")}
checks["base_served_tampered_text_too"] = base_res.get("text") == invented

status = "FAIL" if checks["h1_tampered_text_served_from_cache"] else H.verdict(checks)
H.emit("h1_coherent_text_rewrite", status, observed, checks)
H.cleanup(root)
H.cleanup(base_root)
