"""Inventory bytes are retained before JSON parse and survive parse failure.

Cases: invalid JSON 200; empty 200 body; positive control recognized empty; positive
control cache reuse; failure path writes no cache file but leaves the object.
"""
import _harness as H
import hashlib
import json

import httpx

from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained

NOTICE = "a" * 32
root = H.fresh_dir("inv-parse")
H.set_cache_dirs(root)
cache_dir = root / "notice"
observed = {}
checks = {}

# Case 1: HTTP 200 with a body that is not JSON.
body = b'{"attachments": [ this is not json'
H.bind_mock(lambda request: httpx.Response(200, content=body))
res = detail.fetch_notice_resources(NOTICE)
observed["invalid_json"] = {k: res.get(k) for k in (
    "collection_status", "resources_checked", "attachments", "errors", "from_cache")}
observed["invalid_json"]["raw_capture"] = res.get("raw_capture")
rc = res.get("raw_capture") or {}
checks["invalid_json_status_lookup_failed"] = res["collection_status"] == "lookup_failed"
checks["invalid_json_raw_retained_complete_200"] = (
    rc.get("complete") is True and rc.get("http_status") == 200)
try:
    checks["invalid_json_bytes_readable_exact"] = read_retained(cache_dir, rc) == body
except Exception as exc:  # noqa: BLE001
    checks["invalid_json_bytes_readable_exact"] = False
    observed["invalid_json"]["read_error"] = repr(exc)
checks["invalid_json_no_cache_file"] = not (cache_dir / f"{NOTICE}.resources.json").exists()
observed["files_after_invalid_json"] = H.listing(cache_dir)

# Case 2: empty 200 body.
H.bind_mock(lambda request: httpx.Response(200, content=b""))
res2 = detail.fetch_notice_resources(NOTICE)
rc2 = res2.get("raw_capture") or {}
observed["empty_body"] = {"collection_status": res2["collection_status"],
                          "raw_capture": rc2, "errors": res2["errors"]}
checks["empty_body_lookup_failed"] = res2["collection_status"] == "lookup_failed"
checks["empty_body_retained"] = (rc2.get("bytes") == 0 and rc2.get("sha256")
                                 == hashlib.sha256(b"").hexdigest()
                                 and read_retained(cache_dir, rc2) == b"")

# Case 3: positive control, recognized empty inventory, then cache reuse w/o network.
good = b'{"_embedded": {"opportunityAttachmentList": []}, "opportunityId": "' + NOTICE.encode() + b'"}'
calls = H.bind_mock(lambda request: httpx.Response(200, content=good))
res3 = detail.fetch_notice_resources(NOTICE)
res4 = detail.fetch_notice_resources(NOTICE)
observed["positive"] = {"first": {k: res3.get(k) for k in (
    "collection_status", "resources_checked", "attachments", "from_cache")},
    "second_from_cache": res4.get("from_cache"), "calls": len(calls),
    "raw_capture": res3.get("raw_capture")}
checks["positive_confirmed_empty"] = res3["collection_status"] == "confirmed_empty"
checks["positive_cache_reused_once_fetched"] = res4.get("from_cache") is True and len(calls) == 1
checks["positive_raw_exact"] = read_retained(cache_dir, res3["raw_capture"]) == good
saved = json.loads((cache_dir / f"{NOTICE}.resources.json").read_text())
checks["positive_cache_carries_receipt"] = saved.get("raw_capture", {}).get("sha256") == res3["raw_capture"]["sha256"]

# Case 4: failure objects accumulate with no receipt on disk (orphans).
objects = sorted(p.name for p in (cache_dir / "objects").iterdir())
referenced = {saved["raw_capture"]["sha256"] + ".bin"}
observed["objects"] = objects
observed["orphan_objects_without_disk_receipt"] = sorted(set(objects) - referenced)
checks["no_temp_litter"] = all(name.endswith(".bin") for name in objects)

status = H.verdict(checks)
H.emit("inventory_retain_before_parse", status, observed, checks)
H.cleanup(root)
