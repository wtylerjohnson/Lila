"""Representation claim: raw_capture bytes are decoded HTTP entity bytes.

Realistic transport shape: the handler returns a streaming body (httpx.ByteStream)
with Content-Encoding: gzip, the way a real HTTPTransport response arrives. Expect the
retained bytes to be the DECODED JSON, complete=true, inventory recognized, and the
reconstructed response free of content-encoding/content-length headers. Second case:
a pre-read body (content=gz) which httpx treats as already-decoded (MockTransport
artifact, INFO). Third: byte cap applied to decoded length, not wire length.
Fourth: truncated gzip stream (corrupt) -> what is retained and how it is labeled.
"""
import _harness as H
import gzip
import json

import httpx

from tools.api import _http
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained

NOTICE = "a" * 32
root = H.fresh_dir("gzip")
H.set_cache_dirs(root)
cache_dir = root / "notice"
observed = {}
checks = {}

plain = json.dumps({"_embedded": {"opportunityAttachmentList": [
    {"name": "SOW.pdf", "resourceId": "b" * 32, "mimeType": "application/pdf",
     "accessLevel": "public"}]}, "opportunityId": NOTICE}).encode()
gz = gzip.compress(plain)

# Case 1: streaming gzip body (realistic).
H.bind_mock(lambda request: httpx.Response(200, stream=httpx.ByteStream(gz),
                                           headers={"content-encoding": "gzip",
                                                    "content-length": str(len(gz)),
                                                    "content-type": "application/hal+json"}))
res = detail.fetch_notice_resources(NOTICE)
rc = res.get("raw_capture") or {}
retained = read_retained(cache_dir, rc) if rc else None
observed["stream_gzip"] = {"collection_status": res["collection_status"], "raw_capture": rc,
                           "retained_is_decoded_json": retained == plain,
                           "retained_is_wire_gzip": retained == gz, "wire_len": len(gz), "plain_len": len(plain),
                           "attachments": res.get("attachments")}
checks["stream_gzip_retained_decoded"] = retained == plain and rc.get("complete") is True
checks["stream_gzip_inventory_captured"] = res["collection_status"] == "inventory_captured"
(cache_dir / f"{NOTICE}.resources.json").unlink(missing_ok=True)

# Observe the reconstructed response headers directly through the helper.
seen = {}
H.bind_mock(lambda request: httpx.Response(200, stream=httpx.ByteStream(gz),
                                           headers={"content-encoding": "gzip", "content-length": str(len(gz))}))
payload = _http.get_json("https://sam.gov/x", retries=1, max_response_bytes=1 << 20,
                         response_observer=lambda r, raw, c: seen.update(status=r.status_code, raw=len(raw), complete=c,
                                                                          wire_headers=dict(r.headers)))
observed["helper_direct"] = {"parsed_ok": payload.get("opportunityId") == NOTICE, "observer": seen}
checks["helper_parses_decoded_json"] = payload.get("opportunityId") == NOTICE and seen["raw"] == len(plain)

# Case 2: pre-read body (content=gz). httpx marks it already decoded; MockTransport artifact.
H.bind_mock(lambda request: httpx.Response(200, content=gz, headers={"content-encoding": "gzip"}))
res2 = detail.fetch_notice_resources(NOTICE)
rc2 = res2.get("raw_capture") or {}
retained2 = read_retained(cache_dir, rc2) if rc2 else None
observed["preread_gzip_content"] = {"collection_status": res2["collection_status"], "errors": res2["errors"],
                                    "retained_is_wire_gzip": retained2 == gz,
                                    "note": "httpx Response(content=...) is treated as decoded; not a transport path"}

# Case 3: byte cap measured on decoded bytes: decoded 3000 bytes of spaces compress tiny.
padded = b'{"attachments": []' + b" " * 3000 + b"}"
gz_padded = gzip.compress(padded)
seen3 = {}
H.bind_mock(lambda request: httpx.Response(200, stream=httpx.ByteStream(gz_padded),
                                           headers={"content-encoding": "gzip"}))
try:
    _http.get_json("https://sam.gov/x", retries=1, max_response_bytes=1000,
                   response_observer=lambda r, raw, c: seen3.update(raw=len(raw), complete=c))
    cap_result = "returned"
except Exception as exc:  # noqa: BLE001
    cap_result = repr(exc)
observed["cap_on_decoded"] = {"wire_len": len(gz_padded), "decoded_len": len(padded), "result": cap_result, "observer": seen3}
checks["cap_applies_to_decoded_length"] = "byte boundary" in cap_result and seen3.get("raw") == 1000 and seen3.get("complete") is False

# Case 4: corrupt/truncated gzip stream (cache from case 2 removed first).
(cache_dir / f"{NOTICE}.resources.json").unlink(missing_ok=True)
H.bind_mock(lambda request: httpx.Response(200, stream=httpx.ByteStream(gz[: len(gz) // 2]),
                                           headers={"content-encoding": "gzip"}))
res4 = detail.fetch_notice_resources(NOTICE)
rc4 = res4.get("raw_capture") or {}
observed["truncated_gzip"] = {"collection_status": res4["collection_status"], "errors": res4["errors"],
                              "from_cache": res4.get("from_cache"), "raw_capture": rc4,
                              "note": "MockTransport bypasses h11 body-length enforcement; a real transport raises RemoteProtocolError on a short body",
                              "retained_prefix_of_plain": (read_retained(cache_dir, rc4) == plain[: rc4["bytes"]]) if rc4 else None}
checks["truncated_gzip_not_recognized"] = res4["collection_status"] == "lookup_failed" and res4.get("from_cache") is False
observed["truncated_gzip"]["complete_flag_despite_truncation"] = rc4.get("complete")

H.emit("gzip_representation", H.verdict(checks), observed, checks)
H.cleanup(root)
