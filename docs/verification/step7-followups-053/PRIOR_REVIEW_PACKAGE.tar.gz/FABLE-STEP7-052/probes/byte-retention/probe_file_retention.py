"""File byte retention in extract_public_attachment_text (positive + hostile).

Cases: retained before parse and kept after parse failure (unreadable docx, empty
text, unsupported type is refused BEFORE download or after?); 4xx/5xx download bodies
are NOT retained (raise_for_status before body); partial/over-cap file downloads are
NOT retained; redirect to an unapproved host; text_capture and raw_capture on
success; cache reuse without network; run_searches receipts carry raw_capture for an
unreadable file and an inventory failure.
"""
import _harness as H
import hashlib
import json

import httpx

from tools.api import sam_attachment_text as sat
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained

RID = "b" * 32
NOTICE = "a" * 32


def public(name, rid=RID):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


NATIVE_DOWNLOAD = sat._download_bytes
root = H.fresh_dir("file-ret")
H.set_cache_dirs(root)
text_dir = root / "text"
observed = {}
checks = {}

# 1. Positive: txt file captured; raw and text objects both retained; cache reuse offline.
body = "Statement of work. Café Δ packet capture.".encode()
sat._download_bytes = lambda rid, **k: body
ok = sat.extract_public_attachment_text(public("SOW.txt"))
observed["positive"] = {k: ok.get(k) for k in ("collection_status", "sha256", "raw_capture", "text_capture", "text_sha256", "text_locator")}
checks["positive_captured"] = ok["collection_status"] == "captured_discovery_only"
checks["positive_raw_exact"] = read_retained(text_dir, ok["raw_capture"]) == body
checks["positive_text_exact"] = read_retained(text_dir, ok["text_capture"]).decode() == ok["text"]
sat._download_bytes = lambda rid, **k: (_ for _ in ()).throw(AssertionError("network"))
again = sat.extract_public_attachment_text(public("SOW.txt"))
checks["positive_cache_reuse_offline"] = again.get("from_cache") is True and again["text"] == ok["text"]

# 2. Unreadable docx (bytes retained before parse; kept after failure).
junk = b"PK\x03\x04 not really a docx"
sat._download_bytes = lambda rid, **k: junk
bad = sat.extract_public_attachment_text(public("Requirements.docx", "c" * 32))
observed["unreadable_docx"] = {k: bad.get(k) for k in ("collection_status", "error", "sha256", "raw_capture", "retrieved_at")}
observed["unreadable_docx"]["cache_written"] = (text_dir / ("c" * 32 + ".json")).exists()
checks["unreadable_bytes_retained"] = (bad["collection_status"] == "unreadable"
                                      and read_retained(text_dir, bad["raw_capture"]) == junk
                                      and bad["sha256"] == hashlib.sha256(junk).hexdigest())
checks["unreadable_not_cached_receipt_only_in_memory"] = not (text_dir / ("c" * 32 + ".json")).exists()

# 3. Empty text after parse: bytes retained.
sat._download_bytes = lambda rid, **k: b"   \n  "
empty = sat.extract_public_attachment_text(public("Blank.txt", "d" * 32))
observed["empty_text"] = {k: empty.get(k) for k in ("collection_status", "error", "raw_capture")}
checks["empty_text_unreadable_with_bytes"] = empty["collection_status"] == "unreadable" and "raw_capture" in empty

# 4. Unsupported type: is the download made and retained?
downloads = []


def counting(rid, **k):
    downloads.append(rid)
    return b"binary xlsx"


sat._download_bytes = counting
xlsx = sat.extract_public_attachment_text(public("Pricing.xlsx", "e" * 32))
observed["unsupported_type"] = {k: xlsx.get(k) for k in ("collection_status", "error", "raw_capture")}
observed["unsupported_type"]["downloaded"] = len(downloads)
checks["unsupported_type_downloaded_then_unreadable_with_bytes"] = (
    len(downloads) == 1 and xlsx["collection_status"] == "unreadable" and "raw_capture" in xlsx)

# 5. Download errors through the REAL _download_bytes with a mocked client: 403/404/500 bodies, over-cap, mid-stream reset.
import tools.api.sam_attachment_text as module


def with_transport(handler):
    real_client = httpx.Client

    class MockClient(httpx.Client):
        def __init__(self, *a, **k):
            k.pop("transport", None)
            super().__init__(*a, transport=httpx.MockTransport(handler), **k)

    module.httpx.Client = MockClient
    try:
        return sat.extract_public_attachment_text(public("SOW.pdf", "f" * 32))
    finally:
        module.httpx.Client = real_client


sat._download_bytes = NATIVE_DOWNLOAD  # restore the real production downloader

for status in (403, 404, 500):
    res = with_transport(lambda request, status=status: httpx.Response(status, content=f"denied {status}".encode()))
    observed[f"download_http_{status}"] = {k: res.get(k) for k in ("collection_status", "error")}
    observed[f"download_http_{status}"]["raw_capture_present"] = "raw_capture" in res
    checks[f"download_http_{status}_error_body_not_retained"] = "raw_capture" not in res

big = b"%PDF" + b"x" * (5 * 1024 * 1024)
res = with_transport(lambda request: httpx.Response(200, content=big))
observed["download_over_cap"] = {k: res.get(k) for k in ("collection_status", "error")}
observed["download_over_cap"]["raw_capture_present"] = "raw_capture" in res
checks["download_over_cap_partial_not_retained"] = "raw_capture" not in res and res["collection_status"] == "lookup_failed"


class Reset(httpx.SyncByteStream):
    def __iter__(self):
        yield b"%PDF-1.4 partial"
        raise httpx.ReadError("reset")

    def close(self):
        pass


res = with_transport(lambda request: httpx.Response(200, stream=Reset()))
observed["download_midstream_reset"] = {k: res.get(k) for k in ("collection_status", "error")}
observed["download_midstream_reset"]["raw_capture_present"] = "raw_capture" in res
checks["download_partial_not_retained"] = "raw_capture" not in res

res = with_transport(lambda request: httpx.Response(302, headers={"location": "https://evil.example/x"}) if "sam.gov" in str(request.url) else httpx.Response(200, content=b"%PDF"))
observed["download_redirect_unapproved"] = {k: res.get(k) for k in ("collection_status", "error")}
checks["redirect_unapproved_host_refused"] = "unapproved host" in res.get("error", "")

# 6. run_searches receipts carry raw_capture for unreadable file and failed inventory.
import run_searches as searches
import tools.api.sam_quota as quota
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

quota.calls_today = lambda: 0
files = [public("SOW 1.txt", "1" * 32), public("Broken.docx", "2" * 32)]
inventory = detail._manifest_hash(files)
detail.fetch_notice_resources = lambda *a, **k: {"id": NOTICE, "resources_checked": True, "attachments": files,
                                                 "attachment_inventory_hash": inventory, "collection_status": "inventory_captured"}
texts = {"1" * 32: b"Buyer requires network visibility.", "2" * 32: b"PK not docx"}
sat._download_bytes = lambda rid, **k: texts[rid]


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})]


tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term="network visibility")])
rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
receipt = stats["attachment_record_receipts"][NOTICE]
file_states = {r["resource_id"]: (r["status"], "raw_capture" in r, r.get("reason")) for r in receipt["files"]}
observed["run_searches_file_receipts"] = file_states
checks["receipt_unreadable_file_carries_raw_capture"] = file_states["2" * 32][0] == "unreadable" and file_states["2" * 32][1]
checks["receipt_captured_file_carries_raw_capture"] = file_states["1" * 32][0] == "captured_discovery_only" and file_states["1" * 32][1]
collection = rows[0]["raw_payload"]["attachment_collection_v1"]
checks["collection_files_carry_raw_and_text_capture"] = all(
    "raw_capture" in f and "text_capture" in f for f in collection["files"]) and len(collection["files"]) == 1

# Inventory failure with retained error body reaches the inventory receipt.
detail.fetch_notice_resources = lambda *a, **k: {"id": NOTICE, "attachments": None, "resources_checked": False,
                                                 "collection_status": "lookup_failed", "errors": ["resources fetch failed: HTTP 500"],
                                                 "raw_capture": {"path": "objects/x.bin", "sha256": "x" * 64, "bytes": 3, "complete": True, "http_status": 500}}
rows2, stats2 = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
inv_receipt = stats2["attachment_record_receipts"][NOTICE]
observed["run_searches_inventory_receipt"] = {"status": inv_receipt["status"], "inventory_receipt": inv_receipt.get("inventory_receipt")}
checks["inventory_failure_receipt_carries_raw_capture"] = (inv_receipt["status"] == "INVENTORY_UNAVAILABLE"
                                                            and inv_receipt["inventory_receipt"]["raw_capture"]["http_status"] == 500)

observed["text_objects"] = H.listing(text_dir / "objects")
checks["no_temp_litter"] = all(n.endswith(".bin") for n in observed["text_objects"])
H.emit("file_retention", H.verdict(checks), observed, checks)
H.cleanup(root)
