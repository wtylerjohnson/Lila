"""retain_bytes hardlink publication semantics and H7 (os.link unsupported).

Cases: existing object with same bytes (no rewrite, inode preserved); existing object
with DIFFERENT bytes (poisoned digest slot); existing path is a symlink (same/other
bytes); existing path is a directory; objects/ is a regular file; os.link raising
EXDEV/EPERM/ENOTSUP. Each hostile case is also driven through the two production
callers (fetch_notice_resources, extract_public_attachment_text) to observe what
collection_status the caller records and whether the download is lost. BASE
(2d522f0) extract_public_attachment_text is run under the same os.link failure to
classify the yield regression.
"""
import _harness as H
import errno
import hashlib
import os
from pathlib import Path

import httpx

from tools.api import sam_attachment_text as sat
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained, retain_bytes

observed = {}
checks = {}
NOTICE = "a" * 32
RID = "b" * 32
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def objects_listing(directory: Path):
    return H.listing(directory / "objects")


# 1. Same bytes twice: second call must not rewrite; inode/mtime preserved.
root = H.fresh_dir("hl-same")
payload = b"identical bytes"
first = retain_bytes(root, payload)
stat1 = os.stat(root / first["path"])
second = retain_bytes(root, payload)
stat2 = os.stat(root / first["path"])
observed["same_bytes"] = {"receipt_equal": first == second, "inode_same": stat1.st_ino == stat2.st_ino,
                          "mtime_ns_same": stat1.st_mtime_ns == stat2.st_mtime_ns,
                          "nlink": stat2.st_nlink, "objects": objects_listing(root)}
checks["same_bytes_idempotent_no_rewrite"] = (first == second and stat1.st_ino == stat2.st_ino
                                              and stat1.st_mtime_ns == stat2.st_mtime_ns
                                              and stat2.st_nlink == 1)
checks["same_bytes_no_temp_litter"] = objects_listing(root) == [first["path"].split("/")[1]]
H.cleanup(root)

# 2. Poisoned digest slot: object exists with different bytes.
root = H.fresh_dir("hl-poison")
digest = hashlib.sha256(payload).hexdigest()
(root / "objects").mkdir(parents=True)
(root / "objects" / f"{digest}.bin").write_bytes(b"POISON")
try:
    retain_bytes(root, payload)
    poison_result = "returned"
except Exception as exc:  # noqa: BLE001
    poison_result = repr(exc)
observed["poisoned_slot"] = {"retain": poison_result, "existing_bytes_after": (root / "objects" / f"{digest}.bin").read_bytes().decode(),
                             "objects": objects_listing(root)}
checks["poisoned_slot_raises_not_overwrites"] = "retained SAM bytes changed" in poison_result and (root / "objects" / f"{digest}.bin").read_bytes() == b"POISON"
checks["poisoned_slot_no_temp_litter"] = objects_listing(root) == [f"{digest}.bin"]
# Through the inventory caller: SAM returns a body whose digest slot is poisoned.
H.set_cache_dirs(root)
inv_body = b'{"attachments": []}'
inv_digest = hashlib.sha256(inv_body).hexdigest()
(root / "notice" / "objects").mkdir(parents=True)
(root / "notice" / "objects" / f"{inv_digest}.bin").write_bytes(b"POISON")
calls = H.bind_mock(lambda request: httpx.Response(200, content=inv_body))
res_a = detail.fetch_notice_resources(NOTICE)
res_b = detail.fetch_notice_resources(NOTICE)
observed["poisoned_slot_inventory"] = {"status": res_a["collection_status"], "errors": res_a["errors"],
                                        "raw_capture_present": "raw_capture" in res_a,
                                        "second_call_status": res_b["collection_status"], "network_calls": len(calls)}
checks["poisoned_inventory_reported_as_lookup_failed_although_http_200_recognized"] = (
    res_a["collection_status"] == "lookup_failed" and res_b["collection_status"] == "lookup_failed"
    and any("bytes changed" in e for e in res_a["errors"]))
# Through the file caller.
text_body = b"Statement of work: packet capture required."
text_digest = hashlib.sha256(text_body).hexdigest()
(root / "text" / "objects").mkdir(parents=True)
(root / "text" / "objects" / f"{text_digest}.bin").write_bytes(b"POISON")
sat._download_bytes = lambda rid, **k: text_body
res_f = sat.extract_public_attachment_text(PUBLIC)
observed["poisoned_slot_file"] = {k: res_f.get(k) for k in ("collection_status", "error", "text", "sha256", "raw_capture")}
checks["poisoned_file_download_lost_and_labeled_lookup_failed"] = (
    res_f["collection_status"] == "lookup_failed" and res_f["text"] == "" and "raw_capture" not in res_f)
H.cleanup(root)

# 3. Existing path is a symlink.
root = H.fresh_dir("hl-symlink")
(root / "objects").mkdir(parents=True)
outside = root / "outside.bin"
outside.write_bytes(payload)
os.symlink(outside, root / "objects" / f"{digest}.bin")
try:
    r = retain_bytes(root, payload)
    sym_same = {"retain": r}
    try:
        read_retained(root, r)
        sym_same["read_retained"] = "ok"
    except Exception as exc:  # noqa: BLE001
        sym_same["read_retained"] = repr(exc)
except Exception as exc:  # noqa: BLE001
    sym_same = {"retain": repr(exc)}
observed["symlink_same_bytes_outside_target"] = sym_same
checks["symlink_outside_accepted_by_retain_but_rejected_by_read"] = (
    isinstance(sym_same.get("retain"), dict) and "escaped cache" in str(sym_same.get("read_retained")))
# symlink with different target bytes
other_payload = b"other bytes"
other_digest = hashlib.sha256(other_payload).hexdigest()
os.symlink(outside, root / "objects" / f"{other_digest}.bin")
try:
    retain_bytes(root, other_payload)
    sym_diff = "returned"
except Exception as exc:  # noqa: BLE001
    sym_diff = repr(exc)
observed["symlink_different_bytes"] = sym_diff
checks["symlink_different_bytes_raises"] = "bytes changed" in sym_diff
# dangling symlink
dangling_payload = b"dangling"
dangling_digest = hashlib.sha256(dangling_payload).hexdigest()
os.symlink(root / "missing-target", root / "objects" / f"{dangling_digest}.bin")
try:
    retain_bytes(root, dangling_payload)
    dangling = "returned"
except Exception as exc:  # noqa: BLE001
    dangling = repr(exc)
observed["dangling_symlink"] = dangling
checks["dangling_symlink_raises_oserror"] = "Error" in dangling
observed["symlink_case_objects"] = objects_listing(root)
checks["symlink_cases_no_temp_litter"] = all(n.endswith(".bin") for n in objects_listing(root))
H.cleanup(root)

# 4. Existing path is a directory; objects/ is a regular file.
root = H.fresh_dir("hl-dir")
(root / "objects" / f"{digest}.bin").mkdir(parents=True)
try:
    retain_bytes(root, payload)
    as_dir = "returned"
except Exception as exc:  # noqa: BLE001
    as_dir = repr(exc)
observed["path_is_directory"] = as_dir
checks["path_is_directory_raises"] = as_dir != "returned"
root2 = H.fresh_dir("hl-objfile")
(root2 / "objects").write_bytes(b"not a dir")
try:
    retain_bytes(root2, payload)
    obj_file = "returned"
except Exception as exc:  # noqa: BLE001
    obj_file = repr(exc)
observed["objects_is_file"] = obj_file
checks["objects_is_file_raises"] = obj_file != "returned"
H.cleanup(root)
H.cleanup(root2)

# 5. H7: os.link unsupported (EXDEV / EPERM / ENOTSUP). Candidate callers vs BASE.
real_link = os.link
h7 = {}
for code in (errno.EXDEV, errno.EPERM, errno.ENOTSUP):
    def failing_link(src, dst, *a, _code=code, **k):
        raise OSError(_code, os.strerror(_code), str(dst))

    root = H.fresh_dir(f"hl-h7-{code}")
    H.set_cache_dirs(root)
    os.link = failing_link
    try:
        try:
            retain_bytes(root, payload)
            direct = "returned"
        except Exception as exc:  # noqa: BLE001
            direct = repr(exc)
        # Inventory caller.
        calls = H.bind_mock(lambda request: httpx.Response(200, content=inv_body))
        res_i = detail.fetch_notice_resources(NOTICE)
        # File caller (candidate).
        sat._download_bytes = lambda rid, **k: text_body
        res_f = sat.extract_public_attachment_text(PUBLIC)
        # File caller (BASE 2d522f0).
        base_sat = H.load_base("base_sat", "base_sam_attachment_text.py")
        base_sat._download_bytes = lambda rid, **k: text_body
        base_res = base_sat.extract_public_attachment_text(PUBLIC)
    finally:
        os.link = real_link
    h7[os.strerror(code)] = {
        "retain_bytes": direct,
        "inventory": {"status": res_i["collection_status"], "errors": res_i["errors"],
                      "raw_capture_present": "raw_capture" in res_i,
                      "resources_checked": res_i["resources_checked"]},
        "file_candidate": {k: res_f.get(k) for k in ("collection_status", "error", "text")},
        "file_base": {"text": base_res.get("text"), "error": base_res.get("error")},
        "objects_notice": objects_listing(root / "notice"), "objects_text": objects_listing(root / "text"),
    }
    checks[f"h7_{code}_inventory_becomes_lookup_failed_bytes_dropped"] = (
        res_i["collection_status"] == "lookup_failed" and "raw_capture" not in res_i
        and objects_listing(root / "notice") == [])
    checks[f"h7_{code}_candidate_file_yield_lost_base_kept"] = (
        res_f["text"] == "" and res_f["collection_status"] == "lookup_failed"
        and base_res.get("text", "").startswith("Statement of work"))
    H.cleanup(root)
observed["h7_os_link_unsupported"] = h7

# Verdict: any hostile case where the candidate drops a successful download and
# labels it lookup_failed is a demonstrated defect for this dimension.
defects = [k for k, v in checks.items() if v and ("lookup_failed" in k or "yield_lost" in k)]
observed["defect_checks_true"] = defects
status = "FAIL" if defects else ("PASS" if all(checks.values()) else "FAIL")
H.emit("hardlink_semantics", status, observed, checks)
