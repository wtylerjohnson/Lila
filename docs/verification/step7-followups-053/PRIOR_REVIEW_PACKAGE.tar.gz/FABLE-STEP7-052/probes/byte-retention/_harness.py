"""Shared probe harness: network block, MockTransport binding, temp dirs, JSON output.

Import from every probe. Nothing here touches the review clone; every write goes to
a probe-local temp dir under this probe directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

# Hard network block: any socket connect anywhere in this process fails loudly.
_real_connect = socket.socket.connect


def _blocked_connect(self, *args, **kwargs):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked_connect
socket.socket.connect_ex = _blocked_connect
socket.create_connection = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("network blocked"))

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
# No sleeping between retries; production code sleeps 0.5s+ on retryable errors.
time.sleep = lambda seconds: None


def fresh_dir(label: str) -> Path:
    base = PROBE_DIR / "_tmp"
    base.mkdir(exist_ok=True)
    path = Path(tempfile.mkdtemp(prefix=f"{label}-", dir=base))
    return path


def cleanup(path: Path) -> None:
    shutil.rmtree(path, ignore_errors=True)


def set_cache_dirs(path: Path) -> None:
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(path / "text")


def bind_mock(handler):
    """Bind tools.api._http._client to a MockTransport handler. Returns call list."""
    import httpx
    from tools.api import _http

    calls = []

    def wrapped(request):
        calls.append(str(request.url))
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(wrapped), follow_redirects=True)
    return calls


def load_base(name: str, filename: str):
    """Import a BASE (2d522f0) module copy that lives in this probe dir."""
    spec = importlib.util.spec_from_file_location(name, PROBE_DIR / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def listing(path: Path) -> list[str]:
    if not path.exists():
        return []
    return sorted(str(p.relative_to(path)) for p in path.rglob("*") if p.is_file())


def emit(name: str, status: str, observed: dict, checks: dict | None = None) -> None:
    out = {"probe": name, "status": status, "observed": observed}
    if checks is not None:
        out["checks"] = checks
    print(json.dumps(out, indent=2, sort_keys=True, default=str))


def verdict(checks: dict[str, bool], fail_means: str = "FAIL") -> str:
    return "PASS" if all(checks.values()) else fail_means
