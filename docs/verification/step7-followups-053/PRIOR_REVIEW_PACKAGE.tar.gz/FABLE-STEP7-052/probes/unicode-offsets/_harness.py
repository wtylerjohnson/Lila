"""Shared probe harness: real candidate functions, network blocked, base loadable."""
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile

REPO = "/Users/wtjohnson/lila-step7-052"
PROBE_DIR = os.path.dirname(os.path.abspath(__file__))
TMP_ROOT = os.path.join(PROBE_DIR, "tmp")
os.makedirs(TMP_ROOT, exist_ok=True)
NOTICE_CACHE = tempfile.mkdtemp(prefix="notice-cache-", dir=TMP_ROOT)
os.environ["LILA_NOTICE_CACHE_DIR"] = NOTICE_CACHE
os.environ["LILA_SUITE_OFFLINE"] = "1"
if REPO not in sys.path:
    sys.path.insert(0, REPO)


def _deny(*args, **kwargs):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _deny
socket.socket.connect_ex = _deny
socket.create_connection = _deny

import run_searches as searches  # noqa: E402
from agents.decisions import dossier as dossier_c  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

TERM = "network visibility"
NOTICE = "a" * 32


def load_base(name, filename):
    spec = importlib.util.spec_from_file_location(
        name, os.path.join(PROBE_DIR, "base", filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def public_file(resource_id, name):
    return {"resource_id": resource_id, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def sha(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def run_pipeline(file_specs, *, notice_id=NOTICE, term=TERM, max_chars=None,
                 module=None, extra_attachments=None, limit=8):
    """file_specs: list of (resource_id, name, payload_bytes). Returns rows, stats, inventory, cache_dir."""
    module = module or searches
    cache_dir = tempfile.mkdtemp(prefix="text-cache-", dir=TMP_ROOT)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = cache_dir
    files = [public_file(rid, name) for rid, name, _ in file_specs] + list(extra_attachments or [])
    inventory = detail._manifest_hash(files)
    payloads = {rid: payload for rid, _, payload in file_specs}
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term=term)])
    saved = (detail.fetch_notice_resources, sat._download_bytes, sam_quota.calls_today,
             sat.MAX_ATTACHMENT_TEXT_CHARS)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": notice_id, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}
    sat._download_bytes = lambda rid, **k: payloads[rid]
    sam_quota.calls_today = lambda: 0
    if max_chars is not None:
        sat.MAX_ATTACHMENT_TEXT_CHARS = max_chars
    try:
        rows, stats = module._enrich_sam_public_attachments(
            [], Source(), object(), taxonomy, None, limit=limit)
    finally:
        (detail.fetch_notice_resources, sat._download_bytes, sam_quota.calls_today,
         sat.MAX_ATTACHMENT_TEXT_CHARS) = saved
    return rows, stats, inventory, cache_dir


def depth_for(notice_id, inventory):
    return {"id": notice_id, "resources_checked": True, "attachment_inventory_hash": inventory}


def context(row, inventory, module=None, notice_id=NOTICE):
    module = module or dossier_c
    return module._attachment_research_context(row, depth_for(notice_id, inventory))


def rehash_collection(raw):
    raw["attachment_collection_sha256"] = sha(canonical(raw["attachment_collection_v1"]))


def rehash_text(raw):
    """Recompute every text-derived hash after raw['text'] changed (legit local rewrite)."""
    text_sha = sha(raw["text"])
    raw["attachment_collection_v1"]["combined_text_sha256"] = text_sha
    basis = {"files": sorted([{"resource_id": str(i.get("resource_id") or ""),
                               "sha256": str(i.get("sha256") or "")}
                              for i in raw["attachment_evidence"]],
                             key=lambda i: (i["resource_id"], i["sha256"])),
             "text_sha256": text_sha}
    raw["attachment_evidence_sha256"] = sha(canonical(basis))
    rehash_collection(raw)


def roundtrip_ascii(obj):
    return json.loads(json.dumps(obj))


def roundtrip_atomic(obj):
    data = (json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n").encode("utf-8")
    return json.loads(data)


def emit(status, observed, **extra):
    out = {"status": status, "observed": observed}
    out.update(extra)
    print(json.dumps(out, indent=2, ensure_ascii=True, default=str))


def cleanup():
    shutil.rmtree(TMP_ROOT, ignore_errors=True)
