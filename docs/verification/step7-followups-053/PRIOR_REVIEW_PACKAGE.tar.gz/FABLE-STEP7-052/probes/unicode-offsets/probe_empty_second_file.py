"""Second file empty after strip; whitespace-only, NBSP, ZWSP-only, replacement-only, UTF-16 payloads."""
import _harness as H

checks = {}
observed = {}
payload_b = b"network visibility requirement \xce\x94"
payload_d = b"Third file \xe4\xb8\xad\xe6\x96\x87 deliverables"

# Case A: whitespace/NBSP/CRLF only -> stripped to "" -> unreadable, skipped; locators stay contiguous.
rows, stats, inventory, _ = H.run_pipeline([
    ("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", b"   \r\n\t \xc2\xa0 \n"),
    ("d" * 32, "SOW 3.txt", payload_d)])
raw = rows[0]["raw_payload"]
ev = raw["attachment_evidence"]
receipts = {r["resource_id"]: r for r in stats["attachment_record_receipts"][H.NOTICE]["files"]}
checks["A_two_files_in_evidence"] = [i["resource_id"] for i in ev] == ["b" * 32, "d" * 32]
checks["A_second_file_receipt_unreadable"] = (receipts["c" * 32]["status"] == "unreadable"
    and receipts["c" * 32]["reason"] == "attachment yielded no readable text")
exp_b = payload_b.decode().strip(); exp_d = payload_d.decode().strip()
checks["A_locators_skip_empty_file"] = ([(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in ev]
    == [(0, len(exp_b)), (len(exp_b) + 2, len(exp_b) + 2 + len(exp_d))])
checks["A_text_is_two_file_join"] = raw["text"] == exp_b + "\n\n" + exp_d
ctx = H.context(rows[0], inventory)
checks["A_dossier_discovery_only_two_passages"] = ctx["status"] == "discovery_only" and len(ctx["file_passages"]) == 2
observed["A_receipt_c"] = {k: receipts["c" * 32].get(k) for k in ("status", "reason", "collection_status", "sha256")}

# Case B: ZWSP-only payload (U+200B is Cf, not whitespace) -> retained as 1-char text.
rows, stats, inventory, _ = H.run_pipeline([
    ("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", "​".encode()),
    ("d" * 32, "SOW 3.txt", payload_d)])
ev = rows[0]["raw_payload"]["attachment_evidence"]
zw = next((i for i in ev if i["resource_id"] == "c" * 32), None)
observed["B_zwsp_only_file_retained"] = zw is not None and zw["combined_text_locator"]["end"] - zw["combined_text_locator"]["start"] == 1
checks["B_dossier_accepts_zwsp_file"] = H.context(rows[0], inventory)["status"] == "discovery_only"

# Case C: replacement-only payload (all invalid UTF-8) -> "�..." counted as readable text.
rows, stats, inventory, _ = H.run_pipeline([
    ("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", b"\xff\xfe\xfd"),
    ("d" * 32, "SOW 3.txt", payload_d)])
ev = rows[0]["raw_payload"]["attachment_evidence"]
rep = next((i for i in ev if i["resource_id"] == "c" * 32), None)
observed["C_replacement_only_file_retained_as_text"] = rep is not None
observed["C_text_repr"] = repr(rows[0]["raw_payload"]["text"][rep["combined_text_locator"]["start"]:rep["combined_text_locator"]["end"]]) if rep else None
checks["C_dossier_accepts"] = H.context(rows[0], inventory)["status"] == "discovery_only"

# Case D: UTF-16 encoded .txt (BOM) decoded as UTF-8 with replace -> NUL-interleaved garbage retained.
rows, stats, inventory, _ = H.run_pipeline([
    ("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", "network visibility spec".encode("utf-16")),
    ("d" * 32, "SOW 3.txt", payload_d)])
ev = rows[0]["raw_payload"]["attachment_evidence"]
u16 = next((i for i in ev if i["resource_id"] == "c" * 32), None)
if u16:
    loc = u16["combined_text_locator"]
    seg = rows[0]["raw_payload"]["text"][loc["start"]:loc["end"]]
    observed["D_utf16_segment_repr"] = repr(seg[:40])
    observed["D_utf16_contains_nul"] = "\x00" in seg
observed["D_utf16_file_retained_as_text"] = u16 is not None
checks["D_dossier_accepts"] = H.context(rows[0], inventory)["status"] == "discovery_only"
checks["D_roundtrip_with_nul_survives"] = H.context(H.roundtrip_atomic(rows[0]), inventory)["status"] == "discovery_only"

status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, {"checks": checks, **observed},
       note="B/C/D are measured limits of readability (not offset defects): non-whitespace-only or mis-decoded payloads count as captured discovery text with consistent locators.")
H.cleanup()
