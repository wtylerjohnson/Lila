"""Positive control: multi-byte, U+FFFD, CRLF, lone CR, internal blank lines, whitespace, NFC/NFD, ZWJ."""
import re
import unicodedata
import _harness as H

# File 1: leading/trailing whitespace, doubled spaces/tabs, CRLF, lone CR, internal "\n\n",
# invalid UTF-8 bytes (-> U+FFFD), Latin-1 supplement, Greek, CJK, non-BMP emoji, combining
# sequence, ZWJ family sequence.
payload_b = (b"  \n\n \t" + b"network visibility  Caf\xc3\xa9 \xce\x94 \xe4\xb8\xad\xe6\x96\x87 "
             b"\xf0\x9f\x99\x82 e\xcc\x81 \xf0\x9f\x91\xa9\xe2\x80\x8d\xf0\x9f\x92\xbb\r\n"
             b"line2\rline3\n\ninternal gap \xff\xfe bad bytes \t\t tabs   \n \r\n")
payload_c = "Requirement NFD: Café deliverables".encode("utf-8")
payload_d = "Requirement NFC: Café deliverables".encode("utf-8")


def expected_text(payload):
    # Independent restatement of the documented extraction shape for .txt files.
    text = payload.decode("utf-8", errors="replace")
    return re.sub(r"[ \t]{2,}", " ", text).strip()


checks = {}
rows, stats, inventory, cache = H.run_pipeline([
    ("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", payload_c),
    ("d" * 32, "SOW 3.txt", payload_d)])
checks["row_present"] = len(rows) == 1
raw = rows[0]["raw_payload"]
text = raw["text"]
ev = raw["attachment_evidence"]
exp = [expected_text(payload_b), expected_text(payload_c), expected_text(payload_d)]
checks["three_files"] = len(ev) == 3
checks["combined_equals_join"] = text == "\n\n".join(exp)
prev = 0
loc_ok = []
for i, item in enumerate(ev):
    loc = item["combined_text_locator"]
    start, end = loc["start"], loc["end"]
    loc_ok.append(loc["unit"] == "unicode_characters" and start == prev + (2 if i else 0)
                  and text[start:end] == exp[i]
                  and H.sha(text[start:end].encode("utf-8")) == item["text_sha256"]
                  and item["file_text_locator"] == {"unit": "unicode_characters", "start": 0, "end": len(exp[i])}
                  and item["file_text_truncated"] is False)
    prev = end
checks["locators_contiguous_and_hashed_over_utf8_of_char_slice"] = all(loc_ok)
checks["combined_ends_at_last_locator"] = prev == len(text)
checks["u_fffd_present"] = "�� bad bytes" in exp[0] and "�" in text
checks["crlf_preserved"] = "\r\nline2\rline3" in text
checks["internal_blank_line_inside_file_1"] = "\n\ninternal gap" in exp[0]
checks["leading_trailing_stripped"] = exp[0].startswith("network visibility Café") and exp[0].endswith("tabs")
checks["double_space_collapsed"] = "network visibility Caf" in exp[0]
checks["zwj_and_nonbmp_in_text"] = "\U0001F469‍\U0001F4BB" in text and "\U0001F642" in text
checks["nfd_nfc_not_normalized_lengths_differ"] = (len(exp[1]) == len(exp[2]) + 1
    and unicodedata.normalize("NFC", exp[1]) == exp[2].replace("NFC", "NFD"))
ctx = H.context(rows[0], inventory)
checks["dossier_discovery_only"] = ctx["status"] == "discovery_only"
checks["passages_match_files"] = (ctx.get("status") == "discovery_only"
    and [p["text"] for p in ctx["file_passages"]] == exp
    and all(p["truncated"] is False for p in ctx["file_passages"]))
checks["collection_sha_echoed"] = ctx.get("collection_sha256") == raw["attachment_collection_sha256"]
for name, fn in (("ascii", H.roundtrip_ascii), ("atomic_ensure_ascii_false", H.roundtrip_atomic)):
    rt = fn(rows[0])
    c2 = H.context(rt, inventory)
    checks[f"roundtrip_{name}_same_context"] = c2 == ctx
receipts = stats["attachment_record_receipts"][H.NOTICE]
checks["file_receipts_captured"] = {r["resource_id"]: r["status"] for r in receipts["files"]} == {
    "b" * 32: "captured_discovery_only", "c" * 32: "captured_discovery_only", "d" * 32: "captured_discovery_only"}
status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, {"checks": checks, "combined_chars": len(text), "combined_utf8_bytes": len(text.encode()),
                "locators": [i["combined_text_locator"] for i in ev],
                "file_1_text_repr": repr(exp[0]), "dossier_reason": ctx.get("reason")})
H.cleanup()
