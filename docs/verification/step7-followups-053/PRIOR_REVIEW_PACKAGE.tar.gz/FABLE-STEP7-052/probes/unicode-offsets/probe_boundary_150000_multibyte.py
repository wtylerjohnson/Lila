"""150000 ceiling counts code points, not bytes; per-file sha is over utf-8 of the character slice."""
import _harness as H

checks = {}
b = "network visibility " + "\U0001F642" * (100000 - 19)      # 4-byte code points
c = "é" * 100000                                          # 2-byte code points
rows, stats, inventory, _ = H.run_pipeline([("b" * 32, "SOW 1.txt", b.encode()), ("c" * 32, "SOW 2.txt", c.encode())],
                                           max_chars=100000)
raw = rows[0]["raw_payload"]
text = raw["text"]
ev = raw["attachment_evidence"]
locs = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in ev]
checks["combined_is_150000_code_points"] = len(text) == 150000
expected_bytes = 19 + 4 * (100000 - 19) + 2 + 2 * 49998
checks["combined_utf8_bytes_exceed_chars"] = len(text.encode()) == expected_bytes
checks["locators"] = locs == [(0, 100000), (100002, 150000)]
checks["file2_truncated_flag"] = ev[1]["file_text_truncated"] is True and ev[0]["file_text_truncated"] is False
checks["file2_file_text_locator_is_kept_chars"] = ev[1]["file_text_locator"] == {"unit": "unicode_characters", "start": 0, "end": 49998}
checks["sha_over_utf8_of_char_slice"] = all(
    H.sha(text[s:e].encode("utf-8")) == i["text_sha256"] for (s, e), i in zip(locs, ev))
checks["byte_offset_interpretation_would_fail"] = H.sha(text.encode()[100002:150000]) != ev[1]["text_sha256"]
checks["combined_sha_binds_utf8"] = raw["attachment_collection_v1"]["combined_text_sha256"] == H.sha(text.encode("utf-8"))
ctx = H.context(rows[0], inventory)
checks["dossier_accepts"] = ctx["status"] == "discovery_only"
if ctx["status"] == "discovery_only":
    p0, p1 = ctx["file_passages"]
    checks["passage0_cut_at_14000_chars"] = p0["text"] == text[:14000] and p0["truncated"] is True and p0["included_end"] == 14000
    checks["passage1_beyond_prompt_is_empty_but_marked"] = p1["text"] == "" and p1["truncated"] is True and p1["included_end"] == 100002
    checks["passages_total_14000"] = sum(len(p["text"]) for p in ctx["file_passages"]) == 14000
    checks["context_text_14000_chars"] = len(ctx["text"]) == 14000 and ctx["truncated"] is True and ctx["captured_characters"] == 150000
for name, fn in (("ascii", H.roundtrip_ascii), ("atomic", H.roundtrip_atomic)):
    checks[f"roundtrip_{name}_accepts"] = H.context(fn(rows[0]), inventory)["status"] == "discovery_only"
status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, {"checks": checks, "locators": locs, "combined_chars": len(text), "combined_bytes": len(text.encode()),
                "dossier_reason": ctx.get("reason")})
H.cleanup()
