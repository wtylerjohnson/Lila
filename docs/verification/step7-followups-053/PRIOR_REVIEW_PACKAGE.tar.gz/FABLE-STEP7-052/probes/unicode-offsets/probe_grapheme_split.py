"""Truncation and prompt cuts fall on code points; grapheme clusters may be split (measured limit)."""
import unicodedata
import _harness as H

checks = {}
observed = {}
# File 1 exactly 100000 code points of "e" + U+0301 pairs after the term; file 2 is ZWJ sequences with
# a 1-char offset so the 49998-char remainder cut lands between U+1F469 U+200D and U+1F4BB.
b = "network visibility " + "é" * ((100000 - 19) // 2) + "e"
assert len(b) == 100000
c = "x" + "\U0001F469‍\U0001F4BB" * 40000
rows, stats, inventory, _ = H.run_pipeline([("b" * 32, "SOW 1.txt", b.encode()), ("c" * 32, "SOW 2.txt", c.encode())],
                                           max_chars=100000)
raw = rows[0]["raw_payload"]
text = raw["text"]
ev = raw["attachment_evidence"]
s1, e1 = ev[1]["combined_text_locator"]["start"], ev[1]["combined_text_locator"]["end"]
file2 = text[s1:e1]
observed["file2_kept_chars"] = len(file2)
observed["file2_tail_codepoints"] = [f"U+{ord(ch):04X}" for ch in file2[-3:]]
checks["file2_cut_leaves_dangling_zwj"] = file2.endswith("\U0001F469‍")
checks["file2_truncated_flag"] = ev[1]["file_text_truncated"] is True
ctx = H.context(rows[0], inventory)
checks["dossier_accepts_dangling_zwj"] = ctx["status"] == "discovery_only"
p0 = ctx["file_passages"][0]
observed["prompt_cut_last_two_codepoints"] = [f"U+{ord(ch):04X}" for ch in p0["text"][-2:]]
observed["prompt_cut_next_codepoint"] = f"U+{ord(text[14000]):04X}"
checks["prompt_cut_splits_combining_sequence"] = p0["text"].endswith("e") and text[14000] == "́"
checks["prompt_cut_is_14000_codepoints"] = len(p0["text"]) == 14000 == len(ctx["text"])
observed["nfc_of_prompt_text_len"] = len(unicodedata.normalize("NFC", p0["text"]))
# Regional-indicator flag pair split at the per-file 150000 remainder cut.
flag = "\U0001F1FA\U0001F1F8"   # US flag = 2 code points
b2 = "network visibility " + "é" * (100000 - 19)
c2 = flag * 30000              # 60000 chars, remainder 49998 is even -> whole flags; use odd offset
c2 = "y" + c2
rows2, stats2, inventory2, _ = H.run_pipeline([("b" * 32, "SOW 1.txt", b2.encode()), ("c" * 32, "SOW 2.txt", c2.encode())],
                                              max_chars=100000)
raw2 = rows2[0]["raw_payload"]
ev2 = raw2["attachment_evidence"]
f2 = raw2["text"][ev2[1]["combined_text_locator"]["start"]:ev2[1]["combined_text_locator"]["end"]]
observed["flag_tail_codepoints"] = [f"U+{ord(ch):04X}" for ch in f2[-2:]]
checks["flag_pair_split_at_cut"] = f2.endswith("\U0001F1FA") and not f2.endswith(flag)
checks["dossier_accepts_split_flag"] = H.context(rows2[0], inventory2)["status"] == "discovery_only"
# Whitespace at truncation boundary: strip happens before the per-file cap, so kept text can end in "\n".
b3 = "network visibility x" + ("word\n" * 40000)    # 20-char prefix: index 99999 is "\n"
b3 = b3[:100000]
assert b3[-1] == "\n"
c3 = "second file"
rows3, stats3, inventory3, _ = H.run_pipeline([("b" * 32, "SOW 1.txt", (b3 + "tail that is cut").encode()), ("c" * 32, "SOW 2.txt", c3.encode())],
                                              max_chars=100000)
raw3 = rows3[0]["raw_payload"]
e3 = raw3["attachment_evidence"][0]["combined_text_locator"]["end"]
observed["file1_end_context_repr"] = repr(raw3["text"][e3 - 3:e3 + 3])
checks["kept_file_text_may_end_with_newline"] = raw3["text"][e3 - 1] == "\n" and raw3["text"][e3:e3 + 2] == "\n\n"
checks["dossier_accepts_triple_newline_region"] = H.context(rows3[0], inventory3)["status"] == "discovery_only"
ctx3 = H.context(rows3[0], inventory3)
s3, e3b = raw3["attachment_evidence"][1]["combined_text_locator"]["start"], raw3["attachment_evidence"][1]["combined_text_locator"]["end"]
checks["passage_boundaries_still_exact"] = (raw3["text"][s3:e3b] == "second file" and s3 == e3 + 2
    and ctx3["file_passages"][1]["text"] == "" and ctx3["file_passages"][1]["truncated"] is True)
status = "INFO" if all(checks.values()) else "FAIL"
H.emit(status, {"checks": checks, **observed},
       note="unit 'unicode_characters' means Python code points; per-file remainder cut and the 14000 prompt cut can split combining sequences, ZWJ sequences and flag pairs. Hash binding stays consistent; this is a disclosed bounded-extraction limit, not an offset defect.")
H.cleanup()
