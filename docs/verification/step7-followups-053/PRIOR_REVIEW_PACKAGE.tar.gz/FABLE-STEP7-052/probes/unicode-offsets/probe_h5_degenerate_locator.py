"""H5: raised LILA_SAM_ATTACHMENT_TEXT_CHARS lets files 1+2 fill 150000; file 3 gets start==end. Candidate vs base."""
import _harness as H

base_searches = H.load_base("run_searches_base", "run_searches_base.py")
base_dossier = H.load_base("dossier_base", "dossier_base.py")
checks = {}
observed = {}


def specs(n1, n2, n3):
    b = ("network visibility " + "é" * n1)[:n1]
    c = "Δ" * n2
    d = "中" * n3
    return [("b" * 32, "SOW 1.txt", b.encode()), ("c" * 32, "SOW 2.txt", c.encode()),
            ("d" * 32, "SOW 3.txt", d.encode())]


# Scenario 1: MAX=100000, files 100000 + 100000 + 1000 chars.
rows, stats, inventory, _ = H.run_pipeline(specs(100000, 100000, 1000), max_chars=100000)
raw = rows[0]["raw_payload"]
ev = raw["attachment_evidence"]
locs = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in ev]
observed["S1_locators"] = locs
observed["S1_combined_chars"] = len(raw["text"])
third = ev[2]
observed["S1_third_file_evidence"] = {"file_text_locator": third["file_text_locator"],
    "file_text_truncated": third["file_text_truncated"], "text_sha256_is_sha_of_empty": third["text_sha256"] == H.sha(b""),
    "start_gt_len_text": third["combined_text_locator"]["start"] > len(raw["text"])}
receipt = stats["attachment_record_receipts"][H.NOTICE]
observed["S1_record_status"] = receipt["status"]
observed["S1_third_file_receipt"] = {k: v for k, v in next(r for r in receipt["files"] if r["resource_id"] == "d" * 32).items()
                                     if k in ("status", "reason", "collection_status")}
observed["S1_fingerprint_lists_three_files"] = len(receipt["discovery_evidence"]["files"]) == 3
ctx = H.context(rows[0], inventory)
observed["S1_candidate_dossier"] = {"status": ctx["status"], "reason": ctx.get("reason")}
checks["S1_degenerate_locator_emitted"] = locs[2][0] == locs[2][1] == 150002
checks["S1_whole_context_dropped_by_candidate_dossier"] = ctx["status"] == "unavailable"

# Same inputs through the BASE run_searches (shared candidate extractor), then both dossiers.
brows, bstats, binv, _ = H.run_pipeline(specs(100000, 100000, 1000), max_chars=100000, module=base_searches)
braw = brows[0]["raw_payload"]
observed["S1_base_row"] = {"combined_chars": len(braw["text"]), "evidence_files": len(braw["attachment_evidence"]),
    "has_collection_keys": "attachment_collection_v1" in braw}
observed["S1_base_dossier_on_base_row"] = H.context(brows[0], binv, module=base_dossier)["status"]
observed["S1_candidate_dossier_on_base_row_legacy_path"] = H.context(brows[0], binv)["status"]
observed["S1_base_dossier_on_candidate_row"] = H.context(rows[0], inventory, module=base_dossier)["status"]
checks["S1_base_pipeline_kept_context"] = observed["S1_base_dossier_on_base_row"] == "discovery_only"

# Scenario 2: two files, MAX=150000, file 1 = 149998 chars -> file 2 start exactly 150000.
rows, stats, inventory, _ = H.run_pipeline(specs(149998, 10, 0)[:2], max_chars=150000)
raw = rows[0]["raw_payload"]
locs2 = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in raw["attachment_evidence"]]
observed["S2_locators"] = locs2
observed["S2_combined_chars"] = len(raw["text"])
observed["S2_text_ends_with_dangling_separator"] = raw["text"].endswith("\n\n")
ctx2 = H.context(rows[0], inventory)
observed["S2_candidate_dossier"] = {"status": ctx2["status"], "reason": ctx2.get("reason")}
checks["S2_two_file_variant_also_dropped"] = ctx2["status"] == "unavailable" and locs2[1] == (150000, 150000)

# Scenario 3: file 1 = 149999 chars -> file 2 start 150001 (> len 150000).
rows, stats, inventory, _ = H.run_pipeline(specs(149999, 10, 0)[:2], max_chars=150000)
locs3 = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in rows[0]["raw_payload"]["attachment_evidence"]]
observed["S3_locators"] = locs3
observed["S3_candidate_dossier"] = H.context(rows[0], inventory)["status"]

# Control A: MAX=100000, 100000 + 49998 -> exactly 150000 with no third file: accepted.
rows, stats, inventory, _ = H.run_pipeline(specs(100000, 49998, 0)[:2], max_chars=100000)
observed["CtrlA_locators"] = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in rows[0]["raw_payload"]["attachment_evidence"]]
checks["CtrlA_exact_fill_two_files_accepted"] = H.context(rows[0], inventory)["status"] == "discovery_only"

# Control B: third file gets exactly one character (start 149999): accepted.
rows, stats, inventory, _ = H.run_pipeline(specs(100000, 49995, 50), max_chars=100000)
locsB = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in rows[0]["raw_payload"]["attachment_evidence"]]
observed["CtrlB_locators"] = locsB
checks["CtrlB_one_char_third_file_accepted"] = H.context(rows[0], inventory)["status"] == "discovery_only" and locsB[2] == (149999, 150000)

# Control C: default MAX (50000): third file truncated to 49996, accepted (producer claim).
rows, stats, inventory, _ = H.run_pipeline(specs(50000, 50000, 50000))
locsC = [(i["combined_text_locator"]["start"], i["combined_text_locator"]["end"]) for i in rows[0]["raw_payload"]["attachment_evidence"]]
observed["CtrlC_default_locators"] = locsC
checks["CtrlC_default_config_never_degenerate"] = locsC == [(0, 50000), (50002, 100002), (100004, 150000)] and H.context(rows[0], inventory)["status"] == "discovery_only"

observed["minimum_max_chars_for_reachability"] = "len1+len2 >= 149996 with 3 files, so LILA_SAM_ATTACHMENT_TEXT_CHARS >= 74998; or >= 149998 with 2 files"
status = "FAIL" if (checks["S1_degenerate_locator_emitted"] and checks["S1_whole_context_dropped_by_candidate_dossier"]
                    and checks["S1_base_pipeline_kept_context"] and checks["CtrlC_default_config_never_degenerate"]) else "INFO"
H.emit(status, {"checks": checks, **observed},
       verdict="new_defect (Low, non-default config): candidate emits a start==end locator for a file whose text budget is zero, records it as captured_discovery_only, then the dossier drops the whole research context; base kept the context.")
H.cleanup()
