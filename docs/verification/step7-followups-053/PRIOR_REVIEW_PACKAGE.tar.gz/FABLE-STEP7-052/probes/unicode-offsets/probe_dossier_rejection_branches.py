"""Every dossier binding branch, each tamper with a re-hashed attachment_collection_sha256 (and text hashes when text changed)."""
import copy
import _harness as H

base_dossier = H.load_base("dossier_base", "dossier_base.py")
payload_b = b"network visibility Caf\xc3\xa9 \xce\x94.\n\nSecond paragraph of file one."
payload_c = b"File two \xf0\x9f\x99\x82 requirement text."
payload_d = b"File three \xe4\xb8\xad\xe6\x96\x87 closing."
rows, stats, inventory, _ = H.run_pipeline([("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", payload_c),
                                            ("d" * 32, "SOW 3.txt", payload_d)])
# Persisted shape: attachment_evidence and collection files become separate but equal objects.
row0 = H.roundtrip_atomic(rows[0])
assert H.context(row0, inventory)["status"] == "discovery_only"
LOC = "Attachment file locator does not match retained text"
BIND = "Attachment collection does not bind this notice/text/inventory"
MISSING = "Attachment file locator is missing"
UNBOUND = "Attachment file locators leave unbound text"
MALFORMED = "Attachment collection receipt is malformed"
META = "Attachment capture metadata is missing or malformed"
results = {}


def case(name, mutate, expect, text_changed=False, both_lists=True):
    row = copy.deepcopy(row0)
    raw = row["raw_payload"]
    lists = [raw["attachment_collection_v1"]["files"]] + ([raw["attachment_evidence"]] if both_lists else [])
    mutate(raw, lists)
    if text_changed:
        H.rehash_text(raw)
    else:
        H.rehash_collection(raw)
    ctx = H.context(row, inventory)
    got = ctx.get("reason") if ctx["status"] == "unavailable" else ctx["status"]
    results[name] = {"expected": expect, "got": got, "ok": got == expect}
    if ctx["status"] == "unavailable":
        results[name]["base_dossier_without_locator_logic"] = H.context(row, inventory, module=base_dossier)["status"]
    return ctx


def set_loc(idx, key, value):
    def mutate(raw, lists):
        for files in lists:
            files[idx]["combined_text_locator"][key] = value
    return mutate


def shift_loc(idx, key, delta):
    def mutate(raw, lists):
        for files in lists:
            files[idx]["combined_text_locator"][key] += delta
    return mutate


ev0 = row0["raw_payload"]["attachment_evidence"]
e0 = ev0[0]["combined_text_locator"]["end"]
e1 = ev0[1]["combined_text_locator"]["end"]
n = len(row0["raw_payload"]["text"])

case("offset_end_plus1_file0", shift_loc(0, "end", 1), LOC)
case("offset_end_minus1_file0", shift_loc(0, "end", -1), LOC)
case("offset_start_plus1_file0", shift_loc(0, "start", 1), LOC)
case("offset_start_minus1_file1_overlaps_gap", shift_loc(1, "start", -1), LOC)
case("offset_start_equals_prev_end_no_gap", set_loc(1, "start", e0), LOC)
case("offset_last_end_minus1_leaves_tail", shift_loc(2, "end", -1), LOC)
case("offset_last_end_plus1_past_text", shift_loc(2, "end", 1), LOC)
case("unit_utf8_bytes", set_loc(0, "unit", "utf8_bytes"), LOC)
case("unit_trailing_space", set_loc(0, "unit", "unicode_characters "), LOC)
case("unit_missing", lambda raw, lists: [f[0]["combined_text_locator"].pop("unit") for f in lists], LOC)
case("start_float_0_0", set_loc(0, "start", 0.0), LOC)
case("end_float", set_loc(0, "end", float(e0)), LOC)
case("start_bool_false", set_loc(0, "start", False), LOC)
case("start_string", set_loc(0, "start", "0"), LOC)
case("start_negative_wraparound", set_loc(0, "start", -n), LOC)


def item_authority(raw, lists):
    for files in lists:
        files[0]["authority"] = "trusted_requirement"
case("item_authority_changed_both_lists", item_authority, LOC)
case("item_authority_changed_collection_only", item_authority, BIND, both_lists=False)


def text_sha_of_other_slice(raw, lists):
    other = H.sha(raw["text"][ev0[1]["combined_text_locator"]["start"]:e1])
    for files in lists:
        files[0]["text_sha256"] = other
case("item_text_sha_swapped", text_sha_of_other_slice, LOC)


def gap_space(raw, lists):
    t = raw["text"]
    raw["text"] = t[:e0] + "\n " + t[e0 + 2:]
case("gap_text_newline_space_slices_intact", gap_space, LOC, text_changed=True)


def gap_crlf(raw, lists):
    t = raw["text"]
    raw["text"] = t[:e0] + "\r\n" + t[e0 + 2:]
case("gap_text_crlf", gap_crlf, LOC, text_changed=True)


def gap_three_newlines(raw, lists):
    t = raw["text"]
    raw["text"] = t[:e0] + "\n\n\n" + t[e0 + 2:]
    for files in lists:
        for item in files[1:]:
            item["combined_text_locator"]["start"] += 1
            item["combined_text_locator"]["end"] += 1
case("gap_widened_locators_shifted", gap_three_newlines, LOC, text_changed=True)


def trailing_text(raw, lists):
    raw["text"] = raw["text"] + " unbound trailing sentence"
case("unbound_trailing_text", trailing_text, UNBOUND, text_changed=True)


def trailing_blank(raw, lists):
    raw["text"] = raw["text"] + "\n\n"
case("unbound_trailing_separator", trailing_blank, UNBOUND, text_changed=True)


def leading_text(raw, lists):
    raw["text"] = "injected " + raw["text"]
case("unbound_leading_text", leading_text, LOC, text_changed=True)


def extra_fourth_file(raw, lists):
    raw["text"] = raw["text"] + "\n\nfourth file text"
    for files in lists:
        item = copy.deepcopy(files[2])
        item.update(resource_id="e" * 32, name="SOW 4.txt", sha256="e" * 64,
                    combined_text_locator={"unit": "unicode_characters", "start": n + 2, "end": n + 2 + 16},
                    text_sha256=H.sha("fourth file text"))
        files.append(item)
case("extra_fourth_file_fully_rehashed", extra_fourth_file, META, text_changed=True)


def zero_length_third(raw, lists):
    t = raw["text"]
    raw["text"] = t[:e1]
    for files in lists:
        files[2]["combined_text_locator"] = {"unit": "unicode_characters", "start": e1 + 2, "end": e1 + 2}
        files[2]["text_sha256"] = H.sha("")
case("zero_length_third_file", zero_length_third, LOC, text_changed=True)


def split_file0_into_two(raw, lists):
    # Forge: file 0 contains an internal "\n\n"; re-describe the text as 4 files split there.
    t = raw["text"]
    cut = t.index("\n\n")
    for files in lists:
        first = files[0]
        second = copy.deepcopy(first)
        second.update(resource_id="f" * 32, name="Forged.txt", sha256="f" * 64)
        first["combined_text_locator"] = {"unit": "unicode_characters", "start": 0, "end": cut}
        first["text_sha256"] = H.sha(t[:cut])
        second["combined_text_locator"] = {"unit": "unicode_characters", "start": cut + 2, "end": e0}
        second["text_sha256"] = H.sha(t[cut + 2:e0])
        files.insert(1, second)
case("forged_split_makes_four_files", split_file0_into_two, META, text_changed=True)


def drop_third_and_split_file0(raw, lists):
    t = raw["text"]
    cut = t.index("\n\n")
    raw["text"] = t[:e1]
    for files in lists:
        files.pop(2)
        first = files[0]
        second = copy.deepcopy(first)
        second.update(resource_id="f" * 32, name="Forged.txt", sha256="f" * 64)
        first["combined_text_locator"] = {"unit": "unicode_characters", "start": 0, "end": cut}
        first["text_sha256"] = H.sha(t[:cut])
        second["combined_text_locator"] = {"unit": "unicode_characters", "start": cut + 2, "end": e0}
        second["text_sha256"] = H.sha(t[cut + 2:e0])
        files.insert(1, second)
forge = case("forged_split_three_files_full_rehash", drop_third_and_split_file0, "discovery_only", text_changed=True)
results["forged_split_three_files_full_rehash"]["note"] = "local writer re-hashing every field passes: integrity check, not authentication (disclosed in SYSTEM_PROMPT)"

case("missing_locator_key", lambda raw, lists: [f[0].pop("combined_text_locator") for f in lists], MISSING)
case("locator_none", lambda raw, lists: [f[0].__setitem__("combined_text_locator", None) for f in lists], MISSING)
case("locator_string", lambda raw, lists: [f[0].__setitem__("combined_text_locator", "0-10") for f in lists], MISSING)
case("locator_list", lambda raw, lists: [f[0].__setitem__("combined_text_locator", [0, 10]) for f in lists], MISSING)


def swap_order_both(raw, lists):
    for files in lists:
        files[0], files[1] = files[1], files[0]
case("files_reordered_both_lists", swap_order_both, LOC)
case("files_reordered_collection_only", swap_order_both, BIND, both_lists=False)
case("collection_notice_id", lambda raw, lists: raw["attachment_collection_v1"].__setitem__("notice_id", "f" * 32), BIND)
case("collection_inventory_hash", lambda raw, lists: raw["attachment_collection_v1"].__setitem__("inventory_hash", "0" * 64), BIND)
case("collection_authority", lambda raw, lists: raw["attachment_collection_v1"].__setitem__("authority", "trusted_requirement"), BIND)
case("collection_combined_sha", lambda raw, lists: raw["attachment_collection_v1"].__setitem__("combined_text_sha256", "0" * 64), BIND)
case("collection_extra_key_rehashed", lambda raw, lists: raw["attachment_collection_v1"].__setitem__("note", "x"), "discovery_only")
results["collection_extra_key_rehashed"]["note"] = "additive keys inside the receipt are accepted when re-hashed (schema not closed)"


def sha_key_removed(raw, lists):
    raw.pop("attachment_collection_sha256")
row = copy.deepcopy(row0); sha_key_removed(row["raw_payload"], None)
ctx = H.context(row, inventory); results["collection_sha_key_removed"] = {"expected": BIND, "got": ctx.get("reason"), "ok": ctx.get("reason") == BIND}
row = copy.deepcopy(row0); row["raw_payload"].pop("attachment_collection_v1")
ctx = H.context(row, inventory); results["collection_removed_sha_kept"] = {"expected": MALFORMED, "got": ctx.get("reason"), "ok": ctx.get("reason") == MALFORMED}
row = copy.deepcopy(row0); row["raw_payload"]["attachment_collection_v1"] = []
H.rehash_collection(row["raw_payload"])
ctx = H.context(row, inventory); results["collection_is_list"] = {"expected": MALFORMED, "got": ctx.get("reason"), "ok": ctx.get("reason") == MALFORMED}
row = copy.deepcopy(row0); row["raw_payload"]["attachment_collection_sha256"] = row["raw_payload"]["attachment_collection_sha256"].upper()
ctx = H.context(row, inventory); results["collection_sha_uppercase"] = {"expected": BIND, "got": ctx.get("reason"), "ok": ctx.get("reason") == BIND}
# Legacy downgrade: strip both collection keys -> accepted via legacy path with no file_passages.
row = copy.deepcopy(row0); row["raw_payload"].pop("attachment_collection_v1"); row["raw_payload"].pop("attachment_collection_sha256")
ctx = H.context(row, inventory)
results["legacy_downgrade_strip_both_keys"] = {"expected": "discovery_only", "got": ctx["status"], "ok": ctx["status"] == "discovery_only",
    "file_passages_present": "file_passages" in ctx, "note": "compat path: a local writer can remove per-file attribution and still pass"}
# Row identity vs collection notice_id.
row = copy.deepcopy(row0); row["source_id"] = "f" * 32
ctx = H.context(row, inventory)
results["row_source_id_changed"] = {"got": ctx.get("reason"), "ok": ctx["status"] == "unavailable"}
# Untouched positive control after deep copy.
ctx = H.context(copy.deepcopy(row0), inventory)
results["untouched_positive_control"] = {"expected": "discovery_only", "got": ctx["status"], "ok": ctx["status"] == "discovery_only",
                                         "passages": len(ctx.get("file_passages", []))}
failed = {k: v for k, v in results.items() if not v["ok"]}
H.emit("PASS" if not failed else "FAIL", {"cases": results, "failed": failed, "count": len(results)})
H.cleanup()
