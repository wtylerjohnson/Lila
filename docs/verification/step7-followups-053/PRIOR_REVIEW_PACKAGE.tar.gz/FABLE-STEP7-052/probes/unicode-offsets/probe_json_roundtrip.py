"""Row persisted with json.dumps (ensure_ascii default) and with tools.artifacts.atomic_write_json, reloaded, validated."""
import json
import os
import _harness as H
from tools.artifacts import atomic_write_json

checks = {}
observed = {}
payload_b = (b"network visibility Caf\xc3\xa9 \xce\x94 \xe4\xb8\xad\xe6\x96\x87 \xf0\x9f\x99\x82 e\xcc\x81 "
             b"\xf0\x9f\x91\xa9\xe2\x80\x8d\xf0\x9f\x92\xbb\r\nline2\rline3\n\n\xff bad \x00 nul \x7f del \xe2\x80\xa6")
payload_c = "Second   line-sep   para-sep ﻿ bom-in-middle   nbsp end".encode()
rows, stats, inventory, cache = H.run_pipeline([("b" * 32, "SOW 1.txt", payload_b), ("c" * 32, "SOW 2.txt", payload_c)])
row = rows[0]
ctx = H.context(row, inventory)
checks["in_memory_discovery_only"] = ctx["status"] == "discovery_only"
# 1. json.dumps default (ensure_ascii=True, no default=) must serialize the row (run_searches relies on it).
try:
    dumped = json.dumps(row)
    checks["row_json_native"] = True
except TypeError as exc:
    checks["row_json_native"] = False
    observed["json_error"] = str(exc)
    dumped = None
if dumped:
    rt = json.loads(dumped)
    checks["ascii_roundtrip_identity"] = rt == row
    checks["ascii_roundtrip_context_equal"] = H.context(rt, inventory) == ctx
    observed["non_ascii_escaped_in_dump"] = "\\u00e9" in dumped and "\\ud83d" in dumped
# 2. atomic_write_json (indent=2, ensure_ascii=False, default=str) to a real file, read back both ways.
target = os.path.join(cache, "sweep.json")
sweep = {"results": {"sam.gov": [row]}, "stats": stats}
atomic_write_json(target, sweep)
with open(target, "r", encoding="utf-8") as handle:        # text mode, universal newlines
    reloaded_text_mode = json.load(handle)
with open(target, "rb") as handle:
    reloaded_bytes = json.loads(handle.read())
r1 = reloaded_text_mode["results"]["sam.gov"][0]
r2 = reloaded_bytes["results"]["sam.gov"][0]
checks["atomic_file_roundtrip_identity"] = r1 == row and r2 == row
checks["atomic_file_context_equal_text_mode"] = H.context(r1, inventory) == ctx
checks["atomic_file_context_equal_binary_mode"] = H.context(r2, inventory) == ctx
checks["cr_survives_file_roundtrip"] = "\r\nline2\rline3" in r1["raw_payload"]["text"]
checks["nul_survives_file_roundtrip"] = "\x00" in r1["raw_payload"]["text"]
checks["line_and_para_separators_survive"] = " " in r1["raw_payload"]["text"] and " " in r1["raw_payload"]["text"]
# 3. Locator ints stay ints; digest recomputed by the dossier from the reloaded object equals stored sha.
loc = r1["raw_payload"]["attachment_evidence"][0]["combined_text_locator"]
checks["locator_types_remain_int"] = type(loc["start"]) is int and type(loc["end"]) is int
checks["collection_digest_stable_after_reload"] = (
    H.sha(H.canonical(r1["raw_payload"]["attachment_collection_v1"])) == r1["raw_payload"]["attachment_collection_sha256"])
# 4. Stats receipts (the sweep also persists them) serialize too.
try:
    json.dumps(stats)
    checks["stats_json_native"] = True
except TypeError as exc:
    checks["stats_json_native"] = False
    observed["stats_json_error"] = str(exc)
# 5. Lone surrogate can never reach the row: extractor's utf-8 encode fails before text is accepted.
from tools.api import sam_attachment_text as sat
saved = (sat._download_bytes, sat._text_from_bytes)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(cache, "surrogate")
sat._download_bytes = lambda *a, **k: b"pdf bytes"
sat._text_from_bytes = lambda *a, **k: "abc\ud800"
try:
    result = sat.extract_public_attachment_text(H.public_file("e" * 32, "SOW.pdf"))
finally:
    sat._download_bytes, sat._text_from_bytes = saved
checks["lone_surrogate_rejected_before_row"] = result["text"] == "" and result["collection_status"] == "unreadable"
observed["lone_surrogate_result"] = {k: result.get(k) for k in ("collection_status", "error")}
status = "PASS" if all(checks.values()) else "FAIL"
H.emit(status, {"checks": checks, **observed})
H.cleanup()
