"""Exercise the REAL _text_from_bytes / _pdf_text / _docx_text through
extract_public_attachment_text. Only _download_bytes is replaced (returns the
crafted payload); the PDF child process really runs (offline, pdfplumber).

Records collection_status, error, raw_capture, retrieved_at for each case.
"""
import io
import subprocess
import time
import zipfile

import _harness as H

H.block_sockets()
text_dir, notice_dir = H.fresh_dirs("parse")

from tools.api import sam_attachment_text as sat  # noqa: E402

payloads: dict[str, bytes] = {}
attempted_downloads: list[str] = []


def fake_download(resource_id, *, deadline_monotonic=None):
    attempted_downloads.append(resource_id)
    if deadline_monotonic is not None:
        sat._remaining_seconds(deadline_monotonic, 30.0)
    return payloads[resource_id]


sat._download_bytes = fake_download


def minimal_pdf(text: str) -> bytes:
    """A hand-built single-page PDF with one text object (valid for pdfminer)."""
    content = f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode()
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
        b"/Resources << /Font << /F1 5 0 R >> >> >>",
        b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for i, obj in enumerate(objs, start=1):
        offsets.append(out.tell())
        out.write(f"{i} 0 obj\n".encode() + obj + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objs) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


def docx(members: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    return buf.getvalue()


GOOD_DOCX_XML = (b'<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/'
                 b'wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Docx requirement text</w:t>'
                 b'</w:r></w:p></w:body></w:document>')

rid_counter = [0]


def rid() -> str:
    rid_counter[0] += 1
    return f"{rid_counter[0]:032x}"


cases = []


def case(label, name, payload, **extra):
    r = rid()
    payloads[r] = payload
    cases.append((label, H.public_file(r, name, size=len(payload)), extra))


case("pdf_garbage_bytes", "SOW.pdf", b"this is not a pdf at all " * 10)
case("pdf_header_only", "SOW.pdf", b"%PDF-1.4\n%%EOF")
case("pdf_valid_positive", "PWS.pdf", minimal_pdf("Hello requirement text"))
case("pdf_valid_uppercase_ext", "PWS.PDF", minimal_pdf("Upper case extension"))
case("pdf_zero_bytes", "SOW.pdf", b"")
case("pdf_parse_timeout_monkeypatched", "SOW.pdf", minimal_pdf("never parsed"), timeout_patch=True)
case("pdf_parse_timeout_real_0.25s", "SOW.pdf", minimal_pdf("real timeout"), real_timeout=True)
case("pdf_deadline_passed_between_download_and_parse", "SOW.pdf", minimal_pdf("deadline"),
     deadline_after_download=True)
case("docx_missing_document_xml", "SOW.docx", docx({"word/other.xml": b"<x/>"}))
case("docx_not_a_zip", "SOW.docx", b"PK\x03\x04 broken zip bytes")
case("docx_malformed_xml", "SOW.docx", docx({"word/document.xml": b"<w:document><unclosed"}))
case("docx_xml_over_cap", "SOW.docx", docx({"word/document.xml": GOOD_DOCX_XML}), docx_cap=10)
case("docx_valid_positive", "SOW.docx", docx({"word/document.xml": GOOD_DOCX_XML}))
case("docx_no_text_nodes", "SOW.docx", docx({"word/document.xml": b"<w:document xmlns:w='u'><w:body/></w:document>"}))
case("docx_xml_bomb_entities", "SOW.docx", docx({"word/document.xml":
     b'<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">]><w:document xmlns:w="u"><w:body><w:p><w:r><w:t>&lol2;</w:t></w:r></w:p></w:body></w:document>'}))
case("txt_whitespace_only", "notes.txt", b"   \n\t\r\n   ")
case("txt_empty", "notes.txt", b"")
case("txt_binary_named_txt", "notes.txt", bytes(range(256)) * 4)
case("txt_nul_only", "notes.txt", b"\x00" * 64)
case("txt_utf16_bom", "notes.txt", "Requirement in UTF-16".encode("utf-16"))
case("csv_positive", "list.csv", b"a,b\n1,2\n")
case("md_positive", "README.md", b"# Requirement\nPacket capture")
case("unsupported_xlsx_direct", "Pricing.xlsx", b"PK\x03\x04 spreadsheet bytes")
case("unsupported_zip_direct", "Bundle.zip", b"PK\x03\x04 zip bytes")
case("no_extension_mime_pdf", "SOW", minimal_pdf("no extension"), type_hint=".pdf")
case("no_extension_name_is_rid", None, minimal_pdf("name missing"))
case("pdf_ext_with_trailing_space", "SOW.pdf ", minimal_pdf("trailing space"))
case("pdf_ext_with_query", "SOW.pdf?download=1", minimal_pdf("query"))
case("double_ext_pdf_exe", "SOW.pdf.exe", b"MZ garbage")
case("dot_pdf_hidden_file", ".pdf", minimal_pdf("dotfile"))

observed = {}
for label, attachment, extra in cases:
    if attachment["name"] is None:
        attachment["name"] = None
    if "type_hint" in extra:
        attachment["type"] = extra["type_hint"]
    saved_run = sat.subprocess.run
    saved_secs = sat.MAX_PDF_PARSE_SECONDS
    saved_docx = sat.MAX_DOCX_XML_BYTES
    deadline = None
    saved_download = sat._download_bytes
    if extra.get("timeout_patch"):
        def timed_out(*a, **k):
            raise subprocess.TimeoutExpired(a[0], k["timeout"])
        sat.subprocess.run = timed_out
    if extra.get("real_timeout"):
        sat.MAX_PDF_PARSE_SECONDS = 0  # becomes max(0.25, 0) = 0.25s; interpreter start exceeds it
    if extra.get("docx_cap"):
        sat.MAX_DOCX_XML_BYTES = extra["docx_cap"]
    if extra.get("deadline_after_download"):
        deadline = time.monotonic() + 3600.0

        def download_then_expire(resource_id, *, deadline_monotonic=None, _d=deadline):
            payload = payloads[resource_id]
            sat.time.monotonic = lambda _real=time.monotonic: _real() + 7200.0  # jump past deadline
            return payload
        sat._download_bytes = download_then_expire
    started = time.perf_counter()
    try:
        result = sat.extract_public_attachment_text(attachment, deadline_monotonic=deadline)
    finally:
        sat.subprocess.run = saved_run
        sat.MAX_PDF_PARSE_SECONDS = saved_secs
        sat.MAX_DOCX_XML_BYTES = saved_docx
        sat._download_bytes = saved_download
        sat.time.monotonic = time.monotonic
    view = H.receipt_view(result)
    view["elapsed_s"] = round(time.perf_counter() - started, 2)
    view["text_preview"] = (result.get("text") or "")[:60]
    view["downloaded"] = attachment["resource_id"] in attempted_downloads
    view["cache_written"] = (text_dir / f"{attachment['resource_id']}.json").exists()
    observed[label] = view

expected = {
    "pdf_garbage_bytes": "unreadable", "pdf_header_only": "unreadable",
    "pdf_valid_positive": "captured_discovery_only", "pdf_valid_uppercase_ext": "captured_discovery_only",
    "pdf_zero_bytes": "unreadable", "pdf_parse_timeout_monkeypatched": "unreadable",
    "pdf_parse_timeout_real_0.25s": "unreadable",
    "pdf_deadline_passed_between_download_and_parse": "unreadable",
    "docx_missing_document_xml": "unreadable", "docx_not_a_zip": "unreadable",
    "docx_malformed_xml": "unreadable", "docx_xml_over_cap": "unreadable",
    "docx_valid_positive": "captured_discovery_only", "docx_no_text_nodes": "unreadable",
    "txt_whitespace_only": "unreadable", "txt_empty": "unreadable",
    "csv_positive": "captured_discovery_only", "md_positive": "captured_discovery_only",
    "unsupported_xlsx_direct": "unreadable", "unsupported_zip_direct": "unreadable",
    "no_extension_mime_pdf": "unreadable", "no_extension_name_is_rid": "unreadable",
    "pdf_ext_with_trailing_space": "unreadable", "pdf_ext_with_query": "unreadable",
    "double_ext_pdf_exe": "unreadable",
}
mismatch = {k: (observed[k]["collection_status"], v) for k, v in expected.items()
            if observed[k]["collection_status"] != v}
findings = []
for k in ("pdf_parse_timeout_monkeypatched", "pdf_parse_timeout_real_0.25s",
          "pdf_deadline_passed_between_download_and_parse"):
    if observed[k]["collection_status"] == "unreadable":
        findings.append(f"{k}: a TIME/BUDGET stop is labelled 'unreadable' (file may be perfectly readable): error={observed[k]['error']!r}")
for k in ("unsupported_xlsx_direct", "unsupported_zip_direct", "no_extension_mime_pdf", "no_extension_name_is_rid"):
    if observed[k]["downloaded"]:
        findings.append(f"{k}: bytes were downloaded and retained BEFORE the extension check rejected the type")
if observed["txt_binary_named_txt"]["collection_status"] == "captured_discovery_only":
    findings.append("binary payload named .txt is captured as discovery text (replacement characters)")
if observed["txt_nul_only"]["collection_status"] == "captured_discovery_only":
    findings.append("NUL-only payload named .txt is captured as discovery text")
if observed["docx_xml_bomb_entities"]["collection_status"] == "captured_discovery_only":
    findings.append("docx with internal entity expansion parsed (stdlib ElementTree expands internal entities)")
for k, v in observed.items():
    if v["collection_status"] == "unreadable" and not (v["has_raw_capture"] and v["has_retrieved_at"]):
        findings.append(f"{k}: unreadable without raw_capture/retrieved_at")

H.emit({
    "probe": "parse_failures",
    "status": "FAIL" if mismatch or any("BEFORE the extension" in f or "TIME/BUDGET" in f for f in findings) else "PASS",
    "observed": {"cases": observed, "expected_vs_actual_mismatches": mismatch, "findings": findings},
})
H.cleanup_tmp()
