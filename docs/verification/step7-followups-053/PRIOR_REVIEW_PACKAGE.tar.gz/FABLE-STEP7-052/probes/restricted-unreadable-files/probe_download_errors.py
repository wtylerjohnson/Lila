"""Exercise the REAL sam_attachment_text._download_bytes through
extract_public_attachment_text. Only httpx.HTTPTransport is swapped for a
MockTransport (no socket is ever opened; sockets are additionally blocked).

Cases: 401 / 403 / 404 / 500, redirect to an unapproved host, redirect to an
approved S3 host, redirect to api.sam.gov (subdomain, not in allow-list),
content-length over cap, streamed bytes over cap without content-length,
lying small content-length with a large body, non-integer content-length,
transport error, and a positive control.
"""
import _harness as H

H.block_sockets()
text_dir, notice_dir = H.fresh_dirs("download")

import httpx  # noqa: E402

from tools.api import sam_attachment_text as sat  # noqa: E402

RID = "b" * 32
SAM_URL = sat.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID)
requests_seen: list[str] = []
scenario = {"name": None}
CAP = 200
sat.MAX_ATTACHMENT_BYTES = CAP  # keep the streamed-cap case cheap


def handler(request: httpx.Request) -> httpx.Response:
    requests_seen.append(f"{request.method} {request.url}")
    name = scenario["name"]
    url = str(request.url)
    if name in ("401", "403", "404", "500"):
        return httpx.Response(int(name), content=b"denied")
    if name == "redirect_unapproved":
        if url == SAM_URL:
            return httpx.Response(302, headers={"location": "https://evil.example.net/x.txt"})
        return httpx.Response(200, content=b"Requirement text from evil host")
    if name == "redirect_unapproved_then_403":
        if url == SAM_URL:
            return httpx.Response(302, headers={"location": "https://evil.example.net/x.txt"})
        return httpx.Response(403, content=b"nope")
    if name == "redirect_s3_allowed":
        if url == SAM_URL:
            return httpx.Response(302, headers={
                "location": "https://iae-fbo-attachments.s3.amazonaws.com/bucket/x.txt"})
        return httpx.Response(200, content=b"Requirement text from S3")
    if name == "redirect_api_subdomain":
        if url == SAM_URL:
            return httpx.Response(302, headers={"location": "https://api.sam.gov/files/x.txt"})
        return httpx.Response(200, content=b"Requirement text from api.sam.gov")
    if name == "content_length_over_cap":
        return httpx.Response(200, headers={"content-length": str(CAP + 1)},
                              stream=httpx.ByteStream(b"x" * (CAP + 1)))
    if name == "streamed_over_cap_no_length":
        return httpx.Response(200, stream=httpx.ByteStream(b"y" * (CAP * 3)))
    if name == "lying_small_content_length":
        return httpx.Response(200, headers={"content-length": "10"},
                              stream=httpx.ByteStream(b"z" * (CAP * 3)))
    if name == "non_integer_content_length":
        return httpx.Response(200, headers={"content-length": "abc"},
                              stream=httpx.ByteStream(b"Short text"))
    if name == "transport_error":
        raise httpx.ConnectError("simulated connect failure")
    if name == "read_timeout":
        raise httpx.ReadTimeout("simulated read timeout")
    if name == "positive":
        return httpx.Response(200, content=b"Buyer requires packet capture.")
    if name == "empty_body_200":
        return httpx.Response(200, content=b"")
    raise AssertionError(f"unknown scenario {name}")


def fake_transport(**kwargs):
    return httpx.MockTransport(handler)


sat.httpx.HTTPTransport = fake_transport  # sat imports the httpx module object

observed = {}
for name in ["401", "403", "404", "500", "redirect_unapproved", "redirect_unapproved_then_403",
             "redirect_s3_allowed", "redirect_api_subdomain", "content_length_over_cap",
             "streamed_over_cap_no_length", "lying_small_content_length",
             "non_integer_content_length", "transport_error", "read_timeout",
             "empty_body_200", "positive"]:
    scenario["name"] = name
    requests_seen.clear()
    for stale in text_dir.glob("*.json"):
        stale.unlink()
    result = sat.extract_public_attachment_text(H.public_file(RID, "SOW.txt", size=50))
    view = H.receipt_view(result)
    view["requests"] = list(requests_seen)
    view["cache_written"] = (text_dir / f"{RID}.json").exists()
    view["objects"] = sorted(p.name for p in (text_dir / "objects").glob("*.bin")) \
        if (text_dir / "objects").exists() else []
    observed[name] = view

expect = {
    "401": "inaccessible", "403": "inaccessible", "404": "lookup_failed", "500": "lookup_failed",
    "redirect_unapproved": "lookup_failed", "redirect_s3_allowed": "captured_discovery_only",
    "redirect_api_subdomain": "lookup_failed", "content_length_over_cap": "lookup_failed",
    "streamed_over_cap_no_length": "lookup_failed", "lying_small_content_length": "lookup_failed",
    "non_integer_content_length": "lookup_failed", "transport_error": "lookup_failed",
    "read_timeout": "lookup_failed", "empty_body_200": "unreadable",
    "positive": "captured_discovery_only",
}
mismatches = {k: (observed[k]["collection_status"], v) for k, v in expect.items()
              if observed[k]["collection_status"] != v}
findings = []
# A redirect to an unapproved host must never leave retained bytes.
if observed["redirect_unapproved"]["has_raw_capture"]:
    findings.append("bytes from unapproved redirect host were retained")
# The unapproved host WAS contacted (the request left before the host check).
if any("evil.example.net" in r for r in observed["redirect_unapproved"]["requests"]):
    findings.append("GET was issued to the unapproved redirect host before the host check")
if observed["redirect_unapproved_then_403"]["collection_status"] == "inaccessible":
    findings.append("403 from an UNAPPROVED redirect host is reported as 'inaccessible' (SAM denial semantics) instead of the host being rejected")
for k in ("content_length_over_cap", "streamed_over_cap_no_length", "lying_small_content_length"):
    if observed[k]["has_raw_capture"]:
        findings.append(f"{k}: over-cap bytes were retained")
if observed["redirect_api_subdomain"]["collection_status"] != "captured_discovery_only":
    findings.append("redirect to api.sam.gov (a sam.gov subdomain) is refused: allow-list is exact-host only (yield residual, conservative)")

H.emit({
    "probe": "download_errors",
    "status": "FAIL" if mismatches or any("retained" in f for f in findings) else "PASS",
    "observed": {"cases": observed, "expected_vs_actual_mismatches": mismatches,
                 "findings": findings, "cap_used": CAP},
})
H.cleanup_tmp()
