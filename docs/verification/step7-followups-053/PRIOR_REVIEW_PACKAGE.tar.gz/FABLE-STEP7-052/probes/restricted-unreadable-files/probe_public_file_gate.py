"""Gate matrix for sam_attachment_text._public_file and the status mapping in
extract_public_attachment_text for every rejected shape. Also runs the SAME
attachment shapes through the real inventory normalizer
(sam_notice_detail._attachment_inventory) to show which raw SAM flag spellings
even reach _public_file in production.
"""
import _harness as H  # noqa: F401  (side effects: offline env, sys.path)

H.block_sockets()
text_dir, notice_dir = H.fresh_dirs("gate")

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

downloads = []


def _no_download(*a, **k):
    downloads.append(a[0] if a else k)
    raise AssertionError("download reached for a rejected attachment")


sat._download_bytes = _no_download

RID = "b" * 32
cases = {
    # access metadata
    "access_level_private": H.public_file(access_level="private"),
    "access_level_Public_mixed_case": H.public_file(access_level="Public"),
    "access_level_PUBLIC_padded": H.public_file(access_level="  PUBLIC "),
    "access_level_public_access_phrase": H.public_file(access_level="public access"),
    "access_status_restricted": H.public_file(access_status="restricted"),
    "access_status_controlled_unclassified": H.public_file(access_status="Controlled Unclassified"),
    "access_both_missing": H.public_file(access_level=None, access_status=None),
    "access_both_empty_string": H.public_file(access_level="", access_status=""),
    # export_controlled variants
    "export_1": H.public_file(export_controlled="1"),
    "export_true_str": H.public_file(export_controlled="true"),
    "export_TRUE_str": H.public_file(export_controlled="TRUE"),
    "export_yes": H.public_file(export_controlled="yes"),
    "export_Y": H.public_file(export_controlled="Y"),
    "export_True_bool": H.public_file(export_controlled=True),
    "export_1_int": H.public_file(export_controlled=1),
    "export_False_bool": H.public_file(export_controlled=False),
    "export_0_int": H.public_file(export_controlled=0),
    "export_none": H.public_file(export_controlled=None),
    "export_no": H.public_file(export_controlled="No"),
    "export_N": H.public_file(export_controlled="n"),
    "export_unknown_word": H.public_file(export_controlled="unknown"),
    # explicit_access variants
    "explicit_1": H.public_file(explicit_access="1"),
    "explicit_true": H.public_file(explicit_access="true"),
    "explicit_yes": H.public_file(explicit_access="yes"),
    "explicit_Y": H.public_file(explicit_access="Y"),
    "explicit_True_bool": H.public_file(explicit_access=True),
    # size
    "size_over_cap_int": H.public_file(size=sat.MAX_ATTACHMENT_BYTES + 1),
    "size_at_cap_int": H.public_file(size=sat.MAX_ATTACHMENT_BYTES),
    "size_over_cap_str": H.public_file(size=str(sat.MAX_ATTACHMENT_BYTES + 1)),
    "size_float_str": H.public_file(size="12.5"),
    "size_alpha": H.public_file(size="abc"),
    "size_list": H.public_file(size=[1]),
    "size_negative": H.public_file(size=-5),
    "size_none": H.public_file(size=None),
    "size_sci_notation": H.public_file(size="1e7"),
    "size_float_1e7": H.public_file(size=1e7),
    # resource id
    "rid_short": H.public_file(resource_id="abc"),
    "rid_traversal": H.public_file(resource_id="../wrong"),
    "rid_nonhex_32": H.public_file(resource_id="g" * 32),
    "rid_upper_hex": H.public_file(resource_id="B" * 32),
    "rid_none": H.public_file(resource_id=None),
    "rid_33": H.public_file(resource_id="b" * 33),
    "rid_padded": H.public_file(resource_id=" " + "b" * 32 + " "),
    # combined: restricted AND oversize AND bad id -> which reason wins
    "combo_badid_private_oversize": H.public_file(resource_id="zz", access_level="private",
                                                  size=10 ** 9),
    "combo_private_oversize": H.public_file(access_level="private", size=10 ** 9),
    "combo_export_oversize": H.public_file(export_controlled="1", size=10 ** 9),
}

observed = {}
for label, attachment in cases.items():
    allowed, reason = sat._public_file(attachment)
    entry = {"allowed": allowed, "reason": reason}
    if not allowed:
        result = sat.extract_public_attachment_text(attachment)
        entry.update(H.receipt_view(result))
        entry["authority"] = result.get("authority")
        entry["keys"] = sorted(result.keys())
    observed[label] = entry

# Which spellings survive the REAL inventory normalizer? Feed raw SAM rows.
raw_rows = []
spellings = ["1", "true", "TRUE", "yes", "Y", True, 1, "0", "false", "No", "n", False, 0, None, "unknown"]
for i, spelling in enumerate(spellings):
    raw_rows.append({"name": f"File {i}.pdf", "resourceId": f"{i:032x}", "mimeType": ".pdf",
                     "exportControlled": spelling, "explicitAccess": "0", "size": 10,
                     "accessLevel": "public", "accessStatus": "public"})
items, recognized = detail._attachment_inventory({"attachments": raw_rows}, "a" * 32)
normalized = {}
for spelling, item in zip(spellings, items):
    normalized[repr(spelling)] = {"export_controlled_normalized": item["export_controlled"],
                                  "public_file": sat._public_file(item)}
# size normalization through the inventory
size_rows = [{"name": "S.pdf", "resourceId": "9" * 32, "mimeType": ".pdf", "size": "abc",
              "accessLevel": "public", "accessStatus": "public",
              "exportControlled": "0", "explicitAccess": "0"}]
size_items, _ = detail._attachment_inventory({"attachments": size_rows}, "a" * 32)
normalized["size_abc_via_inventory"] = {"size": size_items[0]["size"],
                                        "public_file": sat._public_file(size_items[0])}
# missing accessLevel/accessStatus through the inventory
miss_rows = [{"name": "M.pdf", "resourceId": "8" * 32, "mimeType": ".pdf", "size": 5}]
miss_items, _ = detail._attachment_inventory({"attachments": miss_rows}, "a" * 32)
normalized["missing_access_keys_via_inventory"] = {
    "item": miss_items[0], "public_file": sat._public_file(miss_items[0])}

statuses = sorted({v.get("collection_status") for v in observed.values() if not v["allowed"]})
mapping_ok = all(
    (v["reason"] == "invalid resource id" and v["collection_status"] == "identity_mismatch")
    or (("exceeds" in v["reason"] or "invalid attachment size" in v["reason"])
        and v["collection_status"] == "not_fetched")
    or (v["reason"] not in ("invalid resource id",) and "exceeds" not in v["reason"]
        and "invalid attachment size" not in v["reason"] and v["collection_status"] == "inaccessible")
    for v in observed.values() if not v["allowed"])
allowed_labels = sorted(k for k, v in observed.items() if v["allowed"])

notes = []
if observed["access_both_missing"]["allowed"]:
    notes.append("attachments with NO access metadata are treated as public (fall through to download)")
if observed["rid_upper_hex"]["allowed"]:
    notes.append("upper-case hex resource ids pass the gate (regex IGNORECASE)")
if observed["size_negative"]["allowed"]:
    notes.append("negative size passes the gate")
if observed["export_unknown_word"]["allowed"] is False:
    notes.append("unknown export flag words are treated as restricted (conservative)")
if normalized["size_abc_via_inventory"]["size"] == 0:
    notes.append("inventory normalizer coerces invalid sizes to 0, so 'invalid attachment size' is unreachable from the production inventory path")

H.emit({
    "probe": "public_file_gate",
    "status": "PASS" if (mapping_ok and not downloads) else "FAIL",
    "observed": {
        "downloads_attempted_for_rejected": downloads,
        "gate_statuses_seen": statuses,
        "status_mapping_consistent": mapping_ok,
        "allowed_through_gate": allowed_labels,
        "cases": observed,
        "inventory_normalization": normalized,
        "notes": notes,
    },
})
H.cleanup_tmp()
