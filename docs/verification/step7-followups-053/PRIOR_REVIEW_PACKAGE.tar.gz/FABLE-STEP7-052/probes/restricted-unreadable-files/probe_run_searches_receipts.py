"""Exercise the REAL run_searches._enrich_sam_public_attachments and its
per-file receipts. Monkeypatched: fetch_notice_resources (inventory),
sam_attachment_text._download_bytes (bytes or raised errors), sam_quota,
and time.monotonic (controllable clock). Everything else is production code.

Scenarios:
  A priority_and_cap        7 files (6 supported + 1 xlsx): which 3 and the reasons on the rest
  B restricted_consume_cap  3 restricted top-ranked files + 1 public 4th: is the public one attempted?
  C http_errors             403 / 404 / good
  D h6_budget_mid_loop      clock jumps past stop_at during file 1 download
  E deadline_during_download deadline raises inside _download_bytes for file 1
  F deadline_during_parse    deadline passes between download and parse of file 1
  G deadline_before_first_file clock jumps inside the inventory fetch
  H none_resource_id_collision two inventory rows without resourceId (real normalizer)
  I text_unavailable_fallback only reachable when extract omits collection_status
  J positive_control        producer shape: 2 public txt, 1 private pdf, 1 xlsx; then cache hit run
  K over_cap_and_bad_id_consume_cap  over-size + bad-id files also consume the 3 slots
"""
import json
import time

import httpx

import _harness as H

H.block_sockets()

import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0
NOTICE = "a" * 32
TERM = "network visibility"
TAXONOMY = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])

REAL_MONOTONIC = time.monotonic
clock = {"now": 1000.0}
time.monotonic = lambda: clock["now"]  # run_searches and sat both call time.monotonic()

behaviour: dict[str, object] = {}
attempted: list[str] = []


def fake_download(resource_id, *, deadline_monotonic=None):
    attempted.append(resource_id)
    action = behaviour.get(resource_id, b"Buyer requires network visibility.")
    if callable(action):
        return action(deadline_monotonic)
    return action


sat._download_bytes = fake_download


def http_error(status):
    def _raise(_deadline):
        response = httpx.Response(status, request=httpx.Request(
            "GET", sat.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id="x" * 32)))
        response.raise_for_status()
    return _raise


def run(files, *, inventory_hook=None):
    """One real enrichment pass over a synthetic inventory."""
    H.fresh_dirs("rs")
    clock["now"] = 1000.0
    attempted.clear()
    inventory = detail._manifest_hash(files)

    def fake_inventory(*a, **k):
        if inventory_hook:
            inventory_hook()
        return {"id": NOTICE, "resources_checked": True, "attachments": files,
                "attachment_inventory_hash": inventory, "collection_status": "inventory_captured"}
    detail.fetch_notice_resources = fake_inventory
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), TAXONOMY, None, limit=8)
    receipt = stats["attachment_record_receipts"][NOTICE]
    files_view = [{"name": f.get("name"), "rid": (f.get("resource_id") or "")[:4],
                   "status": f.get("status"), "reason": (f.get("reason") or "")[:90],
                   "has_raw_capture": "raw_capture" in f, "has_retrieved_at": "retrieved_at" in f,
                   "from_cache": f.get("from_cache")}
                  for f in receipt.get("files", [])]
    return {"record_status": receipt["status"], "files": files_view,
            "attempted_downloads": [r[:4] for r in attempted],
            "errors": [e[:120] for e in stats["attachment_errors"]],
            "rows": len(rows), "relevant": stats["attachment_relevant"]}


def rid(n):
    return f"{n:032x}"


observed = {}
findings = []

# A. priority and the 3-file cap
files_a = [
    H.public_file(rid(1), "Amendment 0001.txt"),
    H.public_file(rid(2), "Solicitation.txt"),
    H.public_file(rid(3), "Attachment 2 - PWS.txt"),
    H.public_file(rid(4), "Attachment 1 - Statement of Work.txt"),
    H.public_file(rid(5), "Q and A RFI responses.txt"),
    H.public_file(rid(6), "Pricing.xlsx"),
    H.public_file(rid(7), "Wage Determination.txt"),
]
observed["A_priority_and_cap"] = run(files_a)
chosen = [f["name"] for f in observed["A_priority_and_cap"]["files"] if f["status"] != "not_fetched"]
observed["A_priority_and_cap"]["chosen"] = chosen
unsupported_reason = next(f["reason"] for f in observed["A_priority_and_cap"]["files"] if f["name"] == "Pricing.xlsx")
overflow_reason = next(f["reason"] for f in observed["A_priority_and_cap"]["files"] if f["name"] == "Solicitation.txt")
if unsupported_reason == overflow_reason:
    findings.append(f"A: unsupported type and over-the-3-file-cap share one indistinguishable receipt: status not_fetched reason {overflow_reason!r}")

# B. restricted files consume the cap
files_b = [
    {**H.public_file(rid(11), "Statement of Work.txt"), "access_level": "private"},
    {**H.public_file(rid(12), "PWS.txt"), "access_status": "restricted"},
    {**H.public_file(rid(13), "Requirements.txt"), "export_controlled": "1"},
    H.public_file(rid(14), "Amendment 0001.txt"),
]
observed["B_restricted_consume_cap"] = run(files_b)
amend = next(f for f in observed["B_restricted_consume_cap"]["files"] if f["name"] == "Amendment 0001.txt")
if amend["status"] == "not_fetched" and rid(14)[:4] not in observed["B_restricted_consume_cap"]["attempted_downloads"]:
    findings.append("B: three gate-rejected (inaccessible) files consumed all 3 slots; the only PUBLIC readable file was never attempted and is receipted as 'outside file/type budget'")

# K. over-cap size and bad id consume the cap too
files_k = [
    H.public_file(rid(21), "Statement of Work.txt", size=sat.MAX_ATTACHMENT_BYTES + 1),
    H.public_file("not-a-resource-id", "PWS.txt"),
    H.public_file(rid(23), "Requirements.txt", size="abc"),
    H.public_file(rid(24), "Amendment 0001.txt"),
]
observed["K_overcap_badid_consume_cap"] = run(files_k)
amend_k = next(f for f in observed["K_overcap_badid_consume_cap"]["files"] if f["name"] == "Amendment 0001.txt")
if amend_k["status"] == "not_fetched":
    findings.append("K: over-size / invalid-id files (known unfetchable before any network) also consumed the 3 slots; the public readable file was not attempted")

# C. HTTP errors
behaviour[rid(31)] = http_error(403)
behaviour[rid(32)] = http_error(404)
behaviour[rid(33)] = http_error(401)
files_c = [H.public_file(rid(31), "SOW.txt"), H.public_file(rid(32), "PWS.txt"),
           H.public_file(rid(33), "Requirements.txt"), H.public_file(rid(34), "Amendment.txt")]
observed["C_http_errors"] = run(files_c)

# D. H6: clock jumps past stop_at during file 1 download (file 1 still succeeds)
def jump_after_download(_deadline):
    clock["now"] += 10_000.0
    return b"Buyer requires network visibility."
behaviour[rid(41)] = jump_after_download
files_d = [H.public_file(rid(41), "SOW.txt"), H.public_file(rid(42), "PWS.txt"),
           H.public_file(rid(43), "Requirements.txt")]
observed["D_h6_budget_mid_loop"] = run(files_d)
d_files = {f["name"]: f for f in observed["D_h6_budget_mid_loop"]["files"]}
if d_files["Requirements.txt"]["reason"] == "outside file/type budget":
    findings.append("D (H6 CONFIRMED): after the stage budget was exhausted, the eligible third file carries reason 'outside file/type budget' although it was inside the file/type budget and merely unattempted")

# E. deadline raises inside the download of file 1
def expire_inside_download(deadline):
    clock["now"] += 10_000.0
    sat._remaining_seconds(deadline, 30.0)  # what the real streaming loop does per chunk
    return b"never"
behaviour[rid(51)] = expire_inside_download
files_e = [H.public_file(rid(51), "SOW.txt"), H.public_file(rid(52), "PWS.txt"),
           H.public_file(rid(53), "Requirements.txt")]
observed["E_deadline_during_download"] = run(files_e)

# F. deadline passes between download and parse of file 1
def expire_after_download(_deadline):
    clock["now"] += 10_000.0
    return b"Buyer requires network visibility."
behaviour[rid(61)] = expire_after_download
files_f = [H.public_file(rid(61), "SOW.txt"), H.public_file(rid(62), "PWS.txt"),
           H.public_file(rid(63), "Requirements.txt")]
observed["F_deadline_during_parse"] = run(files_f)
f1 = observed["F_deadline_during_parse"]["files"][0]
if f1["status"] == "unreadable":
    findings.append(f"F: a stage-deadline stop between download and parse is receipted as status 'unreadable' (reason {f1['reason']!r}); the bytes were fully acquired and readable")

# G. deadline passed before the first file (inside inventory fetch)
files_g = [H.public_file(rid(71), "SOW.txt"), H.public_file(rid(72), "PWS.txt"),
           H.public_file(rid(73), "Requirements.txt")]
observed["G_deadline_before_first_file"] = run(files_g, inventory_hook=lambda: clock.__setitem__("now", clock["now"] + 10_000.0))
if observed["G_deadline_before_first_file"]["record_status"] == "TEXT_UNAVAILABLE":
    findings.append("G: zero files attempted (deadline before first file) is receipted at record level as TEXT_UNAVAILABLE, same as 'all files tried and unreadable'")

# H. two inventory rows without resourceId, through the REAL normalizer
payload_h = {"attachments": [{"name": "Alpha SOW.pdf", "mimeType": ".pdf"},
                             {"name": "Beta SOW.pdf", "mimeType": ".pdf"}]}
items_h, recognized_h = detail._attachment_inventory(payload_h, NOTICE)
observed["H_none_resource_id_collision"] = {"normalized": items_h, "recognized": recognized_h}
if items_h and recognized_h:
    observed["H_none_resource_id_collision"]["run"] = run(items_h)
    names = [f["name"] for f in observed["H_none_resource_id_collision"]["run"]["files"]]
    if names.count("Beta SOW.pdf") == 2 or "Alpha SOW.pdf" not in names:
        findings.append(f"H: receipts for two files with resource_id None collapse onto one receipt (names now {names}); one attempted file is receipted as not_fetched and the other file's name is overwritten")

# I. text_unavailable fallback reachability
real_extract = sat.extract_public_attachment_text
def extract_without_status(attachment, **k):
    return {"resource_id": attachment["resource_id"], "name": attachment["name"], "text": "", "error": ""}
sat.extract_public_attachment_text = extract_without_status
observed["I_text_unavailable_fallback"] = run([H.public_file(rid(81), "SOW.txt")])
sat.extract_public_attachment_text = real_extract
fallback_reached = observed["I_text_unavailable_fallback"]["files"][0]["status"]
observed["I_text_unavailable_fallback"]["note"] = (
    "fallback status appears ONLY when extract omits collection_status; the production extract sets it on every return path")

# L. name without extension but mimeType .pdf, plus a padded-extension name, through run_searches
files_l = [{**H.public_file(rid(85), "SOW"), "type": ".pdf"},
           H.public_file(rid(86), "PWS.pdf "),
           H.public_file(rid(87), "Amendment.txt")]
observed["L_no_extension_mime_pdf"] = run(files_l)
l_files = {f["name"]: f for f in observed["L_no_extension_mime_pdf"]["files"]}
if l_files["SOW"]["status"] == "not_fetched" and rid(85)[:4] not in observed["L_no_extension_mime_pdf"]["attempted_downloads"]:
    findings.append("L: a file named without an extension but typed .pdf by the inventory is never attempted (type filter reads the name suffix only); receipt says 'outside file/type budget'")

# J. positive control incl. cache-hit second run
files_j = [H.public_file(rid(91), "SOW 1.txt"), H.public_file(rid(92), "SOW 2.txt"),
           {**H.public_file(rid(93), "SOW 3.pdf"), "access_level": "private"},
           H.public_file(rid(94), "Other.xlsx")]
observed["J_positive_first_run"] = run(files_j)
# second run with the same cache dir: re-run without fresh dirs
clock["now"] = 1000.0
attempted.clear()
rows2, stats2 = searches._enrich_sam_public_attachments(
    [], type("S", (), {"last_attachment_census": {}, "attachment_candidates": lambda self, *a, **k: [
        RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="NASA",
                       raw_payload={"type": "Solicitation"})]})(), object(), TAXONOMY, None, limit=8)
observed["J_positive_cache_hit"] = {
    "files": [{"name": f["name"], "status": f["status"], "reason": f["reason"], "from_cache": f.get("from_cache")}
              for f in stats2["attachment_record_receipts"][NOTICE]["files"]],
    "attempted_downloads": attempted[:],
}

all_file_statuses = sorted({f["status"] for k, v in observed.items() if isinstance(v, dict)
                            for f in (v.get("files") or (v.get("run") or {}).get("files") or [])})
time.monotonic = REAL_MONOTONIC

j_ok = {f["name"]: f["status"] for f in observed["J_positive_first_run"]["files"]} == {
    "SOW 1.txt": "captured_discovery_only", "SOW 2.txt": "captured_discovery_only",
    "SOW 3.pdf": "inaccessible", "Other.xlsx": "not_fetched"}
H.emit({
    "probe": "run_searches_receipts",
    "status": "FAIL" if any(s.startswith(("D (H6", "F:", "H:")) for s in findings) else "PASS",
    "observed": {"positive_control_ok": j_ok, "file_statuses_seen": all_file_statuses,
                 "text_unavailable_fallback_status_when_forced": fallback_reached,
                 "findings": findings, "scenarios": observed},
})
H.cleanup_tmp()
