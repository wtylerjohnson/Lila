"""Run the suspected-defect cases against the BASE (2d522f0) versions to
classify new_defect vs pre_existing.

Base sam_attachment_text (base_sam_attachment_text.py, from `git show`):
  1 unsupported extension / no extension: is the download issued before the type check?
  2 deadline between download and parse: what did base return?
  3 parse timeout: what did base return?
Base run_searches (base_run_searches.py, from `git show`):
  4 do gate-rejected files consume the 3 slots in base too?
  5 base has no per-file receipts at all (H6 / collision receipts cannot pre-exist)
"""
import importlib.util
import subprocess
import time

import _harness as H

H.block_sockets()
H.fresh_dirs("base")

base_sat = H.load_base_sat()
from tools.api import sam_attachment_text as sat  # noqa: E402  (candidate, for run_searches path)
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402

payloads = {}
attempted = []


def fake_download(resource_id, *, deadline_monotonic=None):
    attempted.append(resource_id)
    return payloads[resource_id]


base_sat._download_bytes = fake_download
sat._download_bytes = fake_download


def rid(n):
    return f"{n:032x}"


observed = {}
for label, name in [("unsupported_xlsx", "Pricing.xlsx"), ("no_extension", "SOW"),
                    ("no_ext_mime_pdf", "SOW")]:
    r = rid(len(observed) + 1)
    payloads[r] = b"PK bytes"
    attempted.clear()
    item = H.public_file(r, name)
    if label == "no_ext_mime_pdf":
        item["type"] = ".pdf"
    result = base_sat.extract_public_attachment_text(item)
    observed[f"base_{label}"] = {"downloaded_before_type_check": r in attempted,
                                 "error": result["error"], "keys": sorted(result)}

# deadline between download and parse on base
r = rid(50)
payloads[r] = b"Readable text"
real_mono = time.monotonic


def jump_download(resource_id, *, deadline_monotonic=None):
    attempted.append(resource_id)
    base_sat.time.monotonic = lambda: real_mono() + 10_000.0
    return payloads[resource_id]


base_sat._download_bytes = jump_download
res = base_sat.extract_public_attachment_text(H.public_file(r, "SOW.txt"), deadline_monotonic=real_mono() + 3600)
base_sat.time.monotonic = real_mono
observed["base_deadline_between_download_and_parse"] = {"error": res["error"], "keys": sorted(res),
                                                        "has_collection_status": "collection_status" in res}
base_sat._download_bytes = fake_download

# parse timeout on base
def timed_out(*a, **k):
    raise subprocess.TimeoutExpired(a[0], k["timeout"])
saved = base_sat.subprocess.run
base_sat.subprocess.run = timed_out
r = rid(51)
payloads[r] = b"%PDF-1.4 fake"
res = base_sat.extract_public_attachment_text(H.public_file(r, "SOW.pdf"))
base_sat.subprocess.run = saved
observed["base_pdf_parse_timeout"] = {"error": res["error"], "keys": sorted(res)}

# base run_searches: do gate-rejected files consume the cap?
# Base run_searches is compiled in memory from `git show` (read-only on the
# review clone); no copy of that source is written into the probe directory.
base_src = subprocess.run(["git", "-C", str(H.REPO), "show", "2d522f0:run_searches.py"],
                          check=True, capture_output=True, text=True).stdout
base_rs = importlib.util.module_from_spec(
    importlib.util.spec_from_loader("base_run_searches", loader=None))
base_rs.__file__ = str(H.REPO / "run_searches.py")  # path resolution only; nothing is written
exec(compile(base_src, "<git show 2d522f0:run_searches.py>", "exec"), base_rs.__dict__)
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0
NOTICE = "a" * 32
files_b = [
    {**H.public_file(rid(11), "Statement of Work.txt"), "access_level": "private"},
    {**H.public_file(rid(12), "PWS.txt"), "access_status": "restricted"},
    {**H.public_file(rid(13), "Requirements.txt"), "export_controlled": "1"},
    H.public_file(rid(14), "Amendment 0001.txt"),
]
for f in files_b:
    payloads[f["resource_id"]] = b"Buyer requires network visibility."
detail.fetch_notice_resources = lambda *a, **k: {
    "id": NOTICE, "resources_checked": True, "attachments": files_b,
    "attachment_inventory_hash": detail._manifest_hash(files_b)}
candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement", agency="NASA",
                           raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term="network visibility")])
attempted.clear()
rows, stats = base_rs._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
receipt = stats["attachment_record_receipts"][NOTICE]
observed["base_run_searches_restricted_consume_cap"] = {
    "attempted_downloads": [a[:4] for a in attempted],
    "public_amendment_attempted": rid(14) in attempted,
    "record_status": receipt["status"],
    "receipt_keys": sorted(receipt),
    "has_per_file_receipts": "files" in receipt,
    "errors": [e[:100] for e in stats["attachment_errors"]],
}

classification = {
    "download_before_type_check": "pre_existing" if observed["base_unsupported_xlsx"]["downloaded_before_type_check"] else "new_defect",
    "gate_rejected_files_consume_cap": "pre_existing" if not observed["base_run_searches_restricted_consume_cap"]["public_amendment_attempted"] else "new_defect",
    "deadline_stop_labelled_unreadable": "new_defect (status field introduced by Step7; base returned only the error string)",
    "h6_and_none_id_receipt_misattribution": "new_defect (base had no per-file receipts)" if not observed["base_run_searches_restricted_consume_cap"]["has_per_file_receipts"] else "pre_existing",
}
H.emit({"probe": "base_comparison", "status": "INFO", "observed": observed,
        "classification": classification})
H.cleanup_tmp()
