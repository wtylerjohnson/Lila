"""Static proof of the file-state vocabulary in the candidate.

sam_attachment_text.extract_public_attachment_text: every string that can
land in `collection_status` (dict literal, .update(collection_status=...),
result["collection_status"] = ..., and the `status` ternary in the gate return).
run_searches._enrich_sam_public_attachments: every string that can land in a
per-file receipt `status` (list-comprehension dict literal and
file_receipt["status"] = ...). Also: is every `return` in extract preceded by
a collection_status assignment (i.e. is the run_searches 'text_unavailable'
fallback reachable from production extract)?
"""
import ast

import _harness as H

CLAIMED = {"captured_discovery_only", "lookup_failed", "unreadable", "inaccessible",
           "identity_mismatch", "not_fetched"}


def consts(node):
    return {s.value for s in ast.walk(node) if isinstance(s, ast.Constant) and isinstance(s.value, str)}


def fn_named(tree, name):
    return next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)


sat_tree = ast.parse((H.REPO / "tools/api/sam_attachment_text.py").read_text())
rs_tree = ast.parse((H.REPO / "run_searches.py").read_text())
extract = fn_named(sat_tree, "extract_public_attachment_text")
enrich = fn_named(rs_tree, "_enrich_sam_public_attachments")

sat_states = set()
for node in ast.walk(extract):
    if isinstance(node, ast.Dict):
        for k, v in zip(node.keys, node.values):
            if isinstance(k, ast.Constant) and k.value == "collection_status":
                if isinstance(v, ast.Name) and v.id == "status":
                    pass  # resolved via the `status = (...)` ternary below
                else:
                    sat_states |= consts(v)
    if isinstance(node, ast.keyword) and node.arg == "collection_status":
        sat_states |= consts(node.value)
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Subscript) and isinstance(target.slice, ast.Constant) \
                    and target.slice.value == "collection_status":
                sat_states |= consts(node.value)
            if isinstance(target, ast.Name) and target.id == "status":
                # ternary: take only the produced values, not the compared reasons
                def outcomes(n):
                    if isinstance(n, ast.IfExp):
                        return outcomes(n.body) | outcomes(n.orelse)
                    return consts(n)
                sat_states |= outcomes(node.value)

rs_states = set()
for node in ast.walk(enrich):
    if isinstance(node, ast.Dict):
        for k, v in zip(node.keys, node.values):
            if isinstance(k, ast.Constant) and k.value == "status":
                # record-level statuses are UPPER_CASE; file receipts are lower_case
                rs_states |= {s for s in consts(v) if s == s.lower()}
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Subscript) and isinstance(target.slice, ast.Constant) \
                    and target.slice.value == "status" and isinstance(target.value, ast.Name) \
                    and target.value.id == "file_receipt":
                # RHS is `extracted.get("collection_status") or ("captured_discovery_only" if ... else "text_unavailable")`
                rs_states |= consts(node.value) - {"collection_status", "text"}

# Does every return of extract carry a collection_status?  Walk the function
# source lines: the gate return (dict literal with "collection_status": status),
# the cache return (validated to captured_discovery_only by _text_capture_valid),
# the success return and the except return both return `result`, which is
# initialised with collection_status="lookup_failed" and only ever .update()d.
returns = sorted(n.lineno for n in ast.walk(extract) if isinstance(n, ast.Return))
init = next(n for n in ast.walk(extract) if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "result" for t in n.targets)
            and isinstance(n.value, ast.Dict))
init_status = next(consts(v) for k, v in zip(init.value.keys, init.value.values)
                   if isinstance(k, ast.Constant) and k.value == "collection_status")
deletes_status = any(isinstance(n, ast.Delete) for n in ast.walk(extract))
pops_status = any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                  and n.func.attr == "pop" for n in ast.walk(extract))

extra = (sat_states | rs_states) - CLAIMED - {"text_unavailable"}
H.emit({
    "probe": "state_enumeration",
    "status": "PASS" if not extra else "FAIL",
    "observed": {
        "claimed_six": sorted(CLAIMED),
        "extract_collection_status_literals": sorted(sat_states),
        "run_searches_file_status_literals": sorted(rs_states),
        "unclaimed_states_in_code": sorted(extra),
        "extract_return_lines": returns,
        "result_initialised_with": sorted(init_status),
        "result_status_ever_deleted_or_popped": deletes_status or pops_status,
        "text_unavailable_in_run_searches": "text_unavailable" in rs_states,
        "text_unavailable_reachability": (
            "DEAD from production extract: gate return sets status via ternary; result dict is "
            "initialised with lookup_failed and never deleted/popped; cache return requires "
            "captured_discovery_only. Reached only by a monkeypatched extract "
            "(probe_run_searches_receipts scenario I)."),
    },
})
