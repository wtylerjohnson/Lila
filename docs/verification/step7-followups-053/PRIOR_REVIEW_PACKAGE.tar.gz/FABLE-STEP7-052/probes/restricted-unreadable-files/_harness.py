"""Shared probe harness: offline seams, probe-local cache dirs, base-module loader.

Import this FIRST in every probe. It never writes outside the probe directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.setdefault("LILA_SUITE_OFFLINE", "1")
sys.dont_write_bytecode = True
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
os.chdir(REPO)

_TMP_ROOT = PROBE_DIR / "_tmp"
_TMP_ROOT.mkdir(exist_ok=True)


def fresh_dirs(tag: str) -> tuple[Path, Path]:
    """Probe-local text-cache dir and notice-cache dir, both exported to env."""
    base = Path(tempfile.mkdtemp(prefix=f"{tag}-", dir=_TMP_ROOT))
    text_dir = base / "attachment_text"
    notice_dir = base / "notice"
    text_dir.mkdir()
    notice_dir.mkdir()
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text_dir)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(notice_dir)
    return text_dir, notice_dir


def cleanup_tmp() -> None:
    shutil.rmtree(_TMP_ROOT, ignore_errors=True)


class _NoNetwork(RuntimeError):
    pass


def block_sockets() -> None:
    def _deny(self, *args, **kwargs):  # noqa: ANN001
        raise _NoNetwork(f"probe blocked socket connect {args!r}")
    socket.socket.connect = _deny  # type: ignore[method-assign]
    socket.socket.connect_ex = _deny  # type: ignore[method-assign]
    socket.create_connection = _deny  # type: ignore[assignment]


def load_base_sat():
    """Load the BASE (2d522f0) sam_attachment_text as module `base_sat`."""
    path = PROBE_DIR / "base_sam_attachment_text.py"
    spec = importlib.util.spec_from_file_location("base_sat", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def public_file(resource_id: str = "b" * 32, name: str = "SOW.txt", **extra) -> dict:
    item = {"resource_id": resource_id, "name": name, "type": None,
            "source_url": None, "size": 10, "access_level": "public",
            "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}
    item.update(extra)
    return item


def receipt_view(result: dict) -> dict:
    """The fields this dimension records for every case."""
    return {
        "collection_status": result.get("collection_status"),
        "error": (result.get("error") or "")[:160],
        "has_raw_capture": "raw_capture" in result,
        "has_retrieved_at": "retrieved_at" in result,
        "has_text": bool(result.get("text")),
        "from_cache": result.get("from_cache"),
    }


def emit(payload: dict) -> None:
    print(json.dumps(payload, indent=1, sort_keys=True, default=str))
