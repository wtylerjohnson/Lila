"""Probe: strict Assess with every requirement/action cue ONLY in attachment text.

Cases:
  A. no retained depth at all
  B. trusted depth whose description is irrelevant (lawn maintenance), zero attachments
  C. B plus a human requirement review whose approved excerpt is copied from the
     attachment text and bound to the current evidence id
  D. trusted depth whose attachment inventory equals the native inventory (4 files)
  E. B with triage verdict 'monitor' instead of 'pursue' (verdict independence)
For every case: classification != BID_NOW, requirement_reviewed_at is None,
attachment_gap set, requirement_excerpt None, and NO attachment-derived text in
the LiveSolicitation or anywhere in the AssessRun dump. Also checks the row's
raw_payload carries no trusted keys and that clocks come from the sweep row.
"""
from _common import (ATTACHMENT_NEEDLES, MARKER, depth_with, emit, hostile_row,
                     irrelevant_sweep, record_for, scan)
import copy
import json

from agents.assess.contracts import LiveClassification
from agents.assess.ledger import build_assess_run
from tests.test_assess_ledger import BINDING, NOW, _build, _profile

row, stats, inventory, texts, files, taxonomy = hostile_row()
raw = row["raw_payload"]
observed = {"cases": {}, "problems": []}

# Enrichment-side invariants.
observed["raw_payload_keys"] = sorted(raw.keys())
forbidden_raw_keys = {"source_depth", "full_description", "description",
                      "description_checked", "resources_checked", "retrieved_at",
                      "requirement_excerpt", "response_deadline", "active"}
leaked = sorted(forbidden_raw_keys & set(raw.keys()))
if leaked:
    observed["problems"].append(f"enrichment wrote trusted keys into raw_payload: {leaked}")
observed["record_receipt_status"] = stats["attachment_record_receipts"]["N1"]["status"]
observed["collection_authority"] = raw["attachment_collection_v1"]["authority"]
observed["text_contains_marker"] = MARKER in raw["text"]


def evaluate(name, sweep, *, reviews=None, expect_gap_contains=None):
    if reviews is None:
        run, diagnostics, index = _build(sweep)
    else:
        run, diagnostics, index = build_assess_run(
            "Testco", sweep, _profile(), BINDING,
            requirement_reviews_payload=reviews, as_of=NOW)
    rec = record_for(run, "N1")
    dump = json.loads(rec.model_dump_json())
    case = {
        "classification": rec.classification.value,
        "recommendation": rec.recommendation.value,
        "requirement_excerpt": rec.requirement_excerpt,
        "requirement_reviewed_at": rec.requirement_reviewed_at,
        "requirement_review_evidence_id": rec.requirement_review_evidence_id,
        "attachments_checked": rec.attachments_checked,
        "attachment_gap": rec.attachment_gap,
        "response_deadline": str(rec.response_deadline),
        "fit_trace": list(rec.fit_trace),
        "evidence_excerpts": [e.excerpt for e in rec.authoritative_evidence],
        "evidence_supports": [[s.value for s in e.supports] for e in rec.authoritative_evidence],
        "evidence_retrieved_at": [str(e.retrieved_at) for e in rec.authoritative_evidence],
        "record_leak": scan(dump),
        "run_leak": scan(json.loads(run.model_dump_json())),
        "diagnostics_for_N1": [d for d in diagnostics if "N1" in d],
    }
    problems = []
    if rec.classification == LiveClassification.BID_NOW:
        problems.append("BID_NOW reached")
    if rec.requirement_reviewed_at is not None:
        problems.append("requirement_reviewed_at populated")
    if not rec.attachment_gap:
        problems.append("attachment_gap empty")
    if rec.requirement_excerpt:
        problems.append(f"requirement_excerpt populated: {rec.requirement_excerpt!r}")
    if case["record_leak"]:
        problems.append(f"attachment text reached LiveSolicitation: {case['record_leak']}")
    if case["run_leak"]:
        problems.append(f"attachment text reached AssessRun dump: {case['run_leak']}")
    if str(rec.response_deadline) != "2026-08-01":
        problems.append(f"deadline moved from sweep row: {rec.response_deadline}")
    if expect_gap_contains and expect_gap_contains not in (rec.attachment_gap or ""):
        problems.append(f"expected gap text {expect_gap_contains!r} missing")
    case["problems"] = problems
    observed["cases"][name] = case
    observed["problems"].extend(f"{name}: {p}" for p in problems)
    return run, rec


# A. no depth
sweep_a = irrelevant_sweep(row)
evaluate("A_no_depth", sweep_a,
         expect_gap_contains="Authoritative notice description and attachments were not retained")

# B. trusted depth, irrelevant description, zero attachments
sweep_b = irrelevant_sweep(row)
sweep_b["results"]["dossiers"] = {"depth_records": [depth_with(
    "The contractor shall provide lawn maintenance for the campus.")]}
run_b, rec_b = evaluate("B_trusted_irrelevant_depth", sweep_b,
                        expect_gap_contains="No approved core capability term")

# C. B plus a human review approving an excerpt copied from the attachment
excerpt = ("The contractor shall provide an enterprise packet capture platform "
           "for CISA network operations.")
assert excerpt in raw["text"]
reviews = {
    "schema_version": 1, "client": "Testco", "binding": dict(BINDING),
    "reviews": [{
        "notice_id": "N1",
        "evidence_id": rec_b.authoritative_evidence[-1].evidence_id,
        "excerpt": excerpt,
        "capability_terms": ["packet capture"],
        "decision": "approved",
        "attachment_inventory_count": rec_b.attachment_inventory_count,
        "attachment_inventory_hash": rec_b.attachment_inventory_hash,
        "attachments_reviewed": True,
        "reviewed_by": "operator", "reviewed_at": NOW.isoformat(),
    }],
}
evaluate("C_review_copied_from_attachment", copy.deepcopy(sweep_b), reviews=reviews,
         expect_gap_contains="excerpt is not exact current source text")

# D. trusted depth with the real 4-file inventory
sweep_d = irrelevant_sweep(row)
sweep_d["results"]["dossiers"] = {"depth_records": [depth_with(
    "The contractor shall provide lawn maintenance for the campus.",
    attachments=files)]}
evaluate("D_depth_with_inventory", sweep_d,
         expect_gap_contains="have not been downloaded and reviewed")

# E. triage verdict monitor instead of pursue
evaluate("E_triage_monitor", irrelevant_sweep(row, keep_triage_pursue=False))

status = "PASS" if not observed["problems"] else "FAIL"
emit({"probe": "hostile_attachment_only_assess", "status": status,
      "observed": observed})
