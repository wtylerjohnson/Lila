"""Probe: base-vs-candidate for the research_evidence consumer (classification).

Writes the BASE (2d522f0) agents/decisions/research_evidence.py into this probe
dir via git show, imports it under a private module name, and runs the same
attachment-only row through both. The row is produced by the CANDIDATE
enrichment (the base enrichment writes the same raw_payload.text /
attachment_evidence keys; only attachment_collection_v1 is new and it is not read
by research_evidence). Confirms whether 'stored_source_text' / 'channel_fact'
from discovery-only text is pre-existing.
"""
from _common import PROBE_DIR, REPO, emit, hostile_row
import importlib.util
import os
import subprocess
from datetime import datetime, timezone

base_path = os.path.join(PROBE_DIR, "base_research_evidence.py")
with open(base_path, "wb") as fh:
    fh.write(subprocess.run(
        ["git", "-C", REPO, "show", "2d522f0:agents/decisions/research_evidence.py"],
        check=True, capture_output=True).stdout)
import sys
spec = importlib.util.spec_from_file_location("base_research_evidence", base_path)
base = importlib.util.module_from_spec(spec)
sys.modules["base_research_evidence"] = base  # pydantic forward-ref resolution
spec.loader.exec_module(base)
for _model in (base.EvidenceRef, base.ResearchClaim, base.EvidenceSource):
    _model.model_rebuild()
from agents.decisions import research_evidence as cand

diff = subprocess.run(["git", "-C", REPO, "diff", "--stat", "2d522f0..6b51f00", "--",
                       "agents/decisions/research_evidence.py", "tools/relevance",
                       "agents/assess", "agents/leadgen", "agents/decisions/triage.py"],
                      check=True, capture_output=True, text=True).stdout.strip()

row, stats, inventory, texts, files, taxonomy = hostile_row()
raw = row["raw_payload"]
row["title"] = "Lawn maintenance services"
raw.update({"notice_id": "N1", "description_snippet": "Lawn maintenance services",
            "active": "Yes", "url": "https://sam.gov/opp/N1/view", "retrieved_at": "2026-07-10T11:00:00+00:00"})
row["api_url"] = "https://sam.gov/opp/N1/view"
row["response_deadline"] = "2026-08-01"
as_of = datetime(2026, 7, 10, 12, 0, tzinfo=timezone.utc)
quote_veh = "This is a Combined Synopsis/Solicitation for packet capture."
quote_req = "The contractor shall provide an enterprise packet capture platform for CISA network operations."


def run(mod):
    src = mod.source_record("sam.gov", "results.sam.gov[0]", row)
    claims = [
        mod.ResearchClaim(kind="vehicle_route", statement="x", evidence=[mod.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_veh)]),
        mod.ResearchClaim(kind="procurement_state", statement="x", evidence=[mod.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_req)]),
        mod.ResearchClaim(kind="offering_fit", statement="x", evidence=[mod.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_req)]),
        mod.ResearchClaim(kind="next_action", statement="x", evidence=[mod.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_req)]),
    ]
    return {
        "retrieval_status": src.retrieval_status,
        "text_authority": src.passage_authority.get("raw_payload.text", {}).get("authority"),
        "classification": mod.classification(src, claims, as_of, taxonomy),
        "current_notice": mod.current_notice(src, claims, as_of, taxonomy),
        "claim_prefix": mod.claim_text(claims[0], {"N1": src}).split(":")[0],
    }


observed = {"base": run(base), "candidate": run(cand),
            "consumer_diff_stat_base_to_candidate": diff or "(no changes)"}
observed["identical"] = observed["base"] == observed["candidate"]
observed["verdict"] = ("pre_existing" if observed["identical"] else "behaviour differs")
emit({"probe": "base_research_evidence", "status": "INFO", "observed": observed})
