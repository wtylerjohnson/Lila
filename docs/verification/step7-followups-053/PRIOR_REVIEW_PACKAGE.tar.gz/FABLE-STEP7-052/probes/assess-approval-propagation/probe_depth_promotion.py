"""Probe: promote attachment text via the depth path (out of Step7 scope; report).

  1. A depth record whose `description` is the attachment combined text. The
     Assess ledger treats depth.description as authoritative by construction, so
     a candidate excerpt appears and an approved review yields BID_NOW. Measured
     and reported as INFO: the depth producer (run_dossiers / fetch_notice_depth)
     is the trust boundary, not Step7.
  2. compose_dossier with a capturing fake engine (no LLM): full_description is
     depth.description only; attachment_research is discovery_only with
     file_passages; the two are never merged.
  3. _attachment_research_context when raw text is swapped for depth text:
     fingerprint fails (unavailable), so discovery text cannot be relabelled.
"""
from _common import MARKER, depth_with, emit, hostile_row, irrelevant_sweep, record_for, scan
import copy
import json

from agents.assess.contracts import LiveClassification
from agents.decisions import dossier as dossier_mod
from tests.test_assess_ledger import _build, _build_with_requirement_review

row, stats, inventory, texts, files, taxonomy = hostile_row()
raw = row["raw_payload"]
observed = {"problems": [], "info": []}

# 1. depth.description := attachment text
sweep = irrelevant_sweep(row)
sweep["results"]["dossiers"] = {"depth_records": [depth_with(raw["text"])]}
run, _, _ = _build(sweep)
rec = record_for(run, "N1")
observed["depth_copy_no_review"] = {
    "classification": rec.classification.value,
    "requirement_excerpt": rec.requirement_excerpt,
    "attachment_gap": rec.attachment_gap,
    "marker_in_record": MARKER in rec.model_dump_json(),
}
try:
    run2, _, _ = _build_with_requirement_review(copy.deepcopy(sweep))
    rec2 = record_for(run2, "N1")
    observed["depth_copy_with_review"] = {
        "classification": rec2.classification.value,
        "requirement_excerpt": rec2.requirement_excerpt,
        "requirement_reviewed_at": str(rec2.requirement_reviewed_at),
        "attachment_gap": rec2.attachment_gap,
    }
    if rec2.classification == LiveClassification.BID_NOW:
        observed["info"].append(
            "depth.description copied from attachment text reaches BID_NOW after human review; "
            "the depth producer is the trust boundary (out of Step7 scope, pre-existing by design)")
except Exception as exc:  # noqa: BLE001
    observed["depth_copy_with_review"] = {"error": repr(exc)}

# 2. compose_dossier context via a capturing engine
captured = {}


class FakeEngine:
    def deliberate(self, *, layer, system_prompt, context, schema):
        captured["context"] = context
        return schema(id=context["notice"]["id"], title="t", scope_summary="s",
                      evaluation_criteria=[], submission_requirements=[],
                      incumbent_signals=[], fit_verdict="stretch", win_themes=[],
                      next_action="n")


depth_honest = {"id": "N1", "notice_id": "N1", "description": "Lawn maintenance.",
                "attachments": files, "resources_checked": True,
                "attachment_inventory_hash": inventory, "errors": []}
dossier_mod.compose_dossier("Testco", "strategy", row, depth_honest, engine=FakeEngine())
ctx = captured["context"]
research = ctx.get("attachment_research")
observed["dossier_context"] = {
    "full_description": ctx["full_description"],
    "full_description_has_marker": MARKER in ctx["full_description"],
    "attachment_research_status": research and research.get("status"),
    "attachment_research_authority_fields": {
        "status": research.get("status"), "collection_sha256": research.get("collection_sha256"),
        "file_passage_authorities": [p["authority"] for p in research.get("file_passages", [])],
    } if research else None,
    "keys": sorted(ctx.keys()),
}
if MARKER in ctx["full_description"]:
    observed["problems"].append("dossier full_description carries attachment text from an honest depth")
if not research or research.get("status") != "discovery_only":
    observed["problems"].append("bound collection did not reach dossier as discovery_only")
if research and any(p["authority"] != "discovery_only" for p in research.get("file_passages", [])):
    observed["problems"].append("file passage authority not discovery_only")

# 3. relabel attempt: swap text for something else, keep receipts
tampered = copy.deepcopy(row)
tampered["raw_payload"]["text"] = "Lawn maintenance."
res = dossier_mod._attachment_research_context(tampered, {"id": "N1", "attachment_inventory_hash": inventory})
observed["text_swap_result"] = res
if res.get("status") != "unavailable":
    observed["problems"].append("text swap accepted by dossier binding")

# 3b. authority relabel inside per-file evidence only (collection rehashed)
tampered2 = copy.deepcopy(row)
tampered2["raw_payload"]["attachment_evidence"][0]["authority"] = "original_notice"
col = tampered2["raw_payload"]["attachment_collection_v1"]
col["files"] = tampered2["raw_payload"]["attachment_evidence"]
import hashlib
tampered2["raw_payload"]["attachment_collection_sha256"] = hashlib.sha256(json.dumps(
    col, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
res2 = dossier_mod._attachment_research_context(tampered2, {"id": "N1", "attachment_inventory_hash": inventory})
observed["file_authority_relabel_result"] = {"status": res2.get("status"), "reason": res2.get("reason")}
if res2.get("status") != "unavailable":
    observed["problems"].append("per-file authority relabel accepted")

status = "FAIL" if observed["problems"] else "INFO"
emit({"probe": "depth_promotion", "status": status, "observed": observed})
