"""Probe: trace every non-Assess reader of raw_payload.text / attachment fields.

Consumers exercised with the hostile row (all requirement cues in attachment text):
  * tools.relevance.engine.record_text_fields / score_record (discovery screen)
  * tools.relevance.requirement_support.requirement_support (spans + requested_support)
  * agents.decisions.triage.deterministic_prefilter (LLM-eligibility gate)
  * tools.relevance.screening.screening_evidence
  * agents.decisions.research_evidence.source_record / current_notice / classification / claim_text
  * agents.reports.composer.select_best_fit fingerprint binding
Each is classified discovery-only vs trusted and any trusted-shaped output that is
fed solely by attachment text is flagged.
"""
from _common import MARKER, emit, hostile_row
import json
from datetime import datetime, timezone

from tools.relevance.engine import record_text_fields, score_record
from tools.relevance.requirement_support import requirement_support
from tools.relevance.screening import screening_evidence
from agents.decisions.triage import deterministic_prefilter
from agents.decisions import research_evidence as rev

row, stats, inventory, texts, files, taxonomy = hostile_row()
raw = row["raw_payload"]
# Make the row look like a real irrelevant sam.gov notice, as in the sweep.
row["title"] = "Lawn maintenance services"
raw.update({"notice_id": "N1", "description_snippet": "Lawn maintenance services",
            "active": "Yes", "url": "https://sam.gov/opp/N1/view"})
row["api_url"] = "https://sam.gov/opp/N1/view"
row["response_deadline"] = "2026-08-01"
row["posted_date"] = "2026-07-01"
row["raw_payload"]["retrieved_at"] = "2026-07-10T11:00:00+00:00"

observed = {"problems": [], "info": [], "consumers": {}}

# 1. relevance engine
fields = [f for f, _ in record_text_fields(row)]
verdict = score_record(row, taxonomy)
observed["consumers"]["engine"] = {
    "text_fields": fields, "relevant": verdict.relevant, "score": verdict.score,
    "span_fields": sorted({s.field for s in verdict.spans}),
    "classification": "discovery_only (relevance screen; feeds candidate retention only)",
}

# 2. requirement_support
support = requirement_support(row, taxonomy)
observed["consumers"]["requirement_support"] = {
    "requested_support": support["requested_support"], "state": support["state"],
    "span_fields_roles": sorted({(s["field"], s["role"]) for s in support["spans"]}),
    "attachment_context_authority": support["attachment_context"]["authority"],
    "qualification": support["qualification"],
}
if support["requested_support"] is True and all(s["field"] == "raw_payload.text" for s in support["spans"]):
    observed["info"].append(
        "requirement_support returns requested_support=True from attachment-text spans alone "
        "(field=raw_payload.text); consumers: triage prefilter eligibility, LLM triage context, "
        "research_evidence.current_notice (which strips untrusted text first), notice_bridge "
        "(uses depth description, not raw text). Pre-existing: requirement_support.py unchanged by Step7.")

# 3. deterministic prefilter (LLM eligibility)
candidates, ruled, receipt = deterministic_prefilter(
    [row], taxonomy, attachment_receipts=stats["attachment_record_receipts"])
screen = receipt["screening_records"]["N1"]
observed["consumers"]["deterministic_prefilter"] = {
    "reached_model_candidates": bool(candidates), "ruled": ruled.get("N1"),
    "screen_state": screen["screen_state"], "attachment_status": screen["attachment_status"],
    "discovery_excerpt_present": bool((screen.get("attachment_discovery_evidence") or {}).get("text_excerpt")),
    "disposition": (screen.get("attachment_discovery_evidence") or {}).get("disposition"),
}
if candidates:
    observed["info"].append(
        "attachment-only requirement language makes the notice an LLM-triage candidate "
        "(SUPPORTED_CAPABILITY_AWAITING_JUDGMENT). This is the documented discovery purpose; "
        "triage verdicts only reach Assess as pursue/monitor/discard, never as requirement approval.")

# 4. research_evidence.source_record and downstream
src = rev.source_record("sam.gov", "results.sam.gov[0]", row)
text_auth = src.passage_authority.get("raw_payload.text", {}).get("authority")
observed["consumers"]["research_evidence.source_record"] = {
    "retrieval_status": src.retrieval_status, "primary_notice": src.primary_notice,
    "raw_payload.text_authority": text_auth,
    "passages": sorted(src.passages.keys()),
    "attachment_provenance_keys": sorted(src.attachment_provenance.keys()),
}
if text_auth != "discovery_only":
    observed["problems"].append(f"raw_payload.text authority is {text_auth!r}")

as_of = datetime(2026, 7, 10, 12, 0, tzinfo=timezone.utc)
quote_req = "The contractor shall provide an enterprise packet capture platform for CISA network operations."
quote_act = "Offerors shall submit proposals via SAM.gov no later than 2026-09-15 17:00 Eastern."
quote_veh = "This is a Combined Synopsis/Solicitation for packet capture."
assert quote_req in src.passages["raw_payload.text"]
claims = [
    rev.ResearchClaim(kind="procurement_state", statement="x", evidence=[rev.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_req)]),
    rev.ResearchClaim(kind="offering_fit", statement="x", evidence=[rev.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_req)]),
    rev.ResearchClaim(kind="next_action", statement="x", evidence=[rev.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_act)]),
    rev.ResearchClaim(kind="vehicle_route", statement="x", evidence=[rev.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=quote_veh)]),
]
registry = {"N1": src}
current = rev.current_notice(src, claims, as_of, taxonomy)
cls = rev.classification(src, claims, as_of, taxonomy)
labels = {c.kind: rev.claim_text(c, registry).split(":")[0] for c in claims}
checked = {c.kind: rev.checked_claim(c, registry)[0] is not None for c in claims}
observed["consumers"]["research_evidence.downstream"] = {
    "current_notice": current, "classification": cls, "claim_prefixes": labels,
    "checked_claim_accepts_text_quotes": checked,
}
if current:
    observed["problems"].append("research_evidence.current_notice confirmed a notice from attachment text alone")
if cls == "confirmed_opportunity":
    observed["problems"].append("classification confirmed_opportunity from attachment text")
if cls == "channel_fact":
    observed["info"].append(
        "research_evidence.classification returns 'channel_fact' for a vehicle_route claim whose only "
        "quote is attachment (discovery_only) text, because retrieval_status is 'stored_source_text' "
        "when raw_payload.text is the only text field (has_text ignores passage authority). Label prefix "
        "still says 'Discovery excerpt (not requirement approval)'. Research Picture only; file unchanged by Step7.")
if src.retrieval_status == "stored_source_text":
    observed["info"].append(
        "source_record retrieval_status='stored_source_text' although the only text passage is discovery_only attachment text")

# 5. screening_evidence direct
ev = screening_evidence(row, verdict, stats["attachment_record_receipts"].get("N1"))
observed["consumers"]["screening_evidence"] = {"attachment_status": ev["attachment_status"],
                                               "qualification": ev["qualification"]}

# 6. composer select_best_fit binding
from agents.reports.composer import select_best_fit
sweep = {"results": {"sam.gov": [row], "triage": {"N1": {"verdict": "pursue", "reason": "r"}}}}
try:
    picks_unbound = select_best_fit(sweep, taxonomy, None, n=3)
    sweep["results"]["triage"]["N1"]["attachment_evidence_sha256"] = raw["attachment_evidence_sha256"]
    picks_bound = select_best_fit(sweep, taxonomy, None, n=3)
    observed["consumers"]["composer.select_best_fit"] = {
        "picks_without_fingerprint_bound_triage": len(picks_unbound),
        "picks_with_fingerprint_bound_triage": len(picks_bound),
        "note": "triage verdict must be bound to the attachment fingerprint; otherwise the saved verdict is dropped",
    }
except Exception as exc:  # noqa: BLE001
    observed["consumers"]["composer.select_best_fit"] = {"error": repr(exc)[:300]}

status = "FAIL" if observed["problems"] else "INFO"
emit({"probe": "consumer_trace", "status": status, "observed": observed})
