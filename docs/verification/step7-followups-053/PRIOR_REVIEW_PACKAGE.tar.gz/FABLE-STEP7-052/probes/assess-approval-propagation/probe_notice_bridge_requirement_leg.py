"""Probe: golden_press notice_bridge requirement leg reads raw_payload.text.

agents/golden_press/notice_bridge.py decision():
    checked = deepcopy(original); checked['description'] = description
    support = requirement_support(checked, self.taxonomy)
    if support.get('requested_support') is not True:
        gaps.append('Original source does not establish requested capability work')
requirement_support scans record_text_fields(checked), which includes
raw_payload.text (attachment discovery text). This probe reproduces that exact
leg with the REAL requirement_support on the hostile row: depth description is
irrelevant lawn maintenance, attachment text carries the requirement. It also
runs the same leg with raw_payload.text removed, and checks the independent
BID_NOW leg (from Assess) still blocks admission. Base comparison: file is
unchanged between 2d522f0 and 6b51f00 (git diff --stat).
"""
from _common import REPO, emit, hostile_row
import copy
import subprocess

from tools.relevance.requirement_support import requirement_support

row, stats, inventory, texts, files, taxonomy = hostile_row()
original = copy.deepcopy(row)
original["title"] = "Lawn maintenance services"
original["raw_payload"]["description_snippet"] = "Lawn maintenance services"
original["raw_payload"]["notice_id"] = "N1"
description = "The contractor shall provide lawn maintenance for the campus."

checked = copy.deepcopy(original)
checked["description"] = description
support_with_text = requirement_support(checked, taxonomy)

stripped = copy.deepcopy(checked)
for key in list(stripped["raw_payload"].keys()):
    if key.startswith("attachment_") or key == "text":
        stripped["raw_payload"].pop(key)
support_without_text = requirement_support(stripped, taxonomy)

diff = subprocess.run(["git", "-C", REPO, "diff", "--stat", "2d522f0..6b51f00", "--",
                       "agents/golden_press/notice_bridge.py", "tools/relevance/requirement_support.py"],
                      check=True, capture_output=True, text=True).stdout.strip()

leg_satisfied_by_attachment_only = (support_with_text["requested_support"] is True
                                    and support_without_text["requested_support"] is not True
                                    and all(s["field"] == "raw_payload.text" for s in support_with_text["spans"]))
observed = {
    "with_text": {"requested_support": support_with_text["requested_support"],
                  "state": support_with_text["state"],
                  "span_fields": sorted({s["field"] for s in support_with_text["spans"]}),
                  "roles": sorted({s["role"] for s in support_with_text["spans"]})},
    "without_text": {"requested_support": support_without_text["requested_support"],
                     "state": support_without_text["state"],
                     "span_fields": sorted({s["field"] for s in support_without_text["spans"]})},
    "leg_satisfied_by_attachment_text_alone": leg_satisfied_by_attachment_only,
    "independent_bid_now_leg": ("still blocks admission: the same row is UNSCREENED in Assess "
                                "(see probe_hostile_attachment_only_assess case B), so 'No current bound "
                                "Assess BID_NOW/PURSUE requirement approval' remains in gaps"),
    "notice_bridge_diff_stat_base_to_candidate": diff or "(no changes)",
    "classification": "pre_existing" if not diff else "changed in delta",
}
emit({"probe": "notice_bridge_requirement_leg",
      "status": "INFO" if leg_satisfied_by_attachment_only else "PASS", "observed": observed})
