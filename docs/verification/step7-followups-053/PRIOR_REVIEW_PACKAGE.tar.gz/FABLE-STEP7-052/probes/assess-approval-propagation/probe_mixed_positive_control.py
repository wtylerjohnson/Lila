"""Probe: mixed positive control.

The same notice where the trusted depth description independently supports the
requirement must keep its Step6 classification with and without the Step7
attachment fields (attachment_evidence, attachment_collection_v1, text ...).
Variants:
  1. candidate span awaiting approval (no review): UNSCREENED both ways, same gap
  2. approved review, zero attachments in depth: BID_NOW both ways
  3. approved review, 4-file inventory in depth, attachments_reviewed=True: BID_NOW both ways
The comparison is on the full LiveSolicitation minus fields that legitimately
depend on the observation hash (evidence ids/record hashes/fit_trace ids).
"""
from _common import ATTACHMENT_NEEDLES, emit, hostile_row, record_for
from _common import scan as _scan
import copy
import json
import re

# The test depth description deliberately shares the sentence "contractor shall
# provide an enterprise packet capture platform" with the attachment text, so
# scan only for needles that exist ONLY in the attachment text.
UNIQUE_NEEDLES = tuple(n for n in ATTACHMENT_NEEDLES
                       if n != "contractor shall provide an enterprise packet capture platform")


def scan(obj):
    return _scan(obj, UNIQUE_NEEDLES)

from agents.assess.contracts import LiveClassification
from tests.test_assess_ledger import (_build, _build_with_requirement_review,
                                      _depth_record, _sweep)

row, stats, inventory, texts, files, taxonomy = hostile_row()
observed = {"variants": {}, "problems": []}


def with_attachments(sweep):
    sweep = copy.deepcopy(sweep)
    sweep["results"]["sam.gov"][0]["raw_payload"].update(copy.deepcopy(row["raw_payload"]))
    return sweep


def normalize(rec):
    dump = json.loads(rec.model_dump_json())
    blob = json.dumps(dump, sort_keys=True)
    blob = re.sub(r"[0-9a-f]{64}", "<hash>", blob)
    return blob


def compare(name, base_sweep, *, review=False, attachments_reviewed=False, expect):
    plain = base_sweep
    enriched = with_attachments(base_sweep)
    if review:
        run_p, _, _ = _build_with_requirement_review(plain, attachments_reviewed=attachments_reviewed)
        run_e, _, _ = _build_with_requirement_review(enriched, attachments_reviewed=attachments_reviewed)
    else:
        run_p, _, _ = _build(plain)
        run_e, _, _ = _build(enriched)
    rp, re_ = record_for(run_p, "N1"), record_for(run_e, "N1")
    variant = {
        "plain": {"classification": rp.classification.value, "recommendation": rp.recommendation.value,
                  "requirement_excerpt": rp.requirement_excerpt, "attachment_gap": rp.attachment_gap,
                  "reviewed_at": str(rp.requirement_reviewed_at), "attachments_checked": rp.attachments_checked},
        "enriched": {"classification": re_.classification.value, "recommendation": re_.recommendation.value,
                     "requirement_excerpt": re_.requirement_excerpt, "attachment_gap": re_.attachment_gap,
                     "reviewed_at": str(re_.requirement_reviewed_at), "attachments_checked": re_.attachments_checked},
        "normalized_records_identical": normalize(rp) == normalize(re_),
        "enriched_record_leak": scan(json.loads(re_.model_dump_json())),
        "enriched_run_leak": scan(json.loads(run_e.model_dump_json())),
    }
    problems = []
    if rp.classification.value != expect:
        problems.append(f"plain control did not reach {expect}: {rp.classification.value}")
    if re_.classification != rp.classification or re_.recommendation != rp.recommendation:
        problems.append("attachment fields changed classification/recommendation")
    if re_.requirement_excerpt != rp.requirement_excerpt:
        problems.append("attachment fields changed requirement_excerpt")
    if re_.attachment_gap != rp.attachment_gap:
        problems.append("attachment fields changed attachment_gap")
    if not variant["normalized_records_identical"]:
        problems.append("normalized LiveSolicitation differs")
    if variant["enriched_record_leak"] or variant["enriched_run_leak"]:
        problems.append("attachment text leaked into record/run")
    variant["problems"] = problems
    observed["variants"][name] = variant
    observed["problems"].extend(f"{name}: {p}" for p in problems)


s1 = _sweep()
s1["results"]["dossiers"] = {"depth_records": [_depth_record()]}
compare("1_candidate_awaiting_approval", s1, expect="unscreened")

compare("2_approved_zero_attachments", copy.deepcopy(s1), review=True, expect="bid_now")

s3 = _sweep()
s3["results"]["dossiers"] = {"depth_records": [_depth_record(attachments=files)]}
compare("3_approved_four_file_inventory", s3, review=True, attachments_reviewed=True, expect="bid_now")

status = "PASS" if not observed["problems"] else "FAIL"
emit({"probe": "mixed_positive_control", "status": status, "observed": observed})
