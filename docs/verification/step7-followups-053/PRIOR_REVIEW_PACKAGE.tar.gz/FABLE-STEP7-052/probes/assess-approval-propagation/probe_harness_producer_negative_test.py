"""Probe (harness): does the producer's negative test discriminate?

tests/test_step7_evidence_collection.py::test_collected_attachment_text_cannot_supply_strict_notice_requirement
builds _sweep() with NO depth records and asserts classification != BID_NOW,
requirement_reviewed_at is None, attachment_gap set. Without any retained depth
every solicitation is UNSCREENED regardless of attachment text, so the test would
pass even if attachment text were promoted into the requirement path. Measured
here by running the producer's exact assertions on (a) the enriched row and
(b) the same sweep with every attachment field stripped: identical outcomes.
The producer test also keeps N1's title "Packet capture platform" so the notice
itself is not irrelevant. Compare with probe_hostile_attachment_only_assess
cases B/D which supply a trusted irrelevant depth and DO discriminate.
"""
from _common import emit, hostile_row
import copy
import json

from agents.assess.contracts import LiveClassification
from tests.test_assess_ledger import _build, _sweep

row, stats, inventory, texts, files, taxonomy = hostile_row()


def producer_assertions(sweep):
    run, diagnostics, index = _build(sweep)
    parent = next(r for r in run.live.records if r.notice_id == "N1")
    return {
        "classification": parent.classification.value,
        "not_bid_now": parent.classification != LiveClassification.BID_NOW,
        "reviewed_at_none": parent.requirement_reviewed_at is None,
        "attachment_gap_set": bool(parent.attachment_gap),
        "attachment_gap": parent.attachment_gap,
        "requirement_excerpt": parent.requirement_excerpt,
    }


# (a) exactly as the producer test builds it
sweep_a = _sweep()
original = sweep_a["results"]["sam.gov"][0]
original["source_id"] = row["source_id"]
original["raw_payload"].update(copy.deepcopy(row["raw_payload"]))
with_attachment = producer_assertions(sweep_a)

# (b) same sweep, every attachment-derived key removed
sweep_b = _sweep()
without_attachment = producer_assertions(sweep_b)

# (c) producer sweep + trusted depth whose description is the notice's own
# (supporting) text: still not BID_NOW without human review, but the
# candidate excerpt comes from depth, never from attachment text.
from tests.test_assess_ledger import _depth_record
sweep_c = copy.deepcopy(sweep_a)
sweep_c["results"]["dossiers"] = {"depth_records": [_depth_record()]}
with_depth = producer_assertions(sweep_c)

identical = {k: with_attachment[k] == without_attachment[k]
             for k in ("classification", "not_bid_now", "reviewed_at_none", "attachment_gap_set", "attachment_gap")}
observed = {
    "producer_shape_with_attachment": with_attachment,
    "producer_shape_without_attachment": without_attachment,
    "producer_shape_plus_supporting_depth": with_depth,
    "assertions_identical_with_and_without_attachment": identical,
    "verdict": ("producer negative test does not discriminate: the same assertions hold with "
                "zero attachment fields because no depth is retained" if all(identical.values())
                else "producer test discriminates"),
}
emit({"probe": "harness_producer_negative_test",
      "status": "INFO" if all(identical.values()) else "PASS", "observed": observed})
