"""Probe: eight-slot / LeadRow surface built from the hostile Assess run.

draft_lead_rows(run) over the hostile row (attachment-only requirement cues,
trusted irrelevant depth). Checks: lead tier HOLD, blocked_by carries the
attachment gap, requirement_span None on the parent, and no attachment-derived
text anywhere in the drafted parents/leads/traces. Positive control: the
mixed row (depth supports requirement, approved review) with attachment fields
yields the same lead surface as without them.
"""
from _common import ATTACHMENT_NEEDLES, depth_with, emit, hostile_row, irrelevant_sweep
from _common import scan as _scan
import copy
import json
import re

# The control depth description shares one sentence with the attachment text
# by test design; the control scan uses only attachment-unique needles. The
# hostile scan keeps the full needle set (its depth is lawn maintenance).
UNIQUE_NEEDLES = tuple(n for n in ATTACHMENT_NEEDLES
                       if n != "contractor shall provide an enterprise packet capture platform")


def scan(obj, needles=ATTACHMENT_NEEDLES):
    return _scan(obj, needles)

from agents.leadgen.from_assess import draft_lead_rows
from tests.test_assess_ledger import (_build, _build_with_requirement_review,
                                      _depth_record, _sweep)

row, stats, inventory, texts, files, taxonomy = hostile_row()
observed = {"problems": []}

sweep = irrelevant_sweep(row)
sweep["results"]["dossiers"] = {"depth_records": [depth_with(
    "The contractor shall provide lawn maintenance for the campus.", attachments=files)]}
run, _, _ = _build(sweep)
drafts = draft_lead_rows(run)
parent = next(p for p in drafts.parents if p.notice_id == "N1")
leads = [l for l in drafts.leads if getattr(l, "parent_assessment_id", None) == parent.assessment_id] or list(drafts.leads)
dump = json.loads(drafts.model_dump_json())
observed["hostile"] = {
    "parent_live_classification": str(parent.live_classification),
    "parent_requirement_span": parent.requirement_span,
    "lead_count": len(drafts.leads),
    "lead_tiers": sorted({str(l.lead_tier) for l in drafts.leads}),
    "blocked_by": sorted({str(l.current_next_action.blocked_by)[:300] for l in drafts.leads}),
    "verbs": sorted({str(l.current_next_action.verb) for l in drafts.leads}),
    "drafts_leak": scan(dump),
}
if parent.requirement_span:
    observed["problems"].append("parent requirement_span populated from attachment-only row")
if observed["hostile"]["drafts_leak"]:
    observed["problems"].append(f"attachment text reached lead drafts: {observed['hostile']['drafts_leak']}")
if any(str(l.lead_tier).endswith("WATCH") or "watch" in str(l.lead_tier).lower() for l in drafts.leads):
    observed["problems"].append("a lead is WATCH tier despite attachment gap")
if drafts.leads and not all("attachment gap" in str(l.current_next_action.blocked_by) for l in drafts.leads):
    observed["problems"].append("attachment gap missing from blocked_by")


def normalize(d):
    return re.sub(r"[0-9a-f]{64}", "<h>", json.dumps(d, sort_keys=True))


# Positive control: supporting depth + approved review, with and without attachment fields
s = _sweep()
s["results"]["dossiers"] = {"depth_records": [_depth_record(attachments=files)]}
e = copy.deepcopy(s)
e["results"]["sam.gov"][0]["raw_payload"].update(copy.deepcopy(row["raw_payload"]))
run_p, _, _ = _build_with_requirement_review(s, attachments_reviewed=True)
run_e, _, _ = _build_with_requirement_review(e, attachments_reviewed=True)
dp = json.loads(draft_lead_rows(run_p).model_dump_json())
de = json.loads(draft_lead_rows(run_e).model_dump_json())
for d in (dp, de):
    d.pop("assess_run_id", None)
    for item in d.get("parents", []) + d.get("leads", []) + d.get("traces", []):
        for k in list(item.keys()):
            if k.endswith("_id") or k in {"assess_run_id", "lead_ids"}:
                item[k] = "<id>"
pp = next(p for p in run_p.live.records if p.notice_id == "N1")
pe = next(p for p in run_e.live.records if p.notice_id == "N1")
observed["control"] = {
    "plain_classification": pp.classification.value, "enriched_classification": pe.classification.value,
    "plain_leads": len(dp["leads"]), "enriched_leads": len(de["leads"]),
    "plain_tiers": sorted({str(l["lead_tier"]) for l in dp["leads"]}),
    "enriched_tiers": sorted({str(l["lead_tier"]) for l in de["leads"]}),
    "normalized_identical": normalize(dp) == normalize(de),
    "enriched_leak": scan(de, UNIQUE_NEEDLES),
}
observed["hostile"]["parent_fields"] = {
    "live_recommendation": str(parent.live_recommendation),
    "lifecycle": str(parent.lifecycle),
    "note": "UNSCREENED parent mints zero LeadRows; attachment gap stays on the Assess record",
}
if pp.classification.value != "bid_now":
    observed["problems"].append("control did not reach bid_now")
if not observed["control"]["normalized_identical"]:
    observed["problems"].append("attachment fields changed the lead surface of the control row")
if observed["control"]["enriched_leak"]:
    observed["problems"].append("attachment text in control lead drafts")

status = "PASS" if not observed["problems"] else "FAIL"
emit({"probe": "leadrow_propagation", "status": status, "observed": observed})
