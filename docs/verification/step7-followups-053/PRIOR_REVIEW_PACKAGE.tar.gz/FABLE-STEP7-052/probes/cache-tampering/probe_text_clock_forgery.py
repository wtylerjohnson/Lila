"""Text cache: retrieved_at forgeries (future, past, naive, non-ISO, Z suffix, epoch int, null, offset zones)."""
import json
import common
from common import fresh_dirs, mock_download, mock_download_fail, public_file, emit, now_iso
from tools.api import sam_attachment_text as sat

RID = "b" * 32
ORIGINAL = b"Original requirement text."

variants = {
    "future_plus_1_day": now_iso(86400),
    "future_plus_5_seconds": now_iso(5),
    "past_1970_aware": "1970-01-01T00:00:00+00:00",
    "past_10_years_aware": "2016-09-13T00:00:00+00:00",
    "naive_now": now_iso().split("+")[0],
    "non_iso_text": "yesterday at noon",
    "z_suffix_now": now_iso().split("+")[0] + "Z",
    "z_suffix_past": "2026-01-01T00:00:00Z",
    "offset_plus_14_now_local": None,  # filled below
    "epoch_int": 1757700000,
    "null": None,
    "empty_string": "",
    "date_only": "2026-09-13",
}
from datetime import datetime, timezone, timedelta
# a wall-clock string in +14:00 that is in the future by wall reading but past in UTC once offset applied
variants["offset_plus_14_now_local"] = (datetime.now(timezone(timedelta(hours=14)))).isoformat()
# a -12:00 zone string whose UTC instant is in the future (wall time = now+1h at -12 means UTC now+13h)
variants["offset_minus_12_future_instant"] = (datetime.now(timezone(timedelta(hours=-12))) + timedelta(hours=1)).isoformat()

cases = {}
for label, stamp in variants.items():
    notice, text = fresh_dirs(f"text_clock_{label}")
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    cache = text / f"{RID}.json"
    saved = json.loads(cache.read_text())
    saved["retrieved_at"] = stamp
    cache.write_text(json.dumps(saved))
    mock_download_fail()
    try:
        r = sat.extract_public_attachment_text(public_file())
        outcome = {**common.summarize_text(r), "accepted": r.get("from_cache") is True}
    except Exception as exc:  # noqa: BLE001
        outcome = {"exception": f"{type(exc).__name__}: {exc}", "accepted": False, "crashed": True}
    cases[label] = {"stamp": stamp, **outcome}

accepted = sorted(k for k, v in cases.items() if v.get("accepted"))
crashed = sorted(k for k, v in cases.items() if v.get("crashed"))
expected_accept = {"past_1970_aware", "past_10_years_aware", "z_suffix_now", "z_suffix_past", "offset_plus_14_now_local"}
expected_reject = set(cases) - expected_accept
mismatch = [k for k in cases if (k in expected_accept) != bool(cases[k].get("accepted"))]
status = "FAIL" if crashed or mismatch else "INFO"
emit(status, {"cases": cases, "accepted": accepted, "crashed": crashed,
              "unexpected_vs_code_reading": mismatch,
              "note": "text cache has no TTL by design (permanent by resource id); past clocks are accepted; any aware past instant is unauthenticated (H2 text side)"},
     "text_clock_forgery")
