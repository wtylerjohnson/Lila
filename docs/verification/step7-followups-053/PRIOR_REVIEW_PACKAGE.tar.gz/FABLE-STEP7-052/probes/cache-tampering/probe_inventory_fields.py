"""Inventory cache: positive control, coherent raw+projection rewrite, projection-only edits, per-attachment metadata edits, reorder, count/hash mismatch, status/authority/schema edits, type confusion, id mismatch."""
import json, copy
import common
from common import fresh_dirs, mock_http, mock_http_fail, emit, sha, place_object, now_iso
from tools.api import sam_notice_detail as detail

NID = "a" * 32
RID1, RID2 = "b" * 32, "c" * 32
BODY = json.dumps({"_embedded": {"opportunityAttachmentList": [{"attachments": [
    {"name": "SOW.txt", "resourceId": RID1, "mimeType": "text/plain", "size": 100, "accessLevel": "public"},
    {"name": "Pricing.txt", "resourceId": RID2, "mimeType": "text/plain", "size": 200, "accessLevel": "public"},
]}]}}).encode()
cases = {}


def capture(tag):
    notice, text = fresh_dirs(f"inv_fields_{tag}")
    mock_http(BODY)
    first = detail.fetch_notice_resources(NID)
    assert first["collection_status"] == "inventory_captured", first
    return notice, notice / f"{NID}.resources.json", first


def rerun():
    mock_http_fail()
    try:
        return detail.fetch_notice_resources(NID), None
    except Exception as exc:  # noqa: BLE001
        return None, f"{type(exc).__name__}: {exc}"


def record(label, r, err, **extra):
    if err:
        cases[label] = {"crashed": True, "exception": err, **extra}
    else:
        cases[label] = {**common.summarize_inv(r), "served_fresh_from_cache": r.get("from_cache") is True and r.get("stale_cache") is False,
                        "served_stale": r.get("stale_cache") is True, **extra}

# positive control
notice, cache, first = capture("pos")
r, err = rerun(); record("positive_control", r, err)

# coherent rewrite: new raw body with invented attachment, projection recomputed, raw_capture receipt updated
notice, cache, first = capture("coherent")
saved = json.loads(cache.read_text())
invented_body = json.dumps({"attachments": [{"name": "Invented Requirements.txt", "resourceId": "d" * 32, "mimeType": "text/plain", "size": 5, "accessLevel": "public"}]}).encode()
items, recognized = detail._attachment_inventory(json.loads(invented_body), NID)
saved["raw_capture"].update(place_object(notice, invented_body))
saved["attachments"] = items; saved["attachment_inventory_count"] = len(items); saved["attachment_inventory_hash"] = detail._manifest_hash(items)
cache.write_text(json.dumps(saved))
r, err = rerun(); record("coherent_raw_and_projection_rewrite", r, err, accepted_invented_inventory=(r or {}).get("from_cache") is True and (r or {}).get("attachments") == items)

# projection-only edits (raw untouched): each is DETECTED as fresh-cache miss; on refetch failure the STALE path returns the tampered projection
proj_edits = {
    "attachment_name": lambda a: a[0].__setitem__("name", "Renamed SOW.txt"),
    "attachment_size": lambda a: a[0].__setitem__("size", 101),
    "attachment_type": lambda a: a[0].__setitem__("type", "application/pdf"),
    "attachment_access_level_private_to_public": lambda a: a[0].__setitem__("access_level", "public"),
    "attachment_export_controlled_flag": lambda a: a[0].__setitem__("export_controlled", "1"),
    "attachment_explicit_access_flag": lambda a: a[0].__setitem__("explicit_access", "1"),
    "attachment_resource_id": lambda a: a[0].__setitem__("resource_id", "e" * 32),
    "attachment_source_url": lambda a: a[0].__setitem__("source_url", "https://sam.gov/x"),
    "attachments_reordered": lambda a: a.reverse(),
    "attachment_appended_invented": lambda a: a.append({**a[0], "name": "Invented.txt", "resource_id": "f" * 32}),
    "attachment_removed": lambda a: a.pop(),
    "attachment_size_as_string": lambda a: a[0].__setitem__("size", "100"),
}
for label, mutate in proj_edits.items():
    notice, cache, first = capture(label)
    saved = json.loads(cache.read_text()); mutate(saved["attachments"])
    # keep count/hash consistent with the tampered projection where a coherent local writer would
    saved["attachment_inventory_count"] = len(saved["attachments"]); saved["attachment_inventory_hash"] = detail._manifest_hash(saved["attachments"])
    cache.write_text(json.dumps(saved))
    r, err = rerun()
    record(f"projection_{label}", r, err, tampered_attachments_returned_via_stale=(r or {}).get("attachments") == saved["attachments"] and (r or {}).get("stale_cache") is True)

# count / hash mismatch alone
for label, mutate in {"count_mismatch": lambda s: s.__setitem__("attachment_inventory_count", 5),
                      "hash_mismatch": lambda s: s.__setitem__("attachment_inventory_hash", "0" * 64),
                      "count_as_string": lambda s: s.__setitem__("attachment_inventory_count", "2"),
                      "resources_checked_string_true": lambda s: s.__setitem__("resources_checked", "true"),
                      "resources_checked_1": lambda s: s.__setitem__("resources_checked", 1),
                      "http_status_string": lambda s: s["raw_capture"].__setitem__("http_status", "200"),
                      "http_status_201": lambda s: s["raw_capture"].__setitem__("http_status", 201),
                      "complete_string_true": lambda s: s["raw_capture"].__setitem__("complete", "true"),
                      "complete_1": lambda s: s["raw_capture"].__setitem__("complete", 1),
                      "raw_bytes_as_string": lambda s: s["raw_capture"].__setitem__("bytes", str(s["raw_capture"]["bytes"])),
                      "raw_source_url_other_notice": lambda s: s["raw_capture"].__setitem__("source_url", detail.RESOURCES_URL_TPL.format(id="9" * 32)),
                      "representation_changed": lambda s: s["raw_capture"].__setitem__("representation", "forged"),
                      "collection_status_confirmed_empty": lambda s: s.__setitem__("collection_status", "confirmed_empty"),
                      "collection_status_arbitrary": lambda s: s.__setitem__("collection_status", "trusted_inventory"),
                      "authority_trusted": lambda s: s.__setitem__("authority", "trusted"),
                      "resources_schema_forged": lambda s: s.__setitem__("resources_schema", "recognized_v9"),
                      "errors_injected": lambda s: s.__setitem__("errors", ["injected error text"]),
                      "retrieved_at_far_past_with_received_at_now": lambda s: s.__setitem__("retrieved_at", "2016-01-01T00:00:00+00:00"),
                      "id_other_notice": lambda s: s.__setitem__("id", "9" * 32),
                      "id_uppercase": lambda s: s.__setitem__("id", "A" * 32),
                      "extra_key_ignored": lambda s: s.__setitem__("operator_note", "x"),
                      }.items():
    notice, cache, first = capture(label)
    saved = json.loads(cache.read_text()); mutate(saved); cache.write_text(json.dumps(saved))
    r, err = rerun()
    record(f"field_{label}", r, err, returned_collection_status=(r or {}).get("collection_status"), returned_authority=(r or {}).get("authority"), returned_schema=(r or {}).get("resources_schema"))

fresh_served = sorted(k for k, v in cases.items() if v.get("served_fresh_from_cache"))
stale_served = sorted(k for k, v in cases.items() if v.get("served_stale"))
crashed = sorted(k for k, v in cases.items() if v.get("crashed"))
tampered_via_stale = sorted(k for k, v in cases.items() if v.get("tampered_attachments_returned_via_stale"))
notes = []
status = "PASS"
if cases["coherent_raw_and_projection_rewrite"].get("accepted_invented_inventory"):
    notes.append("coherent raw+projection rewrite served as fresh inventory_captured (hash custody only)")
for k in ("field_collection_status_confirmed_empty", "field_collection_status_arbitrary", "field_authority_trusted", "field_resources_schema_forged", "field_errors_injected"):
    if k in fresh_served:
        notes.append(f"{k}: unbound receipt field served from fresh cache with forged value {cases[k].get('returned_collection_status') if 'status' in k else cases[k].get('returned_authority') or cases[k].get('returned_schema')}")
        status = "FAIL"
if tampered_via_stale:
    notes.append("projection-only tampers are refused as FRESH but the stale fallback returns the tampered projection unvalidated")
    status = "FAIL"
if crashed:
    status = "FAIL"; notes.append(f"crashes: {crashed}")
emit(status, {"cases": cases, "served_fresh_from_cache": fresh_served, "served_stale": stale_served, "tampered_projection_via_stale": tampered_via_stale, "crashed": crashed, "notes": notes}, "inventory_fields")
