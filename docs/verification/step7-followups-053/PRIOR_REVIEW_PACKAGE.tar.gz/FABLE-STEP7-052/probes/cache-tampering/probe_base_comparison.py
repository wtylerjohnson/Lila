"""Run the same tampers against BASE 2d522f0 modules to classify new_defect vs pre_existing."""
import json, importlib.util, sys, os
import common
from common import fresh_dirs, mock_http, mock_http_fail, emit, sha, now_iso
from pathlib import Path

BASE = Path(__file__).resolve().parent / "base"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); sys.modules[name] = mod; spec.loader.exec_module(mod)
    return mod

bdetail = load("base_sam_notice_detail", BASE / "base_sam_notice_detail.py")
bsat = load("base_sam_attachment_text", BASE / "base_sam_attachment_text.py")
from tools.api import sam_notice_detail as cdetail
from tools.api import sam_attachment_text as csat

NID = "a" * 32; RID = "b" * 32
BODY = b'{"attachments":[{"name":"SOW.txt","resourceId":"' + RID.encode() + b'","mimeType":"text/plain","size":5,"accessLevel":"public"}]}'
cases = {}


def mock_dl(mod, payload=None, fail=False):
    def dl(resource_id, **k):
        if fail: raise RuntimeError("source unavailable (probe)")
        return payload
    mod._download_bytes = dl


def text_case(label, mutate, mod, mod_name):
    notice, text = fresh_dirs(f"base_text_{mod_name}_{label}")
    mock_dl(mod, b"Original requirement")
    first = mod.extract_public_attachment_text(common.public_file())
    cache = text / f"{RID}.json"; saved = json.loads(cache.read_text()); mutate(saved, text); cache.write_text(json.dumps(saved))
    mock_dl(mod, fail=True)
    try:
        r = mod.extract_public_attachment_text(common.public_file())
        return {"from_cache": r.get("from_cache"), "text": (r.get("text") or "")[:60], "collection_status": r.get("collection_status"), "crashed": False}
    except Exception as exc:  # noqa: BLE001
        return {"crashed": True, "exception": f"{type(exc).__name__}: {exc}"}


def inv_case(label, mutate, mod, mod_name):
    notice, text = fresh_dirs(f"base_inv_{mod_name}_{label}")
    mock_http(BODY); first = mod.fetch_notice_resources(NID)
    cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text()); mutate(saved, notice); cache.write_text(json.dumps(saved))
    mock_http_fail()
    try:
        r = mod.fetch_notice_resources(NID)
        return {"from_cache": r.get("from_cache"), "stale_cache": r.get("stale_cache"), "attachments": r.get("attachments"), "collection_status": r.get("collection_status"), "crashed": False}
    except Exception as exc:  # noqa: BLE001
        return {"crashed": True, "exception": f"{type(exc).__name__}: {exc}"}

text_tampers = {
    "text_only": lambda s, d: s.__setitem__("text", "Invented requirement"),
    "retrieved_at_null": lambda s, d: s.__setitem__("retrieved_at", None),
    "retrieved_at_int": lambda s, d: s.__setitem__("retrieved_at", 1757700000),
    "raw_capture_string": lambda s, d: s.__setitem__("raw_capture", "corrupt"),
    "name_only": lambda s, d: s.__setitem__("name", "Renamed.txt"),
}
inv_tampers = {
    "projection_invented_attachment": lambda s, d: s["attachments"].append({**s["attachments"][0], "name": "Invented.txt", "resource_id": "f" * 32}),
    "raw_capture_string": lambda s, d: s.__setitem__("raw_capture", "corrupt"),
    "collection_status_forged": lambda s, d: s.__setitem__("collection_status", "trusted_inventory"),
    "clock_rewrite_after_8_days": lambda s, d: (s.__setitem__("retrieved_at", now_iso()), s.get("raw_capture", {}).__setitem__("received_at", now_iso()) if isinstance(s.get("raw_capture"), dict) else None),
}
for label, mutate in text_tampers.items():
    cases[f"text_{label}"] = {"base": text_case(label, mutate, bsat, "base"), "candidate": text_case(label, mutate, csat, "cand")}
for label, mutate in inv_tampers.items():
    cases[f"inventory_{label}"] = {"base": inv_case(label, mutate, bdetail, "base"), "candidate": inv_case(label, mutate, cdetail, "cand")}

# stale fallback with tampered projection at base vs candidate (expire the clock first)
def stale_tamper(s, d):
    s["attachments"].append({**s["attachments"][0], "name": "Invented.txt", "resource_id": "f" * 32})
    s["attachment_inventory_hash"] = cdetail._manifest_hash(s["attachments"]); s["attachment_inventory_count"] = 2
    s["retrieved_at"] = now_iso(-(cdetail.RESOURCE_CACHE_TTL_SECONDS + 60))
    if isinstance(s.get("raw_capture"), dict): s["raw_capture"]["received_at"] = s["retrieved_at"]
cases["inventory_stale_fallback_tampered_projection"] = {"base": inv_case("stale", stale_tamper, bdetail, "base"), "candidate": inv_case("stale", stale_tamper, cdetail, "cand")}

classification = {}
for k, v in cases.items():
    b, c = v["base"], v["candidate"]
    if c.get("crashed") and not b.get("crashed"):
        classification[k] = "new_defect (candidate crashes, base did not)"
    elif b.get("crashed") and c.get("crashed"):
        classification[k] = "pre_existing crash"
    elif k.startswith("text_") and b.get("from_cache") and not c.get("from_cache"):
        classification[k] = "candidate detects; base accepted (improvement)"
    elif k.startswith("text_") and b.get("from_cache") and c.get("from_cache"):
        classification[k] = "accepted by both (pre_existing, unbound field)"
    elif k.startswith("inventory_") and b.get("stale_cache") and c.get("stale_cache"):
        classification[k] = "served as stale by both (pre_existing unvalidated stale path)"
    elif k.startswith("inventory_") and b.get("from_cache") and not b.get("stale_cache") and c.get("from_cache") and not c.get("stale_cache"):
        classification[k] = "served fresh by both (pre_existing, unbound field or unauthenticated clock)"
    elif k.startswith("inventory_") and b.get("from_cache") and not b.get("stale_cache") and (c.get("stale_cache") or not c.get("from_cache")):
        classification[k] = "candidate refuses fresh reuse; base served fresh (improvement)"
    else:
        classification[k] = "see raw"
emit("INFO", {"cases": cases, "classification": classification}, "base_comparison")
