"""Inventory cache: cache path is a directory, unreadable, objects dir symlink, object symlink escape, malformed raw_capture types, poisoned object, no hardlink."""
import json, os
import common
from common import fresh_dirs, mock_http, mock_http_fail, emit, sha
from tools.api import sam_notice_detail as detail

NID = "a" * 32
BODY = b'{"attachments":[{"name":"SOW.txt","resourceId":"' + b"b" * 32 + b'","mimeType":"text/plain","size":5,"accessLevel":"public"}]}'
cases = {}


def run(label, fn):
    try:
        cases[label] = fn()
    except Exception as exc:  # noqa: BLE001
        cases[label] = {"exception": f"{type(exc).__name__}: {exc}", "crashed": True}


def case_dir():
    notice, text = fresh_dirs("inv_fs_dir")
    (notice / f"{NID}.resources.json").mkdir()
    calls = mock_http(BODY)
    r = detail.fetch_notice_resources(NID)
    return {**common.summarize_inv(r), "http_calls": len(calls), "raw_capture_present": "raw_capture" in r,
            "successful_fetch_reported_as": r.get("collection_status")}


def case_unreadable():
    notice, text = fresh_dirs("inv_fs_unreadable")
    mock_http(BODY); detail.fetch_notice_resources(NID)
    cache = notice / f"{NID}.resources.json"; os.chmod(cache, 0)
    try:
        calls = mock_http(BODY); r = detail.fetch_notice_resources(NID)
        return {**common.summarize_inv(r), "http_calls": len(calls), "successful_fetch_reported_as": r.get("collection_status")}
    finally:
        os.chmod(cache, 0o644)


def case_objects_symlink():
    notice, text = fresh_dirs("inv_fs_objsym")
    mock_http(BODY); detail.fetch_notice_resources(NID)
    real = notice / "objects"; elsewhere = notice.parent / "elsewhere_objects"
    real.rename(elsewhere); os.symlink(elsewhere, real)
    mock_http_fail(); r = detail.fetch_notice_resources(NID)
    return {**common.summarize_inv(r), "accepted_via_symlinked_objects_dir": r.get("from_cache") is True and r.get("stale_cache") is False}


def case_object_escape():
    notice, text = fresh_dirs("inv_fs_objescape")
    mock_http(BODY); first = detail.fetch_notice_resources(NID)
    target = notice / first["raw_capture"]["path"]; outside = notice.parent / "outside.bin"; outside.write_bytes(BODY)
    target.unlink(); os.symlink(outside, target)
    mock_http_fail(); r = detail.fetch_notice_resources(NID)
    return {**common.summarize_inv(r), "fresh_rejected": not (r.get("from_cache") is True and r.get("stale_cache") is False),
            "note": "escape rejected for FRESH reuse; the stale fallback then serves the projection without reading the object"}


def case_malformed_types():
    out = {}
    for label, mutate in {
        "raw_capture_string": lambda s: s.__setitem__("raw_capture", "abc"),
        "raw_capture_list": lambda s: s.__setitem__("raw_capture", [1]),
        "raw_capture_int": lambda s: s.__setitem__("raw_capture", 7),
        "raw_capture_null": lambda s: s.__setitem__("raw_capture", None),
        "received_at_int": lambda s: s["raw_capture"].__setitem__("received_at", 1757700000),
        "received_at_null": lambda s: s["raw_capture"].__setitem__("received_at", None),
        "attachments_string": lambda s: s.__setitem__("attachments", "none"),
        "attachments_dict": lambda s: s.__setitem__("attachments", {"name": "x"}),
    }.items():
        notice, text = fresh_dirs(f"inv_fs_types_{label}")
        mock_http(BODY); detail.fetch_notice_resources(NID)
        cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text()); mutate(saved); cache.write_text(json.dumps(saved))
        mock_http_fail()
        try:
            r = detail.fetch_notice_resources(NID)
            out[label] = {**common.summarize_inv(r), "crashed": False}
        except Exception as exc:  # noqa: BLE001
            out[label] = {"exception": f"{type(exc).__name__}: {exc}", "crashed": True}
    return out


def case_poisoned_object():
    notice, text = fresh_dirs("inv_fs_poison")
    (notice / "objects").mkdir(); (notice / "objects" / f"{sha(BODY)}.bin").write_bytes(b"poison")
    calls = mock_http(BODY); r = detail.fetch_notice_resources(NID)
    return {**common.summarize_inv(r), "http_calls": len(calls), "denied": r.get("collection_status") != "inventory_captured"}


def case_no_hardlink():
    notice, text = fresh_dirs("inv_fs_nolink")
    real = os.link
    def no_link(*a, **k): raise OSError(1, "Operation not permitted (probe)")
    os.link = no_link
    try:
        mock_http(BODY); r = detail.fetch_notice_resources(NID)
    finally:
        os.link = real
    return {**common.summarize_inv(r), "raw_capture_present": "raw_capture" in r}

run("cache_path_is_directory", case_dir)
run("cache_file_unreadable_chmod000", case_unreadable)
run("objects_dir_replaced_by_symlink", case_objects_symlink)
run("object_file_symlink_escapes_objects", case_object_escape)
run("malformed_raw_capture_types", case_malformed_types)
run("poisoned_object_under_true_hash_name", case_poisoned_object)
run("retain_bytes_without_hardlink", case_no_hardlink)

crashes = [k for k, v in cases.get("malformed_raw_capture_types", {}).items() if v.get("crashed")]
notes = []; status = "PASS"
if crashes:
    status = "FAIL"; notes.append(f"AttributeError escapes _resource_capture_valid for {crashes}")
for k in ("cache_path_is_directory", "cache_file_unreadable_chmod000"):
    if cases.get(k, {}).get("successful_fetch_reported_as") == "lookup_failed":
        status = "FAIL"; notes.append(f"{k}: HTTP 200 recognized inventory reported as lookup_failed because the cache write failed")
if cases.get("object_file_symlink_escapes_objects", {}).get("stale_cache"):
    notes.append("object escape: fresh path rejects, stale fallback serves projection anyway")
emit(status, {"cases": cases, "notes": notes}, "inventory_filesystem")
