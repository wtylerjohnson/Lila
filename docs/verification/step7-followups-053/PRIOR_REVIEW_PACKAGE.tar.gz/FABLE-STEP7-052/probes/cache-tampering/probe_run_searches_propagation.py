"""run_searches-level consequences of cache tampering: malformed cache crash sinks a whole notice, write-failure receipt, cache-only rename reaching collection receipt/dossier, H1 invented text driving relevance."""
import json, os, hashlib
import common
from common import fresh_dirs, mock_download, mock_download_fail, emit, sha, place_object, now_iso
from tools.api import sam_notice_detail as detail
from tools.api import sam_attachment_text as sat
import tools.api.sam_quota as sam_quota
import run_searches as searches
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
from agents.decisions.dossier import _attachment_research_context

NID = "a" * 32
R1, R2 = "b" * 32, "c" * 32
TERM = "network visibility"
sam_quota.calls_today = lambda: 0
cases = {}


def files():
    return [common.public_file(R1, "SOW 1.txt"), common.public_file(R2, "SOW 2.txt")]


def run_enrich(inventory_files):
    inventory = detail._manifest_hash(inventory_files)
    detail.fetch_notice_resources = lambda *a, **k: {"id": NID, "resources_checked": True, "attachments": inventory_files,
                                                     "attachment_inventory_hash": inventory, "collection_status": "inventory_captured"}
    searches.fetch_notice_resources = detail.fetch_notice_resources
    candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA", raw_payload={"type": "Solicitation"})
    class Source:
        last_attachment_census = {"selected": 1}
        def attachment_candidates(self, *a, **k): return [candidate]
    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
    return rows, stats, inventory

TEXTS = {R1: f"Buyer requires {TERM}. File one.".encode(), R2: b"Unrelated file two with pricing."}

# 0. positive control
notice, text = fresh_dirs("rs_pos")
mock_download(TEXTS); rows, stats, inv = run_enrich(files())
rec = stats["attachment_record_receipts"][NID]
cases["positive_control"] = {"rows": len(rows), "status": rec["status"], "file_states": {f["resource_id"]: f["status"] for f in rec["files"]}}

# 1. malformed text cache for file 1 (raw_capture replaced with a string): crash sinks the whole notice
notice, text = fresh_dirs("rs_crash")
mock_download(TEXTS); run_enrich(files())
cache = text / f"{R1}.json"; saved = json.loads(cache.read_text()); saved["raw_capture"] = "corrupt"; cache.write_text(json.dumps(saved))
mock_download(TEXTS); rows, stats, inv = run_enrich(files())
rec = stats["attachment_record_receipts"][NID]
cases["malformed_text_cache_file1"] = {"rows": len(rows), "status": rec["status"], "errors": rec.get("errors"),
                                        "files_receipt_present": "files" in rec,
                                        "file2_lost_although_healthy": rec["status"] == "FAILED",
                                        "download_would_have_succeeded": True}

# 1b. same, but for the inventory cache (real fetch_notice_resources with mocked HTTP)
import importlib; importlib.reload(detail); importlib.reload(searches)
notice, text = fresh_dirs("rs_crash_inv")
body = json.dumps({"attachments": [{"name": "SOW 1.txt", "resourceId": R1, "mimeType": "text/plain", "size": 5, "accessLevel": "public"}]}).encode()
common.mock_http(body); first = detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text()); saved["raw_capture"] = "corrupt"; cache.write_text(json.dumps(saved))
common.mock_http(body); mock_download(TEXTS)
candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA", raw_payload={"type": "Solicitation"})
class Source:
    last_attachment_census = {"selected": 1}
    def attachment_candidates(self, *a, **k): return [candidate]
tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
rec = stats["attachment_record_receipts"][NID]
cases["malformed_inventory_cache"] = {"rows": len(rows), "status": rec["status"], "errors": rec.get("errors"), "inventory_receipt_present": "inventory_receipt" in rec,
                                      "note": "HTTP source was reachable and would have returned a recognized inventory"}

# 2. text cache write failure (cache path is a directory) -> file receipt says captured_discovery_only but no text
notice, text = fresh_dirs("rs_writefail")
(text / f"{R1}.json").mkdir()
mock_download(TEXTS); rows, stats, inv = run_enrich(files())
rec = stats["attachment_record_receipts"][NID]
f1 = next(f for f in rec["files"] if f["resource_id"] == R1)
cases["text_cache_write_failure_receipt"] = {"rows": len(rows), "record_status": rec["status"], "file1_status": f1["status"], "file1_reason": f1.get("reason", "")[:100],
                                              "file1_text_in_collection": any(e["resource_id"] == R1 for e in (rows[0]["raw_payload"]["attachment_collection_v1"]["files"] if rows else [])),
                                              "misleading": f1["status"] == "captured_discovery_only" and not any(e["resource_id"] == R1 for e in (rows[0]["raw_payload"]["attachment_collection_v1"]["files"] if rows else []))}

# 3. cache-only rename + forged extraction_limits flow into collection receipt and dossier passages
notice, text = fresh_dirs("rs_rename")
mock_download(TEXTS); run_enrich(files())
cache = text / f"{R1}.json"; saved = json.loads(cache.read_text()); saved["name"] = "Award Notice - Testco Selected.txt"
saved["extraction_limits"] = {"max_text_characters": 10**9, "max_pdf_pages": 10**6, "completeness": "full_document"}
cache.write_text(json.dumps(saved))
mock_download_fail(); rows, stats, inv = run_enrich(files())
coll = rows[0]["raw_payload"]["attachment_collection_v1"]
ctx = _attachment_research_context(rows[0], {"id": NID, "resources_checked": True, "attachment_inventory_hash": inv})
cases["cache_only_rename_and_limits"] = {"collection_file1_name": coll["files"][0]["name"], "collection_file1_limits": coll["files"][0].get("extraction_limits"),
                                          "dossier_status": ctx["status"], "dossier_passage_names": [p["name"] for p in ctx.get("file_passages", [])],
                                          "renamed_name_reaches_dossier": any(p["name"] == saved["name"] for p in ctx.get("file_passages", []))}

# 4. H1 invented text (coherent rewrite) drives relevance and reaches dossier as discovery research
notice, text = fresh_dirs("rs_h1")
neutral = {R1: b"Nothing relevant here at all.", R2: b"Also nothing relevant."}
mock_download(neutral); rows0, stats0, inv = run_enrich(files())
cache = text / f"{R1}.json"; saved = json.loads(cache.read_text())
invented = f"Buyer requires {TERM} and has selected Testco."
saved["text"] = invented; saved["text_sha256"] = sha(invented.encode()); saved["text_capture"] = place_object(text, invented.encode())
saved["text_locator"]["end"] = len(invented); cache.write_text(json.dumps(saved))
mock_download_fail(); rows, stats, inv = run_enrich(files())
rec = stats["attachment_record_receipts"][NID]
ctx = _attachment_research_context(rows[0], {"id": NID, "resources_checked": True, "attachment_inventory_hash": inv}) if rows else None
cases["H1_invented_text_relevance"] = {"rows_before": len(rows0), "rows_after": len(rows), "record_status": rec["status"],
                                        "relevant_after": stats["attachment_relevant"], "file1_from_cache": next(f for f in rec["files"] if f["resource_id"] == R1).get("from_cache"),
                                        "dossier_status": ctx["status"] if ctx else None, "dossier_text_contains_invented": bool(ctx and invented in ctx.get("text", "")),
                                        "raw_sha_still_neutral": rows and rows[0]["raw_payload"]["attachment_collection_v1"]["files"][0]["sha256"] == sha(neutral[R1])}

status = "PASS"; notes = []
if cases["malformed_text_cache_file1"]["file2_lost_although_healthy"]:
    status = "FAIL"; notes.append("one malformed local text-cache entry makes the whole notice FAILED; the healthy second file and the retry download are lost")
if cases["malformed_inventory_cache"]["status"] == "FAILED":
    status = "FAIL"; notes.append("one malformed inventory-cache entry makes the notice FAILED although the source was reachable")
if cases["text_cache_write_failure_receipt"]["misleading"]:
    status = "FAIL"; notes.append("file receipt reports captured_discovery_only with no captured text when the cache write fails")
if cases["cache_only_rename_and_limits"]["renamed_name_reaches_dossier"]:
    notes.append("cache-only name/extraction_limits are unbound and reach attachment_collection_v1 and dossier passages")
if cases["H1_invented_text_relevance"]["dossier_text_contains_invented"]:
    notes.append("H1 invented text drives native relevance and reaches dossier research (discovery_only)")
emit(status, {"cases": cases, "notes": notes}, "run_searches_propagation")
