"""Text cache: cache path is a directory, unreadable file, objects dir symlink, object symlink escape, poisoned object, malformed receipt types."""
import json, os, stat
import common
from common import fresh_dirs, mock_download, mock_download_fail, public_file, emit, sha
from tools.api import sam_attachment_text as sat
from tools.api import sam_capture

RID = "b" * 32
ORIGINAL = b"Original requirement text for filesystem probe."
cases = {}


def run(label, fn):
    try:
        cases[label] = fn()
    except Exception as exc:  # noqa: BLE001
        cases[label] = {"exception": f"{type(exc).__name__}: {exc}", "crashed": True}


def case_dir_at_cache_path():
    notice, text = fresh_dirs("text_fs_dir")
    (text / f"{RID}.json").mkdir()
    mock_download(ORIGINAL)
    r = sat.extract_public_attachment_text(public_file())
    objects = sorted(p.name for p in (text / "objects").glob("*.bin")) if (text / "objects").exists() else []
    return {**common.summarize_text(r), "objects_written": objects,
            "inconsistent_receipt": r.get("collection_status") == "captured_discovery_only" and not r.get("text")}


def case_unreadable_cache_file():
    notice, text = fresh_dirs("text_fs_unreadable")
    mock_download(ORIGINAL)
    sat.extract_public_attachment_text(public_file())
    cache = text / f"{RID}.json"
    os.chmod(cache, 0)
    try:
        mock_download(b"Second download bytes")
        r = sat.extract_public_attachment_text(public_file())
        return {**common.summarize_text(r), "download_called": True,
                "inconsistent_receipt": r.get("collection_status") == "captured_discovery_only" and not r.get("text")}
    finally:
        os.chmod(cache, 0o644)


def case_objects_dir_symlink():
    notice, text = fresh_dirs("text_fs_objsym")
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    real = text / "objects"
    elsewhere = text.parent / "elsewhere_objects"
    real.rename(elsewhere)
    os.symlink(elsewhere, real)
    mock_download_fail()
    r = sat.extract_public_attachment_text(public_file())
    return {**common.summarize_text(r), "accepted_via_symlinked_objects_dir": r.get("from_cache") is True}


def case_object_file_symlink_escape():
    notice, text = fresh_dirs("text_fs_objescape")
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    rel = first["raw_capture"]["path"]
    target = text / rel
    outside = text.parent / "outside.bin"
    outside.write_bytes(ORIGINAL)  # identical content, but lives outside objects/
    target.unlink()
    os.symlink(outside, target)
    mock_download_fail()
    r = sat.extract_public_attachment_text(public_file())
    return {**common.summarize_text(r), "rejected_escape": r.get("from_cache") is False}


def case_object_symlink_inside_objects():
    notice, text = fresh_dirs("text_fs_objinside")
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    rel = first["raw_capture"]["path"]
    target = text / rel
    alias = text / "objects" / "alias.bin"
    alias.write_bytes(ORIGINAL)
    target.unlink()
    os.symlink(alias, target)
    mock_download_fail()
    r = sat.extract_public_attachment_text(public_file())
    return {**common.summarize_text(r), "accepted_symlink_same_content_inside_objects": r.get("from_cache") is True}


def case_poisoned_object_blocks_download():
    notice, text = fresh_dirs("text_fs_poison")
    digest = sha(ORIGINAL)
    (text / "objects").mkdir()
    (text / "objects" / f"{digest}.bin").write_bytes(b"poison")
    mock_download(ORIGINAL)
    r = sat.extract_public_attachment_text(public_file())
    return {**common.summarize_text(r), "poisoned_object_denies_capture": r.get("collection_status") != "captured_discovery_only"}


def case_malformed_receipt_types():
    out = {}
    for label, mutate in {
        "raw_capture_string": lambda s: s.__setitem__("raw_capture", "abc"),
        "raw_capture_list": lambda s: s.__setitem__("raw_capture", []),
        "raw_capture_int": lambda s: s.__setitem__("raw_capture", 5),
        "retrieved_at_int": lambda s: s.__setitem__("retrieved_at", 1757700000),
        "retrieved_at_list": lambda s: s.__setitem__("retrieved_at", ["2026"]),
        "text_capture_null": lambda s: s.__setitem__("text_capture", None),
        "text_locator_string": lambda s: s.__setitem__("text_locator", "0-10"),
    }.items():
        notice, text = fresh_dirs(f"text_fs_types_{label}")
        mock_download(ORIGINAL)
        sat.extract_public_attachment_text(public_file())
        cache = text / f"{RID}.json"
        saved = json.loads(cache.read_text()); mutate(saved); cache.write_text(json.dumps(saved))
        mock_download_fail()
        try:
            r = sat.extract_public_attachment_text(public_file())
            out[label] = {**common.summarize_text(r), "crashed": False}
        except Exception as exc:  # noqa: BLE001
            out[label] = {"exception": f"{type(exc).__name__}: {exc}", "crashed": True}
    return out


def case_retain_bytes_without_hardlink():
    notice, text = fresh_dirs("text_fs_nolink")
    real_link = os.link
    def no_link(src, dst, *a, **k):
        raise OSError(1, "Operation not permitted (probe: filesystem without hardlinks)")
    os.link = no_link
    try:
        mock_download(ORIGINAL)
        r = sat.extract_public_attachment_text(public_file())
    finally:
        os.link = real_link
    return {**common.summarize_text(r), "raw_capture_present": "raw_capture" in r,
            "download_dropped": r.get("collection_status") == "lookup_failed"}

run("cache_path_is_directory", case_dir_at_cache_path)
run("cache_file_unreadable_chmod000", case_unreadable_cache_file)
run("objects_dir_replaced_by_symlink", case_objects_dir_symlink)
run("object_file_symlink_escapes_objects", case_object_file_symlink_escape)
run("object_file_symlink_inside_objects_same_bytes", case_object_symlink_inside_objects)
run("poisoned_object_under_true_hash_name", case_poisoned_object_blocks_download)
run("malformed_receipt_field_types", case_malformed_receipt_types)
run("retain_bytes_without_hardlink_support", case_retain_bytes_without_hardlink)

crashes = [k for k, v in cases.get("malformed_receipt_field_types", {}).items() if v.get("crashed")]
status = "PASS"
notes = []
if crashes:
    status = "FAIL"; notes.append(f"AttributeError escapes _text_capture_valid for {crashes}")
if cases.get("cache_path_is_directory", {}).get("inconsistent_receipt") or cases.get("cache_file_unreadable_chmod000", {}).get("inconsistent_receipt"):
    status = "FAIL"; notes.append("cache write failure after successful download returns collection_status=captured_discovery_only with empty text")
if cases.get("poisoned_object_under_true_hash_name", {}).get("poisoned_object_denies_capture"):
    notes.append("a pre-placed wrong-content object under the true digest name blocks capture (denial, not forgery)")
emit(status, {"cases": cases, "notes": notes}, "text_filesystem")
