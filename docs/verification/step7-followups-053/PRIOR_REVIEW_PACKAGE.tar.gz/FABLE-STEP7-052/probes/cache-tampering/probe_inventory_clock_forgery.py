"""Inventory cache: received_at / retrieved_at forgeries and H2 (moving clocks to keep a stale inventory fresh)."""
import json
from datetime import datetime, timezone, timedelta
import common
from common import fresh_dirs, mock_http, mock_http_fail, emit, now_iso
from tools.api import sam_notice_detail as detail

NID = "a" * 32
BODY = b'{"attachments":[{"name":"SOW.txt","resourceId":"' + b"b" * 32 + b'","mimeType":"text/plain","size":5,"accessLevel":"public"}]}'
cases = {}
TTL = detail.RESOURCE_CACHE_TTL_SECONDS
MAX_STALE = detail.RESOURCE_CACHE_MAX_STALE_SECONDS

variants = {
    "received_now": now_iso(),
    "received_future_1_day": now_iso(86400),
    "received_future_5s": now_iso(5),
    "received_past_ttl_minus_60": now_iso(-(TTL - 60)),
    "received_past_ttl_plus_60": now_iso(-(TTL + 60)),
    "received_past_max_stale_minus_60": now_iso(-(MAX_STALE - 60)),
    "received_past_max_stale_plus_60": now_iso(-(MAX_STALE + 60)),
    "received_1970": "1970-01-01T00:00:00+00:00",
    "received_naive_now": now_iso().split("+")[0],
    "received_naive_ttl_plus_60": now_iso(-(TTL + 60)).split("+")[0],
    "received_non_iso": "last tuesday",
    "received_empty": "",
    "received_null": None,
    "received_epoch_int": 1757700000,
    "received_z_now": now_iso().split("+")[0] + "Z",
    "received_z_1970": "1970-01-01T00:00:00Z",
    "received_offset_plus_14_wallclock_ahead": datetime.now(timezone(timedelta(hours=14))).isoformat(),
    "received_offset_minus_12_future_instant": (datetime.now(timezone(timedelta(hours=-12))) + timedelta(hours=1)).isoformat(),
    "received_date_only": "2026-09-13",
    "received_missing_key": "MISSING",
}
for label, stamp in variants.items():
    notice, text = fresh_dirs(f"inv_clock_{label}")
    mock_http(BODY)
    first = detail.fetch_notice_resources(NID)
    cache = notice / f"{NID}.resources.json"
    saved = json.loads(cache.read_text())
    if stamp == "MISSING":
        saved["raw_capture"].pop("received_at")
    else:
        saved["raw_capture"]["received_at"] = stamp
    cache.write_text(json.dumps(saved))
    mock_http_fail()
    try:
        r = detail.fetch_notice_resources(NID)
        cases[label] = {"stamp": stamp, **common.summarize_inv(r),
                        "fresh": r.get("from_cache") is True and r.get("stale_cache") is False,
                        "stale": r.get("stale_cache") is True}
    except Exception as exc:  # noqa: BLE001
        cases[label] = {"stamp": stamp, "crashed": True, "exception": f"{type(exc).__name__}: {exc}"}

# H2 scenario: a 10-day-old inventory (beyond max stale) whose clocks are rewritten to now is served as fresh
notice, text = fresh_dirs("inv_clock_h2")
mock_http(BODY); detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text())
saved["raw_capture"]["received_at"] = now_iso(-(MAX_STALE + 3 * 86400)); saved["retrieved_at"] = saved["raw_capture"]["received_at"]
cache.write_text(json.dumps(saved))
mock_http_fail(); r_old = detail.fetch_notice_resources(NID)
saved["raw_capture"]["received_at"] = now_iso(); saved["retrieved_at"] = now_iso(); cache.write_text(json.dumps(saved))
r_forged = detail.fetch_notice_resources(NID)
cases["H2_10_day_old_inventory"] = {"before_forgery": common.summarize_inv(r_old), "after_clock_forgery": common.summarize_inv(r_forged),
                                    "kept_fresh_by_clock_rewrite": r_forged.get("from_cache") is True and r_forged.get("stale_cache") is False}
# which clock governs? retrieved_at expired but received_at fresh and vice versa
for label, (received, retrieved) in {"retrieved_expired_received_fresh": (now_iso(), now_iso(-(TTL + 60))),
                                     "retrieved_fresh_received_expired": (now_iso(-(TTL + 60)), now_iso())}.items():
    notice, text = fresh_dirs(f"inv_clock_{label}")
    mock_http(BODY); detail.fetch_notice_resources(NID)
    cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text())
    saved["raw_capture"]["received_at"] = received; saved["retrieved_at"] = retrieved; cache.write_text(json.dumps(saved))
    mock_http_fail(); r = detail.fetch_notice_resources(NID)
    cases[label] = {**common.summarize_inv(r), "fresh": r.get("from_cache") is True and r.get("stale_cache") is False}

fresh = sorted(k for k, v in cases.items() if v.get("fresh"))
stale = sorted(k for k, v in cases.items() if v.get("stale"))
crashed = sorted(k for k, v in cases.items() if v.get("crashed"))
notes = []
status = "INFO"
if crashed:
    status = "FAIL"; notes.append(f"crashes: {crashed}")
if cases.get("received_naive_now", {}).get("stale"):
    notes.append("naive received_at: rejected as FRESH by _resource_capture_valid but the stale fallback (which uses _timestamp assuming UTC) still serves it as stale_inventory")
if cases["H2_10_day_old_inventory"]["kept_fresh_by_clock_rewrite"]:
    notes.append("H2 CONFIRMED: rewriting received_at/retrieved_at keeps an expired inventory fresh forever; clocks are unauthenticated")
emit(status, {"cases": cases, "fresh": fresh, "stale": stale, "crashed": crashed, "notes": notes}, "inventory_clock_forgery")
