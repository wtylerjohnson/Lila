"""Shared harness for cache-tampering probes. Network is blocked; clocks are real unless patched."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import socket
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402


def _blocked_connect(*a, **k):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]
socket.socket.connect_ex = _blocked_connect  # type: ignore[assignment]
socket.create_connection = _blocked_connect  # type: ignore[assignment]


def fresh_dirs(name: str) -> tuple[Path, Path]:
    root = PROBE_DIR / "tmp" / name
    if root.exists():
        shutil.rmtree(root)
    notice = root / "notice"
    text = root / "text"
    notice.mkdir(parents=True)
    text.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(notice)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text)
    return notice, text


def mock_http(payload: bytes, status: int = 200):
    from tools.api import _http
    calls = []

    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=payload)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def mock_http_fail():
    from tools.api import _http
    calls = []

    def handler(request):
        calls.append(str(request.url))
        raise httpx.ConnectError("source unavailable (probe)", request=request)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def mock_download(mapping):
    from tools.api import sam_attachment_text as sat
    calls = []

    def dl(resource_id, **k):
        calls.append(resource_id)
        if isinstance(mapping, bytes):
            return mapping
        return mapping[resource_id]

    sat._download_bytes = dl
    return calls


def mock_download_fail():
    from tools.api import sam_attachment_text as sat
    calls = []

    def dl(resource_id, **k):
        calls.append(resource_id)
        raise RuntimeError("source unavailable (probe)")

    sat._download_bytes = dl
    return calls


def public_file(resource_id="b" * 32, name="SOW.txt", **extra):
    base = {"resource_id": resource_id, "name": name, "type": "text/plain",
            "source_url": None, "size": 20, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
    base.update(extra)
    return base


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def place_object(directory: Path, payload: bytes) -> dict:
    digest = sha(payload)
    (directory / "objects").mkdir(parents=True, exist_ok=True)
    (directory / "objects" / f"{digest}.bin").write_bytes(payload)
    return {"path": f"objects/{digest}.bin", "sha256": digest, "bytes": len(payload)}


def now_iso(delta_seconds: float = 0) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=delta_seconds)).isoformat()


def emit(status: str, observed: dict, name: str):
    print(json.dumps({"probe": name, "status": status, "observed": observed},
                     indent=1, sort_keys=True, default=str))


def summarize_text(result: dict) -> dict:
    return {"collection_status": result.get("collection_status"),
            "from_cache": result.get("from_cache"),
            "text": (result.get("text") or "")[:80],
            "error": (result.get("error") or "")[:120]}


def summarize_inv(result: dict) -> dict:
    return {"collection_status": result.get("collection_status"),
            "from_cache": result.get("from_cache"),
            "stale_cache": result.get("stale_cache"),
            "resources_checked": result.get("resources_checked"),
            "attachments": result.get("attachments"),
            "attachment_inventory_hash": result.get("attachment_inventory_hash"),
            "errors": [str(e)[:160] for e in (result.get("errors") or [])],
            "has_refresh_attempt": "refresh_attempt" in result}
