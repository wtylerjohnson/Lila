"""Inventory: legacy entry (no raw_capture) + refetch failure -> stale_inventory; stale fallback does not re-validate tampered attachments; run_searches exclusion and receipt content."""
import json, hashlib
import common
from common import fresh_dirs, mock_http, mock_http_fail, mock_download, emit, now_iso
from tools.api import sam_notice_detail as detail
from tools.api import sam_attachment_text as sat
import tools.api.sam_quota as sam_quota
import run_searches as searches
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

NID = "a" * 32
RID = "b" * 32
TERM = "network visibility"
cases = {}
sam_quota.calls_today = lambda: 0


def legacy_entry(attachments, retrieved_at):
    return {"id": NID, "attachments": attachments, "retrieved_at": retrieved_at, "resources_checked": True,
            "resources_schema": "recognized_v1", "errors": [], "attachment_inventory_count": len(attachments),
            "attachment_inventory_hash": detail._manifest_hash(attachments)}


def run_enrich():
    candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA", raw_payload={"type": "Solicitation"})
    class Source:
        last_attachment_census = {"selected": 1}
        def attachment_candidates(self, *a, **k): return [candidate]
    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
    return rows, stats

legacy_files = [{"name": "SOW.txt", "type": "text/plain", "resource_id": RID, "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID),
                 "size": 40, "access_level": "public", "access_status": "public", "export_controlled": "0", "explicit_access": "0"}]

# 1. legacy entry, refetch fails, within 7 days
notice, text = fresh_dirs("inv_legacy_fail")
(notice / f"{NID}.resources.json").write_text(json.dumps(legacy_entry(legacy_files, now_iso(-3600))))
mock_http_fail()
r = detail.fetch_notice_resources(NID)
cases["legacy_refetch_fail_direct"] = {**common.summarize_inv(r), "refresh_attempt_status": (r.get("refresh_attempt") or {}).get("collection_status"),
                                       "refresh_attempt_has_raw_capture": "raw_capture" in (r.get("refresh_attempt") or {})}
mock_download({RID: f"Buyer requires {TERM}.".encode()})
rows, stats = run_enrich()
receipt = stats["attachment_record_receipts"][NID]
cases["legacy_refetch_fail_run_searches"] = {"rows": len(rows), "record_status": receipt.get("status"), "files_key_present": "files" in receipt,
                                             "inventory_receipt": receipt.get("inventory_receipt"), "errors": receipt.get("errors"),
                                             "excluded_from_relevance": receipt.get("status") == "STALE_INVENTORY" and len(rows) == 0}

# 2. legacy entry, refetch fails, older than 7 days
notice, text = fresh_dirs("inv_legacy_old")
(notice / f"{NID}.resources.json").write_text(json.dumps(legacy_entry(legacy_files, now_iso(-(8 * 86400)))))
mock_http_fail(); r = detail.fetch_notice_resources(NID)
cases["legacy_older_than_7d_refetch_fail"] = common.summarize_inv(r)

# 3. legacy entry, refetch succeeds -> replaced
notice, text = fresh_dirs("inv_legacy_ok")
(notice / f"{NID}.resources.json").write_text(json.dumps(legacy_entry(legacy_files, now_iso(-3600))))
mock_http(b'{"attachments":[]}'); r = detail.fetch_notice_resources(NID)
cases["legacy_refetch_success"] = {**common.summarize_inv(r), "raw_capture_written": "raw_capture" in r}

# 4. stale fallback with tampered attachments: fresh capture, then projection tampered (invented file), refetch fails
notice, text = fresh_dirs("inv_stale_tampered")
body = json.dumps({"attachments": [{"name": "Pricing.txt", "resourceId": "c" * 32, "mimeType": "text/plain", "size": 5, "accessLevel": "public"}]}).encode()
mock_http(body); first = detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text())
saved["attachments"] = legacy_files + saved["attachments"]  # invented SOW.txt injected
saved["attachment_inventory_count"] = 2; saved["attachment_inventory_hash"] = detail._manifest_hash(saved["attachments"])
cache.write_text(json.dumps(saved))
mock_http_fail(); r = detail.fetch_notice_resources(NID)
cases["stale_fallback_tampered_projection_direct"] = {**common.summarize_inv(r),
    "tampered_attachments_served_as_stale": r.get("stale_cache") is True and any(a.get("resource_id") == RID for a in (r.get("attachments") or [])),
    "raw_still_original": (notice / first["raw_capture"]["path"]).read_bytes() == body,
    "capture_valid_says": detail._resource_capture_valid(saved)}
rows, stats = run_enrich()
receipt = stats["attachment_record_receipts"][NID]
cases["stale_fallback_tampered_run_searches"] = {"rows": len(rows), "record_status": receipt.get("status"),
    "inventory_receipt_hash_is_tampered": (receipt.get("inventory_receipt") or {}).get("attachment_inventory_hash") == saved["attachment_inventory_hash"],
    "inventory_receipt_raw_capture_is_original": (receipt.get("inventory_receipt") or {}).get("raw_capture", {}).get("sha256") == first["raw_capture"]["sha256"],
    "inventory_receipt": receipt.get("inventory_receipt"), "errors": receipt.get("errors")}

# 5. stale fallback when cached id was swapped (must not be used)
notice, text = fresh_dirs("inv_stale_idswap")
mock_http(body); first = detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text()); saved["id"] = "9" * 32; cache.write_text(json.dumps(saved))
mock_http_fail(); r = detail.fetch_notice_resources(NID)
cases["stale_fallback_after_id_swap"] = common.summarize_inv(r)

# 6. stale fallback: cached resources_checked False (unrecognized inventory retained?) is never cached, but a writer may plant one
notice, text = fresh_dirs("inv_stale_unchecked")
planted = legacy_entry(legacy_files, now_iso(-3600)); planted["resources_checked"] = False
(notice / f"{NID}.resources.json").write_text(json.dumps(planted))
mock_http_fail(); r = detail.fetch_notice_resources(NID)
cases["stale_fallback_resources_checked_false"] = common.summarize_inv(r)

# 7. refresh_attempt content on a stale return: does it carry the failed attempt raw_capture when the HTTP body was an error page?
notice, text = fresh_dirs("inv_stale_refresh_body")
mock_http(body); first = detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"; saved = json.loads(cache.read_text())
saved["raw_capture"]["received_at"] = now_iso(-(detail.RESOURCE_CACHE_TTL_SECONDS + 60)); cache.write_text(json.dumps(saved))
mock_http(b"<html>gateway timeout</html>", 504); r = detail.fetch_notice_resources(NID)
ra = r.get("refresh_attempt") or {}
cases["expired_then_504_refresh"] = {**common.summarize_inv(r), "refresh_attempt_status": ra.get("collection_status"),
                                     "refresh_attempt_http_status": (ra.get("raw_capture") or {}).get("http_status"),
                                     "refresh_attempt_raw_retained": bool((ra.get("raw_capture") or {}).get("sha256"))}

status = "PASS"
notes = []
if cases["stale_fallback_tampered_projection_direct"]["tampered_attachments_served_as_stale"]:
    notes.append("CONFIRMED: stale fallback does not call _resource_capture_valid; a tampered projection is returned as stale_inventory (excluded from relevance by run_searches, but its tampered hash lands in inventory_receipt)")
    status = "FAIL"
if not cases["legacy_refetch_fail_run_searches"]["excluded_from_relevance"]:
    status = "FAIL"; notes.append("legacy stale inventory was NOT excluded by run_searches")
if cases["stale_fallback_after_id_swap"].get("stale_cache"):
    status = "FAIL"; notes.append("id-swapped cache used as stale")
emit(status, {"cases": cases, "notes": notes}, "inventory_stale_legacy")
