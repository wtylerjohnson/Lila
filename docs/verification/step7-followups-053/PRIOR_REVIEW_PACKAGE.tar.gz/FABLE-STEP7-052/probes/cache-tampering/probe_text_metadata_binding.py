"""Text cache: per-field attachment metadata binding, cache field edits, JSON type confusion, legacy entry."""
import json, hashlib
import common
from common import fresh_dirs, mock_download, mock_download_fail, public_file, emit, sha
from tools.api import sam_attachment_text as sat

RID = "b" * 32
ORIGINAL = b"Original requirement text for binding probe."


def fresh_capture(tag):
    notice, text = fresh_dirs(f"text_meta_{tag}")
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    assert first["collection_status"] == "captured_discovery_only"
    return text, text / f"{RID}.json"

cases = {}
# A. attachment metadata changes at call time (individually)
meta_changes = {
    "name": "Changed SOW.txt", "size": 21, "type": "application/octet-stream",
    "source_url": "https://sam.gov/api/prod/opps/v3/opportunities/resources/files/" + RID + "/download",
    "access_level": "Public", "access_status": "PUBLIC ", "export_controlled": "false", "explicit_access": "no",
}
for key, value in meta_changes.items():
    text, cache = fresh_capture(f"attr_{key}")
    mock_download_fail()
    r = sat.extract_public_attachment_text(public_file(**{key: value}))
    cases[f"attachment_{key}_changed"] = {"new_value": value, **common.summarize_text(r),
                                          "cache_miss": r.get("from_cache") is False}
# A2. same size expressed as string "20" vs int 20 (inventory normalizes to int; a caller passing str misses)
text, cache = fresh_capture("attr_size_str")
mock_download_fail()
r = sat.extract_public_attachment_text(public_file(size="20"))
cases["attachment_size_as_string_20"] = {**common.summarize_text(r), "cache_miss": r.get("from_cache") is False}
# A3. extra key not in binding set (e.g. resource description) -> must still hit
text, cache = fresh_capture("attr_extra")
mock_download_fail()
r = sat.extract_public_attachment_text(public_file(description="new field"))
cases["attachment_unbound_extra_key"] = {**common.summarize_text(r), "cache_hit": r.get("from_cache") is True}

# B. cache-file field edits (attachment unchanged)
edits = {
    "collection_status_trusted": ("collection_status", "trusted_requirement"),
    "collection_status_unreadable": ("collection_status", "unreadable"),
    "authority_trusted": ("authority", "trusted"),
    "source_url_other_host": ("source_url", "https://evil.example/" + RID),
    "resource_id_other": ("resource_id", "e" * 32),
    "binding_recomputed_for_other_name": ("attachment_binding_sha256", "0" * 64),
    "name_changed_in_cache_only": ("name", "Renamed.txt"),
    "sha256_uppercase": ("sha256", None),
    "text_sha256_uppercase": ("text_sha256", None),
    "locator_end_as_string": ("text_locator", {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": str(len(ORIGINAL.decode().strip()))}),
    "locator_start_1": ("text_locator", {"surface": "extracted_text", "unit": "unicode_characters", "start": 1, "end": len(ORIGINAL.decode().strip())}),
    "locator_missing": ("text_locator", None),
    "extraction_limits_forged": ("extraction_limits", {"max_text_characters": 10**9, "max_pdf_pages": 10**6, "completeness": "full_document"}),
    "retrieved_at_missing": ("retrieved_at", None),
    "raw_capture_bytes_as_string": ("raw_capture", "STR_BYTES"),
    "raw_capture_path_traversal": ("raw_capture", "TRAVERSAL"),
    "raw_capture_sha_uppercase": ("raw_capture", "UPPER"),
    "text_capture_path_absolute": ("text_capture", "ABS"),
    "from_cache_true_in_file": ("from_cache", True),
    "text_whitespace_only_with_matching_object": ("text", "WS"),
    "text_leading_space_added": ("text", "LEAD"),
}
for label, (key, value) in edits.items():
    text, cache = fresh_capture(label)
    saved = json.loads(cache.read_text())
    if value is None and key in ("sha256", "text_sha256"):
        saved[key] = saved[key].upper()
    elif value is None:
        saved.pop(key, None)
    elif value == "STR_BYTES":
        saved[key]["bytes"] = str(saved[key]["bytes"])
    elif value == "TRAVERSAL":
        saved[key]["path"] = "../" + saved[key]["path"]
    elif value == "UPPER":
        saved[key]["sha256"] = saved[key]["sha256"].upper()
    elif value == "ABS":
        saved[key]["path"] = str(text / saved[key]["path"])
    elif value == "WS":
        ws = "   "
        saved["text"] = ws; saved["text_sha256"] = sha(ws.encode()); saved["text_capture"] = common.place_object(text, ws.encode())
        saved["text_locator"]["end"] = len(ws)
    elif value == "LEAD":
        saved["text"] = " " + saved["text"]
    else:
        saved[key] = value
    cache.write_text(json.dumps(saved))
    mock_download_fail()
    try:
        r = sat.extract_public_attachment_text(public_file())
        cases[f"cachefile_{label}"] = {**common.summarize_text(r), "accepted": r.get("from_cache") is True,
                                       "returned_field": r.get(key) if key not in ("raw_capture", "text_capture") else None}
    except Exception as exc:  # noqa: BLE001
        cases[f"cachefile_{label}"] = {"exception": f"{type(exc).__name__}: {exc}", "accepted": False, "crashed": True}

# C. legacy (base-shape) entry without raw_capture, refetch fails / succeeds
for outcome in ("fail", "succeed"):
    text, cache = fresh_capture(f"legacy_{outcome}")
    legacy = {"resource_id": RID, "name": "SOW.txt", "text": "Legacy cached requirement text",
              "sha256": sha(b"legacy"), "retrieved_at": "2026-08-01T00:00:00+00:00",
              "source_url": sat.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID), "error": ""}
    cache.write_text(json.dumps(legacy))
    if outcome == "fail":
        mock_download_fail()
    else:
        mock_download(b"Refetched text")
    r = sat.extract_public_attachment_text(public_file())
    cases[f"legacy_entry_refetch_{outcome}"] = {**common.summarize_text(r),
                                                "legacy_text_returned": r.get("text") == legacy["text"]}

accepted = sorted(k for k, v in cases.items() if v.get("accepted"))
crashed = sorted(k for k, v in cases.items() if v.get("crashed"))
misses_expected_hit = [k for k in ("attachment_unbound_extra_key",) if not cases[k].get("cache_hit")]
status = "PASS"
notes = []
if crashed:
    status = "FAIL"; notes.append("malformed cache field types crash the collector instead of missing")
if any(k.startswith("cachefile_collection_status") or k.startswith("cachefile_authority") for k in accepted):
    status = "FAIL"; notes.append("status/authority edit accepted")
if "cachefile_extraction_limits_forged" in accepted:
    notes.append("extraction_limits is not bound; forged limits are served from cache (receipt-level)")
    if status == "PASS": status = "FAIL"
if "cachefile_name_changed_in_cache_only" in accepted:
    notes.append("cached name not bound to caller name (binding covers caller metadata only)")
if cases["legacy_entry_refetch_fail"]["legacy_text_returned"]:
    status = "FAIL"; notes.append("legacy text returned after failed refetch")
emit(status, {"cases": cases, "accepted": accepted, "crashed": crashed, "notes": notes}, "text_metadata_binding")
