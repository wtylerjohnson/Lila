"""Text cache: positive control, text-only tamper, raw-only tamper, H1 coherent text rewrite, coherent raw rewrite."""
import copy, json, hashlib
from pathlib import Path
import common
from common import fresh_dirs, mock_download, mock_download_fail, public_file, sha, place_object, emit

from tools.api import sam_attachment_text as sat

RID = "b" * 32
ORIGINAL = b"Original requirement: network visibility appliance."
cases = {}


def capture(text_dir: Path):
    mock_download(ORIGINAL)
    first = sat.extract_public_attachment_text(public_file())
    assert first["collection_status"] == "captured_discovery_only", first
    return first, text_dir / f"{RID}.json"


def rerun(attachment=None):
    mock_download_fail()
    return sat.extract_public_attachment_text(attachment or public_file())


# 1. positive control
notice, text = fresh_dirs("text_h1_pos")
first, cache = capture(text)
r = rerun()
cases["positive_control_untampered_cache_reused"] = {
    **common.summarize_text(r), "reused": r.get("from_cache") is True and r["text"] == first["text"]}

# 2. text-only tamper (producer's own test)
notice, text = fresh_dirs("text_h1_textonly")
first, cache = capture(text)
saved = json.loads(cache.read_text()); saved["text"] = "Invented requirement"; cache.write_text(json.dumps(saved))
r = rerun()
cases["tamper_text_only"] = {**common.summarize_text(r), "detected": r.get("from_cache") is False and not r["text"]}

# 3. raw-only tamper (object bytes changed, receipt unchanged)
notice, text = fresh_dirs("text_h1_rawonly")
first, cache = capture(text)
saved = json.loads(cache.read_text())
(text / saved["raw_capture"]["path"]).write_bytes(b"changed raw")
r = rerun()
cases["tamper_raw_object_only"] = {**common.summarize_text(r), "detected": r.get("from_cache") is False}

# 4. H1: coherent text rewrite: new text + text_sha256 + text_capture receipt + new objects/<sha>.bin + locator
notice, text = fresh_dirs("text_h1_coherent_text")
first, cache = capture(text)
saved = json.loads(cache.read_text())
invented = "Invented requirement: the buyer needs Testco Widget Pro immediately."
saved["text"] = invented
saved["text_sha256"] = sha(invented.encode())
saved["text_capture"] = place_object(text, invented.encode())
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": len(invented)}
cache.write_text(json.dumps(saved))
r = rerun()
cases["H1_coherent_text_rewrite"] = {
    **common.summarize_text(r),
    "accepted_invented_text": r.get("from_cache") is True and r["text"] == invented,
    "raw_still_original": (text / saved["raw_capture"]["path"]).read_bytes() == ORIGINAL,
    "note": "text never re-derived from raw; raw hash and text hash verified independently"}

# 5. coherent raw rewrite: new raw bytes object + raw_capture receipt + sha256, text unchanged
notice, text = fresh_dirs("text_h1_coherent_raw")
first, cache = capture(text)
saved = json.loads(cache.read_text())
new_raw = b"%PDF-1.4 completely different bytes"
saved["raw_capture"] = place_object(text, new_raw)
saved["sha256"] = sha(new_raw)
cache.write_text(json.dumps(saved))
r = rerun()
cases["coherent_raw_rewrite_text_unchanged"] = {
    **common.summarize_text(r), "sha256_returned": r.get("sha256"),
    "accepted_with_foreign_raw": r.get("from_cache") is True and r.get("sha256") == sha(new_raw)}

# 6. coherent BOTH rewrite: raw and text replaced consistently (text derivable from raw), attacker story
notice, text = fresh_dirs("text_h1_coherent_both")
first, cache = capture(text)
saved = json.loads(cache.read_text())
new_raw = invented.encode()
saved["raw_capture"] = place_object(text, new_raw); saved["sha256"] = sha(new_raw)
saved["text"] = invented; saved["text_sha256"] = sha(new_raw); saved["text_capture"] = place_object(text, new_raw)
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": len(invented)}
cache.write_text(json.dumps(saved))
r = rerun()
cases["coherent_raw_and_text_rewrite"] = {**common.summarize_text(r),
                                          "accepted": r.get("from_cache") is True and r["text"] == invented}

# 7. text_sha256 rewritten but text_capture object NOT replaced -> must be detected
notice, text = fresh_dirs("text_h1_sha_only")
first, cache = capture(text)
saved = json.loads(cache.read_text())
saved["text"] = invented; saved["text_sha256"] = sha(invented.encode())
saved["text_locator"]["end"] = len(invented)
cache.write_text(json.dumps(saved))
r = rerun()
cases["text_and_sha_rewritten_without_new_object"] = {**common.summarize_text(r), "detected": r.get("from_cache") is False}

accepted = [k for k, v in cases.items() if v.get("accepted_invented_text") or v.get("accepted_with_foreign_raw") or v.get("accepted")]
status = "FAIL" if cases["H1_coherent_text_rewrite"]["accepted_invented_text"] else "PASS"
emit(status, {"cases": cases, "accepted_tampers": accepted,
              "verdict": "H1 CONFIRMED: coherent rewrite of text+text_sha256+objects/<sha>.bin is served from_cache with raw untouched" if status == "FAIL" else "H1 refuted"},
     "text_h1_coherent_rewrite")
