"""Observer exceptions: masking of the original error and end-to-end effect via fetch_notice_resources."""
import json
import os
import tempfile
import _probe_common as pc
import httpx
from tools.api import _http

out = {}
checks = []
body = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32}]}).encode()


def boom(resp, raw, complete):
    raise OSError(13, "retention failed (simulated read-only cache)")


def go(name, handler, retries=3, cap=10 * 1024 * 1024, observer=boom):
    ft = pc.FakeTime(); _http.time = ft
    seen = pc.install_client(_http, handler)
    res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=retries, max_response_bytes=cap, response_observer=observer)
    out[name] = {"attempts": len(seen), "sleeps": ft.sleeps, "result": res}
    return out[name]


# i) cap exceeded (ValueError) then observer raises OSError: OSError propagates, ValueError only in __context__
o = go("cap_then_observer_raises", lambda req: httpx.Response(200, content=b"x" * 100), cap=10)
checks.append(("observer_masks_cap_valueerror", o["result"]["type"] in ("OSError", "PermissionError") and o["result"]["context"] == "ValueError" and o["attempts"] == 1))
# ii) success path, observer raises: payload lost, no retry
o = go("success_then_observer_raises", lambda req: httpx.Response(200, content=body))
checks.append(("observer_failure_discards_good_payload_no_retry", o["result"]["type"] in ("OSError", "PermissionError") and o["result"]["context"] is None and o["attempts"] == 1 and o["sleeps"] == []))
# iii) mid-stream ReadError (retryable) then observer raises: retry suppressed
def midstream(req):
    return httpx.Response(200, stream=pc.ChunkStream([b"x" * 70000], raise_after=1))
o = go("readerror_then_observer_raises", midstream)
checks.append(("observer_masks_retryable_transport_error", o["result"]["type"] in ("OSError", "PermissionError") and o["result"]["context"] == "ReadError" and o["attempts"] == 1))
# iv) 503 then observer raises: retryable status never reached (observer runs first in finally)
o = go("503_then_observer_raises", lambda req: httpx.Response(503, content=b"busy"))
checks.append(("observer_raise_preempts_503_retry", o["result"]["type"] in ("OSError", "PermissionError") and o["attempts"] == 1))
# v) non-stream path (dead in prod): observer raise also propagates, no retry
ft = pc.FakeTime(); _http.time = ft
seen = pc.install_client(_http, lambda req: httpx.Response(200, content=body))
res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=3, response_observer=boom)
out["nonstream_observer_raises"] = {"attempts": len(seen), "result": res}
checks.append(("nonstream_observer_raise_propagates", res["type"] in ("OSError", "PermissionError") and len(seen) == 1))

# vi) END TO END: real fetch_notice_resources with a good 200 inventory but retain_bytes failing
from tools.api import sam_notice_detail as detail, sam_capture
tmp = tempfile.mkdtemp(prefix="cap-seam-", dir=os.path.dirname(os.path.abspath(__file__)))
os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
_http.time = pc.FakeTime()
pc.install_client(_http, lambda req: httpx.Response(200, headers={"content-type": "application/hal+json"}, content=body))
orig = sam_capture.retain_bytes
sam_capture.retain_bytes = lambda d, p: (_ for _ in ()).throw(OSError(13, "Permission denied: objects/"))
try:
    r = detail.fetch_notice_resources("a" * 32)
finally:
    sam_capture.retain_bytes = orig
out["e2e_retention_failure_good_inventory"] = {
    "collection_status": r.get("collection_status"), "resources_checked": r.get("resources_checked"),
    "attachments": r.get("attachments"), "errors": r.get("errors"), "has_raw_capture": "raw_capture" in r,
    "cache_written": os.path.exists(os.path.join(tmp, "a" * 32 + ".resources.json"))}
checks.append(("e2e_good_inventory_becomes_lookup_failed_on_retention_error",
               r.get("collection_status") == "lookup_failed" and r.get("attachments") is None and "raw_capture" not in r))
# vii) same but a stale prior inventory exists: stale path taken, refresh_attempt has no raw_capture
import shutil
shutil.rmtree(tmp, ignore_errors=True)

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL",
        {"checks": checks, "failed": failed, "scenarios": out,
         "finding": "an exception inside the observer (raised in the finally block) replaces whatever the capture loop raised; "
                    "the original boundary/transport error survives only as __context__, retry classification is lost, and on the "
                    "success path a fully received good inventory is discarded (end to end: lookup_failed with attachments None)"},
        "observer_exception")
