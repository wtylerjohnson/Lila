"""Cross-check with a custom httpx.BaseTransport (not MockTransport) that yields controlled raw chunks."""
import json
import _probe_common as pc
import httpx
from tools.api import _http

K = 65536
out = {}
checks = []


class ChunkTransport(httpx.BaseTransport):
    def __init__(self, chunks, status=200, headers=None, raise_after=None):
        self.chunks, self.status, self.headers, self.raise_after = chunks, status, headers or {}, raise_after
        self.requests = []

    def handle_request(self, request):
        self.requests.append(request)
        return httpx.Response(self.status, headers=self.headers, stream=pc.ChunkStream(self.chunks, raise_after=self.raise_after), request=request)


def go(name, transport, cap, retries=1):
    obs = []
    _http.time = pc.FakeTime()
    _http._client = lambda timeout: httpx.Client(transport=transport, timeout=timeout, follow_redirects=True)
    r = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=retries, max_response_bytes=cap,
               response_observer=lambda resp, b, c: obs.append((resp.status_code, len(b), c)))
    out[name] = {"attempts": len(transport.requests), "result": r, "observer_calls": obs}
    return out[name]


doc = b'"' + b"x" * (3 * K + 500 - 2) + b'"'   # 3 blocks + 500 bytes, valid JSON string
# straddle: cap sits inside the 4th (final) chunker block
o = go("straddle_cap_in_final_block", ChunkTransport([doc[:1000], doc[1000:K + 7], doc[K + 7:]]), cap=3 * K + 100)
checks.append(("straddle_partial_exact_cap", o["result"]["type"] == "ValueError" and o["observer_calls"] == [(200, 3 * K + 100, False)]))
# exact fit
o = go("exact_fit", ChunkTransport([doc[:1000], doc[1000:]]), cap=len(doc))
checks.append(("exact_fit_complete_json_ok", o["result"]["outcome"] == "ok" and o["observer_calls"] == [(200, len(doc), True)]))
# raise mid-stream after one raw chunk of 70000: observer sees 65536 (one block), ReadError retried once then fails
t = ChunkTransport([b"x" * 70000, b"y" * 10], raise_after=1)
o = go("midstream_raise_retries2", t, cap=10 * K, retries=2)
checks.append(("midstream_partial_block_then_retry", o["attempts"] == 2 and o["observer_calls"] == [(200, K, False), (200, K, False)] and o["result"]["type"] == "ReadError"))
# custom transport 503 with body under cap: HTTPStatusError with body carried
o = go("503_body", ChunkTransport([b'{"status":"maintenance"}'], status=503), cap=1000)
checks.append(("503_body_carried", o["result"]["type"] == "HTTPStatusError" and "maintenance" in o["result"]["message"] and o["observer_calls"] == [(503, 24, True)]))
failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL", {"checks": checks, "failed": failed, "scenarios": out}, "custom_transport")
