"""Which production callers pass response_observer / max_response_bytes; confirm the non-stream observer path is dead."""
import ast
import os
import json
import tempfile
import shutil
import _probe_common as pc
import httpx
from tools.api import _http

REPO = pc.REPO
out = {"observer_callers": [], "cap_only_callers": [], "observer_without_cap": [], "scanned_files": 0}
for root, dirs, files in os.walk(REPO):
    dirs[:] = [d for d in dirs if d not in (".venv", ".git", "node_modules", "__pycache__", "data")]
    for f in files:
        if not f.endswith(".py"):
            continue
        path = os.path.join(root, f)
        try:
            tree = ast.parse(open(path, encoding="utf-8").read())
        except (SyntaxError, UnicodeDecodeError):
            continue
        out["scanned_files"] += 1
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                kws = {k.arg for k in node.keywords if k.arg}
                if "response_observer" in kws or "max_response_bytes" in kws:
                    rel = os.path.relpath(path, REPO)
                    rec = {"file": rel, "line": node.lineno, "kwargs": sorted(kws & {"response_observer", "max_response_bytes", "retries"})}
                    if "response_observer" in kws and "max_response_bytes" in kws:
                        out["observer_callers"].append(rec)
                    elif "max_response_bytes" in kws:
                        out["cap_only_callers"].append(rec)
                    else:
                        out["observer_without_cap"].append(rec)
prod_obs = [c for c in out["observer_callers"] if not c["file"].startswith("tests/")]
prod_obs_nocap = [c for c in out["observer_without_cap"] if not c["file"].startswith("tests/")]

# dynamic: record kwargs reaching _request during fetch_notice_resources and fetch_notice_depth's keyless resources leg
from tools.api import sam_notice_detail as detail
recorded = []
real = _http._request
def recorder(method, url, **kw):
    recorded.append({"url": url, "has_observer": kw.get("response_observer") is not None, "cap": kw.get("max_response_bytes"), "retries": kw.get("retries")})
    return real(method, url, **kw)
_http._request = recorder
tmp = tempfile.mkdtemp(prefix="cap-seam-callers-", dir=os.path.dirname(os.path.abspath(__file__)))
os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
_http.time = pc.FakeTime()
pc.install_client(_http, lambda req: httpx.Response(200, content=b'{"attachments": []}'))
r1 = detail.fetch_notice_resources("a" * 32)
# get_json is imported by name into sam_notice_detail, so patch it there too for the depth path
import tools.api.sam_quota as sq
sq.calls_today = lambda: 0
detail.get_json = lambda url, **kw: recorder("GET", url, **kw)
try:
    r2 = pc.run(detail.fetch_notice_depth, "b" * 32, None)
except Exception as exc:  # noqa: BLE001
    r2 = {"exc": repr(exc)}
_http._request = real
shutil.rmtree(tmp, ignore_errors=True)
out["dynamic_calls"] = recorded
out["fetch_notice_resources_status"] = r1.get("collection_status")
out["fetch_notice_depth_result_kind"] = r2.get("outcome") if isinstance(r2, dict) else None
checks = [
    ("exactly_one_production_observer_caller", len(prod_obs) == 1 and prod_obs[0]["file"] == "tools/api/sam_notice_detail.py"),
    ("no_production_caller_passes_observer_without_cap", prod_obs_nocap == []),
    ("dynamic_resources_call_has_observer_and_cap", any(c["has_observer"] and c["cap"] == 2 * 1024 * 1024 and c["retries"] == 1 for c in recorded)),
    ("dynamic_depth_keyless_leg_has_no_observer", all(not c["has_observer"] for c in recorded if "/resources" in c["url"] and c["cap"] is None)),
]
failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL", {"checks": checks, "failed": failed, **out,
        "note": "fetch_notice_depth's keyless resources leg (two sites) calls get_json WITHOUT observer/cap: those inventories are neither captured nor byte-bounded; only fetch_notice_resources uses the seam"},
        "production_callers")
