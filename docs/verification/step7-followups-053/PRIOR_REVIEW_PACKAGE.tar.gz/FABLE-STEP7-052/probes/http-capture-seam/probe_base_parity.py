"""REGRESSION: with max_response_bytes None and no observer, candidate _request must match base 2d522f0 exactly.
Also: every other function in _http.py is source-identical to base; MockTransport matrix diffed on
result/exception/attempt count/sleep calls/requests seen; explicit None kwargs; get_json/post_json wrappers."""
import inspect
import json
import subprocess
import _probe_common as pc
import httpx
from tools.api import _http

base = pc.load_base_http()
out = {}
checks = []
body = json.dumps({"attachments": [{"name": "SOW.pdf"}]}).encode()

# A. source identity of everything except _request
cand_src = open("/Users/wtjohnson/lila-step7-052/tools/api/_http.py").read()
base_src = subprocess.run(["git", "-C", pc.REPO, "show", "2d522f0:tools/api/_http.py"], capture_output=True, text=True, check=True).stdout
def strip_request(src):
    lines = src.splitlines()
    keep, skip = [], False
    for ln in lines:
        if ln.startswith("def _request("):
            skip = True
        elif skip and ln.startswith("def "):
            skip = False
        if not skip:
            keep.append(ln)
    return "\n".join(keep)
same_rest = strip_request(cand_src) == strip_request(base_src)
out["non_request_source_identical"] = same_rest
checks.append(("everything_but__request_identical", same_rest))
sig_b = str(inspect.signature(base._request)); sig_c = str(inspect.signature(_http._request))
out["signatures"] = {"base": sig_b, "cand": sig_c}
checks.append(("new_params_are_keyword_only_with_None_defaults", sig_c.replace(", response_observer=None, max_response_bytes: 'int | None' = None", "") == sig_b))

# B. behavior matrix
def matrix_case(name, handler_factory, method="GET", **kw):
    rows = {}
    for label, mod, extra in (("base", base, {}), ("cand", _http, {}), ("cand_explicit_none", _http, {"response_observer": None, "max_response_bytes": None})):
        ft = pc.FakeTime(); mod.time = ft
        seen = pc.install_client(mod, handler_factory())
        r = pc.run(mod._request, method, "https://mock.invalid/r", **extra, **kw)
        rows[label] = {"result": r, "attempts": len(seen), "sleeps": ft.sleeps, "monotonic_calls": ft.calls,
                       "seen": [(q.method, str(q.url), q.content.decode("latin-1"), sorted(q.headers.multi_items())) for q in seen]}
    identical = rows["base"] == rows["cand"] == rows["cand_explicit_none"]
    out[name] = {"identical": identical, "base": rows["base"], "cand": rows["cand"] if not identical else "same", "cand_explicit_none": rows["cand_explicit_none"] if not identical else "same"}
    checks.append((f"parity:{name}", identical))

def seq(*responses):
    def factory():
        st = {"i": 0}
        def h(req):
            r = responses[min(st["i"], len(responses) - 1)]
            st["i"] += 1
            if isinstance(r, Exception):
                raise r
            return r(req) if callable(r) else r
        return h
    return factory

R = lambda *a, **k: (lambda req: httpx.Response(*a, **k))  # noqa: E731
matrix_case("200_json", seq(R(200, content=body)))
matrix_case("200_json_hal", seq(R(200, headers={"content-type": "application/hal+json"}, content=body)))
matrix_case("200_non_json", seq(R(200, content=b"<html>")))
matrix_case("200_empty", seq(R(200)))
matrix_case("204", seq(R(204)))
matrix_case("404_body", seq(R(404, content=b"gone")))
matrix_case("403_empty", seq(R(403)))
matrix_case("429_body_x3", seq(R(429, content=b'{"msg":"cap"}')))
matrix_case("503_then_200", seq(R(503, content=b"busy"), R(200, content=body)))
matrix_case("500_502_504_then_200", seq(R(500), R(502), R(504), R(200, content=body)))  # exhausts at 3
matrix_case("connect_error_x3", seq(httpx.ConnectError("nope")))
matrix_case("read_timeout_then_200", seq(httpx.ReadTimeout("slow"), R(200, content=body)))
matrix_case("readerror_midbody_then_200", seq(lambda req: httpx.Response(200, stream=pc.ChunkStream([b"x" * 10], raise_after=1)), R(200, content=body)))
matrix_case("gzip_stream_200", seq(lambda req: httpx.Response(200, headers={"content-encoding": "gzip"}, stream=pc.ChunkStream([__import__("gzip").compress(body)]))))
matrix_case("corrupt_gzip_stream", seq(lambda req: httpx.Response(200, headers={"content-encoding": "gzip"}, stream=pc.ChunkStream([b"not gzip at all"]))))
matrix_case("redirect_then_200", seq(lambda req: httpx.Response(302, headers={"location": "https://mock.invalid/x"}) if req.url.path == "/r" else httpx.Response(200, content=body)))
matrix_case("HEAD", seq(R(200)), method="HEAD")
matrix_case("POST_json_headers", seq(lambda req: httpx.Response(200, content=req.content)), method="POST", json={"a": 1}, headers={"X-K": "v", "Content-Type": "application/json"})
matrix_case("params", seq(lambda req: httpx.Response(200, content=json.dumps({"u": str(req.url)}).encode())), params={"q": "z"})
matrix_case("retries_1_503", seq(R(503, content=b"busy")), retries=1)
matrix_case("retries_0", seq(R(200, content=body)), retries=0)   # assert path: last_exc None -> AssertionError on both
matrix_case("timeout_kw", seq(R(200, content=body)), timeout=3.0)
matrix_case("big_body_3MiB_default_path_unbounded", seq(R(200, content=b'"' + b"x" * (3 * 1024 * 1024) + b'"')))
matrix_case("large_429_body_truncated_message", seq(R(429, content=b"y" * 1000)))
matrix_case("utf16_json", seq(R(200, content=json.dumps({"k": "v"}).encode("utf-16"))))

# C. wrappers
for label, mod in (("base", base), ("cand", _http)):
    ft = pc.FakeTime(); mod.time = ft
    seen = pc.install_client(mod, lambda req: httpx.Response(200, content=req.content or body))
    g = pc.run(mod.get_json, "https://mock.invalid/r", params={"a": "b"}, retries=2)
    p = pc.run(mod.post_json, "https://mock.invalid/r", json={"z": 9})
    out[f"wrappers_{label}"] = {"get": g, "post": p, "seen": [(q.method, str(q.url), q.content.decode(), q.headers.get("content-type")) for q in seen]}
checks.append(("wrappers_identical", out["wrappers_base"] == out["wrappers_cand"]))

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL", {"checks": checks, "failed": failed, "cases": out}, "base_parity")
