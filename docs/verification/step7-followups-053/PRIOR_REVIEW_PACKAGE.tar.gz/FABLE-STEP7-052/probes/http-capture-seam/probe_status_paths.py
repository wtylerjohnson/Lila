"""4xx/5xx/429 retry paths, non-JSON 200, HEAD/POST/params on the streaming path vs base."""
import json
import _probe_common as pc
import httpx
from tools.api import _http

base = pc.load_base_http()
out = {}
checks = []
body = json.dumps({"ok": True}).encode()


def both(name, handler, method="GET", cap=10 * 1024 * 1024, retries=3, **kw):
    res = {}
    for label, mod, extra in (("base", base, {}), ("cand_stream", _http, {"max_response_bytes": cap}),
                              ("cand_default", _http, {})):
        ft = pc.FakeTime(); mod.time = ft
        seen = pc.install_client(mod, handler)
        obs = []
        if label == "cand_stream":
            extra["response_observer"] = lambda r, b, c: obs.append((r.status_code, len(b), c))
        r = pc.run(mod._request, method, "https://mock.invalid/r?x=1", retries=retries, **extra, **kw)
        rec = {"attempts": len(seen), "sleeps": ft.sleeps, "result": r,
               "seen": [(q.method, str(q.url), q.content.decode("latin-1")[:60], dict((k, v) for k, v in q.headers.items() if k in ("content-type", "x-probe"))) for q in seen]}
        if obs:
            rec["observer_calls"] = obs
        res[label] = rec
    out[name] = res
    same = res["base"]["result"] == res["cand_default"]["result"] and res["base"]["attempts"] == res["cand_default"]["attempts"] and res["base"]["sleeps"] == res["cand_default"]["sleeps"]
    stream_same = (res["base"]["result"] == res["cand_stream"]["result"] and res["base"]["attempts"] == res["cand_stream"]["attempts"]
                   and res["base"]["sleeps"] == res["cand_stream"]["sleeps"] and res["base"]["seen"] == res["cand_stream"]["seen"])
    res["default_matches_base"] = same
    res["stream_matches_base"] = stream_same
    return res


# 429 with body: retried 3x, body carried into the message
r = both("429_with_body", lambda req: httpx.Response(429, content=b'{"error":"daily cap reached"}', headers={"content-type": "application/json"}))
checks.append(("429_stream_matches_base", r["stream_matches_base"] and r["default_matches_base"]
               and "daily cap reached" in r["cand_stream"]["result"]["message"] and r["cand_stream"]["attempts"] == 3
               and r["cand_stream"]["observer_calls"] == [(429, 29, True)] * 3))
# 404 body: no retry, body in message
r = both("404_with_body", lambda req: httpx.Response(404, content=b"not here"))
checks.append(("404_stream_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["attempts"] == 1))
# 403 empty body message
r = both("403_empty", lambda req: httpx.Response(403))
checks.append(("403_empty_matches_base", r["stream_matches_base"] and r["default_matches_base"] and "(empty body)" in r["cand_stream"]["result"]["message"]))
# 503 then 200
st = {"i": 0}
def h503(req):
    st["i"] += 1
    return httpx.Response(503, content=b"busy") if st["i"] % 2 == 1 else httpx.Response(200, content=body)
r = both("503_then_200", h503)
checks.append(("503_then_200_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["result"]["outcome"] == "ok"))
# 200 non-JSON
r = both("200_non_json", lambda req: httpx.Response(200, content=b"<html>maintenance</html>", headers={"content-type": "text/html"}))
checks.append(("200_non_json_matches_base_observer_complete", r["stream_matches_base"] and r["default_matches_base"]
               and r["cand_stream"]["result"]["type"] == "JSONDecodeError" and r["cand_stream"]["observer_calls"] == [(200, 24, True)]))
# 200 empty body
r = both("200_empty", lambda req: httpx.Response(200))
checks.append(("200_empty_matches_base", r["stream_matches_base"] and r["default_matches_base"]))
# HEAD
r = both("HEAD", lambda req: httpx.Response(200, headers={"content-length": "999"}), method="HEAD")
checks.append(("HEAD_matches_base", r["stream_matches_base"] and r["default_matches_base"]))
# POST json echo (via c.stream with json=)
r = both("POST_json_echo", lambda req: httpx.Response(200, content=req.content), method="POST", json={"q": "abc"}, headers={"X-Probe": "1"})
checks.append(("POST_json_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["result"]["result"] == {"q": "abc"}))
# params merged with query in URL
r = both("params_merge", lambda req: httpx.Response(200, content=json.dumps({"url": str(req.url)}).encode()), params={"y": "2"})
checks.append(("params_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["result"]["result"]["url"].endswith("y=2")))
# redirect followed on both paths
def redir(req):
    if req.url.path == "/r":
        return httpx.Response(302, headers={"location": "https://mock.invalid/final"})
    return httpx.Response(200, content=body)
r = both("redirect", redir)
checks.append(("redirect_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["result"]["outcome"] == "ok"))
# retries=1 with 503: single attempt, raises HTTPStatusError
r = both("503_retries1", lambda req: httpx.Response(503, content=b"busy"), retries=1)
checks.append(("503_retries1_matches_base", r["stream_matches_base"] and r["default_matches_base"] and r["cand_stream"]["attempts"] == 1))
# 429 body larger than cap on the stream path: divergence from base (ValueError, no retry)
r = both("429_body_over_cap", lambda req: httpx.Response(429, content=b"z" * 64), cap=16)
checks.append(("429_over_cap_diverges_to_valueerror", (not r["stream_matches_base"]) and r["cand_stream"]["result"]["type"] == "ValueError"
               and r["cand_stream"]["attempts"] == 1 and r["base"]["attempts"] == 3 and r["default_matches_base"]))

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL",
        {"checks": checks, "failed": failed, "scenarios": out,
         "measured_limits": ["a 4xx/5xx whose body exceeds max_response_bytes surfaces as ValueError('byte boundary'), not HTTPStatusError; the retryable status is not retried and the error body is not carried (edge: 2 MiB cap in production)"]},
        "status_paths")
