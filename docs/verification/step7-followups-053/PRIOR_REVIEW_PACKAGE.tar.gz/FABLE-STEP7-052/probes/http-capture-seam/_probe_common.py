"""Shared helpers for the HTTP capture seam probes. Never touches the network."""
import json
import os
import socket
import subprocess
import sys
import types

sys.dont_write_bytecode = True
REPO = "/Users/wtjohnson/lila-step7-052"
BASE_SHA = "2d522f0"
if REPO not in sys.path:
    sys.path.insert(0, REPO)


def _no_connect(*a, **k):
    raise RuntimeError("probe attempted a real socket connect; forbidden")


socket.socket.connect = _no_connect  # belt and braces: no live network ever
socket.create_connection = _no_connect

import httpx  # noqa: E402
from tools.api import _http as cand  # noqa: E402


def load_base_http():
    """Import the BASE _http.py (2d522f0) in memory from git show; nothing written."""
    src = subprocess.run(["git", "-C", REPO, "show", f"{BASE_SHA}:tools/api/_http.py"],
                         check=True, capture_output=True, text=True).stdout
    mod = types.ModuleType("base_http_2d522f0")
    exec(compile(src, "<git 2d522f0:tools/api/_http.py>", "exec"), mod.__dict__)
    return mod


class FakeTime:
    """Deterministic clock for _http.time: monotonic() pops a scripted sequence."""
    def __init__(self, seq=None, sleep_log=None):
        self.seq = list(seq or [])
        self.calls = 0
        self.sleeps = sleep_log if sleep_log is not None else []
        self.last = 0.0

    def monotonic(self):
        self.calls += 1
        if self.seq:
            self.last = self.seq.pop(0)
        return self.last

    def sleep(self, s):
        self.sleeps.append(s)

    def time(self):
        return 0.0


class ChunkStream(httpx.SyncByteStream):
    """Yields controlled raw chunks; optionally raises after N chunks."""
    def __init__(self, chunks, raise_after=None, exc=None):
        self.chunks = list(chunks)
        self.raise_after = raise_after
        self.exc = exc or httpx.ReadError("simulated read error mid-stream")

    def __iter__(self):
        for i, c in enumerate(self.chunks):
            if self.raise_after is not None and i == self.raise_after:
                raise self.exc
            yield c
        if self.raise_after is not None and self.raise_after >= len(self.chunks):
            raise self.exc


def install_client(mod, handler):
    """Bind MockTransport into module.mod._client. Returns list of requests seen."""
    seen = []

    def _handler(request):
        seen.append(request)
        return handler(request)

    mod._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(_handler),
                                               follow_redirects=True, timeout=timeout)
    return seen


def run(fn, *a, **k):
    """Call fn; return ('ok', result) or ('exc', type name, str)."""
    try:
        return {"outcome": "ok", "result": fn(*a, **k)}
    except BaseException as exc:  # noqa: BLE001
        return {"outcome": "exc", "type": type(exc).__name__,
                "module": type(exc).__module__, "message": str(exc),
                "context": type(exc.__context__).__name__ if exc.__context__ else None,
                "cause": type(exc.__cause__).__name__ if exc.__cause__ else None}


def _clean(o):
    if isinstance(o, str):
        return o.replace("\u2014", "-").replace("\u2013", "-")
    if isinstance(o, dict):
        return {_clean(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (bytes, bytearray)):
        return {"bytes_len": len(o), "head": o[:24].decode("latin-1")}
    return o


def emit(status, observed, name):
    print(json.dumps(_clean({"probe": name, "status": status, "observed": observed}),
                     indent=1, sort_keys=True, ensure_ascii=True))
