"""Time boundary on the streaming path with a scripted monotonic clock."""
import json
import _probe_common as pc
import httpx
from tools.api import _http

K = 65536
out = {}
checks = []


def scenario(name, chunks, seq, timeout=30.0, retries=3, status=200):
    observed = []
    ft = pc.FakeTime(seq)
    _http.time = ft
    seen = pc.install_client(_http, lambda req: httpx.Response(status, stream=pc.ChunkStream(chunks)))
    res = pc.run(_http._request, "GET", "https://mock.invalid/r", timeout=timeout, retries=retries,
                 max_response_bytes=10 * 1024 * 1024,
                 response_observer=lambda r, b, c: observed.append((r.status_code, len(b), c)))
    o = {"clock_seq": seq, "monotonic_calls": ft.calls, "attempts": len(seen), "sleeps": ft.sleeps,
         "result": res, "observer_calls": observed}
    out[name] = o
    return o


body = json.dumps({"attachments": []}).encode()
# a) single chunk arriving exactly at stop: 30.0 > 30.0 is False -> complete
o = scenario("exactly_at_stop", [body], [0.0, 30.0])
checks.append(("exactly_at_stop_complete", o["result"]["outcome"] == "ok" and o["observer_calls"] == [(200, len(body), True)]))
# b) single chunk, clock just past stop: whole body received yet reported complete=False and TimeoutError
o = scenario("past_stop_after_full_body", [body], [0.0, 30.0001])
checks.append(("past_stop_full_body_reported_incomplete", o["result"]["type"] == "TimeoutError"
               and o["observer_calls"] == [(200, len(body), False)] and o["attempts"] == 1 and o["sleeps"] == []))
# c) multi block: 3 chunker blocks (64 KiB each), clock passes stop at block 3
three = b"[" + b"1," * ((3 * K - 2) // 2) + b"]"
assert len(three) == 3 * K
o = scenario("past_stop_at_third_block", [three], [0.0, 1.0, 2.0, 31.0])
checks.append(("partial_two_blocks_then_timeout", o["result"]["type"] == "TimeoutError" and o["observer_calls"] == [(200, 3 * K, False)]))
# d) empty body with clock far past stop: no chunk, so no time check -> complete True
o = scenario("empty_body_far_past_stop", [b""], [0.0, 999.0])
checks.append(("empty_body_skips_time_check", o["observer_calls"] == [(200, 0, True)] and o["result"]["type"] == "JSONDecodeError"))
# e) TimeoutError is not in the retry except: no retry even with retries=3
checks.append(("timeout_not_retried", out["past_stop_after_full_body"]["attempts"] == 1))
# f) the stop clock is armed before the connection opens (first monotonic call precedes c.stream)
checks.append(("stop_armed_before_stream", out["exactly_at_stop"]["monotonic_calls"] == 2))
# g) a 5xx that arrives past the stop becomes TimeoutError (not the retryable status)
o = scenario("503_past_stop", [b"busy"], [0.0, 31.0], status=503)
checks.append(("503_past_stop_is_timeouterror_not_retried", o["result"]["type"] == "TimeoutError" and o["attempts"] == 1))
# h) base-vs-candidate: base module has no time boundary; the candidate default path has none either
base = pc.load_base_http()
ftb = pc.FakeTime([0.0, 999.0]); base.time = ftb
pc.install_client(base, lambda req: httpx.Response(200, content=body))
rb = pc.run(base._request, "GET", "https://mock.invalid/r", timeout=30.0)
ftc = pc.FakeTime([0.0, 999.0]); _http.time = ftc
pc.install_client(_http, lambda req: httpx.Response(200, content=body))
rc = pc.run(_http._request, "GET", "https://mock.invalid/r", timeout=30.0)
out["default_path_ignores_clock"] = {"base": rb, "cand": rc, "base_monotonic_calls": ftb.calls, "cand_monotonic_calls": ftc.calls}
checks.append(("default_path_no_clock_reads", ftb.calls == 0 and ftc.calls == 0 and rb == rc))

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL",
        {"checks": checks, "failed": failed, "scenarios": out,
         "measured_limits": [
             "time check runs only after a decoded 64 KiB block (or the final flush) arrives; a fully received body whose last block lands after stop is reported complete=False with TimeoutError",
             "an empty body never runs the time check",
             "TimeoutError/ValueError from the capture boundaries are not retried (not in the except tuple); with retries=1 in the only production caller this is moot"]},
        "time_boundary")
