"""Observer call count/arguments per attempt on the streaming path; partial bytes mid-stream."""
import json
import _probe_common as pc
import httpx
from tools.api import _http

K = 65536
out = {}
checks = []
body = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32}]}).encode()


def run_seq(name, responses, retries=3, cap=10 * 1024 * 1024, probe_response=False):
    """responses: list of callables(request)->Response, consumed per attempt (last repeats)."""
    calls = []
    ft = pc.FakeTime()
    _http.time = ft
    idx = {"i": 0}

    def handler(req):
        r = responses[min(idx["i"], len(responses) - 1)](req)
        idx["i"] += 1
        return r

    seen = pc.install_client(_http, handler)

    def observer(resp, raw, complete):
        rec = {"status": resp.status_code, "len": len(raw), "complete": complete,
               "type": type(resp).__name__}
        if probe_response:
            rec["content_access"] = pc.run(lambda: resp.content)
            rec["text_access"] = pc.run(lambda: resp.text)
            rec["headers_present"] = bool(resp.headers)
            rec["url"] = str(resp.url)
        calls.append(rec)

    res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=retries,
                 max_response_bytes=cap, response_observer=observer)
    o = {"attempts": len(seen), "sleeps": ft.sleeps, "result": res, "observer_calls": calls}
    out[name] = o
    return o


ok200 = lambda req: httpx.Response(200, content=body)  # noqa: E731
busy503 = lambda req: httpx.Response(503, content=b"busy")  # noqa: E731

# 1 503 then 200: observer once per attempt (2), caller keeping the LAST sees the 200
o = run_seq("503_then_200", [busy503, ok200])
checks.append(("503_then_200_two_observer_calls_last_is_200", o["attempts"] == 2 and o["sleeps"] == [0.5]
               and [c["status"] for c in o["observer_calls"]] == [503, 200] and o["result"]["outcome"] == "ok"))
# 2 503 x3 exhausted: three observer calls all complete=True, last kept is a 503
o = run_seq("503_x3", [busy503])
checks.append(("503_x3_three_calls_complete_true", o["attempts"] == 3 and o["sleeps"] == [0.5, 1.0]
               and [(c["status"], c["complete"]) for c in o["observer_calls"]] == [(503, True)] * 3
               and o["result"]["type"] == "HTTPStatusError"))
# 3 connect error on every attempt: observer NEVER called (stream never opened)
def connerr(req):
    raise httpx.ConnectError("simulated connect failure")
o = run_seq("connect_error_x3", [connerr])
checks.append(("connect_error_zero_observer_calls_retried", o["attempts"] == 3 and o["observer_calls"] == [] and o["result"]["type"] == "ConnectError"))
# 4 mid-stream ReadError after two full 64 KiB blocks + 100 bytes then 200: observer gets partial (complete False) then full
big = b'"' + b"x" * (2 * K + 100 - 2) + b'"'
def midstream(req):
    return httpx.Response(200, stream=pc.ChunkStream([big[:K], big[K:2 * K], big[2 * K:]], raise_after=2))
o = run_seq("readerror_midstream_then_200", [midstream, lambda req: httpx.Response(200, content=big)])
checks.append(("midstream_partial_then_retry_full", o["attempts"] == 2 and o["sleeps"] == [0.5]
               and [(c["len"], c["complete"]) for c in o["observer_calls"]] == [(2 * K, False), (2 * K + 100, True)]
               and o["result"]["outcome"] == "ok"))
# 5 chunker truncation: server sent 60000 bytes then died -> observer sees 0 bytes (buffer below one 64 KiB block lost)
def small_then_die(req):
    return httpx.Response(200, stream=pc.ChunkStream([b"x" * 60000], raise_after=1))
o = run_seq("60000_bytes_then_readerror", [small_then_die], retries=1)
checks.append(("partial_below_64k_observed_as_zero_bytes", o["observer_calls"] == [{"status": 200, "len": 0, "complete": False, "type": "Response"}]
               and o["result"]["type"] == "ReadError"))
def big_then_die(req):
    return httpx.Response(200, stream=pc.ChunkStream([b"x" * 100000], raise_after=1))
o = run_seq("100000_bytes_then_readerror", [big_then_die], retries=1)
checks.append(("partial_100000_observed_as_65536", o["observer_calls"][0]["len"] == K and o["observer_calls"][0]["complete"] is False))
# 6 what the observer receives on the stream path: the streaming Response; .content/.text raise ResponseNotRead
o = run_seq("observer_receives_streamed_response", [lambda req: httpx.Response(200, stream=pc.ChunkStream([body]))], retries=1, probe_response=True)
c = o["observer_calls"][0]
checks.append(("stream_observer_content_raises_ResponseNotRead", c["content_access"]["outcome"] == "exc" and c["content_access"]["type"] == "ResponseNotRead"
               and c["text_access"]["type"] == "ResponseNotRead" and c["url"] == "https://mock.invalid/r"))
# 7 non-stream path observer (dead in production): receives a fully read response, called once per attempt too
calls = []
ft = pc.FakeTime(); _http.time = ft
idx = {"i": 0}
def h(req):
    idx["i"] += 1
    return busy503(req) if idx["i"] == 1 else ok200(req)
seen = pc.install_client(_http, h)
res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=3,
             response_observer=lambda r, b, c: calls.append((r.status_code, len(b), c, pc.run(lambda: len(r.content))["outcome"])))
out["nonstream_observer_503_then_200"] = {"attempts": len(seen), "sleeps": ft.sleeps, "result": res, "observer_calls": calls}
checks.append(("nonstream_observer_once_per_attempt_content_readable", calls == [(503, 4, True, "ok"), (200, len(body), True, "ok")]))
# 8 notice_detail-style closure keeps the LAST capture (overwrites)
kept = {}
def closure(resp, raw, complete):
    kept["raw_capture"] = {"http_status": resp.status_code, "bytes": len(raw), "complete": complete}
ft = pc.FakeTime(); _http.time = ft
idx = {"i": 0}
def h2(req):
    idx["i"] += 1
    return midstream(req) if idx["i"] == 1 else busy503(req)
pc.install_client(_http, h2)
res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=2, max_response_bytes=10 * K, response_observer=closure)
out["closure_keeps_last"] = {"kept": kept, "result": res}
checks.append(("closure_keeps_last_attempt_capture", kept["raw_capture"] == {"http_status": 503, "bytes": 4, "complete": True}))

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL",
        {"checks": checks, "failed": failed, "scenarios": out,
         "measured_limits": [
             "observer is called once per attempt in which a response stream was opened; connect-phase failures produce zero calls (no raw_capture at all)",
             "mid-stream TransportError: partial bytes are only the decoded 64 KiB blocks already yielded by httpx's ByteChunker; the trailing sub-block buffer is lost (60000 bytes received -> 0 bytes observed)",
             "on the stream path the observer receives the un-read streaming Response: .content/.text raise ResponseNotRead (production observer reads only status_code)",
             "a closure that overwrites keeps the LAST attempt's capture, which may be a later failure after an earlier partial success"]},
        "observer_contract")
