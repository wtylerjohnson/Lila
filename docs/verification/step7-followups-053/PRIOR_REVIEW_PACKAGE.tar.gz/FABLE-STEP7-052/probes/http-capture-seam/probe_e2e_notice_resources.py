"""End to end through the REAL fetch_notice_resources: what the seam's outcomes become in receipts and on disk."""
import json
import os
import shutil
import tempfile
import _probe_common as pc
import httpx
from tools.api import _http
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained

HERE = os.path.dirname(os.path.abspath(__file__))
out = {}
checks = []
NID = "a" * 32
inv = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32}]}).encode()


def fresh_dir():
    d = tempfile.mkdtemp(prefix="cap-seam-e2e-", dir=HERE)
    os.environ["LILA_NOTICE_CACHE_DIR"] = d
    return d


def disk(d):
    objs = sorted(os.listdir(os.path.join(d, "objects"))) if os.path.isdir(os.path.join(d, "objects")) else []
    return {"cache_file": os.path.exists(os.path.join(d, NID + ".resources.json")), "objects": objs}


def go(name, handler, clock=None, prior=None):
    d = fresh_dir()
    if prior is not None:
        with open(os.path.join(d, NID + ".resources.json"), "w") as fh:
            json.dump(prior, fh)
    _http.time = pc.FakeTime(clock or [])
    seen = pc.install_client(_http, handler)
    r = pc.run(detail.fetch_notice_resources, NID)
    rec = {"attempts": len(seen), "result_outcome": r["outcome"]}
    if r["outcome"] == "ok":
        res = r["result"]
        rc = res.get("raw_capture")
        rec.update({"collection_status": res.get("collection_status"), "resources_checked": res.get("resources_checked"),
                    "attachments": res.get("attachments"), "errors": res.get("errors"), "from_cache": res.get("from_cache"), "stale_cache": res.get("stale_cache"),
                    "raw_capture": {k: v for k, v in rc.items() if k != "received_at"} if rc else None,
                    "retained_ok": (pc.run(read_retained, d, rc)["outcome"] == "ok") if rc else None,
                    "refresh_attempt_status": (res.get("refresh_attempt") or {}).get("collection_status")})
    else:
        rec["exc"] = r
    rec["disk"] = disk(d)
    out[name] = rec
    shutil.rmtree(d, ignore_errors=True)
    return rec


# 1 positive control
r = go("200_inventory", lambda req: httpx.Response(200, content=inv))
checks.append(("positive_inventory_captured", r["collection_status"] == "inventory_captured" and r["raw_capture"]["complete"] is True and r["disk"]["cache_file"] and len(r["disk"]["objects"]) == 1))
# 2 503: retries=1 so one attempt; capture retained with http_status 503; no cache file; orphan object on disk
r = go("503", lambda req: httpx.Response(503, content=b"busy"))
checks.append(("503_lookup_failed_capture_503_orphan_object", r["collection_status"] == "lookup_failed" and r["raw_capture"]["http_status"] == 503 and r["raw_capture"]["complete"] is True
               and r["attempts"] == 1 and not r["disk"]["cache_file"] and len(r["disk"]["objects"]) == 1))
# 3 mid-stream ReadError after 64 KiB: capture complete False, 65536 bytes retained, lookup_failed
big = b'"' + b"x" * 100000 + b'"'
r = go("midstream_readerror", lambda req: httpx.Response(200, stream=pc.ChunkStream([big], raise_after=1)))
checks.append(("midstream_partial_retained_incomplete", r["collection_status"] == "lookup_failed" and r["raw_capture"]["complete"] is False and r["raw_capture"]["bytes"] == 65536 and r["raw_capture"]["http_status"] == 200))
# 4 oversize: 2 MiB + 1 -> byte boundary, 2 MiB partial retained complete False
over = b'"' + b"x" * (2 * 1024 * 1024 - 1) + b'"'
r = go("oversize_2MiB_plus1", lambda req: httpx.Response(200, stream=pc.ChunkStream([over])))
checks.append(("oversize_partial_2MiB_retained_incomplete", r["collection_status"] == "lookup_failed" and r["raw_capture"]["bytes"] == 2 * 1024 * 1024 and r["raw_capture"]["complete"] is False
               and any("byte boundary" in e for e in r["errors"])))
# 5 exactly 2 MiB valid inventory: captured complete
exact = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32, "pad": "x" * (2 * 1024 * 1024 - 80)}]}).encode()
exact = exact[:2 * 1024 * 1024 - 4] + b'"}]}' if len(exact) > 2 * 1024 * 1024 else exact
pad = 2 * 1024 * 1024 - len(json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32, "pad": ""}]}).encode())
exact = json.dumps({"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32, "pad": "x" * pad}]}).encode()
assert len(exact) == 2 * 1024 * 1024
r = go("exact_2MiB_inventory", lambda req: httpx.Response(200, stream=pc.ChunkStream([exact[:70000], exact[70000:]])))
checks.append(("exact_2MiB_captured_complete", r["collection_status"] == "inventory_captured" and r["raw_capture"]["bytes"] == 2 * 1024 * 1024 and r["raw_capture"]["complete"] is True))
# 6 200 non-JSON: lookup_failed, capture complete True retained
r = go("200_html", lambda req: httpx.Response(200, content=b"<html>maint</html>"))
checks.append(("200_html_lookup_failed_capture_complete", r["collection_status"] == "lookup_failed" and r["raw_capture"]["complete"] is True and r["raw_capture"]["http_status"] == 200 and not r["disk"]["cache_file"]))
# 7 connect error: no raw_capture at all
def ce(req):
    raise httpx.ConnectError("no route")
r = go("connect_error", ce)
checks.append(("connect_error_no_raw_capture", r["collection_status"] == "lookup_failed" and r["raw_capture"] is None and r["disk"]["objects"] == []))
# 8 time boundary tripped after a full body (clock past stop): lookup_failed with complete False although all bytes present
r = go("time_boundary_after_full_body", lambda req: httpx.Response(200, content=inv), clock=[0.0, 99.0])
checks.append(("time_boundary_full_body_reported_incomplete", r["collection_status"] == "lookup_failed" and r["raw_capture"]["complete"] is False and r["raw_capture"]["bytes"] == len(inv)
               and any("time boundary" in e for e in r["errors"])))
# 9 stale fallback: prior VALID cached inventory (resources_checked True, retrieved 2 days ago, no raw_capture -> legacy) then a mid-stream failure: stale_inventory with refresh_attempt carrying the partial capture
from datetime import datetime, timedelta, timezone
prior = {"id": NID, "attachments": [{"name": "Old.pdf", "resourceId": "c" * 32}], "retrieved_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat(timespec="seconds"),
         "resources_checked": True, "resources_schema": "recognized_v1", "attachment_inventory_count": 1, "attachment_inventory_hash": detail._manifest_hash([{"name": "Old.pdf", "resourceId": "c" * 32}]), "errors": []}
r = go("legacy_stale_then_midstream_fail", lambda req: httpx.Response(200, stream=pc.ChunkStream([big], raise_after=1)), prior=prior)
checks.append(("stale_inventory_with_partial_refresh_attempt", r["collection_status"] == "stale_inventory" and r["refresh_attempt_status"] == "lookup_failed" and r["attachments"][0]["name"] == "Old.pdf"))

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL", {"checks": checks, "failed": failed, "scenarios": out,
        "measured": ["failed attempts still retain their bytes as content-addressed objects that no cache file references (orphans accumulate under objects/)",
                     "a complete body that lands after the stop clock is recorded complete=False with a 'time boundary' error"]},
        "e2e_notice_resources")
