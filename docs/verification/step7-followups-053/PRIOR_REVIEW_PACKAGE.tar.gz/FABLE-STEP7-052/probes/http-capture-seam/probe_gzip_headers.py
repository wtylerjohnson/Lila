"""Content-encoding, header stripping, charset and decoding on the streaming path."""
import gzip
import json
import os
import shutil
import tempfile
import _probe_common as pc
import httpx
from tools.api import _http

base = pc.load_base_http()
out = {}
checks = []
payload = {"attachments": [{"name": "Café SOW.pdf", "resourceId": "b" * 32}]}
plain = json.dumps(payload, ensure_ascii=False).encode("utf-8")
gz = gzip.compress(plain)


def cand_stream(handler, cap=10 * 1024 * 1024, keep_resp=None, **kw):
    obs = []
    _http.time = pc.FakeTime()
    seen = pc.install_client(_http, handler)
    r = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=1, max_response_bytes=cap,
               response_observer=lambda resp, b, c: obs.append({"status": resp.status_code, "len": len(b), "complete": c, "head": b[:12].decode("latin-1"),
                                                                "resp_content_encoding": resp.headers.get("content-encoding"), "resp_content_length": resp.headers.get("content-length")}), **kw)
    return {"result": r, "observer_calls": obs, "attempts": len(seen)}


def base_run(handler, **kw):
    base.time = pc.FakeTime()
    pc.install_client(base, handler)
    return pc.run(base._request, "GET", "https://mock.invalid/r", retries=1, **kw)


# 1 gzip with mixed-case header names: iter_bytes yields DECODED bytes; json decodes; observer bytes are decoded, capture is on decoded size
h_gz = lambda req: httpx.Response(200, headers=[("Content-Encoding", "gzip"), ("Content-Length", str(len(gz))), ("Content-Type", "application/hal+json")], stream=pc.ChunkStream([gz[:5], gz[5:]]))  # noqa: E731
r = cand_stream(h_gz)
b = base_run(h_gz)
out["gzip_mixed_case"] = {"cand": r, "base": b, "plain_len": len(plain), "gz_len": len(gz)}
checks.append(("gzip_decodes_and_observer_gets_decoded_bytes", r["result"] == b and r["result"]["outcome"] == "ok" and r["result"]["result"] == payload
               and r["observer_calls"][0]["len"] == len(plain) and r["observer_calls"][0]["head"].startswith('{"attachmen')
               and r["observer_calls"][0]["resp_content_encoding"] == "gzip" and r["observer_calls"][0]["resp_content_length"] == str(len(gz))))
# 2 cap applies to DECODED size: a gzip body whose compressed size is under cap but decoded size over
bomb_plain = b'"' + b"x" * 300000 + b'"'
bomb = gzip.compress(bomb_plain)
r = cand_stream(lambda req: httpx.Response(200, headers={"Content-Encoding": "gzip"}, stream=pc.ChunkStream([bomb])), cap=200000)
out["gzip_decoded_size_capped"] = {"cand": r, "compressed_len": len(bomb), "decoded_len": len(bomb_plain)}
checks.append(("cap_measures_decoded_bytes", len(bomb) < 200000 and r["result"]["type"] == "ValueError" and r["observer_calls"][0]["len"] == 200000 and r["observer_calls"][0]["complete"] is False))
# 3 corrupt gzip: DecodingError (not TransportError) propagates without retry on both; observer sees partial/complete False on cand
h_bad = lambda req: httpx.Response(200, headers={"Content-Encoding": "gzip"}, stream=pc.ChunkStream([gz[:20], b"garbage-not-gzip-body" * 10]))  # noqa: E731
r = cand_stream(h_bad)
b = base_run(h_bad)
out["corrupt_gzip"] = {"cand": r, "base": b}
checks.append(("corrupt_gzip_decodingerror_both_observer_incomplete_not_retried", r["result"]["type"] == "DecodingError" and b["type"] == "DecodingError"
               and len(r["observer_calls"]) == 1 and r["observer_calls"][0]["complete"] is False and r["attempts"] == 1))
# 4 reconstructed response headers: content-encoding/content-length stripped, new content-length = decoded size (inspect via a 4xx so the Response reaches the error)
h_gz_err = lambda req: httpx.Response(429, headers=[("Content-Encoding", "gzip"), ("Content-Length", "7"), ("Content-Type", "text/plain; charset=utf-8"), ("Set-Cookie", "a=1"), ("Set-Cookie", "b=2"), ("Transfer-Encoding", "chunked")], stream=pc.ChunkStream([gzip.compress("limite dépassée".encode())]))  # noqa: E731
_http.time = pc.FakeTime()
pc.install_client(_http, h_gz_err)
try:
    _http._request("GET", "https://mock.invalid/r", retries=1, max_response_bytes=1000)
    hdrs = None
except httpx.HTTPStatusError as exc:
    hdrs = {"headers": dict(exc.response.headers.multi_items()), "text": exc.response.text, "message": str(exc), "content_len": len(exc.response.content)}
out["reconstructed_4xx_headers"] = hdrs
checks.append(("reconstructed_headers_stripped_and_relengthed", hdrs is not None and "content-encoding" not in hdrs["headers"]
               and hdrs["headers"].get("content-length") == str(hdrs["content_len"]) and hdrs["text"] == "limite dépassée" and "limite dépassée" in hdrs["message"]))
out["reconstructed_4xx_headers_note"] = "duplicate Set-Cookie collapsed to one comma-joined value by Headers.items(); transfer-encoding kept alongside a fresh content-length"
checks.append(("duplicate_headers_collapsed_info", hdrs is not None and hdrs["headers"].get("set-cookie") == "a=1, b=2"))
# 5 charset: utf-16 JSON body with charset in content-type; json.loads on bytes autodetects on both paths
u16 = json.dumps(payload, ensure_ascii=False).encode("utf-16")
h16 = lambda req: httpx.Response(200, headers={"Content-Type": "application/json; charset=utf-16"}, content=u16)  # noqa: E731
r = cand_stream(h16); b = base_run(h16)
out["utf16_json"] = {"cand": r, "base": b}
checks.append(("utf16_matches_base", r["result"] == b and r["result"]["outcome"] == "ok"))
# 6 latin-1 error body: text decoded per charset in message on both
hl1 = lambda req: httpx.Response(500, headers={"Content-Type": "text/plain; charset=latin-1"}, content="défaut serveur".encode("latin-1"))  # noqa: E731
r = cand_stream(hl1); b = base_run(hl1)
out["latin1_error_body"] = {"cand": r, "base": b}
checks.append(("latin1_error_message_matches_base", r["result"] == b and "défaut serveur" in r["result"]["message"]))
# 7 no charset, non-utf8 bytes in a JSON 200: both raise the same (json.loads on invalid utf-8)
hbad = lambda req: httpx.Response(200, headers={"Content-Type": "application/json"}, content=b'{"name":"caf\xe9"}')  # noqa: E731
r = cand_stream(hbad); b = base_run(hbad)
out["invalid_utf8_json"] = {"cand": r, "base": b}
checks.append(("invalid_utf8_matches_base", r["result"] == b))
# 8 END TO END: fetch_notice_resources with gzip inventory -> retained bytes are DECODED and status inventory_captured
from tools.api import sam_notice_detail as detail
from tools.api.sam_capture import read_retained
tmp = tempfile.mkdtemp(prefix="cap-seam-gz-", dir=os.path.dirname(os.path.abspath(__file__)))
os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
_http.time = pc.FakeTime()
inv = json.dumps({"_embedded": {"opportunityAttachmentList": [{"attachments": [{"name": "SOW.pdf", "resourceId": "b" * 32, "accessLevel": "public"}]}]}}).encode()
pc.install_client(_http, lambda req: httpx.Response(200, headers={"Content-Encoding": "gzip", "Content-Type": "application/hal+json"}, stream=pc.ChunkStream([gzip.compress(inv)])))
res = detail.fetch_notice_resources("a" * 32)
retained = read_retained(__import__("pathlib").Path(tmp), res["raw_capture"]) if "raw_capture" in res else None
out["e2e_gzip_inventory"] = {"collection_status": res.get("collection_status"), "raw_capture": res.get("raw_capture"), "retained_equals_decoded": retained == inv,
                            "retained_len": len(retained) if retained else None, "attachments": res.get("attachments"), "errors": res.get("errors")}
checks.append(("e2e_gzip_retained_decoded_bytes", retained == inv and res.get("raw_capture", {}).get("representation") == "decoded_http_entity_bytes"))
# cached reuse validates against the decoded bytes
res2 = detail.fetch_notice_resources("a" * 32)
checks.append(("e2e_gzip_cache_reuse_valid", res2.get("from_cache") is True and res2.get("stale_cache") is False))
shutil.rmtree(tmp, ignore_errors=True)

failed = [n for n, ok in checks if not ok]
pc.emit("PASS" if not failed else "FAIL", {"checks": checks, "failed": failed, "scenarios": out}, "gzip_headers")
