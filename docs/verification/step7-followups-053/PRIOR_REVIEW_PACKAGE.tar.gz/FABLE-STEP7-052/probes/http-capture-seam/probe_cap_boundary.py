"""Byte cap boundaries on the streaming capture path (real tools.api._http._request)."""
import json
import _probe_common as pc
import httpx
from tools.api import _http

K = 65536
obs_all = {}
checks = []


def scenario(name, body_chunks, cap, retries=3, expect_ok=None):
    observed = []
    ft = pc.FakeTime()
    _http.time = ft
    seen = pc.install_client(_http, lambda req: httpx.Response(
        200, headers={"content-type": "application/hal+json"},
        stream=pc.ChunkStream(body_chunks)))
    res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=retries,
                 max_response_bytes=cap,
                 response_observer=lambda r, b, c: observed.append((r.status_code, len(b), c, b[:8].decode("latin-1"))))
    total = sum(len(c) for c in body_chunks)
    out = {"cap": cap, "body_len": total, "attempts": len(seen), "sleeps": ft.sleeps,
           "result": res, "observer_calls": observed}
    obs_all[name] = out
    return out


body = lambda n: json.dumps({"attachments": [], "pad": "x" * max(0, n - 26)}).encode()  # noqa: E731

# 1 len == cap (single small chunk, under the 64 KiB chunker)
b = body(100); o = scenario("len_eq_cap_small", [b], len(b))
checks.append(("len_eq_cap_small_complete", o["result"]["outcome"] == "ok" and o["observer_calls"] == [(200, len(b), True, b[:8].decode())]))
# 2 len == cap + 1 (one over)
o = scenario("len_eq_cap_plus1_small", [b], len(b) - 1)
checks.append(("cap_plus1_small_valueerror_partial_notretried",
               o["result"]["outcome"] == "exc" and o["result"]["type"] == "ValueError"
               and o["observer_calls"][0][1] == len(b) - 1 and o["observer_calls"][0][2] is False
               and o["attempts"] == 1 and o["sleeps"] == []))
# 3 producer's own case: 10 bytes, cap 4
o = scenario("producer_case_10_cap4", [b"0123456789"], 4)
checks.append(("producer_case", o["observer_calls"] == [(200, 4, False, "0123")]))
# 4 large: body exactly 2 MiB with cap 2 MiB (32 chunker blocks), server chunks of odd sizes
big = b'"' + b"x" * (2 * 1024 * 1024 - 2) + b'"'   # valid JSON string, exactly 2 MiB
assert len(big) == 2 * 1024 * 1024, len(big)
o = scenario("2MiB_eq_cap_odd_server_chunks", [big[:70001], big[70001:200000], big[200000:]], 2 * 1024 * 1024)
checks.append(("2MiB_eq_cap_complete", o["result"]["outcome"] == "ok" and o["observer_calls"][0][1] == 2 * 1024 * 1024 and o["observer_calls"][0][2] is True))
# 5 2 MiB + 1 straddling the last chunker block
big1 = big[:-1] + b'x"'
assert len(big1) == 2 * 1024 * 1024 + 1
o = scenario("2MiB_plus1", [big1], 2 * 1024 * 1024)
checks.append(("2MiB_plus1_partial_exact_cap", o["result"]["outcome"] == "exc" and o["result"]["type"] == "ValueError"
               and o["observer_calls"][0][1] == 2 * 1024 * 1024 and o["observer_calls"][0][2] is False))
# 6 cap not a multiple of 64 KiB, chunker block straddles it: cap=100000, body 100000 and 100001
mid = b'"' + b"x" * 99998 + b'"'
assert len(mid) == 100000
o = scenario("cap100000_body100000", [mid[:50000], mid[50000:]], 100000)
checks.append(("cap100000_eq_complete", o["result"]["outcome"] == "ok" and o["observer_calls"][0][1] == 100000 and o["observer_calls"][0][2] is True))
o = scenario("cap100000_body100001", [mid[:-1] + b'x"'], 100000)
checks.append(("cap100000_plus1_partial", o["result"]["outcome"] == "exc" and o["observer_calls"][0][1] == 100000 and o["observer_calls"][0][2] is False))
# 7 cap == 0
o = scenario("cap0_empty_body", [b""], 0)
checks.append(("cap0_empty_complete_then_json_error", o["observer_calls"] == [(200, 0, True, "")] and o["result"]["outcome"] == "exc" and o["result"]["type"] == "JSONDecodeError"))
o = scenario("cap0_nonempty_body", [b"{}"], 0)
checks.append(("cap0_nonempty_valueerror_zero_bytes", o["result"]["type"] == "ValueError" and o["observer_calls"] == [(200, 0, False, "")]))
# 8 negative cap (nonsense config): slice semantics
o = scenario("cap_negative", [b"abcdef"], -1)
obs_all["cap_negative"]["note"] = "chunk[:remaining] with negative remaining slices from the end; captured bytes exceed the (negative) cap"
checks.append(("negative_cap_captures_bytes_beyond_cap", o["observer_calls"][0][1] == 5))
# 9 cap on a 5xx body larger than cap: ValueError replaces the retryable status
o = scenario("cap_smaller_than_503_body", [b"x" * 50], 10)
# (status is 200 here; do a 503 variant)
observed = []
ft = pc.FakeTime(); _http.time = ft
seen = pc.install_client(_http, lambda req: httpx.Response(503, content=b"y" * 50))
res = pc.run(_http._request, "GET", "https://mock.invalid/r", retries=3, max_response_bytes=10,
             response_observer=lambda r, b, c: observed.append((r.status_code, len(b), c)))
obs_all["503_body_over_cap"] = {"result": res, "attempts": len(seen), "sleeps": ft.sleeps, "observer_calls": observed}
checks.append(("503_over_cap_becomes_valueerror_no_retry", res["type"] == "ValueError" and len(seen) == 1 and ft.sleeps == []))

failed = [n for n, ok in checks if not ok]
status = "PASS" if not failed else "FAIL"
pc.emit(status, {"checks": checks, "failed": failed, "scenarios": obs_all,
                 "notes": ["all boundary cases behave as claimed at len==cap, cap+1, straddling 64 KiB blocks",
                           "negative cap and 5xx-over-cap are edge behaviors (no production caller uses them)"]},
        "cap_boundary")
