"""fetch_notice_depth identity: (1) cached <A>.json holding notice B's data;
(2) cached branch resources reconciliation answered with B's body; (3) fresh depth
path answered with B's resources body; (4) positive control. Then the dossier's
_attachment_research_context and run_dossiers-style source_depth view of (1)."""
import json
from datetime import datetime, timezone

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand
import tools.api.sam_quota as sam_quota

base = pc.load_base_detail()
A, B, C = pc.A, pc.B, pc.C
row = pc.row

# never touch a ledger (env already points at tmp; belt and braces)
sam_quota.note_call = lambda purpose: 0
cand.sam_quota.note_call = lambda purpose: 0
base.sam_quota.note_call = lambda purpose: 0

BODY_B = pc.hal_body(B, [row(C, "B notice SOW.pdf", mimeType=".pdf")])
BODY_A = pc.hal_body(A, [row(pc.D, "A notice SOW.pdf", mimeType=".pdf")])


def routed(resources_body, description="<p>Requirement text for the probe.</p>"):
    res_payload = json.dumps(resources_body).encode()

    def handler(request):
        url = str(request.url)
        if "noticedesc" in url:
            return httpx.Response(200, json={"description": description})
        if url.endswith("/resources"):
            return httpx.Response(200, content=res_payload)
        return httpx.Response(404)
    return pc.install_mock(handler)


def view(data):
    return {"id": data.get("id"), "from_cache": data.get("from_cache"),
            "resources_checked": data.get("resources_checked"),
            "resources_schema": data.get("resources_schema"),
            "attachment_names": [a.get("name") for a in (data.get("attachments") or [])],
            "errors": data.get("errors")}


observed = {}
now = datetime.now(timezone.utc).isoformat(timespec="seconds")

# (1) cached depth file for A actually holding B's record (id=B, B's attachments)
b_record = {"id": B, "description": "B notice description", "attachments":
            cand._attachment_inventory(BODY_B, B)[0], "from_cache": False,
            "retrieved_at": now, "description_checked": True, "resources_checked": True,
            "resources_schema": "recognized_v1", "attachment_inventory_count": 1,
            "attachment_inventory_hash": "x" * 64, "errors": []}
for label, module in (("cand", cand), ("base", base)):
    cache_dir = pc.fresh_cache_dir(f"d1_{label}")
    (cache_dir / f"{A}.json").write_text(json.dumps(b_record))
    calls = routed(BODY_A)
    out = module.fetch_notice_depth(A)
    observed[f"1_cached_file_holds_B_{label}"] = {**view(out), "network_calls": len(calls)}

# what downstream sees for (1): dossier research guard and run_dossiers source_depth view
from agents.decisions.dossier import _attachment_research_context
depth_b = dict(b_record); depth_b["from_cache"] = True
notice_a = {"source_id": A, "raw_payload": {"attachment_inventory_hash": "y" * 64,
            "text": "t", "attachment_evidence": [], "attachment_evidence_sha256": "0" * 64}}
ctx = _attachment_research_context(notice_a, depth_b)
observed["1_downstream"] = {
    "dossier_research_context_status": (ctx or {}).get("status"),
    "dossier_research_context_reason": (ctx or {}).get("reason"),
    "run_dossiers_source_depth_projection": {
        "notice_id": A, "attachments": [a.get("name") for a in depth_b["attachments"]],
        "resources_checked": bool(depth_b.get("resources_checked")),
        "attachment_inventory_hash": depth_b.get("attachment_inventory_hash"),
        "note": "run_dossiers.py builds source_depth from depth.* keyed by nid; it never compares depth['id'] to nid",
    },
}

# (2) cached branch reconciliation: cache has description but resources_schema None
for label, module in (("cand", cand), ("base", base)):
    cache_dir = pc.fresh_cache_dir(f"d2_{label}")
    (cache_dir / f"{A}.json").write_text(json.dumps({
        "id": A, "description": "A description", "attachments": None, "retrieved_at": now,
        "description_checked": True, "resources_checked": False, "resources_schema": None,
        "errors": ["resources fetch failed (non-fatal): boom"]}))
    calls = routed(BODY_B)
    out = module.fetch_notice_depth(A)
    observed[f"2_cached_reconcile_gets_B_body_{label}"] = {**view(out), "network_calls": len(calls)}

# (3) fresh depth path with api key; resources answered with B's body
for label, module in (("cand", cand), ("base", base)):
    pc.fresh_cache_dir(f"d3_{label}")
    calls = routed(BODY_B)
    out = module.fetch_notice_depth(A, api_key="probe-key-not-real")
    observed[f"3_fresh_depth_gets_B_body_{label}"] = {**view(out), "network_calls": len(calls)}

# (4) positive control: fresh depth path with A's own body
pc.fresh_cache_dir("d4_cand")
calls = routed(BODY_A)
out = cand.fetch_notice_depth(A, api_key="probe-key-not-real")
observed["4_positive_fresh_depth_A_body_cand"] = {**view(out), "network_calls": len(calls)}

c1 = observed["1_cached_file_holds_B_cand"]
c2 = observed["2_cached_reconcile_gets_B_body_cand"]
c3 = observed["3_fresh_depth_gets_B_body_cand"]
b2 = observed["2_cached_reconcile_gets_B_body_base"]
b3 = observed["3_fresh_depth_gets_B_body_base"]
findings = {
    "cached_depth_file_with_foreign_id_returned_as_A": c1["id"] == B and c1["from_cache"] is True,
    "same_on_base": observed["1_cached_file_holds_B_base"]["id"] == B,
    "reconcile_refused_B_body": c2["resources_checked"] is False and not c2["attachment_names"],
    "reconcile_error_label": [e for e in (c2["errors"] or []) if "resources" in e],
    "base_reconcile_accepted_B_body": b2["resources_checked"] is True,
    "fresh_refused_B_body": c3["resources_checked"] is False and not c3["attachment_names"],
    "fresh_error_label": [e for e in (c3["errors"] or []) if "resources" in e],
    "base_fresh_accepted_B_body": b3["resources_checked"] is True,
    "positive_control_ok": observed["4_positive_fresh_depth_A_body_cand"]["resources_checked"] is True,
}
status = "PASS"
if findings["cached_depth_file_with_foreign_id_returned_as_A"]:
    status = "FAIL"
if not (findings["reconcile_refused_B_body"] and findings["fresh_refused_B_body"] and findings["positive_control_ok"]):
    status = "FAIL"
pc.emit({"probe": "depth_identity", "status": status, "findings": findings, "observed": observed,
         "note": ("fetch_notice_depth's cached branch never checks data['id'] against the requested "
                  "notice (base and candidate alike); the fresh/reconcile paths do refuse B's body on "
                  "the candidate but label it 'unrecognized resources schema', not identity_mismatch.")})
