"""H3: wrong-notice bodies whose ONLY other-notice marker is _links.self.href or a
download URL (no opportunityId/noticeId/notice_id key anywhere). Candidate vs base,
through _attachment_inventory and the real fetch_notice_resources, and then the
run_searches identity guard with the resulting inventory."""
import json

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()
A, B, C = pc.A, pc.B, pc.C
row = pc.row


def href(notice_id):
    return ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")


CASES = {
    # real HAL shape but with the opportunityId key stripped; self href names B
    "hal_no_id_key_self_href_B": {
        "_embedded": {"opportunityAttachmentList": [{"attachments": [row()]}]},
        "_links": {"self": {"href": href(B)}}},
    # real zero-attachment shape for B served for A
    "links_only_B": pc.links_only_body(B),
    # attachments whose download URL path embeds notice B
    "download_url_names_B": {"attachments": [row(
        downloadUrl=f"https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources/files/{C}/download")]},
    # flat list with a per-row self link naming B
    "row_links_self_B": {"attachments": [row(_links={"self": {"href": href(B)}})]},
    # opportunityId matches A but self href says B (contradictory body)
    "id_A_but_self_href_B": pc.hal_body(A, [row()], self_notice=B),
}


def run_fetch(module, body, label):
    pc.fresh_cache_dir(label)
    payload = json.dumps(body).encode()
    pc.install_mock(lambda request: httpx.Response(200, content=payload))
    out = module.fetch_notice_resources(A)
    return {"collection_status": out.get("collection_status"),
            "resources_checked": out.get("resources_checked"),
            "attachments": out.get("attachments"),
            "attachment_inventory_hash": out.get("attachment_inventory_hash"),
            "id": out.get("id")}


observed = {}
accepted_wrong = []
for name, body in CASES.items():
    cand_items, cand_rec = cand._attachment_inventory(body, A)
    base_items, base_rec = base._attachment_inventory(body)
    cf = run_fetch(cand, body, f"c_{name}")
    bf = run_fetch(base, body, f"b_{name}")
    observed[name] = {
        "candidate": {"identity_matches": cand._resource_identity_matches(body, A),
                      "recognized": cand_rec, "fetch": cf},
        "base": {"recognized": base_rec, "fetch": {k: v for k, v in bf.items() if k != "attachments"}},
    }
    if cf["resources_checked"] is True and cf["attachments"]:
        accepted_wrong.append(name)

# does the run_searches guard (resources.get("id")) catch any of these? It compares
# resources["id"], which fetch_notice_resources always sets to the REQUESTED id.
guard_view = {}
for name in accepted_wrong:
    resources = observed[name]["candidate"]["fetch"]
    guard_view[name] = {
        "resources_id": resources["id"],
        "guard_expression": "resources.get('id') not in (None, candidate.source_id)",
        "guard_trips": resources["id"] not in (None, A),
    }

pc.emit({
    "probe": "h3_href_only",
    "status": "FAIL" if accepted_wrong else "PASS",
    "note": ("FAIL here means a body carrying another notice's URL identity (but no "
             "explicit id key) was captured as notice A's inventory with attachments; "
             "candidate == base on these so the class is pre_existing/not fixed."),
    "accepted_as_A_inventory_with_rows": accepted_wrong,
    "run_searches_guard_view": guard_view,
    "observed": observed,
})
