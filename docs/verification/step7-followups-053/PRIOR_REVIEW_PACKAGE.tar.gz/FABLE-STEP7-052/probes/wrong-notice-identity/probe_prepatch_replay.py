"""Replay the producer's pre-patch S7-IDENTITY-002 probe: request a*32, the resources
endpoint answers with a body identifying b*32 and one attachment d*32 'Wrong notice
SOW.txt'. Compare candidate vs base and against the producer's saved
wrong-identity-inventory.json (hash a0475b0c...)."""
import json

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()
A, B, D = pc.A, pc.B, pc.D
saved = json.loads((pc.PREPATCH / "wrong-identity-inventory.json").read_text())
saved_result = json.loads((pc.PREPATCH / "RESULT.json").read_text())

# reconstruct the response the producer described: explicit b*32, one txt attachment d*32
body = {"opportunityId": B, "attachments": [{"resourceId": D, "name": "Wrong notice SOW.txt"}]}
payload = json.dumps(body).encode()

observed = {}
for label, module in (("cand", cand), ("base", base)):
    pc.fresh_cache_dir(f"pre_{label}")
    calls = pc.install_mock(lambda request: httpx.Response(200, content=payload))
    out = module.fetch_notice_resources(A)
    observed[label] = {
        "id": out.get("id"), "resources_checked": out.get("resources_checked"),
        "collection_status": out.get("collection_status"),
        "attachment_inventory_hash": out.get("attachment_inventory_hash"),
        "attachments": out.get("attachments"), "errors": out.get("errors"),
        "calls": len(calls),
        "cache_file_written": (pc.TMP / f"cache_pre_{label}" / f"{A}.resources.json").exists(),
    }

base_matches_producer = (observed["base"]["attachment_inventory_hash"] == saved["attachment_inventory_hash"]
                         and observed["base"]["attachments"] == saved["attachments"])
cand_refuses = (observed["cand"]["collection_status"] == "identity_mismatch"
                and observed["cand"]["resources_checked"] is False
                and observed["cand"]["attachments"] is None
                and observed["cand"]["cache_file_written"] is False)
pc.emit({
    "probe": "prepatch_replay",
    "status": "PASS" if (base_matches_producer and cand_refuses) else "FAIL",
    "producer_saved_hash": saved["attachment_inventory_hash"],
    "producer_saved_result": saved_result,
    "base_reproduces_producer_prepatch_defect": base_matches_producer,
    "candidate_refuses_and_writes_no_cache": cand_refuses,
    "observed": observed,
})
