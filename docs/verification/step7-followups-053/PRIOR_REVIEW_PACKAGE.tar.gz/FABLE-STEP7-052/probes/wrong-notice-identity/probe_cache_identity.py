"""Cache identity: (a) cached entry whose id was edited; (b) another notice's real
raw bytes + projection planted under this notice's cache file with id rewritten;
(c) same plant, cache aged past TTL, refresh FAILS -> stale fallback path;
(d) same plant, refresh returns identity_mismatch body -> stale fallback path;
(e) positive control: untouched fresh cache is reused with zero calls."""
import json
import shutil
from datetime import datetime, timedelta, timezone

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()
A, B, C = pc.A, pc.B, pc.C
row = pc.row

BODY_B = json.dumps(pc.hal_body(B, [row(C, "B notice SOW.pdf", mimeType=".pdf")])).encode()
BODY_A = json.dumps(pc.hal_body(A, [row(pc.D, "A notice SOW.pdf", mimeType=".pdf")])).encode()
BODY_A_NEW = json.dumps(pc.hal_body(A, [row(pc.D, "A notice SOW v2.pdf", mimeType=".pdf")])).encode()


def serve(payload, status=200):
    return pc.install_mock(lambda request: httpx.Response(status, content=payload))


def serve_transport_error():
    def handler(request):
        raise httpx.ConnectError("refused", request=request)
    return pc.install_mock(handler)


def build_legit(module, notice_id, payload, label):
    cache_dir = pc.fresh_cache_dir(label)
    serve(payload)
    out = module.fetch_notice_resources(notice_id)
    assert out.get("resources_checked") is True, out
    return cache_dir


def plant_b_under_a(cache_dir, module):
    """Build B's legit cache in this dir, then copy its file to A's name with id=A."""
    serve(BODY_B)
    module.fetch_notice_resources(B)
    src = cache_dir / f"{B}.resources.json"
    dst = cache_dir / f"{A}.resources.json"
    data = json.loads(src.read_text())
    data["id"] = A
    dst.write_text(json.dumps(data))
    return data


def age(cache_dir, notice_id, hours):
    path = cache_dir / f"{notice_id}.resources.json"
    data = json.loads(path.read_text())
    stamp = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    data["retrieved_at"] = stamp
    if isinstance(data.get("raw_capture"), dict):
        data["raw_capture"]["received_at"] = stamp
    path.write_text(json.dumps(data))


def summarize(out, calls):
    atts = out.get("attachments") or []
    return {"collection_status": out.get("collection_status"), "from_cache": out.get("from_cache"),
            "stale_cache": out.get("stale_cache"), "resources_checked": out.get("resources_checked"),
            "id": out.get("id"), "attachment_names": [a.get("name") for a in atts],
            "network_calls": len(calls), "errors": out.get("errors")}


observed = {}
failures = []

# (e) positive control first
cache_dir = build_legit(cand, A, BODY_A, "e_cand")
calls = serve(BODY_A_NEW)
out = cand.fetch_notice_resources(A)
observed["e_positive_fresh_reuse"] = summarize(out, calls)
if not (out.get("from_cache") is True and len(calls) == 0 and observed["e_positive_fresh_reuse"]["attachment_names"] == ["A notice SOW.pdf"]):
    failures.append("positive control: fresh untouched cache not reused without network")

# (a) id edited in an otherwise legit cache
for label, module in (("cand", cand), ("base", base)):
    cache_dir = build_legit(module, A, BODY_A, f"a_{label}")
    path = cache_dir / f"{A}.resources.json"
    data = json.loads(path.read_text()); data["id"] = B; path.write_text(json.dumps(data))
    calls = serve(BODY_A_NEW)
    out = module.fetch_notice_resources(A)
    observed[f"a_id_edited_{label}"] = summarize(out, calls)
if observed["a_id_edited_cand"]["id"] != A or observed["a_id_edited_cand"]["network_calls"] != 1:
    failures.append("(a) candidate reused a cache entry whose id names another notice")

# (b) B's real bytes planted under A, id rewritten, fresh window, refresh available
for label, module in (("cand", cand), ("base", base)):
    cache_dir = pc.fresh_cache_dir(f"b_{label}")
    plant_b_under_a(cache_dir, module)
    calls = serve(BODY_A_NEW)
    out = module.fetch_notice_resources(A)
    observed[f"b_planted_fresh_{label}"] = summarize(out, calls)
if observed["b_planted_fresh_cand"]["attachment_names"] != ["A notice SOW v2.pdf"]:
    failures.append("(b) candidate served planted wrong-notice inventory on the fresh path")

# (c) planted, aged 7h (past 6h TTL, inside 7d), refresh fails with transport error
for label, module in (("cand", cand), ("base", base)):
    cache_dir = pc.fresh_cache_dir(f"c_{label}")
    plant_b_under_a(cache_dir, module)
    age(cache_dir, A, 7)
    calls = serve_transport_error()
    out = module.fetch_notice_resources(A)
    observed[f"c_planted_stale_refresh_fails_{label}"] = summarize(out, calls)
c = observed["c_planted_stale_refresh_fails_cand"]
c_served_wrong = c["attachment_names"] == ["B notice SOW.pdf"]

# (d) planted, aged, refresh answers with an explicit-B body (identity_mismatch)
for label, module in (("cand", cand), ("base", base)):
    cache_dir = pc.fresh_cache_dir(f"d_{label}")
    plant_b_under_a(cache_dir, module)
    age(cache_dir, A, 7)
    calls = serve(BODY_B)
    out = module.fetch_notice_resources(A)
    observed[f"d_planted_stale_refresh_mismatch_{label}"] = summarize(out, calls)
    observed[f"d_planted_stale_refresh_mismatch_{label}"]["refresh_attempt_status"] = (
        (out.get("refresh_attempt") or {}).get("collection_status"))
d = observed["d_planted_stale_refresh_mismatch_cand"]
d_served_wrong = d["attachment_names"] == ["B notice SOW.pdf"]

# (f) stale path with a legit A cache whose attachments were edited (not identity, but
# shows the stale path performs no _resource_capture_valid at all)
cache_dir = build_legit(cand, A, BODY_A, "f_cand")
path = cache_dir / f"{A}.resources.json"
data = json.loads(path.read_text()); data["attachments"][0]["name"] = "Invented.pdf"; path.write_text(json.dumps(data))
age(cache_dir, A, 7)
calls = serve_transport_error()
out = cand.fetch_notice_resources(A)
observed["f_legit_cache_edited_rows_stale_refresh_fails_cand"] = summarize(out, calls)
observed["f_legit_cache_edited_rows_stale_refresh_fails_cand"]["capture_valid_says"] = cand._resource_capture_valid(json.loads(path.read_text()))

pc.emit({
    "probe": "cache_identity",
    "status": "FAIL" if failures or c_served_wrong or d_served_wrong else "PASS",
    "failures": failures,
    "stale_path_served_planted_wrong_notice_rows": {
        "refresh_transport_error": c_served_wrong,
        "refresh_identity_mismatch": d_served_wrong,
        "labelled": {"c": c["collection_status"], "d": d["collection_status"]},
        "note": ("The stale fallback returns the cached dict when resources_checked is True and "
                 "age <= 7d; it never calls _resource_capture_valid, so planted rows whose raw "
                 "bytes name notice B are returned under id A as stale_inventory. run_searches "
                 "skips stale_cache for relevance; the inventory_receipt still carries B's hash."),
    },
    "observed": observed,
})
