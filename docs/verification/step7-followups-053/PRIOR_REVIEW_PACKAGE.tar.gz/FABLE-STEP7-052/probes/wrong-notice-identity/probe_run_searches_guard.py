"""run_searches._enrich_sam_public_attachments identity guard (resources.get("id")).
(a) inventory dict with id=B for candidate A; (b) id missing (None) -> guard lets it
through; (c) positive control id=A; (d) end-to-end: REAL fetch_notice_resources over
MockTransport serving B's explicit body for A; (e) end-to-end with an id-less body
whose only B marker is _links.self.href (H3) and a downloadable text file.
Candidate vs BASE run_searches for (a) and (d)."""
import json

import httpx

import _probe_common as pc
import tools.api.sam_quota as sam_quota
import tools.api.sam_notice_detail as detail
import tools.api.sam_attachment_text as sat
import run_searches as cand_rs
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

base_rs = pc.load_base_run_searches()
A, B, C, D = pc.A, pc.B, pc.C, pc.D
TERM = "network visibility"
sam_quota.calls_today = lambda: 0
REAL_FETCH = detail.fetch_notice_resources


def public_file(resource_id, name):
    return {"resource_id": resource_id, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0",
            "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=resource_id)}


def taxonomy():
    return CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


def candidate_row():
    return RawOpportunity(source="sam.gov", source_id=A, title="Requirement",
                          agency="NASA", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate_row()]


def run(module, label):
    pc.fresh_cache_dir(label)
    import os
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(pc.TMP / f"text_{label}")
    rows, stats = module._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy(), None, limit=8)
    receipt = (stats.get("attachment_record_receipts") or {}).get(A, {})
    row = rows[0] if rows else None
    raw = (row or {}).get("raw_payload") or {}
    return {
        "rows": len(rows), "receipt_status": receipt.get("status"),
        "receipt_errors": receipt.get("errors"),
        "inventory_receipt_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
        "inventory_receipt_id": (receipt.get("inventory_receipt") or {}).get("id"),
        "row_text_excerpt": (raw.get("text") or "")[:80] or None,
        "collection_notice_id": (raw.get("attachment_collection_v1") or {}).get("notice_id"),
        "collection_files": [f.get("name") for f in (raw.get("attachment_collection_v1") or {}).get("files", [])],
        "stats_errors": [e for e in (stats.get("errors") or []) if A in e][:4],
    }


files = [public_file(D, "Wrong notice SOW.txt")]
inventory_hash = detail._manifest_hash(files)
texts = {D: f"Buyer requires {TERM} from the OTHER notice.".encode(),
         C: f"Href-only body requires {TERM}.".encode()}
sat._download_bytes = lambda rid, **k: texts[rid]

observed = {}
# (a) monkeypatched inventory claims id=B
detail.fetch_notice_resources = lambda *a, **k: {
    "id": B, "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": inventory_hash, "collection_status": "inventory_captured"}
observed["a_inventory_id_B_cand"] = run(cand_rs, "a_cand")
observed["a_inventory_id_B_base"] = run(base_rs, "a_base")

# (b) inventory with NO id key
detail.fetch_notice_resources = lambda *a, **k: {
    "resources_checked": True, "attachments": files, "attachment_inventory_hash": inventory_hash}
observed["b_inventory_id_missing_cand"] = run(cand_rs, "b_cand")

# (c) positive control id=A
detail.fetch_notice_resources = lambda *a, **k: {
    "id": A, "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": inventory_hash, "collection_status": "inventory_captured"}
observed["c_positive_id_A_cand"] = run(cand_rs, "c_cand")

# (d) end-to-end: real fetch_notice_resources; server answers A's URL with B's explicit body
detail.fetch_notice_resources = REAL_FETCH
body_b = json.dumps(pc.hal_body(B, [pc.row(D, "Wrong notice SOW.txt")])).encode()
pc.install_mock(lambda request: httpx.Response(200, content=body_b))
observed["d_e2e_explicit_B_body_cand"] = run(cand_rs, "d_cand")
pc.install_mock(lambda request: httpx.Response(200, content=body_b))
observed["d_e2e_explicit_B_body_base"] = run(base_rs, "d_base")

# (e) end-to-end: id-less body, only _links.self.href names B (H3)
href_b = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
          f"/opps/v3/opportunities/{B}/resources?withScanResult=false&excludeDeleted=false")
body_h3 = json.dumps({"_embedded": {"opportunityAttachmentList": [{"attachments": [pc.row(C, "Href only SOW.txt")]}]},
                      "_links": {"self": {"href": href_b}}}).encode()
pc.install_mock(lambda request: httpx.Response(200, content=body_h3))
observed["e_e2e_href_only_B_body_cand"] = run(cand_rs, "e_cand")
pc.install_mock(lambda request: httpx.Response(200, content=body_h3))
observed["e_e2e_href_only_B_body_base"] = run(base_rs, "e_base")

a = observed["a_inventory_id_B_cand"]; d = observed["d_e2e_explicit_B_body_cand"]
c = observed["c_positive_id_A_cand"]; e = observed["e_e2e_href_only_B_body_cand"]
checks = {
    "a_guard_trips_and_no_row": a["receipt_status"] == "IDENTITY_MISMATCH" and a["rows"] == 0,
    "a_base_enriched_with_wrong_notice": observed["a_inventory_id_B_base"]["rows"] == 1,
    "b_missing_id_passes_guard": observed["b_inventory_id_missing_cand"]["rows"] == 1,
    "c_positive_row_bound_to_A": c["rows"] == 1 and c["collection_notice_id"] == A,
    "d_e2e_no_row_and_identity_status": d["rows"] == 0 and d["inventory_receipt_status"] == "identity_mismatch",
    "d_base_e2e_wrong_text_in_row": observed["d_e2e_explicit_B_body_base"]["rows"] == 1,
    "e_h3_body_text_reaches_row_as_A": e["rows"] == 1 and e["collection_notice_id"] == A,
}
status = "PASS"
if not (checks["a_guard_trips_and_no_row"] and checks["c_positive_row_bound_to_A"] and checks["d_e2e_no_row_and_identity_status"]):
    status = "FAIL"
elif checks["e_h3_body_text_reaches_row_as_A"]:
    status = "FAIL"
pc.emit({"probe": "run_searches_guard", "status": status, "checks": checks, "observed": observed,
         "note": ("FAIL via check e means the H3 body (no id key, href names B) produced discovery text "
                  "bound to notice A through the full candidate path; same as base.")})
