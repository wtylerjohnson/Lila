"""Run the 21 real captured SAM resources bodies through _attachment_inventory
and fetch_notice_resources with (a) the requested id, (b) a WRONG id, and
(c) the uppercase form of the requested id. Cross-check against the receipts."""
import json

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()

bodies = sorted(pc.REAL_BODIES.glob("*.body"))
ids = [p.stem for p in bodies]


def fetch(module, requested, payload, label):
    pc.fresh_cache_dir(label)
    pc.install_mock(lambda request: httpx.Response(200, content=payload))
    out = module.fetch_notice_resources(requested)
    return {"collection_status": out.get("collection_status"),
            "resources_checked": out.get("resources_checked"),
            "count": out.get("attachment_inventory_count"),
            "hash": out.get("attachment_inventory_hash")}


def _ids(payload):
    stack = [payload]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            for key in ("opportunityId", "noticeId", "notice_id"):
                if key in item and item[key]:
                    yield item[key]
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)



table = []
tally = {"correct": {}, "wrong": {}, "upper": {}, "base_wrong_checked": 0,
         "receipt_status_agreement": 0, "receipt_attachment_agreement": 0,
         "wrong_id_undetectable": []}
for index, path in enumerate(bodies):
    notice_id = path.stem
    raw = path.read_bytes()
    receipt = json.loads((pc.REAL_BODIES / f"{notice_id}.json").read_text())
    wrong = ids[(index + 1) % len(ids)]
    body = json.loads(raw)
    items_ok, rec_ok = cand._attachment_inventory(body, notice_id)
    items_wrong, rec_wrong = cand._attachment_inventory(body, wrong)
    items_up, rec_up = cand._attachment_inventory(body, notice_id.upper())
    f_ok = fetch(cand, notice_id, raw, f"ok_{index}")
    f_wrong = fetch(cand, wrong, raw, f"wrong_{index}")
    f_up = fetch(cand, notice_id.upper(), raw, f"up_{index}")
    b_wrong = fetch(base, wrong, raw, f"bwrong_{index}")
    explicit_ids = sorted({m for m in _ids(body)})
    receipt_attachments = receipt.get("attachments")
    receipt_hash = cand._manifest_hash(receipt_attachments) if receipt_attachments is not None else None
    entry = {
        "notice_id": notice_id, "wrong_id": wrong,
        "explicit_ids_in_body": explicit_ids,
        "receipt_status": receipt.get("status"),
        "receipt_response_notice_ids": receipt.get("response_notice_ids"),
        "candidate_correct": f_ok, "candidate_wrong": f_wrong, "candidate_upper": f_up,
        "base_wrong": b_wrong,
        "inventory_matches_receipt": (items_ok == receipt_attachments) if rec_ok else (receipt_attachments is None),
        "hash_matches_receipt": f_ok["hash"] == receipt_hash,
    }
    table.append(entry)
    for key, f in (("correct", f_ok), ("wrong", f_wrong), ("upper", f_up)):
        tally[key][f["collection_status"]] = tally[key].get(f["collection_status"], 0) + 1
    tally["base_wrong_checked"] += int(b_wrong["resources_checked"] is True)
    tally["receipt_status_agreement"] += int(f_ok["collection_status"] == receipt.get("status"))
    tally["receipt_attachment_agreement"] += int(entry["inventory_matches_receipt"])
    if not explicit_ids:
        tally["wrong_id_undetectable"].append(notice_id)


failures = []
for e in table:
    if e["explicit_ids_in_body"] and e["candidate_wrong"]["collection_status"] != "identity_mismatch":
        failures.append(f"{e['notice_id']}: wrong-id request not refused")
    if e["explicit_ids_in_body"] and e["candidate_correct"]["collection_status"] != "inventory_captured":
        failures.append(f"{e['notice_id']}: correct-id request not captured")
    if not e["inventory_matches_receipt"]:
        failures.append(f"{e['notice_id']}: projected inventory differs from receipt")
    if e["candidate_wrong"]["resources_checked"] is True and e["candidate_wrong"]["count"]:
        failures.append(f"{e['notice_id']}: wrong-id request produced attachment rows")

pc.emit({
    "probe": "real_bodies",
    "status": "FAIL" if failures else "PASS",
    "failures": failures,
    "bodies": len(bodies),
    "tally": tally,
    "note_upper": ("'upper' column: requesting the same notice with an uppercase id "
                   "is refused as identity_mismatch (conservative yield loss, only if a "
                   "caller ever passes uppercase ids)."),
    "table": table,
})
