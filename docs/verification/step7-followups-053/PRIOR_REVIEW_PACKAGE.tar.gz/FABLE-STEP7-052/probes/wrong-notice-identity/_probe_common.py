"""Shared harness for the wrong-notice-identity probes.

Import this FIRST in every probe. It isolates every cache/ledger seam to a
probe-local temp dir, blocks sockets, and loads the BASE (2d522f0) copy of
sam_notice_detail from this directory under a distinct module name so a probe
can run the same scenario against base and candidate.
"""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
REAL_BODIES = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/"
                   "extracted/source-proof/public-inventory-001")
PREPATCH = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/"
                "extracted/producer-proof/prepatch-probes-001")

(PROBE_DIR / "_tmp").mkdir(exist_ok=True)
TMP = Path(tempfile.mkdtemp(prefix="wni-", dir=str(PROBE_DIR / "_tmp")))


def _isolate_env() -> None:
    (PROBE_DIR / "_tmp").mkdir(exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
    os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ.pop("SAM_GOV_API_KEY", None)
    if str(REPO) not in sys.path:
        sys.path.insert(0, str(REPO))


def block_sockets() -> None:
    def _refuse(*args, **kwargs):
        raise RuntimeError("probe attempted a real socket connect")
    socket.socket.connect = _refuse  # type: ignore[assignment]
    socket.socket.connect_ex = _refuse  # type: ignore[assignment]
    socket.create_connection = _refuse  # type: ignore[assignment]


_isolate_env()
block_sockets()

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402


def install_mock(handler) -> list:
    """Route every _http client through MockTransport; return the call log."""
    calls: list = []

    def logged(request):
        calls.append({"method": request.method, "url": str(request.url)})
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(logged), follow_redirects=True)
    return calls


def install_mock_no_redirect(handler) -> list:
    calls: list = []

    def logged(request):
        calls.append({"method": request.method, "url": str(request.url)})
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(logged), follow_redirects=False)
    return calls


def load_base_detail():
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", PROBE_DIR / "base_sam_notice_detail.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["base_sam_notice_detail"] = module
    spec.loader.exec_module(module)
    return module


def load_base_run_searches():
    spec = importlib.util.spec_from_file_location(
        "base_run_searches", PROBE_DIR / "base_run_searches.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["base_run_searches"] = module
    spec.loader.exec_module(module)
    return module


def fresh_cache_dir(label: str) -> Path:
    path = TMP / f"cache_{label}"
    path.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path)
    return path


def emit(result: dict) -> None:
    result.setdefault("tmp_dir", str(TMP))
    print(json.dumps(result, indent=2, sort_keys=True, default=str))


A = "a" * 32
B = "b" * 32
C = "c" * 32
D = "d" * 32


def row(resource_id: str = B, name: str = "SOW.txt", **extra) -> dict:
    base = {"resourceId": resource_id, "name": name, "mimeType": ".txt",
            "size": 10, "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}
    base.update(extra)
    return base


def hal_body(notice_id: str, rows: list[dict], *, self_notice: str | None = None) -> dict:
    """Real SAM v3 resources shape (17 of 21 captured bodies)."""
    self_id = self_notice or notice_id
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{self_id}/resources?withScanResult=false&excludeDeleted=false")
    return {
        "_embedded": {"opportunityAttachmentList": [
            {"opportunityId": notice_id, "attachments": rows}]},
        "_links": {"self": {"href": href}, "opportunity:publish:latest": {"href": href}},
    }


def links_only_body(notice_id: str) -> dict:
    """Real SAM zero-attachment shape (4 of 21 captured bodies)."""
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_links": {"self": {"href": href}, "opportunity:publish:latest": {"href": href}}}
