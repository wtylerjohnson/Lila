"""Explicit conflicting notice ids: top level, nested in rows, inside _embedded,
mixed bodies, case differences, odd value types and unchecked key variants.
Runs _resource_identity_matches / _attachment_inventory / fetch_notice_resources
on the candidate and _attachment_inventory / fetch_notice_resources on BASE."""
import json

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()
A, B, C = pc.A, pc.B, pc.C
row = pc.row

OTHER_DL = f"https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources/files/{C}/download"

CASES = {
    # positives: must be accepted as A's inventory
    "pos_top_match": (A, {"attachments": [row()], "opportunityId": A}),
    "pos_hal_match": (A, pc.hal_body(A, [row()])),
    "pos_no_identity_key": (A, {"attachments": [row()]}),
    "pos_null_and_empty_ids": (A, {"attachments": [row()], "opportunityId": None, "noticeId": ""}),
    # info: HAL entry with an EMPTY attachments list is not a captured real shape (real zero = _links only)
    "info_hal_entry_empty_attachments_list": (A, pc.hal_body(A, [])),
    # explicit conflicts: producer claims these are refused
    "neg_top_opportunityId": (A, {"attachments": [row()], "opportunityId": B}),
    "neg_top_noticeId": (A, {"attachments": [row()], "noticeId": B}),
    "neg_top_notice_id": (A, {"attachments": [row()], "notice_id": B}),
    "neg_inside_attachment_row": (A, {"attachments": [row(opportunityId=B)]}),
    "neg_embedded_list_entry": (A, pc.hal_body(B, [row()])),
    "neg_deep_nested_noticeId": (A, {"attachments": [row()], "meta": {"x": {"y": {"noticeId": B}}}}),
    "neg_payload_is_list": (A, [{"opportunityId": B, "attachments": [row()]}]),
    "neg_mixed_two_list_entries": (A, {"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": A, "attachments": [row()]},
        {"opportunityId": B, "attachments": [row(C, "Other.pdf")]}]}}),
    "neg_mixed_one_wrong_row": (A, pc.hal_body(A, [row(), row(C, "Other.pdf", opportunityId=B)])),
    "neg_confirmed_empty_other_notice": (A, pc.hal_body(B, [])),
    # case differences (SAM ids are lowercase hex; regex is IGNORECASE)
    "case_body_upper_request_lower": (A, pc.hal_body(A.upper(), [row()])),
    "case_body_lower_request_upper": (A.upper(), pc.hal_body(A, [row()])),
    # value types and whitespace
    "type_list_value_containing_A": (A, {"attachments": [row()], "opportunityId": [A]}),
    "type_int_value": (A, {"attachments": [row()], "opportunityId": 5}),
    "type_dict_value": (A, {"attachments": [row()], "opportunityId": {"id": A}}),
    "whitespace_padded_A": (A, {"attachments": [row()], "opportunityId": A + " "}),
    # unchecked key variants (should these count as conflicting ids?)
    "variant_opportunity_id_snake": (A, {"attachments": [row()], "opportunity_id": B}),
    "variant_OpportunityId_caps": (A, {"attachments": [row()], "OpportunityId": B}),
    "variant_id_key": (A, {"attachments": [row()], "id": B}),
    "variant_noticeid_lower": (A, {"attachments": [row()], "noticeid": B}),
    "variant_parentOpportunityId": (A, {"attachments": [row()], "parentOpportunityId": B}),
}


def run_fetch(module, requested: str, body, label: str) -> dict:
    pc.fresh_cache_dir(label)
    payload = json.dumps(body).encode()
    calls = pc.install_mock(lambda request: httpx.Response(200, content=payload))
    out = module.fetch_notice_resources(requested)
    return {
        "collection_status": out.get("collection_status"),
        "resources_checked": out.get("resources_checked"),
        "attachment_count": len(out.get("attachments") or []) if out.get("attachments") is not None else None,
        "errors": out.get("errors"),
        "calls": len(calls),
    }


observed = {}
failures = []
for name, (requested, body) in CASES.items():
    cand_ident = cand._resource_identity_matches(body, requested)
    cand_items, cand_rec = cand._attachment_inventory(body, requested)
    base_items, base_rec = base._attachment_inventory(body)
    cand_fetch = run_fetch(cand, requested, body, f"c_{name}")
    base_fetch = run_fetch(base, requested, body, f"b_{name}")
    entry = {
        "requested": requested,
        "candidate": {"identity_matches": cand_ident, "recognized": cand_rec,
                      "items": None if cand_items is None else len(cand_items),
                      "fetch": cand_fetch},
        "base": {"recognized": base_rec,
                 "items": None if base_items is None else len(base_items),
                 "fetch": base_fetch},
    }
    observed[name] = entry
    if name.startswith("pos_") and not (cand_rec and cand_fetch["resources_checked"] is True):
        failures.append(f"{name}: positive control rejected by candidate")
    if name.startswith("neg_") and (cand_rec or cand_fetch["collection_status"] != "identity_mismatch"):
        failures.append(f"{name}: explicit conflicting id accepted by candidate")

# classify the disclosed-but-interesting categories separately
case_notes = {k: v["candidate"]["fetch"]["collection_status"] for k, v in observed.items() if k.startswith("case_")}
variant_notes = {k: v["candidate"]["fetch"]["collection_status"] for k, v in observed.items() if k.startswith("variant_")}
type_notes = {k: v["candidate"]["fetch"]["collection_status"] for k, v in observed.items() if k.startswith(("type_", "whitespace_"))}
base_accepted_negs = [k for k, v in observed.items() if k.startswith("neg_") and v["base"]["fetch"]["resources_checked"] is True]

pc.emit({
    "probe": "identity_matrix",
    "status": "FAIL" if failures else "PASS",
    "failures": failures,
    "summary": {
        "explicit_conflicts_rejected_by_candidate": sum(
            1 for k, v in observed.items() if k.startswith("neg_") and v["candidate"]["fetch"]["collection_status"] == "identity_mismatch"),
        "explicit_conflicts_total": sum(1 for k in observed if k.startswith("neg_")),
        "base_accepted_these_conflicts": base_accepted_negs,
        "case_difference_outcomes": case_notes,
        "unchecked_key_variant_outcomes": variant_notes,
        "value_type_outcomes": type_notes,
    },
    "observed": observed,
})
