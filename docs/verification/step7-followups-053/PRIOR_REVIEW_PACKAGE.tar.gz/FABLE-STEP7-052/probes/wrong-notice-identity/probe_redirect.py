"""Redirect following: the request for notice A is answered with 302 to another
notice's resources URL (or an off-host URL), then 200. Checks what identity state
the candidate assigns and what raw_capture.source_url records versus the URL the
bytes actually came from. Base for comparison."""
import json

import httpx

import _probe_common as pc
from tools.api import sam_notice_detail as cand

base = pc.load_base_detail()
A, B = pc.A, pc.B
row = pc.row
URL_A = cand.RESOURCES_URL_TPL.format(id=A)
URL_B = cand.RESOURCES_URL_TPL.format(id=B)
OFF_HOST = "https://attachments.example.net/opps/v3/opportunities/" + B + "/resources"

VARIANTS = {
    "explicit_id_B_body": (URL_B, pc.hal_body(B, [row()])),
    "no_id_key_body": (URL_B, {"attachments": [row()]}),
    "links_only_B_body": (URL_B, pc.links_only_body(B)),
    "off_host_no_id_body": (OFF_HOST, {"attachments": [row(name="Offhost SOW.pdf")]}),
    "off_host_explicit_B": (OFF_HOST, pc.hal_body(B, [row()])),
}


def make_handler(target, body):
    payload = json.dumps(body).encode()

    def handler(request):
        if str(request.url) == URL_A:
            return httpx.Response(302, headers={"Location": target})
        if str(request.url) == target:
            return httpx.Response(200, content=payload)
        return httpx.Response(404, content=b"unexpected")
    return handler


observed = {}
accepted = []
receipt_lies = []
for name, (target, body) in VARIANTS.items():
    pc.fresh_cache_dir(f"c_{name}")
    calls = pc.install_mock(make_handler(target, body))
    out = cand.fetch_notice_resources(A)
    capture = out.get("raw_capture") or {}
    final_url = calls[-1]["url"] if calls else None
    pc.fresh_cache_dir(f"b_{name}")
    bcalls = pc.install_mock(make_handler(target, body))
    bout = base.fetch_notice_resources(A)
    entry = {
        "hops": [c["url"] for c in calls],
        "candidate": {"collection_status": out.get("collection_status"),
                      "resources_checked": out.get("resources_checked"),
                      "attachment_count": out.get("attachment_inventory_count"),
                      "raw_capture_source_url": capture.get("source_url"),
                      "raw_capture_http_status": capture.get("http_status"),
                      "raw_capture_complete": capture.get("complete"),
                      "final_url_actually_served": final_url,
                      "receipt_source_url_equals_final_url": capture.get("source_url") == final_url},
        "base": {"resources_checked": bout.get("resources_checked"),
                 "attachment_count": bout.get("attachment_inventory_count"),
                 "hops": len(bcalls)},
    }
    observed[name] = entry
    if out.get("resources_checked") is True and out.get("attachments"):
        accepted.append(name)
        if capture.get("source_url") != final_url:
            receipt_lies.append(name)

# does the observer even have access to the final URL? (so the fix is cheap)
seen = {}
pc.fresh_cache_dir("observer_check")
pc.install_mock(make_handler(URL_B, {"attachments": [row()]}))
from tools.api._http import get_json
get_json(URL_A, retries=1, max_response_bytes=1024,
         response_observer=lambda response, raw, complete: seen.update(
             {"observer_response_url": str(response.url), "has_history": bool(getattr(response, "history", None))}))

pc.emit({
    "probe": "redirect",
    "status": "FAIL" if receipt_lies else ("INFO" if accepted else "PASS"),
    "accepted_after_redirect_with_rows": accepted,
    "receipt_source_url_misrecorded_for": receipt_lies,
    "observer_sees_final_url": seen,
    "note": ("raw_capture.source_url is built from RESOURCES_URL_TPL with the requested id, "
             "never from response.url; after a redirect the receipt names a URL the bytes "
             "did not come from. Explicit-id bodies are still refused; id-less bodies are "
             "captured as A's inventory (same as base, which had no identity check)."),
    "observed": observed,
})
