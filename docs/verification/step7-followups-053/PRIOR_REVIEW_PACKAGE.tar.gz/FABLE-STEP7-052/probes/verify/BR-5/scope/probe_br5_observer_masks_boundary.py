"""BR-5 refutation probe: does an observer failure inside the streaming finally
block replace the in-flight byte/time boundary exception in the recorded reason?

Cases
 c1  _request level, oversized body, observer raises OSError(ENOSPC):
     which exception propagates, and is the boundary error still chained
     as __context__ (Python implicit chaining)?
 c2  fetch_notice_resources, oversized body, retain_bytes raises ENOSPC:
     do errors[] carry 'byte boundary'? (finder's case c, re-run independently)
 c3  control: same oversized body, observer healthy: errors[] carry 'byte
     boundary' and raw_capture.complete is False.
 c4  time boundary variant with observer raising: same masking?
 c5  BASE 2d522f0 _http._request: does it accept response_observer at all?
     (pre_existing is impossible if the kwarg is rejected.)
 c6  file path (sam_attachment_text): boundary raised by _download_bytes
     BEFORE retain_bytes runs, so no masking there; confirms the finder's
     file scoping to _http.py is correct.
 c7  disclosure sweep of docs/verification/step7-052 for any producer sentence
     about observer/storage failure replacing the transport reason.

Writes only under this probe's directory. No network (socket connect blocked).
"""
from __future__ import annotations

import errno
import importlib.util
import json
import os
import re
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

_blocked = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("network blocked"))
socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_capture  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

root = Path(tempfile.mkdtemp(prefix="br5-", dir=PROBE_DIR))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(root / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(root / "text")

NOTICE = "a" * 32
RID = "b" * 32
observed: dict = {}
checks: dict = {}
real_retain = sam_capture.retain_bytes


def bind(handler):
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)


def enospc(directory, payload):
    raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(directory))


big = b"x" * (2 * 1024 * 1024 + 5)

# c1: raw _request level.
bind(lambda request: httpx.Response(200, content=big))


def raising_observer(response, raw, complete):
    raise OSError(errno.ENOSPC, "No space left on device", "objects/")


try:
    _http._request("GET", "https://mock.invalid/r", max_response_bytes=2 * 1024 * 1024,
                   retries=1, response_observer=raising_observer)
    c1 = {"raised": None}
except Exception as exc:  # noqa: BLE001
    ctx = exc.__context__
    c1 = {"raised_type": type(exc).__name__, "raised_str": str(exc),
          "context_type": type(ctx).__name__ if ctx else None,
          "context_str": str(ctx) if ctx else None,
          "suppress_context": exc.__suppress_context__}
observed["c1_request_level"] = c1
checks["c1_observer_error_propagates_not_boundary"] = c1.get("raised_type") == "OSError"
checks["c1_boundary_still_chained_as_context"] = (
    c1.get("context_type") == "ValueError" and "byte boundary" in (c1.get("context_str") or ""))

# c2: through fetch_notice_resources with retain_bytes failing (finder's case c).
sam_capture.retain_bytes = enospc
res_c2 = detail.fetch_notice_resources(NOTICE)
sam_capture.retain_bytes = real_retain
observed["c2_fetch_oversized_plus_enospc"] = {
    "collection_status": res_c2["collection_status"], "errors": res_c2["errors"],
    "raw_capture_present": "raw_capture" in res_c2}
checks["c2_byte_boundary_reason_lost_from_errors"] = not any(
    "byte boundary" in e for e in res_c2["errors"])

# c3: control, observer healthy.
res_c3 = detail.fetch_notice_resources(NOTICE)
observed["c3_fetch_oversized_observer_ok"] = {
    "collection_status": res_c3["collection_status"], "errors": res_c3["errors"],
    "raw_capture": {k: res_c3.get("raw_capture", {}).get(k) for k in ("complete", "bytes", "http_status")}}
checks["c3_control_byte_boundary_reason_recorded"] = any(
    "byte boundary" in e for e in res_c3["errors"]) and res_c3.get("raw_capture", {}).get("complete") is False

# c4: time boundary variant. Force monotonic to jump past stop after first chunk.
real_mono = _http.time.monotonic
state = {"n": 0}


def jumping_monotonic():
    state["n"] += 1
    return real_mono() + (0 if state["n"] <= 1 else 10_000)


bind(lambda request: httpx.Response(200, content=b"y" * 70000))
_http.time.monotonic = jumping_monotonic
sam_capture.retain_bytes = enospc
try:
    res_c4 = detail.fetch_notice_resources(NOTICE)
finally:
    _http.time.monotonic = real_mono
    sam_capture.retain_bytes = real_retain
observed["c4_time_boundary_plus_enospc"] = {
    "collection_status": res_c4["collection_status"], "errors": res_c4["errors"]}
checks["c4_time_boundary_reason_lost_from_errors"] = not any(
    "time boundary" in e for e in res_c4["errors"])
# c4 control
_http.time.monotonic = jumping_monotonic
state["n"] = 0
try:
    res_c4b = detail.fetch_notice_resources(NOTICE)
finally:
    _http.time.monotonic = real_mono
observed["c4_control_time_boundary_observer_ok"] = {"errors": res_c4b["errors"]}
checks["c4_control_time_boundary_recorded"] = any("time boundary" in e for e in res_c4b["errors"])

# c5: BASE 2d522f0 _http: kwarg absent?
spec = importlib.util.spec_from_file_location("base_http", PROBE_DIR / "base_http_2d522f0.py")
base_http = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_http)
import inspect  # noqa: E402
base_params = list(inspect.signature(base_http._request).parameters)
cand_params = list(inspect.signature(_http._request).parameters)
try:
    base_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
        lambda r: httpx.Response(200, json={})))
    base_http._request("GET", "https://mock.invalid/r", response_observer=raising_observer,
                       max_response_bytes=10)
    base_result = "accepted"
except TypeError as exc:
    base_result = f"TypeError: {exc}"
observed["c5_base_2d522f0"] = {"base_request_params": base_params,
                               "candidate_request_params": cand_params,
                               "base_call_with_observer": base_result}
checks["c5_feature_absent_at_base_so_not_pre_existing"] = (
    "response_observer" not in base_params and base_result.startswith("TypeError"))

# c6: file path ordering. _download_bytes raises boundary; retain never reached.
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
retain_calls = {"n": 0}


def counting_enospc(directory, payload):
    retain_calls["n"] += 1
    raise OSError(errno.ENOSPC, "No space left on device", str(directory))


def boundary_download(rid, **k):
    raise ValueError("response exceeds 5242880 byte boundary")


real_dl = sat._download_bytes
sat._download_bytes = boundary_download
sam_capture.retain_bytes = counting_enospc
res_c6 = sat.extract_public_attachment_text(PUBLIC)
sat._download_bytes = real_dl
sam_capture.retain_bytes = real_retain
observed["c6_file_path"] = {"collection_status": res_c6["collection_status"],
                            "error": res_c6["error"], "retain_calls": retain_calls["n"]}
checks["c6_file_path_boundary_survives_no_masking"] = (
    "byte boundary" in res_c6["error"] and retain_calls["n"] == 0)

# c7: disclosure sweep.
doc_dir = REPO / "docs" / "verification" / "step7-052"
pattern = re.compile(r"observer|no space|enospc|storage (error|failure)|replac\w+ the (original|transport)|masks?\b", re.I)
hits = []
for p in sorted(doc_dir.iterdir()):
    if p.suffix not in {".md", ".json"}:
        continue
    for i, line in enumerate(p.read_text(errors="replace").splitlines(), 1):
        if pattern.search(line):
            hits.append(f"{p.name}:{i}: {line.strip()[:200]}")
for extra in (REPO / "docs" / "CONTRACT_SURFACES.md", REPO / "docs" / "CONVENTIONS.md"):
    for i, line in enumerate(extra.read_text(errors="replace").splitlines(), 1):
        if re.search(r"response_observer|retain_bytes|capture byte boundary", line):
            hits.append(f"{extra.name}:{i}: {line.strip()[:200]}")
observed["c7_disclosure_hits"] = hits
checks["c7_no_producer_disclosure_of_masking"] = not any(
    "observer" in h.lower() and ("replac" in h.lower() or "mask" in h.lower()) for h in hits)

# Verdict: finding confirmed if masking demonstrated (c2, c4) with healthy controls,
# feature new (c5), file path correctly excluded (c6), and no disclosure (c7).
confirmed = all(checks[k] for k in (
    "c1_observer_error_propagates_not_boundary", "c2_byte_boundary_reason_lost_from_errors",
    "c3_control_byte_boundary_reason_recorded", "c4_time_boundary_reason_lost_from_errors",
    "c4_control_time_boundary_recorded", "c5_feature_absent_at_base_so_not_pre_existing",
    "c6_file_path_boundary_survives_no_masking", "c7_no_producer_disclosure_of_masking"))
observed["nuance"] = (
    "The boundary exception is not destroyed: it survives as exc.__context__ (c1). "
    "It is lost only at the receipt layer because sam_notice_detail records str(exc). "
    "Masking needs two simultaneous failures (oversized/slow body AND local storage failure); "
    "the healthy-observer controls (c3, c4 control) record the boundary reason correctly.")
print(json.dumps({"probe": "br5_observer_masks_boundary",
                  "status": "FAIL" if confirmed else "PASS",
                  "observed": observed, "checks": checks}, indent=2, sort_keys=True, default=str))
shutil.rmtree(root, ignore_errors=True)
