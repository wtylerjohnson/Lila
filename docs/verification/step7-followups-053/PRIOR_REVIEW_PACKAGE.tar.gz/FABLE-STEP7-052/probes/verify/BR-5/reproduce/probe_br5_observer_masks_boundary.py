"""BR-5 independent reproduction: does a raising observer in _http._request's
finally block replace the in-flight byte/time boundary error in the recorded
inventory reason?  No network: _http._client is bound to httpx.MockTransport
and socket.connect is blocked.  Writes only to a probe-local temp dir."""
import errno
import json
import os
import socket
import stat
import sys
import tempfile
import time
import types
from pathlib import Path

import httpx

sys.path.insert(0, "/Users/wtjohnson/lila-step7-052")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

from tools.api import _http, sam_notice_detail as detail  # noqa: E402
from tools.api import sam_capture  # noqa: E402

NOTICE = "a" * 32
BOUNDARY = 2 * 1024 * 1024  # hardcoded in fetch_notice_resources
OVERSIZED = b'{"attachments":[],"pad":"' + b"x" * (BOUNDARY + 4096) + b'"}'
SMALL = b'{"attachments":[]}'

def bind_transport(payload, status=200):
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=payload)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls

def fresh_cache_dir(root, name):
    d = Path(root) / name
    d.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d)
    return d

def run_case(name, payload, *, storage_failure=None, time_boundary=False):
    """storage_failure: None | 'readonly_objects' | 'link_enospc'."""
    root = tempfile.mkdtemp(prefix="br5_", dir=os.environ.get("BR5_TMP"))
    cache_dir = fresh_cache_dir(root, name)
    calls = bind_transport(payload)
    real_link = sam_capture.os.link
    real_time = _http.time
    objects = cache_dir / "objects"
    try:
        if storage_failure == "readonly_objects":
            objects.mkdir()
            objects.chmod(stat.S_IRUSR | stat.S_IXUSR)  # temp file creation fails with EACCES
        elif storage_failure == "link_enospc":
            def failing_link(src, dst, *a, **k):
                raise OSError(errno.ENOSPC, "No space left on device", str(dst))
            sam_capture.os.link = failing_link
        if time_boundary:
            # monotonic jumps far ahead after the first chunk so the time check trips
            base = time.monotonic()
            state = {"n": 0}
            def fake_monotonic():
                state["n"] += 1
                return base if state["n"] <= 1 else base + 10_000.0
            _http.time = types.SimpleNamespace(monotonic=fake_monotonic, sleep=time.sleep)
        # capture the exception chain as fetch_notice_resources sees it
        chain = {}
        real_get_json = detail.get_json
        def spy_get_json(*a, **k):
            try:
                return real_get_json(*a, **k)
            except BaseException as exc:
                chain["type"] = type(exc).__name__
                chain["str"] = str(exc)[:200]
                ctx = exc.__context__
                chain["context_type"] = type(ctx).__name__ if ctx is not None else None
                chain["context_str"] = str(ctx)[:200] if ctx is not None else None
                raise
        detail.get_json = spy_get_json
        try:
            result = detail.fetch_notice_resources(NOTICE)
        finally:
            detail.get_json = real_get_json
    finally:
        sam_capture.os.link = real_link
        _http.time = real_time
        if objects.exists():
            objects.chmod(stat.S_IRWXU)
    errors = result.get("errors") or []
    joined = " | ".join(errors)
    retained = sorted(p.name for p in objects.glob("*.bin")) if objects.exists() else []
    return {
        "case": name,
        "http_calls": len(calls),
        "collection_status": result.get("collection_status"),
        "errors": errors,
        "has_byte_boundary_text": "byte boundary" in joined,
        "has_time_boundary_text": "time boundary" in joined,
        "raw_capture_present": "raw_capture" in result,
        "raw_capture_complete": (result.get("raw_capture") or {}).get("complete"),
        "retained_objects": retained,
        "cache_file_written": (cache_dir / f"{NOTICE}.resources.json").exists(),
        "exception_seen_by_caller": chain,
    }

def main():
    os.environ["BR5_TMP"] = tempfile.mkdtemp(prefix="br5_root_")
    cases = [
        run_case("a_control_oversized_retention_ok", OVERSIZED),
        run_case("b_oversized_plus_readonly_objects", OVERSIZED, storage_failure="readonly_objects"),
        run_case("c_oversized_plus_link_enospc", OVERSIZED, storage_failure="link_enospc"),
        run_case("d_time_boundary_plus_link_enospc", SMALL, storage_failure="link_enospc", time_boundary=True),
        run_case("e_small_body_plus_link_enospc_no_boundary", SMALL, storage_failure="link_enospc"),
        run_case("f_control_small_body_retention_ok", SMALL),
    ]
    by = {c["case"]: c for c in cases}
    checks = {
        "a_control_records_byte_boundary": by["a_control_oversized_retention_ok"]["has_byte_boundary_text"]
            and by["a_control_oversized_retention_ok"]["raw_capture_complete"] is False,
        "b_readonly_masks_byte_boundary": (not by["b_oversized_plus_readonly_objects"]["has_byte_boundary_text"])
            and by["b_oversized_plus_readonly_objects"]["exception_seen_by_caller"].get("context_str", "") is not None
            and "byte boundary" in (by["b_oversized_plus_readonly_objects"]["exception_seen_by_caller"].get("context_str") or ""),
        "c_enospc_masks_byte_boundary": (not by["c_oversized_plus_link_enospc"]["has_byte_boundary_text"])
            and "byte boundary" in (by["c_oversized_plus_link_enospc"]["exception_seen_by_caller"].get("context_str") or ""),
        "d_enospc_masks_time_boundary": (not by["d_time_boundary_plus_link_enospc"]["has_time_boundary_text"])
            and "time boundary" in (by["d_time_boundary_plus_link_enospc"]["exception_seen_by_caller"].get("context_str") or ""),
        "e_storage_failure_alone_is_recorded": any("No space left" in e for e in by["e_small_body_plus_link_enospc_no_boundary"]["errors"]),
        "f_control_small_body_captured": by["f_control_small_body_retention_ok"]["collection_status"] == "confirmed_empty",
        "masked_cases_stay_lookup_failed_uncached": all(
            by[k]["collection_status"] == "lookup_failed" and not by[k]["cache_file_written"]
            for k in ("b_oversized_plus_readonly_objects", "c_oversized_plus_link_enospc", "d_time_boundary_plus_link_enospc")),
    }
    reproduced = checks["a_control_records_byte_boundary"] and checks["b_readonly_masks_byte_boundary"] \
        and checks["c_enospc_masks_byte_boundary"] and checks["d_enospc_masks_time_boundary"]
    print(json.dumps({
        "status": "FAIL" if reproduced else "PASS",
        "finding": "BR-5 retention error masks in-flight boundary error in recorded reason",
        "reproduced": reproduced,
        "checks": checks,
        "observed": cases,
        "note": "FAIL here means the defect reproduced (recorded reason loses the boundary text); "
                "the boundary error survives only as exc.__context__, which no caller records.",
    }, indent=2, default=str))

if __name__ == "__main__":
    main()
