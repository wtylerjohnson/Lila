"""F-12 scope/classification refutation probe (HTTP capture seam edges).

Runs six member claims (BR-4, HCS-02, HCS-03, HCS-04, BR-5, HCS-07) against the
candidate tools/api/_http.py and, where the base helper can accept the call, against
the accepted Step6 base 2d522f0:tools/api/_http.py loaded in memory via git show
(never written to disk: the base file carries characters banned from this dir).

No network: every transport is an in-process httpx transport; socket.connect is
blocked for the whole run. No LLM. Writes only under this probe dir.
Prints ONE JSON object with status in {PASS, FAIL, INFO} and observed details.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import types
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
BASE_SHA = "2d522f0362e656e029986344d47e2e06b86a58f8"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402


def _no_connect(*a, **k):  # pragma: no cover - guard
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

from tools.api import _http as cand  # noqa: E402
from tools.api import sam_notice_detail as snd  # noqa: E402
from tools.api import sam_capture  # noqa: E402


def load_base_http() -> types.ModuleType:
    src = subprocess.run(
        ["git", "-C", str(REPO), "show", f"{BASE_SHA}:tools/api/_http.py"],
        check=True, capture_output=True, text=True).stdout
    spec = importlib.util.spec_from_loader("base_http_2d522f0", loader=None)
    mod = importlib.util.module_from_spec(spec)
    exec(compile(src, "<base 2d522f0 tools/api/_http.py>", "exec"), mod.__dict__)
    return mod


base = load_base_http()

BAD = "\u2014"


def clean(obj):
    """Strip banned characters from any string in the output tree."""
    if isinstance(obj, str):
        return obj.replace(BAD, "-").replace("\u2013", "-")
    if isinstance(obj, dict):
        return {clean(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    return obj


class ScriptedStream(httpx.SyncByteStream):
    """Yield raw chunks in order; optionally raise after them."""

    def __init__(self, chunks, raise_after=None):
        self._chunks = chunks
        self._raise_after = raise_after

    def __iter__(self):
        for c in self._chunks:
            yield c
        if self._raise_after is not None:
            raise self._raise_after

    def close(self):
        pass


class ScriptedTransport(httpx.BaseTransport):
    def __init__(self, status, chunks, raise_after=None, connect_error=None,
                 headers=None):
        self.status = status
        self.chunks = chunks
        self.raise_after = raise_after
        self.connect_error = connect_error
        self.headers = headers or {"content-type": "application/hal+json"}
        self.requests = 0

    def handle_request(self, request):
        self.requests += 1
        if self.connect_error is not None:
            raise self.connect_error
        return httpx.Response(self.status, headers=self.headers,
                              stream=ScriptedStream(self.chunks, self.raise_after),
                              request=request)


def bind(mod, transport):
    mod._client = lambda timeout: httpx.Client(transport=transport, timeout=timeout)


def nosleep(mod, log):
    mod.time = types.SimpleNamespace(monotonic=mod.time.monotonic if hasattr(mod.time, "monotonic") else None,
                                     sleep=lambda s: log.append(s))


def scripted_clock(mod, values, log):
    it = iter(values)
    last = [values[-1]]

    def mono():
        try:
            v = next(it)
        except StopIteration:
            v = last[0]
        return v

    mod.time = types.SimpleNamespace(monotonic=mono, sleep=lambda s: log.append(s))


def run(mod, transport, **kw):
    observed = []
    sleeps = []
    bind(mod, transport)
    if "clock" in kw:
        scripted_clock(mod, kw.pop("clock"), sleeps)
    else:
        import time as _t
        mod.time = types.SimpleNamespace(monotonic=_t.monotonic, sleep=lambda s: sleeps.append(s))
    if kw.pop("observe", False):
        kw["response_observer"] = lambda r, raw, complete: observed.append(
            {"status": r.status_code, "len": len(raw), "complete": complete})
    try:
        result = mod._request("GET", "https://sam.gov/api/prod/opps/v3/opportunities/x/resources", **kw)
        exc = None
    except Exception as e:  # noqa: BLE001
        result = None
        exc = e
    return {
        "result": result,
        "exc_type": type(exc).__name__ if exc else None,
        "exc_msg": (str(exc)[:120] if exc else None),
        "exc_context_type": type(exc.__context__).__name__ if exc and exc.__context__ else None,
        "attempts": transport.requests,
        "sleeps": sleeps,
        "observer": observed,
    }


NOTICE = "a" * 32
GOOD_BODY = json.dumps({"_embedded": {"opportunityAttachmentList": [
    {"attachments": [{"resourceId": "r1", "name": "sow.pdf", "accessLevel": "public"}]}]}}).encode()
CAP = 2 * 1024 * 1024


def caller(transport, clock=None, retain=None):
    """Drive the production caller fetch_notice_resources through an isolated cache dir."""
    d = Path(tempfile.mkdtemp(prefix="f12-", dir=str(HERE)))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d)
    snd._cache_dir.cache_clear() if hasattr(snd._cache_dir, "cache_clear") else None
    bind(cand, transport)
    sleeps = []
    if clock is not None:
        scripted_clock(cand, clock, sleeps)
    else:
        import time as _t
        cand.time = types.SimpleNamespace(monotonic=_t.monotonic, sleep=lambda s: sleeps.append(s))
    orig = sam_capture.retain_bytes
    if retain is not None:
        sam_capture.retain_bytes = retain
    try:
        out = snd.fetch_notice_resources(NOTICE, timeout_seconds=15.0)
    finally:
        sam_capture.retain_bytes = orig
    objs = sorted(p.name for p in (d / "objects").glob("*.bin")) if (d / "objects").exists() else []
    rc = out.get("raw_capture")
    return {
        "collection_status": out.get("collection_status"),
        "errors": out.get("errors"),
        "raw_capture": {k: rc.get(k) for k in ("complete", "http_status", "bytes", "sha256")} if rc else None,
        "objects_on_disk": len(objs),
        "object_sizes": [(d / "objects" / n).stat().st_size for n in objs],
        "cache_written": (d / f"{NOTICE}.resources.json").exists(),
    }


observed = {}
checks = {}

# ---- BR-4 / HCS-03: mid-body transport error, small body and 70000-byte body ----
t = ScriptedTransport(200, [GOOD_BODY[:34]], raise_after=httpx.ReadError("reset"))
observed["cand_midbody_34"] = run(cand, t, retries=1, max_response_bytes=CAP, observe=True)
t = ScriptedTransport(200, [b"x" * 70000], raise_after=httpx.ReadError("reset"))
observed["cand_midbody_70000"] = run(cand, t, retries=1, max_response_bytes=CAP, observe=True)
# Same events, base helper (has no capture seam; nothing is retained at base at all)
t = ScriptedTransport(200, [GOOD_BODY[:34]], raise_after=httpx.ReadError("reset"))
observed["base_midbody_34"] = run(base, t, retries=1)
# Base helper cannot accept the new keywords
t = ScriptedTransport(200, [GOOD_BODY[:34]], raise_after=httpx.ReadError("reset"))
observed["base_with_capture_kwargs"] = run(base, t, retries=1, max_response_bytes=CAP, observe=True)
# Proof that the loss is the 65536 re-chunker, not httpx itself: iter_bytes() with no size keeps 34
t = ScriptedTransport(200, [GOOD_BODY[:34]], raise_after=httpx.ReadError("reset"))
got = bytearray()
try:
    with httpx.Client(transport=t) as c, c.stream("GET", "https://sam.gov/x") as s:
        for ch in s.iter_bytes():
            got.extend(ch)
except httpx.ReadError:
    pass
observed["httpx_iter_bytes_unsized_keeps"] = len(got)
# Production caller view of the small mid-body reset
t = ScriptedTransport(200, [GOOD_BODY[:34]], raise_after=httpx.ReadError("reset"))
observed["caller_midbody_34"] = caller(t)

checks["br4_small_partial_retains_zero"] = observed["cand_midbody_34"]["observer"] == [
    {"status": 200, "len": 0, "complete": False}]
checks["hcs03_70000_retains_65536"] = observed["cand_midbody_70000"]["observer"] == [
    {"status": 200, "len": 65536, "complete": False}]
checks["unsized_iter_bytes_would_keep_34"] = observed["httpx_iter_bytes_unsized_keeps"] == 34
checks["base_rejects_capture_kwargs_TypeError"] = observed["base_with_capture_kwargs"]["exc_type"] == "TypeError"
checks["caller_midbody_lookup_failed_incomplete_zero_bytes"] = (
    observed["caller_midbody_34"]["collection_status"] == "lookup_failed"
    and observed["caller_midbody_34"]["raw_capture"] == {"complete": False, "http_status": 200, "bytes": 0,
                                                          "sha256": observed["caller_midbody_34"]["raw_capture"]["sha256"]}
    and observed["caller_midbody_34"]["cache_written"] is False)

# ---- HCS-02: oversize 4xx/5xx body ----
big429 = b"z" * (CAP + 1)
t = ScriptedTransport(429, [big429])
observed["cand_429_oversize_retries3"] = run(cand, t, retries=3, max_response_bytes=CAP, observe=True)
t = ScriptedTransport(429, [big429])
observed["base_429_oversize_retries3"] = run(base, t, retries=3)
t = ScriptedTransport(429, [big429])
observed["cand_429_oversize_retries1_production"] = run(cand, t, retries=1, max_response_bytes=CAP, observe=True)
t = ScriptedTransport(429, [big429])
observed["base_429_oversize_retries1_production"] = run(base, t, retries=1)
t = ScriptedTransport(429, [big429])
observed["caller_429_oversize"] = caller(t)
# Control: small 4xx error body is retained complete with status via the caller
t = ScriptedTransport(404, [b'{"error":"not found"}'])
observed["caller_404_small"] = caller(t)

checks["hcs02_cand_ValueError_one_attempt_with_retries3"] = (
    observed["cand_429_oversize_retries3"]["exc_type"] == "ValueError"
    and observed["cand_429_oversize_retries3"]["attempts"] == 1)
checks["hcs02_base_HTTPStatusError_three_attempts"] = (
    observed["base_429_oversize_retries3"]["exc_type"] == "HTTPStatusError"
    and observed["base_429_oversize_retries3"]["attempts"] == 3)
checks["hcs02_production_retries1_attempts_equal"] = (
    observed["cand_429_oversize_retries1_production"]["attempts"]
    == observed["base_429_oversize_retries1_production"]["attempts"] == 1)
rc = observed["caller_429_oversize"]["raw_capture"]
checks["hcs02_receipt_keeps_status_and_2MiB_body"] = (
    rc is not None and rc["http_status"] == 429 and rc["complete"] is False and rc["bytes"] == CAP
    and observed["caller_429_oversize"]["object_sizes"] == [CAP])
checks["hcs02_errors_text_lacks_HTTP_429"] = not any(
    "429" in e for e in observed["caller_429_oversize"]["errors"])
checks["control_small_404_body_retained_complete"] = (
    observed["caller_404_small"]["raw_capture"] == {"complete": True, "http_status": 404, "bytes": 21,
                                                    "sha256": observed["caller_404_small"]["raw_capture"]["sha256"]}
    and any("404" in e for e in observed["caller_404_small"]["errors"]))

# ---- HCS-04: full body lands after the stop clock ----
t = ScriptedTransport(200, [GOOD_BODY])
observed["cand_full_body_past_stop"] = run(cand, t, retries=1, max_response_bytes=CAP, observe=True,
                                           clock=[0.0, 30.0001], timeout=30.0)
t = ScriptedTransport(200, [b""])
observed["cand_empty_body_past_stop"] = run(cand, t, retries=1, max_response_bytes=CAP, observe=True,
                                            clock=[0.0, 99.0], timeout=30.0)
t = ScriptedTransport(200, [GOOD_BODY])
observed["caller_full_body_past_stop"] = caller(t, clock=[0.0, 30.0001])
checks["hcs04_full_body_marked_incomplete_TimeoutError"] = (
    observed["cand_full_body_past_stop"]["exc_type"] == "TimeoutError"
    and observed["cand_full_body_past_stop"]["observer"] == [{"status": 200, "len": len(GOOD_BODY), "complete": False}])
checks["hcs04_empty_body_skips_clock"] = observed["cand_empty_body_past_stop"]["observer"] == [
    {"status": 200, "len": 0, "complete": True}]
checks["hcs04_caller_refuses_full_body_lookup_failed"] = (
    observed["caller_full_body_past_stop"]["collection_status"] == "lookup_failed"
    and observed["caller_full_body_past_stop"]["cache_written"] is False)

# ---- BR-5: observer raises while a boundary error is in flight ----
def boom(directory, payload):
    raise OSError(28, "No space left on device")


t = ScriptedTransport(200, [big429])
observed["caller_oversize_plus_disk_full"] = caller(t, retain=boom)
t = ScriptedTransport(200, [big429])
bind(cand, t)
try:
    cand._request("GET", "https://sam.gov/x", retries=1, max_response_bytes=CAP,
                  response_observer=lambda r, raw, c: boom(None, raw))
    br5 = None
except Exception as e:  # noqa: BLE001
    br5 = e
observed["direct_oversize_plus_observer_raise"] = {
    "exc_type": type(br5).__name__, "context_type": type(br5.__context__).__name__ if br5.__context__ else None,
    "context_msg": str(br5.__context__)[:80] if br5.__context__ else None}
checks["br5_errors_lack_byte_boundary"] = not any(
    "byte boundary" in e for e in observed["caller_oversize_plus_disk_full"]["errors"])
checks["br5_errors_carry_disk_full_only"] = any(
    "No space left" in e for e in observed["caller_oversize_plus_disk_full"]["errors"])
checks["br5_original_survives_as_exc_context"] = observed["direct_oversize_plus_observer_raise"]["context_type"] == "ValueError"

# ---- HCS-07: observer interface asymmetry ----
seen = {}


def peek(r, raw, complete):
    try:
        _ = r.content
        seen["content"] = "readable"
    except Exception as e:  # noqa: BLE001
        seen["content"] = type(e).__name__
    seen["status"] = r.status_code


t = ScriptedTransport(200, [GOOD_BODY])
bind(cand, t)
cand._request("GET", "https://sam.gov/x", retries=1, max_response_bytes=CAP, response_observer=peek)
observed["hcs07_stream_observer_sees"] = dict(seen)
t = ScriptedTransport(200, [], connect_error=httpx.ConnectError("boom"))
observed["hcs07_connect_error"] = run(cand, t, retries=3, max_response_bytes=CAP, observe=True)
observed["caller_connect_error"] = caller(ScriptedTransport(200, [], connect_error=httpx.ConnectError("boom")))
checks["hcs07_content_ResponseNotRead_status_ok"] = seen == {"content": "ResponseNotRead", "status": 200}
checks["hcs07_connect_error_zero_observer_calls"] = (
    observed["hcs07_connect_error"]["observer"] == [] and observed["hcs07_connect_error"]["attempts"] == 3)
checks["hcs07_caller_connect_error_no_raw_capture"] = observed["caller_connect_error"]["raw_capture"] is None

# ---- Docs: claim vs disclosure ----
conv = (REPO / "docs/CONVENTIONS.md").read_text()
sentence = re.search(r"Public inventories use one attempt[^.]*\.", conv)
observed["conventions_sentence"] = sentence.group(0).replace("\n", " ") if sentence else None
disclosed = []
for p in sorted((REPO / "docs/verification/step7-052").glob("*")):
    if p.suffix in {".md", ".json"}:
        txt = p.read_text(errors="replace")
        for needle in ("65536", "64 KiB", "64KiB", "block", "partial bod", "observer", "byte boundary",
                       "time boundary", "ValueError", "ResponseNotRead"):
            if needle in txt:
                disclosed.append(f"{p.name}: {needle}")
observed["verification_docs_mentions"] = disclosed
checks["doc_claims_partial_error_bodies_retained"] = bool(sentence) and "partial/error bodies" in sentence.group(0)
checks["no_verification_doc_discloses_seam_edges"] = disclosed == []

# ---- member probes' claims that I checked and what stands ----
status = "FAIL" if all(checks.values()) else "INFO"
verdict = {
    "status": status,
    "finding": "F-12",
    "lens": "scope and classification",
    "candidate_sha": "6b51f005c001d2d99a535e4a302370f9ad80c6ea",
    "base_sha": BASE_SHA,
    "checks": checks,
    "observed": observed,
    "reading": [
        "The streaming capture path does not exist at base (TypeError on the new keywords); every edge is introduced by the Step7 delta, so pre_existing is excluded.",
        "No sentence in docs/verification/step7-052/*.md or *.json or PRIOR_FOLLOWUPS.json discloses block granularity, the oversize-4xx ValueError path, the post-stop complete=false marking, or observer masking; disclosed_residual is excluded.",
        "CONVENTIONS says public inventories retain partial/error bodies; measured: a 34-byte mid-body reset retains 0 bytes, 70000 retains 65536; byte-cap and small error bodies ARE retained, so the sentence is only partly overstated.",
        "HCS-02 is narrower than its title: the caller receipt keeps http_status 429 and the first 2 MiB of the error body on disk; only the errors[] text and the retry policy (moot at retries=1 in the only caller) change versus base.",
        "BR-5 masking is real in the recorded reason but the original ValueError survives as exc.__context__; receipt is incomplete, not wrong.",
        "Incomplete captures cannot be reused (_resource_capture_valid needs complete True and http_status 200) so no evidence-integrity impact; severity Low stands.",
    ],
}
print(json.dumps(clean(verdict), indent=1, sort_keys=False))
