"""Independent reproduction of BR-1: storage failure inside retain_bytes is
recorded as lookup_failed / unreadable and the acquired bytes are discarded.

Written from the finding description only, before reading the cited probes.
No network: _http._client is replaced by a MockTransport client, the file
download helper is replaced, and socket.connect is blocked outright.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402

import tools.api._http as _http  # noqa: E402
import tools.api.sam_capture as sam_capture  # noqa: E402
import tools.api.sam_notice_detail as detail  # noqa: E402
import tools.api.sam_attachment_text as attach  # noqa: E402


def _blocked_connect(*args, **kwargs):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]

NOTICE_ID = "0123456789abcdef0123456789abcdef"
RESOURCE_ID = "fedcba9876543210fedcba9876543210"
INVENTORY_BODY = json.dumps({
    "_embedded": {"opportunityAttachmentList": [{
        "attachments": [{
            "name": "SOW.txt", "resourceId": RESOURCE_ID,
            "mimeType": "text/plain", "size": 11, "accessLevel": "public",
        }],
    }]},
}).encode("utf-8")
FILE_BODY = b"hello world"
ATTACHMENT = {
    "resource_id": RESOURCE_ID, "name": "SOW.txt", "type": "text/plain",
    "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RESOURCE_ID),
    "size": 11, "access_level": "public", "access_status": None,
    "export_controlled": None, "explicit_access": None,
}

ORIGINAL_RETAIN = sam_capture.retain_bytes
ORIGINAL_CLIENT = _http._client
ORIGINAL_DOWNLOAD = attach._download_bytes

observed: dict = {}
checks: list[tuple[str, bool]] = []


def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))


def fresh_dirs() -> tuple[Path, Path]:
    base = Path(tempfile.mkdtemp(prefix="br1_", dir=str(Path(__file__).parent)))
    inv = base / "notice"
    txt = base / "attachment_text"
    inv.mkdir()
    txt.mkdir()
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(inv)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(txt)
    return inv, txt


def mock_inventory_client():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(200, content=INVENTORY_BODY,
                              headers={"content-type": "application/hal+json"})

    def client(timeout):
        return httpx.Client(transport=httpx.MockTransport(handler), timeout=timeout)

    return client, calls


def poison(directory: Path, payload: bytes) -> Path:
    digest = hashlib.sha256(payload).hexdigest()
    slot = directory / "objects" / f"{digest}.bin"
    slot.parent.mkdir(parents=True, exist_ok=True)
    slot.write_bytes(b"NOT THE SAME BYTES")
    return slot


def raising_retain(fail_on_call: int, exc: Exception):
    """Wrap retain_bytes so the Nth call (1-based) raises exc."""
    state = {"n": 0}

    def wrapper(directory, payload):
        state["n"] += 1
        if state["n"] == fail_on_call:
            raise exc
        return ORIGINAL_RETAIN(directory, payload)

    return wrapper, state


def restore() -> None:
    sam_capture.retain_bytes = ORIGINAL_RETAIN
    _http._client = ORIGINAL_CLIENT
    attach._download_bytes = ORIGINAL_DOWNLOAD


# Control: with a clean cache the same inventory body is inventory_captured.
inv_dir, txt_dir = fresh_dirs()
client, calls = mock_inventory_client()
_http._client = client
control = detail.fetch_notice_resources(NOTICE_ID)
observed["control_inventory"] = {
    "collection_status": control.get("collection_status"),
    "attachment_count": control.get("attachment_inventory_count"),
    "network_calls": calls["n"],
}
check("control inventory captured", control.get("collection_status") == "inventory_captured")
restore()

# Case 1: poisoned digest slot, inventory path, two sweeps, no cache file.
inv_dir, txt_dir = fresh_dirs()
slot = poison(inv_dir, INVENTORY_BODY)
client, calls = mock_inventory_client()
_http._client = client
first = detail.fetch_notice_resources(NOTICE_ID)
second = detail.fetch_notice_resources(NOTICE_ID)
observed["poisoned_slot_inventory"] = {
    "first_status": first.get("collection_status"),
    "first_errors": first.get("errors"),
    "first_attachments": first.get("attachments"),
    "second_status": second.get("collection_status"),
    "network_calls_after_two_sweeps": calls["n"],
    "cache_file_written": (inv_dir / f"{NOTICE_ID}.resources.json").exists(),
    "slot_still_poisoned": slot.read_bytes() == b"NOT THE SAME BYTES",
    "raw_capture_key_present": "raw_capture" in first,
}
check("poisoned inventory -> lookup_failed", first.get("collection_status") == "lookup_failed")
check("poisoned inventory error names bytes changed",
      any("retained SAM bytes changed" in e for e in first.get("errors", [])))
check("poisoned inventory drops attachments", first.get("attachments") is None)
check("poisoned inventory: fresh network call each sweep", calls["n"] == 2)
check("poisoned inventory never self-heals", second.get("collection_status") == "lookup_failed"
      and slot.read_bytes() == b"NOT THE SAME BYTES")
restore()

# Case 2: poisoned digest slot, file path.
inv_dir, txt_dir = fresh_dirs()
poison(txt_dir, FILE_BODY)
download_calls = {"n": 0}


def fake_download(resource_id, *, deadline_monotonic=None):
    download_calls["n"] += 1
    return FILE_BODY


attach._download_bytes = fake_download
file_result = attach.extract_public_attachment_text(dict(ATTACHMENT))
observed["poisoned_slot_file"] = {
    "collection_status": file_result.get("collection_status"),
    "text": file_result.get("text"),
    "error": file_result.get("error"),
    "download_calls": download_calls["n"],
    "raw_capture_present": "raw_capture" in file_result,
    "cache_file_written": (txt_dir / f"{RESOURCE_ID}.json").exists(),
}
check("poisoned file -> lookup_failed", file_result.get("collection_status") == "lookup_failed")
check("poisoned file text dropped", file_result.get("text") == "")
check("poisoned file download did succeed", download_calls["n"] == 1)
restore()

# Case 3: retain_bytes raises OSError (disk full) during inventory capture.
inv_dir, txt_dir = fresh_dirs()
client, calls = mock_inventory_client()
_http._client = client
wrapper, state = raising_retain(1, OSError(28, "No space left on device"))
sam_capture.retain_bytes = wrapper
oserr_inv = detail.fetch_notice_resources(NOTICE_ID)
observed["oserror_inventory"] = {
    "collection_status": oserr_inv.get("collection_status"),
    "attachments": oserr_inv.get("attachments"),
    "errors": oserr_inv.get("errors"),
    "network_calls": calls["n"],
    "retain_calls": state["n"],
}
check("oserror inventory -> lookup_failed", oserr_inv.get("collection_status") == "lookup_failed")
check("oserror inventory attachments None", oserr_inv.get("attachments") is None)
check("oserror inventory error names ENOSPC",
      any("No space left on device" in e for e in oserr_inv.get("errors", [])))
check("oserror inventory: HTTP 200 was received", calls["n"] == 1)
restore()

# Case 4: retain_bytes raises OSError on the raw file retain (first call).
inv_dir, txt_dir = fresh_dirs()
attach._download_bytes = fake_download
download_calls["n"] = 0
wrapper, state = raising_retain(1, OSError(28, "No space left on device"))
sam_capture.retain_bytes = wrapper
raw_fail = attach.extract_public_attachment_text(dict(ATTACHMENT))
observed["oserror_file_raw_retain"] = {
    "collection_status": raw_fail.get("collection_status"),
    "text": raw_fail.get("text"),
    "error": raw_fail.get("error"),
    "download_calls": download_calls["n"],
    "sha256": raw_fail.get("sha256"),
}
check("oserror raw retain -> lookup_failed despite download",
      raw_fail.get("collection_status") == "lookup_failed" and download_calls["n"] == 1)
check("oserror raw retain drops text", raw_fail.get("text") == "")
restore()

# Case 5: retain_bytes raises OSError on the text retain (second call),
# after _text_from_bytes succeeded.
inv_dir, txt_dir = fresh_dirs()
attach._download_bytes = fake_download
download_calls["n"] = 0
wrapper, state = raising_retain(2, OSError(28, "No space left on device"))
sam_capture.retain_bytes = wrapper
extracted = attach._text_from_bytes("SOW.txt", FILE_BODY)
text_fail = attach.extract_public_attachment_text(dict(ATTACHMENT))
observed["oserror_file_text_retain"] = {
    "independent_extraction": extracted,
    "collection_status": text_fail.get("collection_status"),
    "text": text_fail.get("text"),
    "error": text_fail.get("error"),
    "raw_capture_present": "raw_capture" in text_fail,
    "retain_calls": state["n"],
}
check("text extraction itself succeeds", extracted == "hello world")
check("oserror text retain -> unreadable", text_fail.get("collection_status") == "unreadable")
check("oserror text retain drops text", text_fail.get("text") == "")
restore()

# Base comparison: at 2d522f0 there was no retention step at all; a 200 body
# was parsed directly. Show the base fetch_notice_resources returns the
# inventory for the same mock body, to classify the failure mode as new.
base_src = os.popen(
    "git -C /Users/wtjohnson/lila-step7-052 show 2d522f0:tools/api/sam_notice_detail.py").read()
base_path = Path(__file__).parent / "base_sam_notice_detail.py"
base_path.write_text(base_src)
observed["base_has_retain"] = "retain_bytes" in base_src or "sam_capture" in base_src
check("base has no retention step", not observed["base_has_retain"])

# Vocabulary check: does any code path name a retention/storage failure?
candidate_src = (REPO / "tools/api/sam_notice_detail.py").read_text() + \
    (REPO / "tools/api/sam_attachment_text.py").read_text()
observed["retention_state_named_in_code"] = any(
    token in candidate_src for token in ("retention_failed", "storage_failed", "retain_failed"))
check("no retention failure state exists", not observed["retention_state_named_in_code"])

failed = [name for name, ok in checks if not ok]
print(json.dumps({
    "status": "FAIL" if not failed else "INFO",
    "meaning": ("FAIL = defect reproduced exactly as described" if not failed
                else "INFO = some expected observations did not hold; see unmet"),
    "unmet": failed,
    "checks": [{"name": n, "ok": ok} for n, ok in checks],
    "observed": observed,
}, indent=2, default=str))
