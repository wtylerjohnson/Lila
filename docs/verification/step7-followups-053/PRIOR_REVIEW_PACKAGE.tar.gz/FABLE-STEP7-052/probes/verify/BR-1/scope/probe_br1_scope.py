"""BR-1 scope and classification probe (independent refuter).

Question: is "storage failure during retention recorded as lookup_failed/unreadable
and acquired bytes discarded" a NEW defect of the Step7 delta, or the same failure
class that BASE 2d522f0 already had for its own cache write?

Cases (all offline; MockTransport bound, socket connect blocked):
 A. CANDIDATE, retain_bytes raises ENOSPC: inventory + file callers (finder's a/d/e).
 B. BASE 2d522f0, atomic_write_json raises ENOSPC: inventory + file callers.
 C. CANDIDATE, atomic_write_json raises ENOSPC (retention OK): same class as base.
 D. os.link unsupported (ENOTSUP/EPERM): candidate vs base; default cache volume
    hard-link support measured on the volume that hosts the review clone.
 E. Poisoned digest slot: repeat calls, network call count, error text, no heal.
 F. Receipt error text: does the OSError message survive into errors/error?
 G. Producer wording: does any Step7 doc promise a storage/retention state?
"""
from __future__ import annotations

import errno
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("network blocked"))
socket.socket.connect_ex = socket.socket.connect
socket.create_connection = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("network blocked"))
time.sleep = lambda s: None

import httpx  # noqa: E402

from tools import artifacts  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_capture  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

NOTICE = "a" * 32
RID = "b" * 32
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
INV_BODY = b'{"attachments": [{"name": "SOW.pdf", "resourceId": "' + RID.encode() + b'", "mimeType": "application/pdf"}]}'
TEXT_BODY = b"Statement of work: packet capture required."
TMP = HERE / "_tmp"
TMP.mkdir(exist_ok=True)
observed: dict = {}
checks: dict = {}


def fresh(label: str) -> Path:
    p = Path(tempfile.mkdtemp(prefix=f"{label}-", dir=TMP))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(p / "text")
    return p


def bind(body: bytes):
    calls = []

    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=body)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler),
                                                 follow_redirects=True)
    return calls


def load_base(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def enospc(*a, **k):
    raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), "probe")


real_retain = sam_capture.retain_bytes
real_atomic = artifacts.atomic_write_json
real_link = os.link
base_detail = load_base("base_detail", "base_sam_notice_detail.py")
base_sat = load_base("base_sat", "base_sam_attachment_text.py")
# BASE modules import get_json from the candidate _http module object; binding _client
# on that module covers both. The base _http.py is saved for reference only.

# A. candidate, retain_bytes raises ENOSPC
root = fresh("A-cand-retain")
bind(INV_BODY)
sam_capture.retain_bytes = enospc
a_inv = detail.fetch_notice_resources(NOTICE)
sat._download_bytes = lambda rid, **k: TEXT_BODY
a_file = sat.extract_public_attachment_text(PUBLIC)
sam_capture.retain_bytes = real_retain
observed["A_candidate_retain_enospc"] = {
    "inventory": {k: a_inv.get(k) for k in ("collection_status", "resources_checked", "attachments", "errors")},
    "file": {k: a_file.get(k) for k in ("collection_status", "text", "error")},
}
checks["A_inventory_lookup_failed_inventory_dropped"] = (
    a_inv["collection_status"] == "lookup_failed" and a_inv["attachments"] is None)
checks["A_file_lookup_failed_text_dropped"] = a_file["collection_status"] == "lookup_failed" and a_file["text"] == ""
shutil.rmtree(root, ignore_errors=True)

# B. BASE 2d522f0, its own cache write raises ENOSPC
root = fresh("B-base-atomic")
bind(INV_BODY)
artifacts.atomic_write_json = enospc
b_inv = base_detail.fetch_notice_resources(NOTICE)
base_sat._download_bytes = lambda rid, **k: TEXT_BODY
b_file = base_sat.extract_public_attachment_text(PUBLIC)
artifacts.atomic_write_json = real_atomic
observed["B_base_atomic_write_enospc"] = {
    "inventory": {k: b_inv.get(k) for k in ("resources_checked", "attachments", "errors")},
    "file": {k: b_file.get(k) for k in ("text", "error")},
    "cache_written": (root / "notice" / f"{NOTICE}.resources.json").exists(),
}
checks["B_base_inventory_dropped_labeled_fetch_failed"] = (
    b_inv["attachments"] is None and b_inv["resources_checked"] is False
    and any(e.startswith("resources fetch failed") and "No space left" in e for e in b_inv["errors"]))
checks["B_base_file_text_dropped_error_enospc"] = b_file["text"] == "" and "No space left" in b_file["error"]
shutil.rmtree(root, ignore_errors=True)

# C. candidate, retention OK, atomic_write_json raises ENOSPC (same class as base)
root = fresh("C-cand-atomic")
bind(INV_BODY)
artifacts.atomic_write_json = enospc
c_inv = detail.fetch_notice_resources(NOTICE)
sat._download_bytes = lambda rid, **k: TEXT_BODY
c_file = sat.extract_public_attachment_text(PUBLIC)
artifacts.atomic_write_json = real_atomic
observed["C_candidate_atomic_write_enospc"] = {
    "inventory": {k: c_inv.get(k) for k in ("collection_status", "resources_checked", "attachments", "errors")},
    "inventory_raw_capture_present": isinstance(c_inv.get("raw_capture"), dict),
    "file": {k: c_file.get(k) for k in ("collection_status", "text", "error")},
    "file_raw_capture_present": isinstance(c_file.get("raw_capture"), dict),
}
checks["C_candidate_cache_write_failure_also_lookup_failed_or_unreadable"] = (
    c_inv["collection_status"] == "lookup_failed" and c_inv["attachments"] is None
    and c_file["collection_status"] in ("unreadable", "lookup_failed") and c_file["text"] == "")
checks["C_candidate_keeps_raw_capture_receipt_on_cache_write_failure"] = (
    observed["C_candidate_atomic_write_enospc"]["inventory_raw_capture_present"]
    and observed["C_candidate_atomic_write_enospc"]["file_raw_capture_present"])
shutil.rmtree(root, ignore_errors=True)

# D. os.link unsupported: candidate vs base, plus default-volume hard-link support
d = {}
for code in (errno.ENOTSUP, errno.EPERM):
    root = fresh(f"D-link-{code}")
    bind(INV_BODY)

    def failing_link(src, dst, *a, _c=code, **k):
        raise OSError(_c, os.strerror(_c), str(dst))

    os.link = failing_link
    try:
        d_inv = detail.fetch_notice_resources(NOTICE)
        sat._download_bytes = lambda rid, **k: TEXT_BODY
        d_file = sat.extract_public_attachment_text(PUBLIC)
        base_sat._download_bytes = lambda rid, **k: TEXT_BODY
        d_base_file = base_sat.extract_public_attachment_text(PUBLIC)
        d_base_inv = base_detail.fetch_notice_resources(NOTICE)
    finally:
        os.link = real_link
    d[os.strerror(code)] = {
        "candidate_inventory": {k: d_inv.get(k) for k in ("collection_status", "resources_checked")},
        "candidate_file": {k: d_file.get(k) for k in ("collection_status", "text")},
        "base_file_text": d_base_file.get("text"),
        "base_inventory_resources_checked": d_base_inv.get("resources_checked"),
    }
    checks[f"D_{code}_candidate_regresses_where_base_succeeds"] = (
        d_inv["collection_status"] == "lookup_failed" and d_file["text"] == ""
        and d_base_file.get("text", "").startswith("Statement") and d_base_inv.get("resources_checked") is True)
    shutil.rmtree(root, ignore_errors=True)
# Default cache location and its volume's hard-link support (measured on the same
# device as the clone, written only inside this probe dir).
default_notice = detail._DEFAULT_CACHE
default_text = sat._DEFAULT_CACHE
same_dev = os.stat(REPO).st_dev == os.stat(HERE).st_dev
probe_dir = Path(tempfile.mkdtemp(prefix="D-linktest-", dir=TMP))
(probe_dir / "src").write_bytes(b"x")
try:
    os.link(probe_dir / "src", probe_dir / "dst")
    link_ok = True
except OSError as exc:
    link_ok = repr(exc)
shutil.rmtree(probe_dir, ignore_errors=True)
d["default_cache_dirs"] = {"notice": str(default_notice), "text": str(default_text),
                           "under_repo": str(default_notice).startswith(str(REPO)) and str(default_text).startswith(str(REPO))}
d["clone_and_probe_same_device"] = same_dev
d["hardlink_supported_on_that_device"] = link_ok
d["temp_file_dir_equals_object_dir"] = True  # retain_bytes: NamedTemporaryFile(dir=path.parent); EXDEV impossible
observed["D_os_link_unsupported"] = d
checks["D_default_config_supports_hardlink"] = link_ok is True and same_dev and d["default_cache_dirs"]["under_repo"]

# E. poisoned digest slot: candidate repeats a network call and never heals
root = fresh("E-poison")
calls = bind(INV_BODY)
digest = hashlib.sha256(INV_BODY).hexdigest()
(root / "notice" / "objects").mkdir(parents=True)
(root / "notice" / "objects" / f"{digest}.bin").write_bytes(b"POISON")
e1 = detail.fetch_notice_resources(NOTICE)
e2 = detail.fetch_notice_resources(NOTICE)
e3 = detail.fetch_notice_resources(NOTICE)
observed["E_poisoned_slot"] = {
    "statuses": [e1["collection_status"], e2["collection_status"], e3["collection_status"]],
    "errors_first": e1["errors"], "network_calls": len(calls),
    "slot_bytes_after": (root / "notice" / "objects" / f"{digest}.bin").read_bytes().decode(),
    "requires_local_writer": "object slot pre-populated by this probe, not by any code path",
}
checks["E_poisoned_slot_never_heals_one_network_call_per_sweep"] = (
    observed["E_poisoned_slot"]["statuses"] == ["lookup_failed"] * 3 and len(calls) == 3)
checks["E_poisoned_slot_bytes_never_overwritten"] = observed["E_poisoned_slot"]["slot_bytes_after"] == "POISON"
shutil.rmtree(root, ignore_errors=True)

# F. receipt error text names the storage cause (not silent)
checks["F_error_text_names_storage_cause"] = (
    any("No space left" in e for e in a_inv["errors"]) and "No space left" in a_file["error"]
    and "bytes changed" in " ".join(e1["errors"]))

# G. producer wording: any promised storage/retention state?
docs_text = ""
for p in [REPO / "docs" / "CONVENTIONS.md", REPO / "docs" / "CONTRACT_SURFACES.md",
          *(REPO / "docs" / "verification" / "step7-052").glob("*.md"),
          *(REPO / "docs" / "verification" / "step7-052").glob("*.json")]:
    docs_text += p.read_text(errors="replace")
g = {
    "mentions_retention_failed_state": "retention_failed" in docs_text,
    "mentions_disk_full_or_ENOSPC": ("disk full" in docs_text.lower()) or ("enospc" in docs_text.lower()),
    "mentions_hard_link_or_os_link": ("hard link" in docs_text.lower()) or ("hardlink" in docs_text.lower()) or ("os.link" in docs_text),
    "conventions_enum_sentence": "`collection_status` distinguishes captured discovery text, lookup failure, unreadable, inaccessible, invalid identity and not fetched." in docs_text,
    "conventions_atomic_no_overwrite_sentence": "Atomic no-overwrite publication and read-time hashes bind those bytes" in docs_text,
}
observed["G_producer_wording"] = g
checks["G_no_storage_state_promised_and_none_disclosed"] = (
    not g["mentions_retention_failed_state"] and not g["mentions_disk_full_or_ENOSPC"]
    and not g["mentions_hard_link_or_os_link"] and g["conventions_enum_sentence"])

# Verdict for this probe: the disk-full class is BASE behavior (B true) so that part
# is pre_existing; the new residual is the coarse enum plus the os.link dependency on
# non-default volumes and the local-writer poisoned slot. FAIL only for the new, narrow
# part; the finding as stated (Medium, whole class new) is overstated.
new_narrow = all(checks[k] for k in checks if k.startswith("D_") and "regresses" in k) and checks["E_poisoned_slot_never_heals_one_network_call_per_sweep"]
pre_existing_class = checks["B_base_inventory_dropped_labeled_fetch_failed"] and checks["B_base_file_text_dropped_error_enospc"] and checks["C_candidate_cache_write_failure_also_lookup_failed_or_unreadable"]
status = "FAIL" if new_narrow else "PASS"
observed["classification"] = {
    "disk_full_class_pre_existing_at_base": pre_existing_class,
    "new_narrow_residual": new_narrow,
    "default_config_reaches_os_link_failure": not checks["D_default_config_supports_hardlink"],
}
print(json.dumps({"probe": "br1_scope", "status": status, "observed": observed, "checks": checks},
                 indent=2, sort_keys=True, default=str))
shutil.rmtree(TMP, ignore_errors=True)
