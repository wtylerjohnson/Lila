"""BR-1 IMPACT lens: where does a retention-failure mislabel actually flow?

Drives each retention failure (ENOSPC on retain_bytes, poisoned digest slot) through
the production sweep stage (run_searches._enrich_sam_public_attachments), then follows
the receipts into the only consumer that reads them (triage deterministic_prefilter via
screening_evidence), into the dossier research context, and into the Assess attachment
path (fetch_notice_depth + agents.assess.ledger._attachment_state). Compares the
screening outcome with a genuine network failure. Compares base vs candidate at the
cache-write step to classify what the Step7 delta introduced.

No network (sockets blocked, httpx.MockTransport). No LLM. Writes only under this dir.
"""
from __future__ import annotations

import errno
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
BASE_DIR = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/byte-retention")
sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda seconds: None

TMP = HERE / "_tmp"
TMP.mkdir(exist_ok=True)
ROOT = Path(tempfile.mkdtemp(prefix="br1-impact-", dir=TMP))
os.environ["LILA_SAM_LEDGER"] = str(ROOT / "sam_calls.json")
os.environ["SAM_GOV_API_KEY"] = "probe-dummy-key-never-sent"

import httpx  # noqa: E402

from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from tools.api import sam_capture, sam_quota  # noqa: E402
import tools.artifacts as artifacts  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from agents.decisions.triage import deterministic_prefilter  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402
from agents.assess.ledger import _attachment_state  # noqa: E402

sam_quota.calls_today = lambda: 0
sam_quota.note_call = lambda purpose: 0

NOTICE = "a" * 32
RID = "b" * 32
INV_BODY = json.dumps({"attachments": [{"name": "SOW.txt", "resourceId": RID,
                                        "mimeType": "text/plain", "accessLevel": "public"}]}).encode()
TEXT_BODY = b"Buyer requires packet capture. Statement of work."
TERM = "packet capture"
REAL_RETAIN = sam_capture.retain_bytes
REAL_ATOMIC = artifacts.atomic_write_json
observed: dict = {}
checks: dict = {}


def fresh_case(label: str) -> Path:
    case = ROOT / label
    (case / "notice").mkdir(parents=True)
    (case / "text").mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(case / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(case / "text")
    sam_capture.retain_bytes = REAL_RETAIN
    artifacts.atomic_write_json = REAL_ATOMIC
    sat._download_bytes = lambda rid, **k: TEXT_BODY
    return case


def bind(handler):
    calls = []

    def wrapped(request):
        calls.append(str(request.url))
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(wrapped), follow_redirects=True)
    return calls


def enospc_for(dir_name: str | None):
    def failing(directory, payload):
        if dir_name is None or Path(directory).name == dir_name:
            raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(directory))
        return REAL_RETAIN(directory, payload)
    return failing


def taxonomy():
    return CapabilityTaxonomy(client_name="Probeco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


def run_stage():
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy(), None, limit=8)
    receipt = stats["attachment_record_receipts"][NOTICE]
    return candidate, rows, stats, receipt


def screen(candidate, receipts):
    row = json.loads(candidate.model_dump_json())
    _, ruled, prefilter_receipt = deterministic_prefilter([row], taxonomy(), attachment_receipts=receipts)
    record = (prefilter_receipt.get("screening_records") or prefilter_receipt.get("records") or {})
    evidence = record.get(NOTICE) if isinstance(record, dict) else None
    disposition = ruled.get(NOTICE)
    return {"attachment_status": (evidence or {}).get("attachment_status"),
            "attachment_errors": (evidence or {}).get("attachment_errors"),
            "screen_state": (evidence or {}).get("screen_state"),
            "disposition": disposition,
            "receipt_keys": sorted(prefilter_receipt.keys())}


def summarize(receipt: dict) -> dict:
    inv = receipt.get("inventory_receipt") or {}
    return {"status": receipt.get("status"),
            "inventory_collection_status": inv.get("collection_status"),
            "inventory_raw_capture": inv.get("raw_capture"),
            "errors": receipt.get("errors"),
            "files": [{k: f.get(k) for k in ("resource_id", "status", "reason", "raw_capture", "text_capture")}
                      for f in receipt.get("files") or []]}


# S0. Baseline, nothing fails.
case = fresh_case("s0-baseline")
bind(lambda request: httpx.Response(200, content=INV_BODY))
candidate, rows, stats, receipt = run_stage()
observed["s0_baseline"] = {**summarize(receipt), "rows": len(rows), "enriched": stats["attachment_enriched"],
                           "row_has_attachment_evidence": bool(rows and rows[0]["raw_payload"].get("attachment_evidence"))}
observed["s0_baseline"]["screening"] = screen(candidate, stats["attachment_record_receipts"])
checks["s0_baseline_captures_and_enriches"] = (
    receipt["status"] == "DISCOVERY_TEXT_CAPTURED" and len(rows) == 1 and stats["attachment_relevant"] == 1)

# S1. Inventory retention fails (ENOSPC inside the HTTP observer).
case = fresh_case("s1-inventory-enospc")
sam_capture.retain_bytes = enospc_for("notice")
calls = bind(lambda request: httpx.Response(200, content=INV_BODY))
candidate, rows, stats, receipt = run_stage()
s1 = {**summarize(receipt), "rows": len(rows), "enriched": stats["attachment_enriched"],
      "network_calls": len(calls), "cache_written": (case / "notice" / f"{NOTICE}.resources.json").exists(),
      "stage_errors": stats["attachment_errors"]}
s1["screening"] = screen(candidate, stats["attachment_record_receipts"])
observed["s1_inventory_retention_enospc"] = s1
checks["s1_receipt_says_lookup_failed"] = s1["inventory_collection_status"] == "lookup_failed"
checks["s1_error_text_names_local_errno_not_sam"] = any("No space left on device" in e for e in s1["errors"])
checks["s1_row_not_enriched_no_wrong_evidence"] = len(rows) == 0 and stats["attachment_enriched"] == 0
checks["s1_screening_is_attachment_unavailable_conservative"] = (
    s1["screening"]["attachment_status"] == "INVENTORY_UNAVAILABLE")

# S1b. Genuine network failure for comparison.
case = fresh_case("s1b-network-failure")


def connect_error(request):
    raise httpx.ConnectError("simulated upstream failure", request=request)


bind(connect_error)
candidate, rows, stats, receipt = run_stage()
s1b = {**summarize(receipt), "rows": len(rows)}
s1b["screening"] = screen(candidate, stats["attachment_record_receipts"])
observed["s1b_genuine_network_failure"] = s1b
checks["s1_vs_s1b_identical_record_status_and_screening"] = (
    s1["status"] == s1b["status"] == "INVENTORY_UNAVAILABLE"
    and s1["inventory_collection_status"] == s1b["inventory_collection_status"]
    and s1["screening"]["attachment_status"] == s1b["screening"]["attachment_status"]
    and s1["screening"]["disposition"] == s1b["screening"]["disposition"])

# S2. File RAW retention fails (inventory fine).
case = fresh_case("s2-file-raw-enospc")
sam_capture.retain_bytes = enospc_for("text")
bind(lambda request: httpx.Response(200, content=INV_BODY))
candidate, rows, stats, receipt = run_stage()
s2 = {**summarize(receipt), "rows": len(rows), "enriched": stats["attachment_enriched"],
      "stage_errors": stats["attachment_errors"]}
s2["screening"] = screen(candidate, stats["attachment_record_receipts"])
row_dict = json.loads(candidate.model_dump_json())
s2["dossier_research_context"] = _attachment_research_context(
    row_dict, {"id": NOTICE, "attachment_inventory_hash": receipt["inventory_receipt"]["attachment_inventory_hash"]})
observed["s2_file_raw_retention_enospc"] = s2
checks["s2_file_status_lookup_failed_despite_download"] = s2["files"][0]["status"] == "lookup_failed"
checks["s2_file_reason_names_local_errno"] = "No space left on device" in str(s2["files"][0]["reason"])
checks["s2_record_TEXT_UNAVAILABLE_row_not_enriched"] = s2["status"] == "TEXT_UNAVAILABLE" and len(rows) == 0
checks["s2_dossier_context_is_none_no_wrong_evidence"] = s2["dossier_research_context"] is None
checks["s2_screening_attachment_unavailable"] = s2["screening"]["attachment_status"] == "TEXT_UNAVAILABLE"

# S3. File TEXT retention fails (raw retained, parse succeeded).
case = fresh_case("s3-file-text-enospc")
count = {"text": 0}


def second_text_fails(directory, payload):
    if Path(directory).name == "text":
        count["text"] += 1
        if count["text"] == 2:
            raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(directory))
    return REAL_RETAIN(directory, payload)


sam_capture.retain_bytes = second_text_fails
bind(lambda request: httpx.Response(200, content=INV_BODY))
candidate, rows, stats, receipt = run_stage()
s3 = {**summarize(receipt), "rows": len(rows), "enriched": stats["attachment_enriched"]}
observed["s3_file_text_retention_enospc"] = s3
checks["s3_file_status_unreadable_although_parsed"] = s3["files"][0]["status"] == "unreadable"
checks["s3_raw_capture_kept_text_capture_absent"] = (
    s3["files"][0]["raw_capture"] is not None and s3["files"][0]["text_capture"] is None)
checks["s3_row_not_enriched"] = len(rows) == 0

# S4. Poisoned digest slot for the inventory: two sweeps, never heals.
case = fresh_case("s4-poisoned-inventory-slot")
digest = hashlib.sha256(INV_BODY).hexdigest()
(case / "notice" / "objects").mkdir(parents=True)
(case / "notice" / "objects" / f"{digest}.bin").write_bytes(b"POISON")
calls = bind(lambda request: httpx.Response(200, content=INV_BODY))
_, rows_a, stats_a, receipt_a = run_stage()
_, rows_b, stats_b, receipt_b = run_stage()
s4 = {"first": summarize(receipt_a), "second": summarize(receipt_b), "network_calls": len(calls),
      "cache_written": (case / "notice" / f"{NOTICE}.resources.json").exists(),
      "slot_still_poisoned": (case / "notice" / "objects" / f"{digest}.bin").read_bytes() == b"POISON"}
observed["s4_poisoned_inventory_slot"] = s4
checks["s4_persists_across_sweeps_with_fresh_network_call_each"] = (
    receipt_a["status"] == receipt_b["status"] == "INVENTORY_UNAVAILABLE" and len(calls) == 2)
checks["s4_error_text_reads_as_sam_side_change"] = any(
    "retained SAM bytes changed" in e for e in receipt_a["errors"])
checks["s4_requires_external_writer_object_never_partially_published"] = True  # retain_bytes: temp+fsync+link, FileExistsError never overwrites

# S5. Assess path: fetch_notice_depth never calls retain_bytes.
case = fresh_case("s5-assess-depth-path")
sam_capture.retain_bytes = enospc_for(None)


def depth_handler(request):
    if "noticedesc" in str(request.url):
        return httpx.Response(200, json={"description": "<p>Packet capture PWS.</p>"})
    return httpx.Response(200, content=INV_BODY)


bind(depth_handler)
depth = detail.fetch_notice_depth(NOTICE)
source_depth = {"notice_id": NOTICE, "retrieved_at": depth.get("retrieved_at"),
                "description": depth.get("description"), "attachments": depth.get("attachments"),
                "description_checked": bool(depth.get("description_checked")),
                "resources_checked": bool(depth.get("resources_checked")),
                "resources_schema": depth.get("resources_schema"),
                "attachment_inventory_count": depth.get("attachment_inventory_count"),
                "attachment_inventory_hash": depth.get("attachment_inventory_hash"),
                "errors": depth.get("errors") or []}
attachments_checked, gap = _attachment_state(source_depth)
observed["s5_assess_depth_with_retain_always_failing"] = {
    "resources_checked": depth.get("resources_checked"), "attachments": depth.get("attachments"),
    "errors": depth.get("errors"), "raw_capture_key_present": "raw_capture" in depth,
    "assess_attachments_checked": attachments_checked, "assess_gap": gap}
checks["s5_assess_inventory_unaffected_by_retention_failure"] = (
    depth.get("resources_checked") is True and len(depth.get("attachments") or []) == 1
    and not depth.get("errors") and attachments_checked is False and "have not been downloaded and reviewed" in (gap or ""))


def count_refs(paths, needles):
    total = {}
    for pattern in paths:
        for path in REPO.glob(pattern):
            text = path.read_text(errors="replace")
            for needle in needles:
                total[needle] = total.get(needle, 0) + text.count(needle)
    return total


observed["s5_static_refs_in_trusted_surfaces"] = count_refs(
    ["agents/assess/*.py", "agents/golden_press/*.py", "agents/reports/*.py", "ui/server.py", "run_dossiers.py"],
    ["collection_status", "raw_capture", "attachment_record_receipts", "lookup_failed"])
checks["s5_no_trusted_surface_reads_collection_status_or_receipts"] = all(
    v == 0 for v in observed["s5_static_refs_in_trusted_surfaces"].values())

# S6. Base vs candidate: storage failure at the CACHE-WRITE step (inventory).
case = fresh_case("s6-cache-write-enospc-inventory")


def atomic_enospc(path, payload):
    raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC), str(path))


artifacts.atomic_write_json = atomic_enospc
bind(lambda request: httpx.Response(200, content=INV_BODY))
cand_inv = detail.fetch_notice_resources(NOTICE)
spec = importlib.util.spec_from_file_location("base_detail", BASE_DIR / "base_sam_notice_detail.py")
base_detail = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_detail)
base_inv = base_detail.fetch_notice_resources(NOTICE)
observed["s6_cache_write_enospc_inventory"] = {
    "candidate": {k: cand_inv.get(k) for k in ("collection_status", "resources_checked", "errors")},
    "candidate_attachments_kept": bool(cand_inv.get("attachments")),
    "base": {k: base_inv.get(k) for k in ("resources_checked", "errors")},
    "base_attachments_kept": bool(base_inv.get("attachments"))}
checks["s6_both_keep_inventory_when_only_cache_write_fails"] = (
    bool(cand_inv.get("attachments")) and bool(base_inv.get("attachments")))
# Candidate with the OBSERVER failing loses the inventory that base would have kept under the same disk-full.
artifacts.atomic_write_json = REAL_ATOMIC
sam_capture.retain_bytes = enospc_for(None)
cand_obs = detail.fetch_notice_resources(NOTICE)
checks["s6_observer_failure_is_new_inventory_loss_point"] = cand_obs.get("attachments") is None and bool(base_inv.get("attachments"))

# S7. Base vs candidate: storage failure at the cache-write step (file text).
case = fresh_case("s7-cache-write-enospc-file")
artifacts.atomic_write_json = atomic_enospc
public = {"resource_id": RID, "name": "SOW.txt", "access_level": "public", "access_status": "public",
          "export_controlled": "0", "explicit_access": "0"}
cand_file = sat.extract_public_attachment_text(public)
spec2 = importlib.util.spec_from_file_location("base_sat", BASE_DIR / "base_sam_attachment_text.py")
base_sat = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(base_sat)
base_sat._download_bytes = lambda rid, **k: TEXT_BODY
base_file = base_sat.extract_public_attachment_text(public)
observed["s7_cache_write_enospc_file"] = {
    "candidate": {k: cand_file.get(k) for k in ("collection_status", "text", "error")},
    "base": {k: base_file.get(k) for k in ("text", "error")}}
checks["s7_base_also_drops_text_on_cache_write_failure_pre_existing_yield_loss"] = base_file.get("text") == ""
checks["s7_candidate_labels_captured_discovery_only_with_empty_text_adjacent_inconsistency"] = (
    cand_file.get("collection_status") == "captured_discovery_only" and cand_file.get("text") == "")

# S8. Environment: does the operator's volume support os.link? Is EXDEV reachable?
artifacts.atomic_write_json = REAL_ATOMIC
sam_capture.retain_bytes = REAL_RETAIN
probe_dir = ROOT / "s8-link"
probe_dir.mkdir()
(probe_dir / "src").write_bytes(b"x")
try:
    os.link(probe_dir / "src", probe_dir / "dst")
    link_ok = True
except OSError as exc:
    link_ok = repr(exc)
observed["s8_environment"] = {
    "os_link_supported_on_review_volume": link_ok,
    "default_notice_cache": str(detail._DEFAULT_CACHE), "default_text_cache": str(sat._DEFAULT_CACHE),
    "exdev_reachable": False,
    "exdev_note": "retain_bytes creates the temp file in path.parent, so temp and target always share a directory; EXDEV cannot arise"}
checks["s8_default_volume_supports_hardlinks"] = link_ok is True

# Verdict for this lens: mislabel confirmed; reach confined to receipts and yield.
mislabel = (checks["s1_receipt_says_lookup_failed"] and checks["s2_file_status_lookup_failed_despite_download"]
            and checks["s3_file_status_unreadable_although_parsed"])
contained = (checks["s1_row_not_enriched_no_wrong_evidence"] and checks["s2_dossier_context_is_none_no_wrong_evidence"]
             and checks["s5_assess_inventory_unaffected_by_retention_failure"]
             and checks["s5_no_trusted_surface_reads_collection_status_or_receipts"]
             and checks["s1_vs_s1b_identical_record_status_and_screening"])
observed["impact_summary"] = {
    "mislabel_confirmed": mislabel,
    "reach": "adapter return dict; saved sweep results.sam_census.attachment_record_receipts[*].inventory_receipt.collection_status and .files[*].status/reason; results.sam_census.attachment_errors; triage screening attachment_status/attachment_errors (record-level only)",
    "not_reached": "Assess ledger (reads fetch_notice_depth source_depth, no retain_bytes), LeadRow/BID_NOW, dossier research context (row never enriched), eight-slot product copy, UI inventory review",
    "confined_to_trusted_surfaces": contained,
    "yield_effect": "candidate row not enriched; base kept the inventory under the same disk-full because base parsed before caching; base also dropped file text on cache-write failure",
    "trigger_conditions": "ENOSPC or non-hardlink filesystem at the cache dir (environmental, non-default volume) or a locally poisoned objects/<sha>.bin (operator-owned cache, external writer required)",
}
status = "FAIL" if mislabel else "PASS"
print(json.dumps({"probe": "br1_impact_flow", "status": status, "observed": observed, "checks": checks},
                 indent=2, sort_keys=True, default=str))
shutil.rmtree(ROOT, ignore_errors=True)
