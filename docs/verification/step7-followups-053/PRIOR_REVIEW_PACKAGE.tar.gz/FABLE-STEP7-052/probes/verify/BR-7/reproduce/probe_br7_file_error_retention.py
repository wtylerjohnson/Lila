"""BR-7 independent reproduction: file download error bodies / partial bytes are not retained.

Claim under test: _download_bytes calls raise_for_status before reading the body, so
403/404/500 file responses retain nothing (403 -> inaccessible, 404/500 -> lookup_failed);
over-cap declared length and mid-stream resets drop partial bytes. Positive downloads
(including parse failures) DO carry raw_capture. Inventories (fetch_notice_resources)
DO retain error bodies, giving the measured asymmetry.

No network: socket.connect is blocked, httpx.HTTPTransport is replaced with a
MockTransport for the file path, and _http._client is mocked for the inventory path.
Writes only inside a temp dir under this probe directory.
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

# Small byte cap so over-cap scenarios are cheap; must be set before import.
CAP = 2048
os.environ["LILA_SAM_ATTACHMENT_MAX_BYTES"] = str(CAP)

TMP = Path(tempfile.mkdtemp(prefix="br7_", dir=str(PROBE_DIR)))
TEXT_DIR = TMP / "attachment_text"
NOTICE_DIR = TMP / "notice_cache"
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(NOTICE_DIR)


def _no_connect(*_a, **_k):
    raise AssertionError("network connect attempted; probe must be offline")


socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

assert sat.MAX_ATTACHMENT_BYTES == CAP, sat.MAX_ATTACHMENT_BYTES

RID = "a" * 32
observed: dict = {"cap": CAP, "cases": {}}
failures: list[str] = []
current: dict = {}


class _Reset(httpx.SyncByteStream):
    """Yield some bytes then die mid-stream like a connection reset."""

    def __init__(self, first: bytes):
        self._first = first

    def __iter__(self):
        yield self._first
        raise httpx.ReadError("connection reset by peer")


class _Chunks(httpx.SyncByteStream):
    def __init__(self, chunks: list[bytes]):
        self._chunks = chunks

    def __iter__(self):
        yield from self._chunks


def _handler(request: httpx.Request) -> httpx.Response:
    current["url"] = str(request.url)
    kind = current["kind"]
    if kind == "status":
        return httpx.Response(current["status"], content=current["body"], request=request)
    if kind == "declared_over_cap":
        return httpx.Response(200, headers={"content-length": str(CAP * 10)},
                              stream=_Chunks([b"tiny"]), request=request)
    if kind == "midstream_reset":
        return httpx.Response(200, stream=_Reset(current["body"]), request=request)
    if kind == "stream_over_cap":
        return httpx.Response(200, stream=_Chunks([b"x" * 1024] * 3), request=request)
    if kind == "ok":
        return httpx.Response(200, content=current["body"], request=request)
    raise AssertionError(kind)


_real_transport = httpx.HTTPTransport
httpx.HTTPTransport = lambda **_kw: httpx.MockTransport(_handler)  # type: ignore[assignment]


def _objects(directory: Path) -> list[str]:
    objs = directory / "objects"
    if not objs.exists():
        return []
    return sorted(p.name for p in objs.iterdir())


def _attachment(name: str) -> dict:
    return {"resource_id": RID, "name": name, "type": "file", "size": 10,
            "access_level": "public", "export_controlled": "false",
            "explicit_access": "false",
            "source_url": f"https://sam.gov/x/{RID}"}


def _run_file_case(label: str, name: str, expect_status: str, expect_raw: bool, **cfg):
    # fresh cache per case so no earlier success is reused
    if TEXT_DIR.exists():
        shutil.rmtree(TEXT_DIR)
    current.clear()
    current.update(cfg)
    result = sat.extract_public_attachment_text(_attachment(name))
    objs = _objects(TEXT_DIR)
    rec = {
        "collection_status": result.get("collection_status"),
        "raw_capture_present": "raw_capture" in result,
        "text_capture_present": "text_capture" in result,
        "sha256": result.get("sha256"),
        "error": result.get("error"),
        "objects_in_cache": objs,
        "cache_json_written": (TEXT_DIR / f"{RID}.json").exists(),
        "request_url_host": httpx.URL(current.get("url", "https://none/")).host,
    }
    if expect_raw:
        try:
            raw = read_retained(TEXT_DIR, result["raw_capture"])
            rec["raw_roundtrip_equal"] = raw == cfg.get("body")
        except Exception as exc:  # noqa: BLE001
            rec["raw_roundtrip_equal"] = f"ERR {exc}"
    observed["cases"][label] = rec
    if rec["collection_status"] != expect_status:
        failures.append(f"{label}: status {rec['collection_status']} != {expect_status}")
    if rec["raw_capture_present"] != expect_raw:
        failures.append(f"{label}: raw_capture_present {rec['raw_capture_present']} != {expect_raw}")
    if not expect_raw and objs:
        failures.append(f"{label}: objects retained despite no raw_capture: {objs}")
    if expect_raw and rec.get("raw_roundtrip_equal") is not True:
        failures.append(f"{label}: retained bytes do not round trip")
    return result


# Negative cases: nothing retained
_run_file_case("download_http_403", "sow.txt", "inaccessible", False,
               kind="status", status=403, body=b"<html>Forbidden: access denied</html>")
_run_file_case("download_http_401", "sow.txt", "inaccessible", False,
               kind="status", status=401, body=b"unauthorized")
_run_file_case("download_http_404", "sow.txt", "lookup_failed", False,
               kind="status", status=404, body=b'{"error":"resource not found"}')
_run_file_case("download_http_500", "sow.txt", "lookup_failed", False,
               kind="status", status=500, body=b"internal server error body")
_run_file_case("download_declared_over_cap", "sow.txt", "lookup_failed", False,
               kind="declared_over_cap")
_run_file_case("download_midstream_reset", "sow.txt", "lookup_failed", False,
               kind="midstream_reset", body=b"partial requirement bytes ")
_run_file_case("download_stream_over_cap_undeclared", "sow.txt", "lookup_failed", False,
               kind="stream_over_cap")

# Positive cases: raw_capture present even when parsing fails
_run_file_case("positive_txt", "sow.txt", "captured_discovery_only", True,
               kind="ok", body=b"Contractor shall provide network monitoring.")
_run_file_case("unreadable_docx", "sow.docx", "unreadable", True,
               kind="ok", body=b"definitely not a zip container")
_run_file_case("empty_text_txt", "sow.txt", "unreadable", True,
               kind="ok", body=b"   \n\t  \n")
_run_file_case("unsupported_type_exe", "tool.exe", "unreadable", True,
               kind="ok", body=b"MZ binary payload")

# Inventory comparator: does fetch_notice_resources retain a 403 error body?
inv_body = b"<html>Forbidden inventory body</html>"


def _inv_handler(request: httpx.Request) -> httpx.Response:
    return httpx.Response(403, content=inv_body, request=request)


_orig_client = _http._client
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(_inv_handler))
try:
    inv = detail.fetch_notice_resources("b" * 32)
finally:
    _http._client = _orig_client
inv_rec = {"collection_status": inv.get("collection_status"),
           "raw_capture_present": "raw_capture" in inv,
           "http_status": (inv.get("raw_capture") or {}).get("http_status"),
           "complete": (inv.get("raw_capture") or {}).get("complete"),
           "objects_in_cache": _objects(NOTICE_DIR)}
try:
    inv_rec["raw_roundtrip_equal"] = read_retained(NOTICE_DIR, inv["raw_capture"]) == inv_body
except Exception as exc:  # noqa: BLE001
    inv_rec["raw_roundtrip_equal"] = f"ERR {exc}"
observed["inventory_http_403"] = inv_rec
if not (inv_rec["raw_capture_present"] and inv_rec["raw_roundtrip_equal"] is True
        and inv_rec["collection_status"] == "lookup_failed"):
    failures.append(f"inventory 403 did not retain error body as claimed: {inv_rec}")

# Static confirmation of the mechanism: raise_for_status precedes any body read.
src = (REPO / "tools/api/sam_attachment_text.py").read_text()
dl = src[src.index("def _download_bytes"):src.index("def _pdf_text_local")]
observed["mechanism"] = {
    "raise_for_status_index": dl.index("raise_for_status"),
    "iter_bytes_index": dl.index("iter_bytes"),
    "raise_for_status_before_body_read": dl.index("raise_for_status") < dl.index("iter_bytes"),
    "retain_bytes_called_inside_download": "retain_bytes" in dl,
}
observed["doc_claims"] = {
    "conventions_inventory_error_body": "retain partial/error bodies separately from complete recognized responses" in (REPO / "docs/CONVENTIONS.md").read_text(),
    "conventions_file_parse_failure": "File extraction retains the acquired bytes/hash/clock even when parsing fails." in (REPO / "docs/CONVENTIONS.md").read_text(),
    "producer_test_asserts_no_raw_on_403": "assert 'raw_capture' not in result" in (REPO / "tests/test_step7_evidence_collection.py").read_text(),
}
observed["base_has_retention"] = None  # sam_capture.py is new in the delta; base lacks raw_capture entirely

httpx.HTTPTransport = _real_transport  # type: ignore[assignment]
shutil.rmtree(TMP, ignore_errors=True)

status = "INFO" if not failures else "FAIL"
print(json.dumps({"probe": "BR-7 reproduction: file error/partial bytes not retained",
                  "status": status,
                  "meaning": ("INFO: asymmetry reproduced exactly as described and it matches the doc scope; "
                              "FAIL means the finding's described behavior did not reproduce"),
                  "failures": failures, "observed": observed}, indent=2, sort_keys=True))
