"""BR-7 refutation probe: file download error/partial body custody, scope and kind.

Questions answered, each with a measured check:
  1. Is `_download_bytes` changed by the Step7 delta? (base 2d522f0 vs candidate, AST-normalized)
  2. Candidate file lane: 403/404/500, over-cap declared length, mid-stream reset:
     is anything retained, what state, is there a structured http_status?
  3. Candidate inventory lane: 403 body retained with http_status/complete (asymmetry real?)
  4. Positive control: 200 body that fails parse keeps raw_capture (doc claim honored?)
  5. Base file lane under the same 403: what did base retain? (regression or inherited?)
  6. Doc scan: does any producer sentence claim error/partial body retention for FILES?
     Which sentences scope it to inventories? Does the producer test pin the 403 shape?
Writes only under this probe directory. No network (socket connect blocked). No LLM.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
BASE = "2d522f0362e656e029986344d47e2e06b86a58f8"
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")

tmp_root = Path(tempfile.mkdtemp(prefix="br7-", dir=PROBE_DIR))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp_root / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp_root / "text")
text_dir = tmp_root / "text"

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

observed: dict = {}
checks: dict = {}
RID = "f" * 32
NOTICE = "a" * 32


def public(name, rid=RID):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def clean(obj):
    """Strip em-dash characters from any string before it reaches the log."""
    if isinstance(obj, str):
        return obj.replace("\u2014", "-").replace("\u2013", "-")
    if isinstance(obj, dict):
        return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    return obj


# 1. Is _download_bytes touched by the delta?
base_src = subprocess.run(
    ["git", "-C", str(REPO), "show", f"{BASE}:tools/api/sam_attachment_text.py"],
    check=True, capture_output=True, text=True).stdout
cand_src = (REPO / "tools/api/sam_attachment_text.py").read_text()


def func_dump(src: str, name: str) -> str:
    for node in ast.parse(src).body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return ast.dump(node, include_attributes=False)
    return ""


observed["download_bytes_identical_base_vs_candidate"] = (
    func_dump(base_src, "_download_bytes") == func_dump(cand_src, "_download_bytes"))
checks["download_bytes_unchanged_by_delta"] = observed["download_bytes_identical_base_vs_candidate"]
base_copy = PROBE_DIR / "base_sam_attachment_text.py"
base_copy.write_text(base_src)

# 2. Candidate file lane through the REAL _download_bytes with a mocked httpx.Client.
real_client = httpx.Client


def with_file_transport(handler, fn=sat.extract_public_attachment_text, module=sat):
    class MockClient(httpx.Client):
        def __init__(self, *a, **k):
            k.pop("transport", None)
            super().__init__(*a, transport=httpx.MockTransport(handler), **k)

    module.httpx.Client = MockClient
    try:
        return fn(public("SOW.pdf"))
    finally:
        module.httpx.Client = real_client


def summarize(res: dict) -> dict:
    return {
        "collection_status": res.get("collection_status"),
        "raw_capture_present": "raw_capture" in res,
        "structured_http_status_key": any(k for k in res if "http_status" in k),
        "sha256": res.get("sha256"),
        "error_head": str(res.get("error", ""))[:90],
        "keys": sorted(res.keys()),
    }


file_lane = {}
for status in (403, 404, 500):
    res = with_file_transport(lambda req, s=status: httpx.Response(
        s, content=f"denied body {s}".encode(), headers={"content-type": "text/html"}))
    file_lane[f"http_{status}"] = summarize(res)
    checks[f"file_http_{status}_nothing_retained"] = "raw_capture" not in res and res.get("sha256") == ""
checks["file_403_is_inaccessible"] = file_lane["http_403"]["collection_status"] == "inaccessible"
checks["file_404_500_are_lookup_failed"] = all(
    file_lane[f"http_{s}"]["collection_status"] == "lookup_failed" for s in (404, 500))
checks["file_error_status_only_in_error_string"] = all(
    not v["structured_http_status_key"] and str(s) in v["error_head"]
    for s, v in ((403, file_lane["http_403"]), (404, file_lane["http_404"]), (500, file_lane["http_500"])))

big = b"%PDF" + b"x" * sat.MAX_ATTACHMENT_BYTES
res = with_file_transport(lambda req: httpx.Response(200, content=big))
file_lane["over_cap_declared"] = summarize(res)
checks["file_over_cap_nothing_retained"] = "raw_capture" not in res and res["collection_status"] == "lookup_failed"


class Reset(httpx.SyncByteStream):
    def __iter__(self):
        yield b"%PDF-1.4 partial prefix"
        raise httpx.ReadError("connection reset")

    def close(self):
        pass


res = with_file_transport(lambda req: httpx.Response(200, stream=Reset()))
file_lane["midstream_reset"] = summarize(res)
checks["file_midstream_partial_nothing_retained"] = "raw_capture" not in res and res["collection_status"] == "lookup_failed"

# Streamed over-cap without content-length: partial chunks are read then dropped.
class Endless(httpx.SyncByteStream):
    def __iter__(self):
        for _ in range((sat.MAX_ATTACHMENT_BYTES // 65536) + 2):
            yield b"y" * 65536

    def close(self):
        pass


res = with_file_transport(lambda req: httpx.Response(200, stream=Endless()))
file_lane["over_cap_streamed_no_length"] = summarize(res)
checks["file_streamed_over_cap_nothing_retained"] = "raw_capture" not in res and res["collection_status"] == "lookup_failed"
observed["candidate_file_lane"] = file_lane

# 3. Candidate inventory lane: 403 body IS retained with http_status and complete flag.
_http._client = lambda timeout: httpx.Client(
    transport=httpx.MockTransport(lambda req: httpx.Response(403, content=b"access denied inventory")),
    follow_redirects=True)
inv = detail.fetch_notice_resources(NOTICE)
cap = inv.get("raw_capture") or {}
observed["candidate_inventory_403"] = clean({
    "collection_status": inv.get("collection_status"),
    "raw_capture": cap,
    "errors": inv.get("errors"),
})
checks["inventory_403_body_retained_with_status"] = (
    inv.get("collection_status") == "lookup_failed"
    and cap.get("http_status") == 403 and cap.get("complete") is True
    and read_retained(tmp_root / "notice", cap) == b"access denied inventory")
checks["asymmetry_real_inventory_yes_file_no"] = (
    checks["inventory_403_body_retained_with_status"] and checks["file_http_403_nothing_retained"])

# 4. Positive control: 200 body that fails to parse keeps raw_capture (doc claim honored).
junk = b"%PDF-1.7 this is not a parseable pdf"
res = with_file_transport(lambda req: httpx.Response(200, content=junk))
observed["candidate_200_parse_failure"] = summarize(res)
checks["file_200_parse_failure_bytes_retained"] = (
    res["collection_status"] == "unreadable" and read_retained(text_dir, res["raw_capture"]) == junk
    and res["sha256"] == hashlib.sha256(junk).hexdigest())

# 5. Base file lane under the same 403 and same parse failure: what did base retain?
spec = importlib.util.spec_from_file_location("base_sat", base_copy)
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp_root / "text_base")
base_403 = with_file_transport(lambda req: httpx.Response(403, content=b"denied"),
                               fn=base_sat.extract_public_attachment_text, module=base_sat)
base_parse = with_file_transport(lambda req: httpx.Response(200, content=junk),
                                 fn=base_sat.extract_public_attachment_text, module=base_sat)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text_dir)
observed["base_file_lane"] = {"http_403": summarize(base_403), "parse_failure_200": summarize(base_parse),
                              "base_objects_dir_exists": (tmp_root / "text_base" / "objects").exists()}
checks["base_retained_nothing_on_403"] = "raw_capture" not in base_403 and base_403.get("sha256") == ""
checks["base_retained_nothing_even_on_parse_failure"] = (
    "raw_capture" not in base_parse and base_parse.get("sha256") == ""
    and "collection_status" not in base_parse)
checks["delta_strictly_widens_retention_no_regression"] = (
    checks["base_retained_nothing_on_403"] and checks["base_retained_nothing_even_on_parse_failure"]
    and checks["file_200_parse_failure_bytes_retained"])

# 6. Doc scan: any sentence claiming error/partial body retention for FILES?
doc_paths = [REPO / "docs/CONVENTIONS.md", REPO / "docs/CONTRACT_SURFACES.md"]
doc_paths += sorted((REPO / "docs/verification/step7-052").glob("*.md"))
doc_paths += [REPO / "docs/verification/step7-052/PRIOR_FOLLOWUPS.json"]
scoping_sentences = []
file_error_body_claims = []
out_of_section_hits = []


def step7_section(text: str) -> str:
    """Only the Step7 (052) section of a repo-wide doc; other sections describe other collectors."""
    match = re.search(r"^## Step7[^\n]*\n(.*?)(?=^## |\Z)", text, flags=re.S | re.M)
    return match.group(1) if match else ""


for path in doc_paths:
    full = path.read_text(errors="replace")
    in_step7_dir = "verification/step7-052" in str(path)
    text = full if in_step7_dir else step7_section(full)
    if not in_step7_dir:
        # Record any hit outside the Step7 section with its owning header, for context only.
        header = None
        for line in full.splitlines():
            if line.startswith("## "):
                header = line
            low = line.casefold()
            if ("partial" in low or "error bod" in low) and "retain" in low and "Step7" not in (header or ""):
                out_of_section_hits.append({"file": str(path.relative_to(REPO)), "section": header, "line": line.strip()[:200]})
    for sentence in re.split(r"(?<=[.])\s+", re.sub(r"\s+", " ", text)):
        low = sentence.casefold()
        if ("partial" in low or "error bod" in low) and "retain" in low:
            scoping_sentences.append({"file": str(path.relative_to(REPO)), "sentence": sentence.strip()[:300]})
            if ("inventor" not in low) and ("file" in low or "attachment" in low or "download" in low):
                file_error_body_claims.append({"file": str(path.relative_to(REPO)), "sentence": sentence.strip()[:300]})
        if "even when parsing fails" in low or "after parse failure" in low or "acquired hash/clock" in low:
            scoping_sentences.append({"file": str(path.relative_to(REPO)), "sentence": sentence.strip()[:300]})
observed["producer_scoping_sentences"] = clean(scoping_sentences)
observed["producer_sentences_claiming_file_error_body_retention"] = clean(file_error_body_claims)
observed["hits_outside_step7_sections_context_only"] = clean(out_of_section_hits)
checks["no_doc_claims_file_error_or_partial_body_retention"] = not file_error_body_claims
checks["conventions_scopes_partial_error_retention_to_inventories"] = any(
    "public inventories" in s["sentence"].casefold() and "partial/error bodies" in s["sentence"].casefold()
    for s in scoping_sentences)
checks["conventions_scopes_file_retention_to_acquired_bytes"] = any(
    "acquired bytes/hash/clock even when parsing fails" in s["sentence"].casefold() for s in scoping_sentences)
checks["prepatch_scopes_repair_to_after_parse_failure"] = any(
    s["file"].endswith("PRE_PATCH_REPORT.md") and "after parse failure" in s["sentence"].casefold()
    for s in scoping_sentences)

test_src = (REPO / "tests/test_step7_evidence_collection.py").read_text().splitlines()
pin = [i + 1 for i, line in enumerate(test_src) if "'raw_capture' not in result" in line]
observed["producer_test_pins_403_no_raw_capture_at_lines"] = pin
checks["producer_test_pins_file_403_shape"] = bool(pin)

# Residual register: any entry naming file error-body custody?
followups = (REPO / "docs/verification/step7-052/PRIOR_FOLLOWUPS.json").read_text().casefold()
observed["prior_followups_mentions_file_error_body"] = ("error bod" in followups)
checks["residual_register_silent_on_file_error_bodies"] = not observed["prior_followups_mentions_file_error_body"]

observed["text_objects_written"] = sorted(p.name for p in (text_dir / "objects").glob("*")) if (text_dir / "objects").exists() else []
checks["only_the_200_parse_failure_object_written_in_file_lane"] = (
    observed["text_objects_written"] == [hashlib.sha256(junk).hexdigest() + ".bin"])

status = "INFO" if all(checks.values()) else "FAIL"
print(json.dumps(clean({"probe": "br7_error_body_custody", "status": status,
                        "observed": observed, "checks": checks}),
                 indent=2, sort_keys=True, default=str))
shutil.rmtree(tmp_root, ignore_errors=True)
