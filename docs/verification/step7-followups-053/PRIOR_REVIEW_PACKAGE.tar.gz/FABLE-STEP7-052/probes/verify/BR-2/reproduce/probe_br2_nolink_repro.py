"""BR-2 independent reproduction: retain_bytes on a filesystem without hardlinks.

Runs the candidate inventory collector (sam_notice_detail.fetch_notice_resources)
and file collector (sam_attachment_text.extract_public_attachment_text) with
LILA_NOTICE_CACHE_DIR / LILA_SAM_ATTACHMENT_TEXT_DIR pointed at
  (a) a REAL exFAT volume mounted inside this probe dir (os.link -> ENOTSUP), and
  (b) APFS scratch with os.link monkeypatched to raise EXDEV / EPERM / ENOTSUP,
then runs the BASE (2d522f0) versions of both collectors under the same conditions.
No network: _http._client is a MockTransport, _download_bytes is patched, and
socket.connect is blocked.
"""
from __future__ import annotations

import errno
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

NOTICE = "0123456789abcdef0123456789abcdef"
RID = "fedcba9876543210fedcba9876543210"
BODY_TEXT = b"Statement of work: packet capture required."
INVENTORY = {
    "_embedded": {"opportunityAttachmentList": [{
        "opportunityId": NOTICE,
        "attachments": [{
            "resourceId": RID, "name": "sow.txt", "mimeType": "text/plain",
            "size": len(BODY_TEXT), "accessLevel": "public",
        }],
    }]},
    "_links": {"self": {"href": f"/opportunities/{NOTICE}/resources"}},
}
ATTACHMENT = {
    "resource_id": RID, "name": "sow.txt", "type": "text/plain",
    "source_url": None, "size": len(BODY_TEXT), "access_level": "public",
    "access_status": None, "export_controlled": "0", "explicit_access": "0",
}


def _block(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _block  # type: ignore[assignment]
socket.socket.connect_ex = _block  # type: ignore[assignment]

import httpx  # noqa: E402
import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as cand_detail  # noqa: E402
import tools.api.sam_attachment_text as cand_text  # noqa: E402


def _handler(request: httpx.Request) -> httpx.Response:
    if request.url.path.endswith(f"/opportunities/{NOTICE}/resources"):
        return httpx.Response(200, json=INVENTORY)
    return httpx.Response(404, json={"error": "unexpected url"})


_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(_handler))


def _load_base(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


base_detail = _load_base("base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base_text = _load_base("base_sam_attachment_text", HERE / "base_sam_attachment_text.py")

cand_text._download_bytes = lambda rid, *, deadline_monotonic=None: BODY_TEXT
base_text._download_bytes = lambda rid, *, deadline_monotonic=None: BODY_TEXT


def _fresh_dirs(root: Path) -> tuple[Path, Path]:
    inv = root / "notice_cache"
    txt = root / "attachment_text"
    for d in (inv, txt):
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(inv)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(txt)
    return inv, txt


def _objects(d: Path) -> list[str]:
    o = d / "objects"
    return sorted(p.name for p in o.iterdir()) if o.exists() else []


def _run_pair(detail_mod, text_mod, inv: Path, txt: Path) -> dict:
    inventory = detail_mod.fetch_notice_resources(NOTICE)
    filerow = text_mod.extract_public_attachment_text(dict(ATTACHMENT))
    return {
        "inventory": {
            "collection_status": inventory.get("collection_status"),
            "resources_checked": inventory.get("resources_checked"),
            "attachments": inventory.get("attachments"),
            "attachment_count": len(inventory.get("attachments") or []),
            "raw_capture_present": "raw_capture" in inventory,
            "errors": inventory.get("errors"),
            "objects": _objects(inv),
            "cache_files": sorted(p.name for p in inv.iterdir()),
        },
        "file": {
            "collection_status": filerow.get("collection_status"),
            "text": filerow.get("text"),
            "sha256": filerow.get("sha256"),
            "error": filerow.get("error"),
            "objects": _objects(txt),
            "cache_files": sorted(p.name for p in txt.iterdir()),
        },
    }


def _with_link_failure(code: int, fn):
    real = os.link

    def failing(*a, **k):
        raise OSError(code, os.strerror(code))

    os.link = failing
    try:
        return fn()
    finally:
        os.link = real


observed: dict = {"candidate_sha": "67f644b (code 6b51f00)", "base_sha": "2d522f0"}

# (a) real exFAT volume mounted inside the probe dir
mnt = HERE / "mnt"
dmg = HERE / "exfat_probe.dmg"
mounted_here = False
if not (mnt.is_dir() and (mnt / ".fseventsd").exists()) and dmg.exists():
    import subprocess
    mnt.mkdir(exist_ok=True)
    mounted_here = subprocess.run(
        ["hdiutil", "attach", "-mountpoint", str(mnt), "-nobrowse", "-quiet", str(dmg)],
        check=False).returncode == 0
exfat_ok = mnt.is_dir() and (mnt / ".fseventsd").exists()
observed["exfat_mounted"] = exfat_ok
if exfat_ok:
    probe_file = mnt / "linkprobe.txt"
    probe_file.write_bytes(b"x")
    try:
        os.link(probe_file, mnt / "linkprobe2.txt")
        observed["exfat_os_link"] = "supported (unexpected)"
    except OSError as e:
        observed["exfat_os_link"] = f"OSError errno={e.errno} {errno.errorcode.get(e.errno)}"
    finally:
        for p in (probe_file, mnt / "linkprobe2.txt"):
            p.unlink(missing_ok=True)
    inv, txt = _fresh_dirs(mnt)
    observed["exfat_candidate"] = _run_pair(cand_detail, cand_text, inv, txt)
    inv, txt = _fresh_dirs(mnt)
    observed["exfat_base"] = _run_pair(base_detail, base_text, inv, txt)

if mounted_here:
    import subprocess
    subprocess.run(["hdiutil", "detach", str(mnt), "-quiet"], check=False)
    try:
        mnt.rmdir()
    except OSError:
        pass

# (b) APFS scratch, os.link monkeypatched
scratch = Path(tempfile.mkdtemp(prefix="br2_", dir=HERE))
observed["apfs_control"] = {}
inv, txt = _fresh_dirs(scratch / "control")
observed["apfs_control"]["candidate"] = _run_pair(cand_detail, cand_text, inv, txt)
observed["monkeypatched"] = {}
for code in (errno.EXDEV, errno.EPERM, errno.ENOTSUP):
    key = f"errno_{code}_{errno.errorcode[code]}"
    inv, txt = _fresh_dirs(scratch / key / "cand")
    cand = _with_link_failure(code, lambda: _run_pair(cand_detail, cand_text, inv, txt))
    inv2, txt2 = _fresh_dirs(scratch / key / "base")
    base = _with_link_failure(code, lambda: _run_pair(base_detail, base_text, inv2, txt2))
    observed["monkeypatched"][key] = {"candidate": cand, "base": base}
shutil.rmtree(scratch, ignore_errors=True)

# verdict logic
def _cand_failed(r: dict) -> bool:
    return (r["inventory"]["collection_status"] == "lookup_failed"
            and r["inventory"]["resources_checked"] is False
            and r["inventory"]["objects"] == []
            and r["file"]["collection_status"] == "lookup_failed"
            and r["file"]["text"] == "")


def _base_ok(r: dict) -> bool:
    return (r["inventory"]["resources_checked"] is True
            and r["inventory"]["attachment_count"] == 1
            and r["file"]["text"] == BODY_TEXT.decode())


control_ok = (observed["apfs_control"]["candidate"]["inventory"]["collection_status"] == "inventory_captured"
              and observed["apfs_control"]["candidate"]["file"]["collection_status"] == "captured_discovery_only")
mp_reproduced = all(_cand_failed(v["candidate"]) and _base_ok(v["base"])
                    for v in observed["monkeypatched"].values())
exfat_reproduced = exfat_ok and _cand_failed(observed["exfat_candidate"]) and _base_ok(observed["exfat_base"])
reproduced = control_ok and mp_reproduced and exfat_reproduced
print(json.dumps({
    "status": "FAIL" if reproduced else ("INFO" if control_ok else "FAIL"),
    "finding": "BR-2 H7 hardlink requirement",
    "reproduced": reproduced,
    "control_apfs_ok": control_ok,
    "monkeypatch_reproduced": mp_reproduced,
    "real_exfat_reproduced": exfat_reproduced,
    "observed": observed,
}, indent=2, default=str))
