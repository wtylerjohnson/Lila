"""BR-2 independent refutation probe: does retain_bytes really require os.link, and is
this new in the Step7 delta?

Design (refuter stance):
  A. Positive control: real os.link, candidate inventory + file collectors succeed and
     objects/ is populated. Proves the probe environment is sound.
  B. Candidate under os.link -> ENOTSUP (documented by macOS link(2) as "underlying file
     system does not support this call") and EPERM (exFAT behaviour): both collectors
     must be observed, and whether the failure is silent or surfaced in errors/error.
  C. Base 2d522f0 (files written from git show, byte-identical) under the SAME os.link
     failure: if base also fails, the finding is pre_existing; if base succeeds, the
     regression is introduced by the delta.
  D. Realism check: EXDEV is only reachable if the temp file and target sit on different
     file systems; retain_bytes creates the temp in path.parent, so EXDEV is essentially
     unreachable and the finding overstates that errno (nuance only).
Nothing is written outside this probe directory; network is blocked at the socket.
"""
from __future__ import annotations

import errno
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402

NOTICE = "a" * 32
RID = "b" * 32
INV_BODY = b'{"attachments": [{"name": "SOW.txt", "resourceId": "' + RID.encode() + b'", "mimeType": "text/plain"}]}'
TEXT_BODY = b"Statement of work: packet capture required."
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
TMP = HERE / "_tmp"
TMP.mkdir(exist_ok=True)
REAL_LINK = os.link


def load_base(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fresh(label):
    root = Path(tempfile.mkdtemp(prefix=f"{label}-", dir=TMP))
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(root / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(root / "text")
    return root


def listing(p: Path):
    return sorted(str(x.relative_to(p)) for x in p.rglob("*") if x.is_file()) if p.exists() else []


def bind_mock():
    calls = []

    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=INV_BODY)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    return calls


def run_candidate(root):
    calls = bind_mock()
    inv = detail.fetch_notice_resources(NOTICE)
    sat._download_bytes = lambda rid, **k: TEXT_BODY
    fil = sat.extract_public_attachment_text(PUBLIC)
    return {
        "inventory": {"collection_status": inv.get("collection_status"), "resources_checked": inv.get("resources_checked"),
                      "attachment_count": len(inv.get("attachments") or []), "raw_capture_present": "raw_capture" in inv,
                      "errors": inv.get("errors"), "network_calls": len(calls)},
        "file": {"collection_status": fil.get("collection_status"), "text": fil.get("text"), "error": fil.get("error"),
                 "raw_capture_present": "raw_capture" in fil},
        "objects_notice": listing(root / "notice" / "objects"),
        "objects_text": listing(root / "text" / "objects"),
    }


def run_base(root):
    base_detail = load_base("base_detail", "base_sam_notice_detail.py")
    base_sat = load_base("base_sat", "base_sam_attachment_text.py")
    calls = bind_mock()
    inv = base_detail.fetch_notice_resources(NOTICE)
    base_sat._download_bytes = lambda rid, **k: TEXT_BODY
    fil = base_sat.extract_public_attachment_text(PUBLIC)
    return {
        "inventory": {"resources_checked": inv.get("resources_checked"), "attachment_count": len(inv.get("attachments") or []),
                      "errors": inv.get("errors"), "network_calls": len(calls)},
        "file": {"text": fil.get("text"), "error": fil.get("error")},
    }


observed = {}
checks = {}

# A. Positive control with the real os.link.
root = fresh("ctl")
ctl = run_candidate(root)
observed["A_control_real_link"] = ctl
checks["A_control_inventory_captured"] = ctl["inventory"]["collection_status"] == "inventory_captured" and ctl["inventory"]["attachment_count"] == 1
checks["A_control_file_captured"] = ctl["file"]["collection_status"] == "captured_discovery_only" and ctl["file"]["text"].startswith("Statement of work")
# ASCII text body: extracted text bytes == raw payload, so raw_capture and text_capture share ONE content-addressed object.
checks["A_control_objects_present"] = len(ctl["objects_notice"]) == 1 and len(ctl["objects_text"]) == 1
shutil.rmtree(root, ignore_errors=True)

# B + C. Failing os.link, candidate vs base.
for code in (errno.ENOTSUP, errno.EPERM):
    name = errno.errorcode[code]

    def failing_link(src, dst, *a, _code=code, **k):
        raise OSError(_code, os.strerror(_code), str(dst))

    root = fresh(f"cand-{name}")
    os.link = failing_link
    try:
        try:
            retain_bytes(root, TEXT_BODY)
            direct = "returned"
        except Exception as exc:  # noqa: BLE001
            direct = repr(exc)
        cand = run_candidate(root)
        root_b = fresh(f"base-{name}")
        base = run_base(root_b)
    finally:
        os.link = REAL_LINK
    observed[f"B_candidate_{name}"] = {"retain_bytes_direct": direct, **cand}
    observed[f"C_base_{name}"] = base
    checks[f"B_{name}_candidate_inventory_lookup_failed"] = (
        cand["inventory"]["collection_status"] == "lookup_failed" and cand["inventory"]["resources_checked"] is False
        and cand["objects_notice"] == [])
    checks[f"B_{name}_candidate_file_lookup_failed_text_dropped"] = (
        cand["file"]["collection_status"] == "lookup_failed" and cand["file"]["text"] == "" and cand["objects_text"] == [])
    checks[f"B_{name}_failure_surfaced_not_silent"] = (
        any(name in e or os.strerror(code) in e for e in cand["inventory"]["errors"]) and os.strerror(code) in (cand["file"]["error"] or ""))
    checks[f"B_{name}_single_network_call_no_retry_burn"] = cand["inventory"]["network_calls"] == 1
    checks[f"C_{name}_base_inventory_unaffected"] = base["inventory"]["resources_checked"] is True and base["inventory"]["attachment_count"] == 1
    checks[f"C_{name}_base_file_unaffected"] = (base["file"]["text"] or "").startswith("Statement of work")
    shutil.rmtree(root, ignore_errors=True)
    shutil.rmtree(root_b, ignore_errors=True)

# D. EXDEV realism: temp file and target share a parent directory by construction.
import inspect  # noqa: E402
import tools.api.sam_capture as cap  # noqa: E402
src = inspect.getsource(cap.retain_bytes)
observed["D_exdev_realism"] = {
    "temp_created_in_target_parent": "NamedTemporaryFile(dir=path.parent" in src,
    "note": "EXDEV needs different file systems; same-directory temp makes EXDEV unreachable in practice, so the finding's EXDEV mention is a nuance not a scenario",
}
checks["D_exdev_unreachable_by_construction"] = observed["D_exdev_realism"]["temp_created_in_target_parent"]

# E. Disclosure and coverage census (read-only).
docs = REPO / "docs" / "verification" / "step7-052"
hits = []
extra = [q for q in REPO.rglob("CONVENTIONS.md") if ".venv" not in q.parts] + [q for q in REPO.rglob("CONTRACT_SURFACES.md") if ".venv" not in q.parts]
observed["E_doc_files_scanned"] = [str(q.relative_to(REPO)) for q in extra]
for p in list(docs.glob("*.md")) + list(docs.glob("*.json")) + extra:
    if not p.is_file():
        continue
    txt = p.read_text(errors="replace").lower()
    for kw in ("hardlink", "hard link", "os.link", "enotsup", "eperm", "exfat"):
        if kw in txt:
            hits.append(f"{p.name}:{kw}")
test_txt = (REPO / "tests" / "test_step7_evidence_collection.py").read_text()
observed["E_disclosure_hits"] = hits
observed["E_producer_test_mentions_link_failure"] = any(k in test_txt for k in ("os.link", "ENOTSUP", "EPERM", "OSError"))
checks["E_not_disclosed"] = hits == []
checks["E_not_tested_by_producer"] = observed["E_producer_test_mentions_link_failure"] is False

regression = all(checks[k] for k in checks if k.startswith(("B_", "C_")))
status = "FAIL" if regression and all(checks.values()) else ("INFO" if not all(checks.values()) else "PASS")
observed["classification"] = (
    "new_defect, Low: sam_capture.py is new in the delta; base collectors return inventory and text under the same os.link failure; "
    "failure is surfaced in errors (not silent) and costs one network call; default APFS unaffected"
)
print(json.dumps({"probe": "br2_hardlink_refute", "status": status, "checks": checks, "observed": observed}, indent=2, sort_keys=True, default=str))
shutil.rmtree(TMP, ignore_errors=True)
