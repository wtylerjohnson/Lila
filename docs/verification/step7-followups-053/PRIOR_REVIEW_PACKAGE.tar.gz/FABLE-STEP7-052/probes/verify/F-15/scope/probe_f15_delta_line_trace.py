"""Measure which ADDED lines of the Step7 delta the producer's focused suite executes.
Compares the literal-grep 'untested branch' method (HDP-06) with execution truth."""
import json, os, re, subprocess, sys
from pathlib import Path
REPO = Path('/Users/wtjohnson/lila-step7-052'); HERE = Path(__file__).resolve().parent
FILES = ['run_searches.py', 'agents/decisions/dossier.py', 'tools/api/_http.py',
         'tools/api/sam_attachment_text.py', 'tools/api/sam_capture.py', 'tools/api/sam_notice_detail.py']
suite = sys.argv[1] if len(sys.argv) > 1 else 'focused'
FOCUSED = ['tests/test_step7_evidence_collection.py', 'tests/test_sam_attachment_text.py', 'tests/test_dossiers.py',
           'tests/test_native_notice_bridge.py', 'tests/test_native_surface_contract.py', 'tests/test_assess_source_clock.py',
           'tests/test_assess_ledger.py', 'tests/test_external_notice_authority.py', 'tests/test_step6_material_source.py',
           'tests/test_triage_prefilter.py']
targets = {'step7only': ['tests/test_step7_evidence_collection.py'], 'focused': FOCUSED, 'full': ['tests/']}[suite]
trace_out = HERE / f'_trace_{suite}.json'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', LILA_SUITE_OFFLINE='1', LILA_SUITE_STRICT='1',
           F15_TRACE_OUT=str(trace_out), PYTHONPATH=str(HERE))
cmd = [str(REPO / '.venv/bin/python'), '-m', 'pytest', *targets, '-q', '-p', 'no:cacheprovider', '-p', 'f15_tracer_plugin', '-x' if False else '-q']
res = subprocess.run(cmd, cwd=REPO, env=env, capture_output=True, text=True, timeout=3000)
tail = res.stdout.strip().splitlines()[-3:]
hits = json.loads(trace_out.read_text())
added = {}
for f in FILES:
    d = subprocess.run(['git', '-C', str(REPO), 'diff', '-U0', '2d522f0..6b51f00', '--', f], capture_output=True, text=True).stdout
    lines = set()
    for m in re.finditer(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@', d, re.M):
        start = int(m.group(1)); n = int(m.group(2)) if m.group(2) is not None else 1
        lines.update(range(start, start + n))
    added[f] = lines
# executable added lines: drop blank/comment/docstring-only/closing-bracket lines
def executable(f, ln):
    s = (REPO / f).read_text().splitlines()[ln - 1].strip()
    return bool(s) and not s.startswith('#') and s not in (')', '})', '}', ']', '],', '},', '"""') and not s.startswith('"""') and not s.startswith('from ') and not s.startswith('import ')
report = {}
total_exec = total_hit = 0
for f in FILES:
    ex = sorted(l for l in added[f] if executable(f, l))
    hit = [l for l in ex if l in set(hits.get(f, []))]
    miss = [l for l in ex if l not in set(hits.get(f, []))]
    src = (REPO / f).read_text().splitlines()
    report[f] = {'added_lines': len(added[f]), 'executable_added': len(ex), 'executed': len(hit), 'not_executed': len(miss),
                 'not_executed_lines': [{'line': l, 'src': src[l - 1].strip()[:110]} for l in miss]}
    total_exec += len(ex); total_hit += len(hit)
# HDP-06 literal list vs execution
literals = ['inventory_captured', 'refresh_attempt', 'received_at', 'stage time budget exhausted', 'outside file/type budget',
            'collected within declared budget', 'text_unavailable', 'file_text_truncated', 'included_end', 'request_started_at',
            'extraction_limits', 'text_capture', 'attachment_binding_sha256', 'export-controlled', 'explicit-access',
            'invalid attachment size', 'IDENTITY_MISMATCH', 'inventory_receipt', 'yielded no readable text',
            'Attachment collection receipt is malformed', 'Attachment collection does not bind', 'Attachment file locator is missing',
            'Attachment file locator does not match retained text', 'Attachment file locators leave unbound text']
lit = {}
for lit_s in literals:
    grep = subprocess.run(['grep', '-rl', '--', lit_s, str(REPO / 'tests')], capture_output=True, text=True).stdout.strip()
    # lines in delta files containing the literal, and whether executed
    where = []
    for f in FILES:
        src = (REPO / f).read_text().splitlines()
        for i, s in enumerate(src, 1):
            if lit_s in s and i in added[f]:
                where.append({'file': f, 'line': i, 'executed': i in set(hits.get(f, []))})
    lit[lit_s] = {'literal_in_tests': bool(grep), 'delta_lines': where, 'any_delta_line_executed': any(w['executed'] for w in where)}
exercised_not_grepped = [k for k, v in lit.items() if not v['literal_in_tests'] and v['any_delta_line_executed']]
truly_unexecuted = [k for k, v in lit.items() if v['delta_lines'] and not v['any_delta_line_executed']]
print(json.dumps({'probe': 'probe_f15_delta_line_trace', 'suite': suite, 'status': 'INFO', 'pytest_tail': tail, 'pytest_exit': res.returncode,
                  'executable_added_total': total_exec, 'executed_total': total_hit,
                  'executed_fraction': round(total_hit / max(1, total_exec), 3),
                  'per_file': report,
                  'hdp06_literals': lit,
                  'literal_absent_from_tests_but_delta_line_executed': exercised_not_grepped,
                  'literal_branches_never_executed': truly_unexecuted}, indent=1))
