"""F-15 scope/classification probe: six harness members, run against the candidate
and (where a base copy exists) against the 2d522f0 copy placed in this directory.
Prints one JSON object with status in {PASS, FAIL, INFO}."""
import hashlib, json, os, re, socket, subprocess, sys, tempfile, traceback
from pathlib import Path

REPO = Path('/Users/wtjohnson/lila-step7-052')
HERE = Path(__file__).resolve().parent
BASE = '2d522f0'
sys.path.insert(0, str(REPO))
os.chdir(REPO)
observed = {}
fails = []

def git_show(path):
    return subprocess.run(['git', '-C', str(REPO), 'show', f'{BASE}:{path}'],
                          capture_output=True, text=True, check=True).stdout

import httpx
from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail

# ---------------------------------------------------------------- network guard
_real_connect = socket.socket.connect
class NetGuard(Exception): pass
def _blocked(self, *a, **k):
    raise NetGuard(f'socket connect blocked: {a[:1]}')
socket.socket.connect = _blocked

def mock_client(payload, status=200, calls=None):
    def handler(request):
        if calls is not None: calls.append(str(request.url))
        return httpx.Response(status, content=payload)
    return lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

# ============================================================ A. AAP-1 / HDP-06
# The strict-Assess negative test: do its three asserts hold with ZERO attachment
# fields (non-discriminating), and does a discriminating shape exist in the same
# helper module (so the test COULD have been written to discriminate)?
def section_a():
    from agents.assess.contracts import LiveClassification
    from tests.test_assess_ledger import _sweep, _build, _depth_record, _build_with_requirement_review
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    import tools.api.sam_quota as quota
    out = {}
    tmp = Path(tempfile.mkdtemp(dir=HERE / '_tmp'))
    os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(tmp)
    saved = (quota.calls_today, detail.fetch_notice_resources, sat._download_bytes)
    try:
        quota.calls_today = lambda: 0
        term = 'packet capture'
        files = [{'resource_id': 'b'*32, 'name': 'SOW 1.txt', 'access_level': 'public',
                  'access_status': 'public', 'export_controlled': '0', 'explicit_access': '0'}]
        inv = detail._manifest_hash(files)
        detail.fetch_notice_resources = lambda *a, **k: {'id': 'N1', 'resources_checked': True,
                                                          'attachments': files, 'attachment_inventory_hash': inv}
        # attachment text carries the strongest buying cue we can write
        sat._download_bytes = lambda rid, **k: (
            b'The contractor shall provide an enterprise packet capture platform. '
            b'Offerors shall deliver packet capture appliances within 30 days of award.')
        cand = RawOpportunity(source='sam.gov', source_id='N1', title='Requirement', agency='NASA',
                              raw_payload={'type': 'Solicitation'})
        class Source:
            last_attachment_census = {'selected': 1}
            def attachment_candidates(self, *a, **k): return [cand]
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(),
            CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21', core=[TaxonomyTerm(term=term)]),
            None, limit=8)
        row = rows[0]
        att_keys = sorted(k for k in row['raw_payload'] if 'attachment' in k or k == 'text')
        out['attachment_fields_in_row'] = att_keys

        def three_asserts(sweep):
            run, diag, idx = _build(sweep)
            p = next(r for r in run.live.records if r.notice_id == 'N1')
            return {'not_bid_now': p.classification != LiveClassification.BID_NOW,
                    'classification': str(p.classification),
                    'requirement_reviewed_at_none': p.requirement_reviewed_at is None,
                    'attachment_gap_truthy': bool(p.attachment_gap),
                    'attachment_gap': p.attachment_gap,
                    'requirement_excerpt': p.requirement_excerpt}
        # (i) producer shape
        s1 = _sweep(); o = s1['results']['sam.gov'][0]; o['source_id'] = 'N1'; o['raw_payload'].update(row['raw_payload'])
        with_att = three_asserts(s1)
        # (ii) untouched _sweep(): zero attachment fields
        without_att = three_asserts(_sweep())
        out['producer_shape'] = with_att
        out['untouched_sweep'] = without_att
        same = all(with_att[k] == without_att[k] for k in ('not_bid_now', 'requirement_reviewed_at_none', 'attachment_gap_truthy', 'attachment_gap', 'classification'))
        out['three_asserts_identical_with_and_without_attachment_fields'] = same
        # (iii) a discriminating shape exists in the same helper module: trusted depth
        # + human review reaches BID_NOW; adding attachment text must not change requirement_excerpt
        s3 = _sweep(); s3['results']['dossiers'] = {'records': [_depth_record()]}
        run3, _, _ = _build_with_requirement_review(s3)
        p3 = next(r for r in run3.live.records if r.notice_id == 'N1')
        out['trusted_depth_plus_human_review_reaches_bid_now'] = p3.classification == LiveClassification.BID_NOW
        # (iv) trusted depth (irrelevant description) + attachment cue: excerpt must not come from attachment
        s4 = _sweep(); d = _depth_record(attachments=files); d['source_depth']['description'] = 'The contractor shall provide lawn mowing services.'
        s4['results']['dossiers'] = {'records': [d]}
        o4 = s4['results']['sam.gov'][0]; o4['raw_payload'].update(row['raw_payload'])
        run4, _, _ = _build(s4)
        p4 = next(r for r in run4.live.records if r.notice_id == 'N1')
        rec_json = json.dumps(p4.model_dump() if hasattr(p4, 'model_dump') else p4.__dict__, default=str)
        out['trusted_irrelevant_depth_plus_attachment_cue'] = {
            'classification': str(p4.classification),
            'requirement_excerpt': p4.requirement_excerpt,
            'attachment_text_leaks_into_record': 'packet capture appliances' in rec_json,
        }
        if out['trusted_irrelevant_depth_plus_attachment_cue']['attachment_text_leaks_into_record']:
            fails.append('attachment text reached the strict record')
    finally:
        quota.calls_today, detail.fetch_notice_resources, sat._download_bytes = saved
    return out

# ================================================================ B. HDP-05 (H9)
def section_b():
    out = {}
    src = (REPO / 'tests/test_step7_evidence_collection.py').read_text()
    out['test_module_restores_native_request'] = "_NATIVE_REQUEST = _http._request" in src and "monkeypatch.setattr(_http, '_request', _NATIVE_REQUEST)" in src
    out['test_module_is_new_in_delta'] = subprocess.run(['git', '-C', str(REPO), 'cat-file', '-e', f'{BASE}:tests/test_step7_evidence_collection.py'], capture_output=True).returncode != 0
    conf = (REPO / 'tests/conftest.py').read_text()
    out['conftest_observer_raises_on_any_request_under_offline'] = 'raise RuntimeError(' in conf and 'offline suite:' in conf
    # dynamic: native _request + mocked _client makes no socket; native _request without the mock hits the guard
    saved_client = _http._client
    try:
        _http._client = mock_client(b'{"attachments":[]}')
        r = _http.get_json('https://sam.gov/api/prod/opps/v3/opportunities/x/resources', retries=1)
        out['native_request_with_mocked_client_no_socket'] = r == {'attachments': []}
    finally:
        _http._client = saved_client
    try:
        _http.get_json('https://sam.gov/api/prod/opps/v3/opportunities/x/resources', retries=1, timeout=1)
        out['native_request_without_mock_reaches_socket'] = 'no-guard-hit (unexpected)'
    except NetGuard as e:
        out['native_request_without_mock_reaches_socket'] = f'NetGuard: {e}'
    except Exception as e:
        out['native_request_without_mock_reaches_socket'] = f'{type(e).__name__}: {str(e)[:120]}'
    # other base tests that touch _http._request
    base_grep = subprocess.run(['git', '-C', str(REPO), 'grep', '-n', '-E', r'_http\._request|_api_http, "_request"', BASE, '--', 'tests/'], capture_output=True, text=True).stdout.strip().splitlines()
    out['base_tests_touching_http_request'] = base_grep
    # disclosure sentences
    review = (REPO / 'docs/verification/step7-052/REVIEW.md').read_text()
    m = re.search(r'The HTTP helper tests bind MockTransport[^.]*\.[^.]*\.', review)
    out['disclosure_REVIEW_md'] = m.group(0).replace('\n', ' ') if m else None
    lv = json.loads((REPO / 'docs/verification/step7-052/LOCAL_VERIFICATION.json').read_text())
    out['disclosure_LOCAL_VERIFICATION_targeted_02'] = lv['earlier_attempts'].get('targeted-02')
    return out

# ============================================================= C. WNI-7 / FVE-5
def section_c():
    out = {}
    tmp = Path(tempfile.mkdtemp(dir=HERE / '_tmp'))
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(tmp)
    body = json.dumps({'attachments': [{'name': 'x.txt', 'resourceId': 'b'*32}], 'opportunityId': 'c'*32}).encode()
    saved_client = _http._client
    try:
        _http._client = mock_client(body)
        r = detail.fetch_notice_resources('a'*32)
        out['candidate_fetch_mismatch_body'] = {'id': r['id'], 'id_equals_requested': r['id'] == 'a'*32,
                                                'collection_status': r['collection_status'], 'errors': r['errors']}
        # every return path in candidate fetch_notice_resources: id is notice_id (static)
        src = (REPO / 'tools/api/sam_notice_detail.py').read_text()
        fn = src[src.index('def fetch_notice_resources'):src.index('def _resource_capture_valid')]
        out['candidate_fetch_static'] = {
            'cache_path_rejects_foreign_id': 'cached.get("id") != notice_id' in fn,
            'out_id_is_notice_id': '"id": notice_id' in fn,
            'stale_path_returns_cached_(id_already_checked)': 'return cached' in fn}
        # end-to-end through candidate run_searches with real fetch_notice_resources
        import run_searches as searches
        from agents.schemas import RawOpportunity
        from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
        import tools.api.sam_quota as quota
        sq = quota.calls_today; quota.calls_today = lambda: 0
        try:
            cand = RawOpportunity(source='sam.gov', source_id='a'*32, title='Requirement', agency='NASA', raw_payload={'type': 'Solicitation'})
            class Source:
                last_attachment_census = {'selected': 1}
                def attachment_candidates(self, *a, **k): return [cand]
            tax = CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21', core=[TaxonomyTerm(term='packet capture')])
            os.environ['LILA_NOTICE_CACHE_DIR'] = str(Path(tempfile.mkdtemp(dir=HERE / '_tmp')))
            rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
            rec = stats['attachment_record_receipts']['a'*32]
            out['candidate_e2e_mismatch_body'] = {'status': rec['status'], 'inventory_collection_status': (rec.get('inventory_receipt') or {}).get('collection_status'), 'errors': rec.get('errors')}
            out['IDENTITY_MISMATCH_status_reached_via_real_adapter'] = rec['status'] == 'IDENTITY_MISMATCH'
            # base run_searches: does the branch exist at all?
            base_rs = git_show('run_searches.py')
            out['base_run_searches_has_IDENTITY_MISMATCH'] = 'IDENTITY_MISMATCH' in base_rs
            out['base_run_searches_has_text_unavailable_lowercase'] = 'text_unavailable' in base_rs
            out['base_run_searches_has_TEXT_UNAVAILABLE_record_status'] = 'TEXT_UNAVAILABLE' in base_rs
            # base fetch_notice_resources: id always notice_id too?
            base_det = git_show('tools/api/sam_notice_detail.py')
            bfn = base_det[base_det.index('def fetch_notice_resources'):]
            bfn = bfn[:bfn.index('\ndef ', 10)]
            out['base_fetch_static'] = {'out_id_is_notice_id': '"id": notice_id' in bfn,
                                        'cache_path_checks_id': 'cached.get("id")' in bfn or '"id"' in bfn.split('cache.exists()')[1][:600] if 'cache.exists()' in bfn else None}
            # guard truth table (candidate expression)
            expr = lambda rid, cid: rid not in (None, cid)
            out['guard_truth_table'] = {'id_missing': expr(None, 'a'), 'id_same': expr('a', 'a'), 'id_other': expr('b', 'a')}
        finally:
            quota.calls_today = sq
    finally:
        _http._client = saved_client
    return out

# ===================================================================== D. RUF-7
def section_d():
    out = {}
    tmp = Path(tempfile.mkdtemp(dir=HERE / '_tmp'))
    os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(tmp)
    def pf(rid='b'*32, name='SOW.txt', **kw):
        d = {'resource_id': rid, 'name': name, 'access_level': 'public', 'access_status': 'public',
             'export_controlled': '0', 'explicit_access': '0'}
        d.update(kw); return d
    saved_dl, saved_tb = sat._download_bytes, sat._text_from_bytes
    states = {}
    try:
        sat._download_bytes = lambda *a, **k: b'Original requirement text'
        states['success'] = sat.extract_public_attachment_text(pf())
        states['cache_hit'] = sat.extract_public_attachment_text(pf())
        states['private'] = sat.extract_public_attachment_text(pf('c'*32, access_level='private'))
        states['export_controlled'] = sat.extract_public_attachment_text(pf('d'*32, export_controlled='1'))
        states['explicit_access'] = sat.extract_public_attachment_text(pf('e'*32, explicit_access='1'))
        states['invalid_id'] = sat.extract_public_attachment_text(pf('../x'))
        states['oversize'] = sat.extract_public_attachment_text(pf('f'*32, size=str(10**9)))
        states['bad_size'] = sat.extract_public_attachment_text(pf('1'*32, size='abc'))
        resp = httpx.Response(403, request=httpx.Request('GET', 'https://sam.gov/x'))
        def denied(*a, **k): resp.raise_for_status()
        sat._download_bytes = denied
        states['http_403'] = sat.extract_public_attachment_text(pf('2'*32))
        def boom(*a, **k): raise RuntimeError('source unavailable')
        sat._download_bytes = boom
        states['download_error'] = sat.extract_public_attachment_text(pf('3'*32))
        sat._download_bytes = lambda *a, **k: b'%PDF broken'
        def unread(*a, **k): raise ValueError('unreadable')
        sat._text_from_bytes = unread
        states['parse_error'] = sat.extract_public_attachment_text(pf('4'*32, name='SOW.pdf'))
        sat._download_bytes = lambda *a, **k: b'   '
        sat._text_from_bytes = lambda *a, **k: '   '
        states['empty_text'] = sat.extract_public_attachment_text(pf('5'*32))
    finally:
        sat._download_bytes, sat._text_from_bytes = saved_dl, saved_tb
    out['collection_status_by_scenario'] = {k: v.get('collection_status', '<MISSING>') for k, v in states.items()}
    out['every_extractor_return_carries_collection_status'] = all('collection_status' in v for v in states.values())
    out['distinct_states_emitted'] = sorted({v.get('collection_status') for v in states.values()})
    # what does run_searches do with an empty-text success? (the one shape that could look like text_unavailable)
    rs = (REPO / 'run_searches.py').read_text()
    m = re.search(r'file_receipt\["status"\] = extracted\.get\("collection_status"\) or \((.|\n)*?\)', rs)
    out['fallback_expression'] = m.group(0).replace('\n', ' ') if m else None
    out['fallback_reachable_only_when_collection_status_falsy'] = True
    # static: all extractor return statements inside extract_public_attachment_text
    src = (REPO / 'tools/api/sam_attachment_text.py').read_text()
    fn = src[src.index('def extract_public_attachment_text'):src.index('\ndef ', src.index('def extract_public_attachment_text') + 10)]
    out['extractor_result_initialised_with_lookup_failed'] = '"collection_status": "lookup_failed"' in fn
    out['extractor_pops_or_deletes_collection_status'] = bool(re.search(r'(pop|del)\s*\(?\s*["\']collection_status', fn))
    # pre-existing tests stubbing extract without collection_status
    hits = subprocess.run(['grep', '-rn', '-l', 'extract_public_attachment_text', str(REPO / 'tests')], capture_output=True, text=True).stdout.strip().splitlines()
    out['tests_referencing_extractor'] = [h.replace(str(REPO) + '/', '') for h in hits]
    return out

# ================================================ E. HDP-06 test-name overstatement
def section_e():
    out = {}
    src = (REPO / 'tests/test_step7_evidence_collection.py').read_text()
    nc = src[src.index('def native_collection'):src.index('def test_native_unicode')]
    out['native_collection_monkeypatches_fetch_notice_resources'] = "monkeypatch.setattr(detail,'fetch_notice_resources'" in nc
    out['patched_inventory_has_collection_status'] = 'collection_status' in nc
    tn = src[src.index('def test_native_unicode'):src.index('@pytest.mark.parametrize', src.index('def test_native_unicode'))]
    m = re.search(r"file_states==\{(.*?)\}", tn)
    asserted = sorted(set(re.findall(r":'([a-z_]+)'", m.group(1)))) if m else None
    out['file_states_asserted_by_the_all_states_test'] = asserted
    out['claimed_file_states'] = ['captured_discovery_only', 'lookup_failed', 'unreadable', 'inaccessible', 'identity_mismatch', 'not_fetched']
    out['claimed_inventory_states'] = ['confirmed_empty', 'unrecognized_inventory', 'identity_mismatch', 'lookup_failed', 'inventory_captured', 'stale_inventory']
    # which inventory states does the WHOLE module assert literally?
    out['inventory_states_literal_in_module'] = [s for s in out['claimed_inventory_states'] if f"'{s}'" in src or f'"{s}"' in src]
    out['file_states_literal_in_module'] = [s for s in out['claimed_file_states'] if f"'{s}'" in src or f'"{s}"' in src]
    cs = (REPO / 'docs/CONTRACT_SURFACES.md').read_text()
    m2 = re.search(r'The change is verified by tests/test_step7_evidence_collection\.py[^.]*\.', cs)
    out['doc_sentence_CONTRACT_SURFACES'] = m2.group(0).replace('\n', ' ') if m2 else None
    return out

# --------------------------------------------------------------------- run all
(HERE / '_tmp').mkdir(exist_ok=True)
for name, fn in (('A_strict_assess_negative_test', section_a), ('B_native_request_restore', section_b),
                 ('C_identity_mismatch_reachability', section_c), ('D_text_unavailable_fallback', section_d),
                 ('E_test_name_and_doc_sentence', section_e)):
    try:
        observed[name] = fn()
    except Exception:
        observed[name] = {'exception': traceback.format_exc()[-2500:]}
        fails.append(f'{name} raised')

status = 'FAIL' if fails else 'INFO'
print(json.dumps({'probe': 'probe_f15_scope', 'finding': 'F-15', 'status': status, 'fails': fails, 'observed': observed}, indent=1, default=str))
