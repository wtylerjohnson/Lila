"""pytest plugin: record executed line numbers in the six Step7 delta files."""
import json, os, sys, threading, atexit
FILES = {os.path.realpath(os.path.join('/Users/wtjohnson/lila-step7-052', p)): p for p in (
    'run_searches.py', 'agents/decisions/dossier.py', 'tools/api/_http.py',
    'tools/api/sam_attachment_text.py', 'tools/api/sam_capture.py', 'tools/api/sam_notice_detail.py')}
HIT = {p: set() for p in FILES.values()}
_cache = {}
def _rel(fn):
    r = _cache.get(fn)
    if r is None:
        r = FILES.get(os.path.realpath(fn), '')
        _cache[fn] = r
    return r
def _local(frame, event, arg):
    if event == 'line':
        HIT[_rel(frame.f_code.co_filename)].add(frame.f_lineno)
    return _local
def _global(frame, event, arg):
    if event == 'call' and _rel(frame.f_code.co_filename):
        HIT[_rel(frame.f_code.co_filename)].add(frame.f_lineno)
        return _local
    return None
def pytest_configure(config):
    sys.settrace(_global); threading.settrace(_global)
def pytest_unconfigure(config):
    sys.settrace(None)
    out = os.environ['F15_TRACE_OUT']
    with open(out, 'w') as fh:
        json.dump({k: sorted(v) for k, v in HIT.items()}, fh)
