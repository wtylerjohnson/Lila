"""Map HDP-06's 31 literal-grep 'zero test hits' labels to candidate delta lines and
check each against the focused-suite execution trace (_trace_focused.json)."""
import json, re, subprocess
from pathlib import Path
REPO = Path('/Users/wtjohnson/lila-step7-052'); HERE = Path(__file__).resolve().parent
hits = {k: set(v) for k, v in json.loads((HERE / '_trace_focused.json').read_text()).items()}
def added(f):
    d = subprocess.run(['git', '-C', str(REPO), 'diff', '-U0', '2d522f0..6b51f00', '--', f], capture_output=True, text=True).stdout
    s = set()
    for m in re.finditer(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@', d, re.M):
        a = int(m.group(1)); n = int(m.group(2)) if m.group(2) is not None else 1; s.update(range(a, a + n))
    return s
CAP, DOSS, FILE, HTTP, INV, RS = 'tools/api/sam_capture.py', 'agents/decisions/dossier.py', 'tools/api/sam_attachment_text.py', 'tools/api/_http.py', 'tools/api/sam_notice_detail.py', 'run_searches.py'
labels = {
 'cap:invalid retained SAM digest': (CAP, 'invalid retained SAM digest'), 'cap:invalid retained SAM locator': (CAP, 'invalid retained SAM locator'),
 'cap:retained SAM bytes changed': (CAP, 'retained SAM bytes changed'), 'cap:retained SAM object escaped cache': (CAP, 'retained SAM object escaped cache'),
 'doss:collection receipt is malformed': (DOSS, 'receipt is malformed'), 'doss:does not bind this notice/text/inventory': (DOSS, 'does not bind this notice'),
 'doss:file locator does not match retained text': (DOSS, 'does not match retained text'), 'doss:file locator is missing': (DOSS, 'locator is missing'),
 'doss:file locators leave unbound text': (DOSS, 'leave unbound text'), 'doss:included_end': (DOSS, 'included_end = min'),
 'file:attachment yielded no readable text': (FILE, 'yielded no readable text'), 'file:attachment_binding_sha256': (FILE, '"attachment_binding_sha256": binding'),
 'file:explicit-access -> inaccessible': (FILE, 'explicit-access attachment'), 'file:export-controlled -> inaccessible': (FILE, 'export-controlled attachment'),
 'file:extraction_limits': (FILE, 'extraction_limits='), 'file:invalid attachment size': (FILE, 'invalid attachment size'),
 "file:not_fetched via size cap ('exceeds')": (FILE, '"exceeds" in reason'), 'file:request_started_at': (FILE, '"request_started_at"'),
 'file:text_capture object': (FILE, 'text_capture=retain_bytes'), 'http:time boundary': (HTTP, 'capture time boundary'),
 'inv:cache id differs from filename': (INV, 'cached.get("id") != notice_id'), 'inv:capture received_at aware/future': (INV, 'received.utcoffset() is None'),
 'inv:inventory_captured': (INV, '"inventory_captured" if attachments'), 'inv:refresh_attempt receipt': (INV, '"refresh_attempt"] = out'),
 'rs:IDENTITY_MISMATCH receipt': (RS, 'status="IDENTITY_MISMATCH"'), 'rs:collected within declared budget': (RS, 'collected within declared budget'),
 'rs:file_text_truncated': (RS, 'file_text_truncated='), 'rs:inventory_receipt': (RS, 'record_receipt["inventory_receipt"]'),
 'rs:outside file/type budget': (RS, 'outside file/type budget'), 'rs:stage time budget exhausted': (RS, 'stage time budget exhausted'),
 'rs:text_unavailable fallback': (RS, '"text_unavailable"'),
}
ADDED = {f: added(f) for f in {v[0] for v in labels.values()}}
out = {}; counts = {'executed_by_focused_suite': 0, 'never_executed': 0, 'not_a_delta_line': 0, 'same_line_ternary_indeterminate': 0}
tern = {'file:invalid attachment size', "file:not_fetched via size cap ('exceeds')", 'inv:inventory_captured', 'rs:text_unavailable fallback'}
for lab, (f, needle) in labels.items():
    src = (REPO / f).read_text().splitlines()
    lines = [i for i, s in enumerate(src, 1) if needle in s]
    # the branch body is the matching line, or for a condition line, the following line
    if lab == 'inv:cache id differs from filename' and lines: lines = [lines[0] + 1]
    if lab == 'inv:capture received_at aware/future' and lines: lines = [lines[0] + 1]
    delta = [l for l in lines if l in ADDED[f]]
    if not delta:
        cls = 'not_a_delta_line'
    elif lab in tern:
        cls = 'same_line_ternary_indeterminate'
    elif any(l in hits[f] for l in delta):
        cls = 'executed_by_focused_suite'
    else:
        cls = 'never_executed'
    counts[cls] += 1
    out[lab] = {'file': f, 'lines': lines, 'delta_lines': delta, 'executed_lines': [l for l in delta if l in hits[f]], 'class': cls}
size_tests = subprocess.run(['grep', '-rn', '-E', r'"size"|\'size\'', str(REPO / 'tests/test_sam_attachment_text.py'), str(REPO / 'tests/test_step7_evidence_collection.py')], capture_output=True, text=True).stdout.strip().splitlines()
print(json.dumps({'probe': 'probe_f15_member31_vs_trace', 'status': 'INFO', 'counts': counts, 'size_gate_literal_in_tests': size_tests[:6], 'labels': out}, indent=1))
