"""Independent REPRODUCTION probe for merged finding F-15 (harness gaps).

Written from the finding text only, before reading any member probe script.
Parts:
  A  AAP-1/HDP-06: producer strict-Assess negative test holds with zero attachment fields
  B  HDP-05:       test module restores native _request; observer blind; escape has no receipt
  C  FVE-5/WNI-7:  run_searches IDENTITY_MISMATCH unreachable via real adapter; no-id inventory admitted
  D  RUF-7:        text_unavailable fallback unreachable from the production extractor
  E  HDP-06:       test name 'all_inventory_states' exercises no inventory state; 3 of 6 file states
  F  HDP-06:       literal grep census of delta vocabulary across tests/
No network: socket.connect is blocked for the whole run. No LLM. Writes only to a probe-local temp dir.
"""
import hashlib, json, os, re, socket, sys, tempfile, traceback
from pathlib import Path

REPO = Path('/Users/wtjohnson/lila-step7-052')
os.chdir(REPO)
sys.path.insert(0, str(REPO))
HERE = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp(prefix='f15_', dir=str(HERE)))
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'notice')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'text')
os.environ['LILA_SAM_CACHE_DIR'] = str(TMP / 'sam_cache')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
os.environ.pop('SAM_GOV_API_KEY', None); os.environ.pop('SAM_GOV_API_KEY_2', None)

# ---- absolute network guard -------------------------------------------------
GUARD_HITS = []
_real_connect = socket.socket.connect
def _blocked(self, addr):
    GUARD_HITS.append(str(addr))
    raise RuntimeError(f'NETGUARD blocked connect {addr}')
socket.socket.connect = _blocked

import httpx
from _pytest.monkeypatch import MonkeyPatch
from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail, sam_quota
import run_searches as searches

NATIVE_REQUEST = _http._request
observed = {}
problems = []

def mock_client(payload, status=200, calls=None):
    def handler(request):
        if calls is not None: calls.append(str(request.url))
        return httpx.Response(status, content=payload)
    return lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

def public_file(rid='b'*32, name='SOW.txt'):
    return {'resource_id': rid, 'name': name, 'access_level': 'public', 'access_status': 'public',
            'export_controlled': '0', 'explicit_access': '0'}

def clean_dirs():
    import shutil
    for d in (TMP / 'notice', TMP / 'text'):
        shutil.rmtree(d, ignore_errors=True)

# =========================== Part A ==========================================
def part_a():
    from agents.assess.contracts import LiveClassification
    from tests.test_assess_ledger import _sweep, _build, _depth_record, _build_with_requirement_review
    out = {}
    # A1 baseline: untouched _sweep, nothing attachment-related at all
    run, _, _ = _build(_sweep())
    n1 = next(r for r in run.live.records if r.notice_id == 'N1')
    out['A1_baseline_no_attachment_fields'] = {
        'classification': str(n1.classification), 'not_bid_now': n1.classification != LiveClassification.BID_NOW,
        'requirement_reviewed_at_is_none': n1.requirement_reviewed_at is None,
        'attachment_gap_truthy': bool(n1.attachment_gap), 'attachment_gap': n1.attachment_gap}
    out['A1_all_three_asserts_hold_with_zero_attachment_fields'] = all([
        n1.classification != LiveClassification.BID_NOW, n1.requirement_reviewed_at is None, bool(n1.attachment_gap)])
    # A2 replicate the producer test shape exactly (native collection on N1, term packet capture)
    mp = MonkeyPatch()
    try:
        clean_dirs()
        from agents.schemas import RawOpportunity
        from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
        mp.setattr('tools.api.sam_quota.calls_today', lambda: 0)
        files = [public_file('b'*32, 'SOW 1.txt'), public_file('c'*32, 'SOW 2.txt')]
        inv = detail._manifest_hash(files)
        mp.setattr(detail, 'fetch_notice_resources', lambda *a, **k: {'id': 'N1', 'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv})
        texts = {'b'*32: 'Buyer requires packet capture. The contractor shall provide an enterprise packet capture platform.', 'c'*32: 'Further packet capture deliverables.'}
        mp.setattr(sat, '_download_bytes', lambda rid, **k: texts[rid].encode())
        cand = RawOpportunity(source='sam.gov', source_id='N1', title='Requirement', agency='NASA', raw_payload={'type': 'Solicitation'})
        class Source:
            last_attachment_census = {'selected': 1}
            def attachment_candidates(self, *a, **k): return [cand]
        tax = CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21', core=[TaxonomyTerm(term='packet capture')])
        rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
        row = rows[0]
        added_keys = sorted(k for k in row['raw_payload'] if k != 'type')
        out['A2_attachment_fields_added_to_raw_payload'] = added_keys
        sweep = _sweep(); orig = sweep['results']['sam.gov'][0]
        orig['source_id'] = row['source_id']; orig['raw_payload'].update(row['raw_payload'])
        run2, _, _ = _build(sweep)
        n1b = next(r for r in run2.live.records if r.notice_id == 'N1')
        out['A2_with_attachment_fields'] = {
            'classification': str(n1b.classification), 'not_bid_now': n1b.classification != LiveClassification.BID_NOW,
            'requirement_reviewed_at_is_none': n1b.requirement_reviewed_at is None,
            'attachment_gap_truthy': bool(n1b.attachment_gap)}
        d1 = n1.model_dump() if hasattr(n1, 'model_dump') else dict(n1.__dict__)
        d2 = n1b.model_dump() if hasattr(n1b, 'model_dump') else dict(n1b.__dict__)
        diff = {k: (d1.get(k), d2.get(k)) for k in set(d1) | set(d2) if d1.get(k) != d2.get(k)}
        out['A2_record_fields_differing_with_vs_without_attachment'] = {k: [str(v[0])[:200], str(v[1])[:200]] for k, v in diff.items()}
        out['A2_asserted_fields_identical'] = (
            out['A1_baseline_no_attachment_fields']['classification'] == out['A2_with_attachment_fields']['classification']
            and n1.requirement_reviewed_at == n1b.requirement_reviewed_at and n1.attachment_gap == n1b.attachment_gap)
        out['A2_attachment_text_substring_in_record_dump'] = 'enterprise packet capture platform' in json.dumps(d2, default=str)
        # A3 a discriminating positive path exists (trusted depth + review reaches BID_NOW), so a sharper test is constructible
        s3 = _sweep(); s3['results']['dossiers'] = {'records': [_depth_record()]}
        run3, _, _ = _build_with_requirement_review(s3)
        n1c = next(r for r in run3.live.records if r.notice_id == 'N1')
        out['A3_positive_path_bid_now_exists'] = n1c.classification == LiveClassification.BID_NOW
        # A3b trusted depth (irrelevant description) + attachment text with cue: attachment text must not supply requirement
        s4 = _sweep(); o4 = s4['results']['sam.gov'][0]; o4['raw_payload'].update(row['raw_payload'])
        dep = _depth_record(); dep['source_depth']['description'] = 'Janitorial supplies for a warehouse.'
        s4['results']['dossiers'] = {'records': [dep]}
        run4, _, _ = _build(s4)
        n1d = next(r for r in run4.live.records if r.notice_id == 'N1')
        out['A3b_trusted_irrelevant_depth_plus_attachment_cue'] = {
            'classification': str(n1d.classification), 'requirement_excerpt': n1d.requirement_excerpt,
            'attachment_text_in_dump': 'enterprise packet capture platform' in json.dumps(n1d.model_dump(), default=str)}
    finally:
        mp.undo()
    return out

# =========================== Part B ==========================================
def part_b():
    out = {}
    receipt = []
    def watched(method, url, **kw):
        receipt.append(str(url)); raise RuntimeError('offline suite: tried to reach ' + str(url))
    mp = MonkeyPatch()
    try:
        clean_dirs()
        # B0 observer intact + MockTransport: the observer raises even for a mocked call (why the test bypasses it)
        mp.setattr(_http, '_request', watched)
        mp.setattr(_http, '_client', mock_client(b'{"attachments":[]}'))
        r0 = detail.fetch_notice_resources('a'*32)
        out['B0_observer_intact_mock_call'] = {'collection_status': r0['collection_status'], 'errors': r0['errors'][:1], 'receipt_len': len(receipt)}
        receipt.clear(); clean_dirs()
        # B1 producer fixture pattern: native restored + MockTransport: observer sees nothing
        mp.setattr(_http, '_request', NATIVE_REQUEST)
        r1 = detail.fetch_notice_resources('a'*32)
        out['B1_native_restored_mock_call'] = {'collection_status': r1['collection_status'], 'receipt_len': len(receipt), 'observer_blind': len(receipt) == 0}
        receipt.clear(); clean_dirs()
        # B2 native restored, _client patch dropped: would go live; only the socket guard stops it; receipt still empty
        mp.setattr(_http, '_client', __import__('tools.api._http', fromlist=['_client']).__dict__['_client'])
        mp.undo(); mp = MonkeyPatch(); mp.setattr(_http, '_request', NATIVE_REQUEST)
        before = len(GUARD_HITS)
        r2 = detail.fetch_notice_resources('a'*32)
        out['B2_native_restored_client_unpatched'] = {'collection_status': r2['collection_status'], 'errors': [e[:160] for e in r2['errors'][:2]],
            'netguard_tripped': len(GUARD_HITS) > before, 'receipt_len': len(receipt), 'receipt_empty': len(receipt) == 0}
        # B3 static: test module captures native at import and restores it in its fixture
        src = (REPO / 'tests/test_step7_evidence_collection.py').read_text()
        out['B3_static'] = {'captures_native_at_import': '_NATIVE_REQUEST = _http._request' in src,
                            'restores_in_fixture': "monkeypatch.setattr(_http, '_request', _NATIVE_REQUEST)" in src,
                            'every_test_using_http_fixture_also_patches_client': "monkeypatch.setattr(_http, '_client'" in src}
    finally:
        mp.undo()
    return out

# =========================== Part C ==========================================
def enrich_with(inventory_fn, texts, notice_id='a'*32, extract_override=None):
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    mp = MonkeyPatch()
    try:
        mp.setattr('tools.api.sam_quota.calls_today', lambda: 0)
        mp.setattr(sam_quota, 'note_call', lambda *a, **k: None)
        if inventory_fn is not None:
            mp.setattr(detail, 'fetch_notice_resources', inventory_fn)
        mp.setattr(sat, '_download_bytes', lambda rid, **k: texts[rid].encode())
        if extract_override is not None:
            mp.setattr(sat, 'extract_public_attachment_text', extract_override)
        cand = RawOpportunity(source='sam.gov', source_id=notice_id, title='Requirement', agency='NASA', raw_payload={'type': 'Solicitation'})
        class Source:
            last_attachment_census = {'selected': 1}
            def attachment_candidates(self, *a, **k): return [cand]
        tax = CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21', core=[TaxonomyTerm(term='network visibility')])
        rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
        rec = stats['attachment_record_receipts'][notice_id]
        return {'rows': len(rows), 'status': rec.get('status'), 'errors': [e[:120] for e in rec.get('errors', [])][:3],
                'inventory_receipt_id': (rec.get('inventory_receipt') or {}).get('id'),
                'inventory_collection_status': (rec.get('inventory_receipt') or {}).get('collection_status'),
                'file_statuses': [f.get('status') for f in rec.get('files', [])]}
    finally:
        mp.undo()

def part_c():
    out = {}
    A, B = 'a'*32, 'c'*32
    texts = {'b'*32: 'Buyer requires network visibility.'}
    # C1 real adapter, body names another notice
    mp = MonkeyPatch()
    try:
        clean_dirs()
        mp.setattr(_http, '_request', NATIVE_REQUEST)
        body = json.dumps({'attachments': [{'name': 'x.txt', 'resourceId': 'b'*32}], 'opportunityId': B}).encode()
        mp.setattr(_http, '_client', mock_client(body))
        out['C1_real_adapter_foreign_opportunityId'] = enrich_with(None, texts, notice_id=A)
        clean_dirs()
        # C1b real adapter, cache file on disk carrying a foreign id under A's filename
        cdir = TMP / 'notice'; cdir.mkdir(parents=True, exist_ok=True)
        (cdir / f'{A}.resources.json').write_text(json.dumps({'id': B, 'resources_checked': True, 'attachments': [], 'retrieved_at': '2026-09-13T00:00:00+00:00'}))
        mp.setattr(_http, '_client', mock_client(b'{"attachments":[]}'))
        r = detail.fetch_notice_resources(A)
        out['C1b_cached_foreign_id_discarded'] = {'returned_id': r['id'], 'from_cache': r['from_cache'], 'collection_status': r['collection_status']}
    finally:
        mp.undo()
    # C2 static: every return path of fetch_notice_resources yields id == notice_id
    src = (REPO / 'tools/api/sam_notice_detail.py').read_text()
    fn = src[src.index('def fetch_notice_resources'):src.index('def _resource_capture_valid')]
    out['C2_static'] = {'out_id_set_to_notice_id': '"id": notice_id,' in fn,
                        'cache_rejects_other_id': 'cached.get("id") != notice_id' in fn,
                        'returns': fn.count('return ')}
    # C3 monkeypatched inventory doubles
    clean_dirs()
    files = [public_file('b'*32, 'SOW.txt')]; inv = detail._manifest_hash(files)
    out['C3a_double_id_other'] = enrich_with(lambda *a, **k: {'id': B, 'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv}, texts, notice_id=A)
    clean_dirs()
    out['C3b_double_id_missing'] = enrich_with(lambda *a, **k: {'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv}, texts, notice_id=A)
    out['C_IDENTITY_MISMATCH_reachable_via_real_adapter'] = out['C1_real_adapter_foreign_opportunityId']['status'] == 'IDENTITY_MISMATCH'
    out['C_IDENTITY_MISMATCH_reachable_via_double'] = out['C3a_double_id_other']['status'] == 'IDENTITY_MISMATCH'
    out['C_no_id_double_admitted_and_enriched'] = out['C3b_double_id_missing']['rows'] == 1 and out['C3b_double_id_missing']['status'] not in ('IDENTITY_MISMATCH',)
    return out

# =========================== Part D ==========================================
def part_d():
    out = {}; statuses = {}
    mp = MonkeyPatch()
    try:
        clean_dirs()
        # gate refusals
        r = sat.extract_public_attachment_text(public_file('../wrong')); statuses['gate_invalid_id'] = r.get('collection_status', 'ABSENT')
        r = sat.extract_public_attachment_text({**public_file(), 'access_level': 'private'}); statuses['gate_private'] = r.get('collection_status', 'ABSENT')
        r = sat.extract_public_attachment_text({**public_file(), 'size': str(10**9)}); statuses['gate_oversize'] = r.get('collection_status', 'ABSENT')
        r = sat.extract_public_attachment_text({**public_file(), 'export_controlled': '1'}); statuses['gate_export_controlled'] = r.get('collection_status', 'ABSENT')
        # success then cache hit
        mp.setattr(sat, '_download_bytes', lambda *a, **k: b'Original requirement text')
        r = sat.extract_public_attachment_text(public_file()); statuses['success'] = r.get('collection_status', 'ABSENT')
        r = sat.extract_public_attachment_text(public_file()); statuses['cache_hit'] = r.get('collection_status', 'ABSENT'); out['cache_hit_from_cache'] = r.get('from_cache')
        # empty text -> unreadable
        mp.setattr(sat, '_download_bytes', lambda *a, **k: b'   ')
        r = sat.extract_public_attachment_text(public_file('f'*32)); statuses['blank_text'] = r.get('collection_status', 'ABSENT')
        # exception -> lookup_failed
        mp.setattr(sat, '_download_bytes', lambda *a, **k: (_ for _ in ()).throw(RuntimeError('boom')))
        r = sat.extract_public_attachment_text(public_file('1'*32)); statuses['exception'] = r.get('collection_status', 'ABSENT')
        # 403 -> inaccessible
        resp = httpx.Response(403, request=httpx.Request('GET', 'https://sam.gov/x'))
        mp.setattr(sat, '_download_bytes', lambda *a, **k: resp.raise_for_status())
        r = sat.extract_public_attachment_text(public_file('2'*32)); statuses['http_403'] = r.get('collection_status', 'ABSENT')
        # deadline exhausted before download
        mp.setattr(sat, '_download_bytes', lambda *a, **k: (_ for _ in ()).throw(TimeoutError('deadline')))
        r = sat.extract_public_attachment_text(public_file('3'*32), deadline_monotonic=0.0); statuses['deadline'] = r.get('collection_status', 'ABSENT')
    finally:
        mp.undo()
    out['extractor_collection_status_by_path'] = statuses
    six = {'captured_discovery_only', 'lookup_failed', 'unreadable', 'inaccessible', 'identity_mismatch', 'not_fetched'}
    out['all_paths_set_collection_status'] = 'ABSENT' not in statuses.values()
    out['all_values_within_claimed_six'] = set(statuses.values()) <= six
    # static: extractor never pops/deletes collection_status
    src = (REPO / 'tools/api/sam_attachment_text.py').read_text()
    out['static_no_pop_or_del_of_collection_status'] = not re.search(r'(pop|del)\s*\(?\s*["\']collection_status', src)
    # run_searches path with the real extractor: text_unavailable never appears
    clean_dirs()
    files = [public_file('b'*32, 'SOW.txt'), public_file('c'*32, 'Blank.txt')]; inv = detail._manifest_hash(files)
    real = enrich_with(lambda *a, **k: {'id': 'a'*32, 'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv},
                       {'b'*32: 'Buyer requires network visibility.', 'c'*32: '   '})
    out['run_searches_real_extractor_file_statuses'] = real['file_statuses']
    # only a double omitting collection_status reaches the fallback
    clean_dirs()
    def stub(att, **k): return {'resource_id': att['resource_id'], 'name': att['name'], 'text': '', 'sha256': '', 'error': ''}
    dbl = enrich_with(lambda *a, **k: {'id': 'a'*32, 'resources_checked': True, 'attachments': files, 'attachment_inventory_hash': inv},
                      {'b'*32: 'x', 'c'*32: 'y'}, extract_override=stub)
    out['run_searches_stub_without_collection_status_file_statuses'] = dbl['file_statuses']
    out['text_unavailable_reachable_only_via_double'] = ('text_unavailable' not in real['file_statuses']) and ('text_unavailable' in dbl['file_statuses'])
    return out

# =========================== Part E ==========================================
def part_e():
    src = (REPO / 'tests/test_step7_evidence_collection.py').read_text()
    name = 'test_native_unicode_file_locators_and_all_inventory_states_reach_dossier'
    helper = src[src.index('def native_collection'):src.index('def ' + name)]
    body = src[src.index('def ' + name):src.index('@pytest.mark.parametrize', src.index('def ' + name))]
    states = re.findall(r"'(captured_discovery_only|lookup_failed|unreadable|inaccessible|identity_mismatch|not_fetched)'", body)
    inv_states = re.findall(r"(confirmed_empty|unrecognized_inventory|identity_mismatch|lookup_failed|inventory_captured|stale_inventory)", body)
    return {'helper_monkeypatches_fetch_notice_resources': "monkeypatch.setattr(detail,'fetch_notice_resources'" in helper,
            'test_body_mentions_inventory_state_literals': sorted(set(inv_states)),
            'distinct_file_states_asserted': sorted(set(states)), 'file_states_count': len(set(states)),
            'name_overstates_inventory_states': ("monkeypatch.setattr(detail,'fetch_notice_resources'" in helper) and not inv_states}

# =========================== Part F ==========================================
def part_f():
    words = ['inventory_captured', 'refresh_attempt', 'received_at', 'retained SAM bytes changed', 'invalid retained SAM digest',
             'invalid retained SAM locator', 'retained SAM object escaped cache', 'invalid attachment size', 'yielded no readable text',
             'attachment_binding_sha256', 'text_capture', 'extraction_limits', 'request_started_at', 'IDENTITY_MISMATCH', 'inventory_receipt',
             'stage time budget exhausted', 'outside file/type budget', 'collected within declared budget', 'text_unavailable',
             'file_text_truncated', 'included_end', 'Attachment collection receipt is malformed', 'does not bind this notice/text/inventory',
             'Attachment file locator is missing', 'does not match retained text', 'leave unbound text', 'stale_inventory']
    hits = {}
    for w in words:
        n = 0
        for p in (REPO / 'tests').rglob('*.py'):
            if w in p.read_text(errors='ignore'): n += 1
        hits[w] = n
    zero = [w for w, n in hits.items() if n == 0]
    return {'zero_hit_terms': zero, 'zero_hit_count': len(zero), 'nonzero': {w: n for w, n in hits.items() if n}}

for label, fn in (('A', part_a), ('B', part_b), ('C', part_c), ('D', part_d), ('E', part_e), ('F', part_f)):
    try:
        observed[label] = fn()
    except Exception:
        observed[label] = {'EXC': traceback.format_exc()[-2500:]}
        problems.append(label)

A, B, C, D, E, F = (observed.get(k, {}) for k in 'ABCDEF')
checks = {
    'A_negative_test_holds_with_zero_attachment_fields': A.get('A1_all_three_asserts_hold_with_zero_attachment_fields') is True and A.get('A2_asserted_fields_identical') is True,
    'B_observer_blind_after_native_restore': (B.get('B1_native_restored_mock_call') or {}).get('observer_blind') is True,
    'B_escape_without_client_patch_has_no_receipt': (B.get('B2_native_restored_client_unpatched') or {}).get('receipt_empty') is True and (B.get('B2_native_restored_client_unpatched') or {}).get('netguard_tripped') is True,
    'C_IDENTITY_MISMATCH_dead_with_real_adapter': C.get('C_IDENTITY_MISMATCH_reachable_via_real_adapter') is False and C.get('C_IDENTITY_MISMATCH_reachable_via_double') is True,
    'C_no_id_double_admitted': C.get('C_no_id_double_admitted_and_enriched') is True,
    'D_text_unavailable_dead_with_real_extractor': D.get('text_unavailable_reachable_only_via_double') is True and D.get('all_paths_set_collection_status') is True,
    'E_test_name_overstates': E.get('name_overstates_inventory_states') is True and E.get('file_states_count') == 3,
    'F_many_delta_terms_have_zero_test_hits': F.get('zero_hit_count', 0) >= 20,
}
status = 'FAIL' if all(checks.values()) and not problems else ('INFO' if not problems else 'FAIL')
# FAIL here means: the harness gap described by F-15 reproduces (the producer test suite is not the proof claimed)
print(json.dumps({'status': status, 'meaning': 'FAIL = F-15 harness gaps reproduce as described', 'checks': checks,
                  'exceptions_in_parts': problems, 'netguard_hits': GUARD_HITS, 'observed': observed}, indent=1, default=str))
