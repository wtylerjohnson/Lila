"""CT-1 IMPACT verification: where can an AttributeError from a re-typed Step7 cache field flow?

Refuter stance. Measures (1) the crash itself at the candidate, (2) the same and the wider
malformed-cache class at base 2d522f0, (3) persistence (does the sweep self-heal?),
(4) breadth preservation for a description-matched census row, (5) every downstream
surface: saved sweep receipts, triage prefilter disposition, Assess ledger coverage,
dossier research context, and (6) realism: which writers can produce the trigger.
No network, no LLM. Writes only under this directory.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]

TMP = HERE / "tmp"
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir()


def fresh_dirs(name: str) -> tuple[Path, Path]:
    root = TMP / name
    notice = root / "notice"
    text = root / "text"
    notice.mkdir(parents=True)
    text.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(notice)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text)
    return notice, text


from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from tools.relevance.engine import score_record  # noqa: E402
from tools.relevance.screening import screening_evidence, no_match_state  # noqa: E402
from agents.assess.ledger import _sam_coverage  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

sam_quota.calls_today = lambda: 0


def load_base(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


BASE_SAT = load_base("base_sam_attachment_text", HERE / "base" / "sam_attachment_text.py")
BASE_DETAIL = load_base("base_sam_notice_detail", HERE / "base" / "sam_notice_detail.py")

NID = "a" * 32
R1, R2 = "b" * 32, "c" * 32
TERM = "network visibility"
TEXTS = {R1: f"Buyer requires {TERM}. File one.".encode(), R2: b"Unrelated file two with pricing."}
INVENTORY_BODY = json.dumps({"attachments": [
    {"name": "SOW 1.txt", "resourceId": R1, "mimeType": "text/plain", "size": 30, "accessLevel": "public"},
    {"name": "SOW 2.txt", "resourceId": R2, "mimeType": "text/plain", "size": 30, "accessLevel": "public"},
]}).encode()

http_calls: list[str] = []
download_calls: list[str] = []


def mock_http(payload: bytes = INVENTORY_BODY, status: int = 200):
    def handler(request):
        http_calls.append(str(request.url))
        return httpx.Response(status, content=payload)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def mock_download(module, mapping=TEXTS):
    def dl(resource_id, **k):
        download_calls.append(resource_id)
        return mapping[resource_id]
    module._download_bytes = dl


mock_http()
mock_download(sat)
mock_download(BASE_SAT)


def public_file(resource_id, name):
    return {"resource_id": resource_id, "name": name, "type": "text/plain",
            "source_url": f"https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{resource_id}/download",
            "size": 30, "access_level": "public", "access_status": None,
            "export_controlled": "0", "explicit_access": "0"}


def attempt(fn, *a, **k):
    try:
        return {"crashed": False, "result": fn(*a, **k)}
    except Exception as exc:  # noqa: BLE001 - measured
        return {"crashed": True, "exception": f"{type(exc).__name__}: {exc}"[:160]}


def summarize(out: dict) -> dict:
    if out["crashed"]:
        return out
    r = out["result"]
    return {"crashed": False, "collection_status": r.get("collection_status"), "from_cache": r.get("from_cache"),
            "text": (r.get("text") or "")[:40], "error": (r.get("error") or "")[:80],
            "attachments_count": len(r.get("attachments") or []) if isinstance(r.get("attachments"), list) else None}


def seed_text_cache(module, text_dir: Path) -> Path:
    """Write a genuine cache entry with the given module's own writer."""
    inventory = detail._attachment_inventory(json.loads(INVENTORY_BODY), NID)[0]
    att = next(a for a in inventory if a["resource_id"] == R1)
    module.extract_public_attachment_text(att)
    return text_dir / f"{R1}.json", att


def seed_inventory_cache(module, notice_dir: Path) -> Path:
    module.fetch_notice_resources(NID)
    return notice_dir / f"{NID}.resources.json"


def mutate(path: Path, **fields):
    saved = json.loads(path.read_text())
    for k, v in fields.items():
        saved[k] = v
    path.write_text(json.dumps(saved))


cases: dict = {}

# ---------------------------------------------------------------- 1. candidate crash, direct
notice, text = fresh_dirs("cand_text")
cache, att = seed_text_cache(sat, text)
written = json.loads(cache.read_text())
cases["candidate_writer_field_types"] = {
    "text_cache": {k: type(written.get(k)).__name__ for k in ("raw_capture", "text_capture", "retrieved_at", "text_locator")}}
direct = {}
for label, fields in {
    "raw_capture_str": {"raw_capture": "corrupt"},
    "raw_capture_null": {"raw_capture": None},
    "text_capture_null": {"text_capture": None},
    "retrieved_at_int": {"retrieved_at": 1700000000},
    "retrieved_at_null": {"retrieved_at": None},
    "invalid_json_file": None,
    "json_list_file": None,
    "empty_file": None,
    "legacy_no_raw_capture": "legacy",
}.items():
    notice, text = fresh_dirs(f"cand_text_{label}")
    cache, att = seed_text_cache(sat, text)
    if fields == "legacy":
        saved = json.loads(cache.read_text())
        for k in ("raw_capture", "text_capture", "text_sha256", "text_locator", "collection_status",
                  "authority", "attachment_binding_sha256", "extraction_limits"):
            saved.pop(k, None)
        cache.write_text(json.dumps(saved))
    elif fields is None:
        cache.write_text({"invalid_json_file": "{not json", "json_list_file": "[]", "empty_file": ""}[label])
    else:
        mutate(cache, **fields)
    direct[label] = summarize(attempt(sat.extract_public_attachment_text, att))
cases["candidate_text_direct"] = direct

direct = {}
for label, fields in {"raw_capture_str": {"raw_capture": "corrupt"}, "raw_capture_null": {"raw_capture": None},
                      "raw_capture_list": {"raw_capture": []},
                      "invalid_json_file": None, "json_list_file": None, "legacy_no_raw_capture": "legacy"}.items():
    notice, text = fresh_dirs(f"cand_inv_{label}")
    cache = seed_inventory_cache(detail, notice)
    if fields == "legacy":
        saved = json.loads(cache.read_text())
        for k in ("raw_capture", "collection_status", "authority"):
            saved.pop(k, None)
        cache.write_text(json.dumps(saved))
    elif fields is None:
        cache.write_text({"invalid_json_file": "{not json", "json_list_file": "[]"}[label])
    else:
        mutate(cache, **fields)
    direct[label] = summarize(attempt(detail.fetch_notice_resources, NID))
cases["candidate_inventory_direct"] = direct

# ---------------------------------------------------------------- 2. base class comparison
base_text = {}
for label, fields in {"raw_capture_str": {"raw_capture": "corrupt"}, "retrieved_at_int": {"retrieved_at": 1700000000},
                      "invalid_json_file": None, "json_list_file": None, "empty_file": None}.items():
    notice, text = fresh_dirs(f"base_text_{label}")
    cache, att = seed_text_cache(BASE_SAT, text)
    if fields is None:
        cache.write_text({"invalid_json_file": "{not json", "json_list_file": "[]", "empty_file": ""}[label])
    else:
        mutate(cache, **fields)
    base_text[label] = summarize(attempt(BASE_SAT.extract_public_attachment_text, att))
cases["base_text_direct"] = base_text

base_inv = {}
for label, fields in {"raw_capture_str": {"raw_capture": "corrupt"}, "invalid_json_file": None, "json_list_file": None}.items():
    notice, text = fresh_dirs(f"base_inv_{label}")
    cache = seed_inventory_cache(BASE_DETAIL, notice)
    if fields is None:
        cache.write_text({"invalid_json_file": "{not json", "json_list_file": "[]"}[label])
    else:
        mutate(cache, **fields)
    base_inv[label] = summarize(attempt(BASE_DETAIL.fetch_notice_resources, NID))
cases["base_inventory_direct"] = base_inv


# ---------------------------------------------------------------- 3. run_searches propagation
def census_row():
    return json.loads(RawOpportunity(source="sam.gov", source_id=NID, title="Requirement",
                                     agency="NASA", raw_payload={"type": "Solicitation"}).model_dump_json())


def run_enrich(sam_rows):
    candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]
    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
    rows, stats = searches._enrich_sam_public_attachments(sam_rows, Source(), object(), tax, None, limit=8)
    return rows, stats, tax


# 3a positive control
notice, text = fresh_dirs("rs_pos")
rows, stats, tax = run_enrich([])
rec = stats["attachment_record_receipts"][NID]
cases["run_searches_positive_control"] = {"rows": len(rows), "status": rec["status"], "relevant": stats["attachment_relevant"]}

# 3b malformed text cache, attachment-only candidate (finder's case) and description-matched census row
for label, sam_rows in {"attachment_only_candidate": [], "description_matched_census_row": [census_row()]}.items():
    notice, text = fresh_dirs(f"rs_text_{label}")
    run_enrich([])
    cache = text / f"{R1}.json"
    mutate(cache, raw_capture="corrupt")
    before = cache.read_bytes()
    download_calls.clear()
    rows, stats, tax = run_enrich(sam_rows)
    rec = stats["attachment_record_receipts"][NID]
    cases[f"run_searches_text_{label}"] = {
        "rows": len(rows), "row_ids": [r["source_id"] for r in rows],
        "census_row_preserved": any(r["source_id"] == NID for r in rows) if sam_rows else None,
        "row_has_attachment_keys": any(k.startswith("attachment") or k == "text" for r in rows for k in r["raw_payload"]) if rows else False,
        "status": rec["status"], "errors": rec["errors"],
        "inventory_receipt_present": "inventory_receipt" in rec,
        "file_receipts": [{k: f.get(k) for k in ("resource_id", "status", "reason")} for f in rec.get("files", [])],
        "download_calls_during_sweep": list(download_calls),
        "cache_bytes_unchanged_after_sweep": cache.read_bytes() == before,
        "stats_attachment_errors": stats["attachment_errors"],
    }

# 3c persistence: second sweep, then with the finder's fix shim applied
notice, text = fresh_dirs("rs_persist")
run_enrich([])
cache = text / f"{R1}.json"
mutate(cache, raw_capture="corrupt")
before = cache.read_bytes()
statuses = []
for _ in range(3):
    rows, stats, tax = run_enrich([])
    statuses.append(stats["attachment_record_receipts"][NID]["status"])
persist = {"three_sweeps_statuses": statuses, "cache_bytes_unchanged": cache.read_bytes() == before}
orig_valid = sat._text_capture_valid


def fixed_valid(*a, **k):
    try:
        return orig_valid(*a, **k)
    except AttributeError:
        return False


sat._text_capture_valid = fixed_valid
download_calls.clear()
rows, stats, tax = run_enrich([])
rec = stats["attachment_record_receipts"][NID]
persist["with_attributeerror_caught"] = {"status": rec["status"], "rows": len(rows),
                                         "download_calls": list(download_calls),
                                         "cache_rewritten_to_dict_raw_capture": isinstance(json.loads(cache.read_text()).get("raw_capture"), dict)}
sat._text_capture_valid = orig_valid
cases["persistence_no_self_heal"] = persist

# 3d malformed inventory cache with description-matched row
notice, text = fresh_dirs("rs_inv")
detail.fetch_notice_resources(NID)
cache = notice / f"{NID}.resources.json"
mutate(cache, raw_capture="corrupt")
before = cache.read_bytes()
http_calls.clear()
rows, stats, tax = run_enrich([census_row()])
rec = stats["attachment_record_receipts"][NID]
cases["run_searches_inventory_description_matched"] = {
    "rows": len(rows), "census_row_preserved": any(r["source_id"] == NID for r in rows),
    "status": rec["status"], "errors": rec["errors"], "inventory_receipt_present": "inventory_receipt" in rec,
    "http_calls_during_sweep": len(http_calls), "cache_bytes_unchanged_after_sweep": cache.read_bytes() == before}

# ---------------------------------------------------------------- 4. downstream surfaces for the FAILED notice
notice, text = fresh_dirs("downstream")
run_enrich([])
mutate(text / f"{R1}.json", raw_capture="corrupt")
rows, stats, tax = run_enrich([census_row()])
rec = stats["attachment_record_receipts"][NID]
row = next(r for r in rows if r["source_id"] == NID)
verdict = score_record(row, tax, engagement_scope=None)
evidence = screening_evidence(row, verdict, rec)
state = no_match_state(evidence)
census = {"source": "sam_extract", "matched": len(rows), "active_screened": 10, "retrieved": 10, "complete": True,
          "attachment_record_receipts": stats["attachment_record_receipts"], "attachment_errors": stats["attachment_errors"]}
cov_with = _sam_coverage({"sam.gov": rows, "sam_census": census})
cov_without = _sam_coverage({"sam.gov": rows, "sam_census": {k: v for k, v in census.items() if not k.startswith("attachment")}})
ctx = _attachment_research_context(row, {"id": NID, "resources_checked": True})
cases["downstream_surfaces"] = {
    "triage_attachment_status": evidence["attachment_status"],
    "triage_attachment_errors": evidence["attachment_errors"],
    "triage_no_match_state": state[0],
    "triage_discovery_evidence": evidence["attachment_discovery_evidence"],
    "triage_would_be_candidate": bool(verdict.core_terms or verdict.adjacent_terms),
    "assess_coverage_status_with_receipts": str(cov_with.status),
    "assess_coverage_status_without_receipts": str(cov_without.status),
    "assess_coverage_identical": cov_with.model_dump(mode="json") == cov_without.model_dump(mode="json"),
    "dossier_research_context": ctx,
    "row_raw_payload_keys": sorted(row["raw_payload"].keys()),
    "eight_slot_reachable_attachment_fields": [k for k in row["raw_payload"] if k.startswith("attachment") or k == "text"],
}

# ---------------------------------------------------------------- 5. realism: default cache location and ownership
default_text = sat._DEFAULT_CACHE
default_notice = detail._DEFAULT_CACHE
cases["realism"] = {
    "default_text_cache_under_repo": str(default_text).startswith(str(REPO)),
    "default_notice_cache_under_repo": str(default_notice).startswith(str(REPO)),
    "default_text_cache": str(default_text), "default_notice_cache": str(default_notice),
    "code_writer_types_text": cases["candidate_writer_field_types"]["text_cache"],
    "trigger_requires": "a JSON object that parses, carries the Step7 keys, and has a Step7 field re-typed; "
                        "the code's own writer, legacy (base) caches, truncation, empty files and non-object JSON do not trigger it",
}

# ---------------------------------------------------------------- verdict
crash_text = [k for k, v in cases["candidate_text_direct"].items() if v.get("crashed")]
crash_inv = [k for k, v in cases["candidate_inventory_direct"].items() if v.get("crashed")]
base_crash_text = [k for k, v in cases["base_text_direct"].items() if v.get("crashed")]
base_crash_inv = [k for k, v in cases["base_inventory_direct"].items() if v.get("crashed")]
notes = []
status = "PASS"
if crash_text or crash_inv:
    status = "FAIL"
    notes.append(f"candidate crashes: text {crash_text}, inventory {crash_inv}; per-notice receipt FAILED, no refetch, no self-heal")
if base_crash_text or base_crash_inv:
    notes.append(f"base also crashed on malformed local caches of a different shape: text {base_crash_text}, inventory {base_crash_inv}; "
                 "the candidate fixed those and introduced the field-type crashes on Step7-only keys")
ds = cases["downstream_surfaces"]
if ds["assess_coverage_identical"] and ds["dossier_research_context"] is None and ds["triage_no_match_state"] == "ATTACHMENT_UNAVAILABLE":
    notes.append("impact confined: census row preserved, triage disposition conservative (ATTACHMENT_UNAVAILABLE), "
                 "Assess coverage unaffected, dossier has no research context, no wrong-notice evidence, no approval field touched")
if cases["run_searches_text_attachment_only_candidate"]["rows"] == 0:
    notes.append("yield loss is real for attachment-only relevance: the notice never enters rows until the local cache file is repaired by hand")
print(json.dumps({"probe": "ct1_impact", "status": status, "observed": {"cases": cases, "notes": notes}},
                 indent=1, sort_keys=True, default=str))
