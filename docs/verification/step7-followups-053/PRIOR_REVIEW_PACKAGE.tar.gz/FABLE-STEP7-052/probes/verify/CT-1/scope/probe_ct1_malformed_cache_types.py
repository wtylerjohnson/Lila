"""CT-1 independent refutation probe: malformed cache field types.

Question: does a cache JSON whose raw_capture / text_capture / retrieved_at
carries a non-dict / non-string type raise AttributeError out of
_text_capture_valid / _resource_capture_valid, and does that sink the whole
notice inside run_searches._enrich_sam_public_attachments?

Parts
 A. validator crash matrix, candidate vs base 2d522f0 modules (direct calls)
 B. run_searches propagation with REAL fetch_notice_resources (mocked HTTP)
    and REAL extract_public_attachment_text (mocked _download_bytes)
 C. persistence: second sweep against the same malformed entry
 D. context: base behaviour on an invalid-JSON cache file (pre-existing class?)
 E. positive control: candidate handles the producer's own 'json' tamper
    (top-level list) as a cache miss followed by a refetch

No network (socket connect blocked), no LLM, no writes outside this scope dir.
"""
from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import traceback
from pathlib import Path

SCOPE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402


def _blocked(*a, **k):
    raise RuntimeError("network blocked by CT-1 probe")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as csat  # noqa: E402
from tools.api import sam_notice_detail as cdetail  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0

NID = "a" * 32
R1, R2 = "b" * 32, "c" * 32
TERM = "network visibility"
TEXTS = {R1: f"Buyer requires {TERM}. File one.".encode(), R2: b"Unrelated file two with pricing."}
INV_BODY = json.dumps({"attachments": [
    {"name": "SOW 1.txt", "resourceId": R1, "mimeType": "text/plain", "size": 5, "accessLevel": "public"},
    {"name": "SOW 2.txt", "resourceId": R2, "mimeType": "text/plain", "size": 5, "accessLevel": "public"},
]}).encode()


def load_base(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


bsat = load_base("base_sam_attachment_text", SCOPE / "base" / "base_sam_attachment_text.py")
bdetail = load_base("base_sam_notice_detail", SCOPE / "base" / "base_sam_notice_detail.py")


def fresh_dirs(name: str) -> tuple[Path, Path]:
    root = SCOPE / "tmp" / name
    if root.exists():
        shutil.rmtree(root)
    notice, text = root / "notice", root / "text"
    notice.mkdir(parents=True)
    text.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(notice)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text)
    return notice, text


def mock_http(payload: bytes | None, fail: bool = False):
    calls = []

    def handler(request):
        calls.append(str(request.url))
        if fail:
            raise httpx.ConnectError("source unavailable (probe)", request=request)
        return httpx.Response(200, content=payload)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def mock_download(mod, mapping=None, fail: bool = False):
    calls = []

    def dl(resource_id, **k):
        calls.append(resource_id)
        if fail:
            raise RuntimeError("source unavailable (probe)")
        return mapping[resource_id]

    mod._download_bytes = dl
    return calls


def public_file(resource_id, name):
    return {"resource_id": resource_id, "name": name, "type": "text/plain",
            "source_url": None, "size": 20, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def excinfo(exc: BaseException) -> str:
    return f"{type(exc).__name__}: {exc}"


observed: dict = {}

# ---------------------------------------------------------------- Part A
TEXT_TAMPERS = {
    "raw_capture_str": lambda s: s.__setitem__("raw_capture", "corrupt"),
    "raw_capture_list": lambda s: s.__setitem__("raw_capture", []),
    "raw_capture_int": lambda s: s.__setitem__("raw_capture", 7),
    "raw_capture_null": lambda s: s.__setitem__("raw_capture", None),
    "text_capture_null": lambda s: s.__setitem__("text_capture", None),
    "text_capture_str": lambda s: s.__setitem__("text_capture", "corrupt"),
    "retrieved_at_int": lambda s: s.__setitem__("retrieved_at", 1757700000),
    "retrieved_at_null": lambda s: s.__setitem__("retrieved_at", None),
    "retrieved_at_list": lambda s: s.__setitem__("retrieved_at", ["2026"]),
    # controls that the except tuple DOES cover
    "text_locator_str": lambda s: s.__setitem__("text_locator", "x"),
    "raw_capture_missing": lambda s: s.pop("raw_capture"),
    "raw_capture_empty_dict": lambda s: s.__setitem__("raw_capture", {}),
}
INV_TAMPERS = {
    "raw_capture_str": lambda s: s.__setitem__("raw_capture", "corrupt"),
    "raw_capture_list": lambda s: s.__setitem__("raw_capture", []),
    "raw_capture_int": lambda s: s.__setitem__("raw_capture", 7),
    "raw_capture_null": lambda s: s.__setitem__("raw_capture", None),
    # controls
    "raw_capture_missing": lambda s: s.pop("raw_capture"),
    "raw_capture_empty_dict": lambda s: s.__setitem__("raw_capture", {}),
    "received_at_int": lambda s: s["raw_capture"].__setitem__("received_at", 1757700000),
}


def text_direct(mod, label, mutate):
    notice, text = fresh_dirs(f"A_text_{mod.__name__}_{label}")
    mock_download(mod, {R1: b"Original requirement"})
    mod.extract_public_attachment_text(public_file(R1, "SOW.txt"))
    cache = text / f"{R1}.json"
    saved = json.loads(cache.read_text())
    try:
        mutate(saved)
    except (KeyError, AttributeError, TypeError):
        return {"skipped": "tamper not applicable to this module's cache shape"}
    cache.write_text(json.dumps(saved))
    calls = mock_download(mod, fail=True)
    try:
        r = mod.extract_public_attachment_text(public_file(R1, "SOW.txt"))
        return {"crashed": False, "from_cache": r.get("from_cache"),
                "collection_status": r.get("collection_status"),
                "text": (r.get("text") or "")[:40], "refetch_attempted": bool(calls)}
    except Exception as exc:  # noqa: BLE001
        return {"crashed": True, "exception": excinfo(exc), "refetch_attempted": bool(calls)}


def inv_direct(mod, label, mutate):
    notice, text = fresh_dirs(f"A_inv_{mod.__name__}_{label}")
    mock_http(INV_BODY)
    mod.fetch_notice_resources(NID)
    cache = notice / f"{NID}.resources.json"
    saved = json.loads(cache.read_text())
    try:
        mutate(saved)
    except (KeyError, AttributeError, TypeError):
        return {"skipped": "tamper not applicable to this module's cache shape"}
    cache.write_text(json.dumps(saved))
    calls = mock_http(INV_BODY)
    try:
        r = mod.fetch_notice_resources(NID)
        return {"crashed": False, "from_cache": r.get("from_cache"), "stale_cache": r.get("stale_cache"),
                "collection_status": r.get("collection_status"),
                "attachments_n": len(r.get("attachments") or []), "refetch_attempted": bool(calls)}
    except Exception as exc:  # noqa: BLE001
        return {"crashed": True, "exception": excinfo(exc), "refetch_attempted": bool(calls)}


part_a = {"text": {}, "inventory": {}}
for label, mutate in TEXT_TAMPERS.items():
    part_a["text"][label] = {"candidate": text_direct(csat, label, mutate),
                             "base": text_direct(bsat, label, mutate)}
for label, mutate in INV_TAMPERS.items():
    part_a["inventory"][label] = {"candidate": inv_direct(cdetail, label, mutate),
                                  "base": inv_direct(bdetail, label, mutate)}
observed["A_validator_matrix"] = part_a
cand_text_crashes = sorted(k for k, v in part_a["text"].items() if v["candidate"].get("crashed"))
cand_inv_crashes = sorted(k for k, v in part_a["inventory"].items() if v["candidate"].get("crashed"))
base_text_crashes = sorted(k for k, v in part_a["text"].items() if v["base"].get("crashed"))
base_inv_crashes = sorted(k for k, v in part_a["inventory"].items() if v["base"].get("crashed"))
all_attr = all("AttributeError" in part_a["text"][k]["candidate"]["exception"] for k in cand_text_crashes) and \
    all("AttributeError" in part_a["inventory"][k]["candidate"]["exception"] for k in cand_inv_crashes)
observed["A_summary"] = {"candidate_text_crashes": cand_text_crashes, "candidate_inventory_crashes": cand_inv_crashes,
                         "base_text_crashes": base_text_crashes, "base_inventory_crashes": base_inv_crashes,
                         "every_candidate_crash_is_AttributeError": all_attr}

# ---------------------------------------------------------------- Part B / C
importlib.reload(cdetail)
importlib.reload(csat)
importlib.reload(searches)


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})]


TAX = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])


def sweep():
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), TAX, None, limit=8)
    rec = stats["attachment_record_receipts"][NID]
    return rows, stats, rec


def receipt_view(rows, rec):
    return {"rows": len(rows), "status": rec["status"], "errors": rec.get("errors"),
            "file_states": {f["resource_id"]: f["status"] for f in rec.get("files", [])} if "files" in rec else None,
            "inventory_receipt_present": "inventory_receipt" in rec}


part_b = {}
# positive control
fresh_dirs("B_positive")
mock_http(INV_BODY)
mock_download(csat, TEXTS)
rows, stats, rec = sweep()
part_b["positive_control"] = receipt_view(rows, rec)

# text cache of file 1 malformed (raw_capture -> str), source reachable for both files
notice, text = fresh_dirs("B_text_raw_capture_str")
mock_http(INV_BODY)
mock_download(csat, TEXTS)
sweep()
cache1 = text / f"{R1}.json"
saved = json.loads(cache1.read_text())
saved["raw_capture"] = "corrupt"
cache1.write_text(json.dumps(saved))
before = cache1.read_bytes()
mock_http(INV_BODY)
dl_calls = mock_download(csat, TEXTS)
rows, stats, rec = sweep()
part_b["text_file1_raw_capture_str"] = receipt_view(rows, rec)
part_b["text_file1_raw_capture_str"].update({
    "download_calls_during_failed_sweep": list(dl_calls),
    "file2_healthy_cache_exists": (text / f"{R2}.json").exists(),
    "file2_text_would_have_been_available": R2 not in dl_calls and (text / f"{R2}.json").exists(),
    "attachment_collection_present": any("attachment_collection_v1" in (r.get("raw_payload") or {}) for r in rows),
})
# Part C persistence: second and third sweep against same entry
dl_calls2 = mock_download(csat, TEXTS)
mock_http(INV_BODY)
rows2, stats2, rec2 = sweep()
mock_http(INV_BODY)
rows3, stats3, rec3 = sweep()
part_b["text_file1_persistence"] = {
    "second_sweep": receipt_view(rows2, rec2), "third_sweep_status": rec3["status"],
    "cache_bytes_unchanged_after_three_sweeps": cache1.read_bytes() == before,
    "refetch_ever_attempted_for_file1": R1 in dl_calls or R1 in dl_calls2,
    "text_cache_has_ttl": False,
    "note": "text cache is permanent by resource id; a malformed entry is never repaired because the crash precedes the refetch",
}

# text cache retrieved_at int
notice, text = fresh_dirs("B_text_retrieved_at_int")
mock_http(INV_BODY)
mock_download(csat, TEXTS)
sweep()
cache1 = text / f"{R1}.json"
saved = json.loads(cache1.read_text())
saved["retrieved_at"] = 1757700000
cache1.write_text(json.dumps(saved))
mock_http(INV_BODY)
mock_download(csat, TEXTS)
rows, stats, rec = sweep()
part_b["text_file1_retrieved_at_int"] = receipt_view(rows, rec)

# inventory cache malformed (raw_capture -> null), HTTP reachable
notice, text = fresh_dirs("B_inv_raw_capture_null")
mock_http(INV_BODY)
mock_download(csat, TEXTS)
sweep()
cachei = notice / f"{NID}.resources.json"
saved = json.loads(cachei.read_text())
saved["raw_capture"] = None
cachei.write_text(json.dumps(saved))
http_calls = mock_http(INV_BODY)
mock_download(csat, TEXTS)
rows, stats, rec = sweep()
part_b["inventory_raw_capture_null"] = receipt_view(rows, rec)
part_b["inventory_raw_capture_null"].update({"http_calls_during_failed_sweep": len(http_calls),
                                             "note": "source reachable; no refetch attempted before the crash"})
# inventory recovers only after TTL: show that expiring the clock routes around the validator
saved["retrieved_at"] = "2000-01-01T00:00:00+00:00"
cachei.write_text(json.dumps(saved))
http_calls = mock_http(INV_BODY)
mock_download(csat, TEXTS)
rows, stats, rec = sweep()
part_b["inventory_raw_capture_null_after_ttl_expiry"] = receipt_view(rows, rec)
part_b["inventory_raw_capture_null_after_ttl_expiry"].update({"http_calls": len(http_calls),
                                                              "ttl_seconds": cdetail.RESOURCE_CACHE_TTL_SECONDS})
observed["B_run_searches_propagation"] = part_b

# ---------------------------------------------------------------- Part D: base on invalid JSON
part_d = {}
for mod, tag in ((bsat, "base"), (csat, "candidate")):
    notice, text = fresh_dirs(f"D_invalid_json_{tag}")
    (text / f"{R1}.json").write_text("{not json")
    calls = mock_download(mod, {R1: b"Original requirement"})
    try:
        r = mod.extract_public_attachment_text(public_file(R1, "SOW.txt"))
        part_d[f"text_invalid_json_{tag}"] = {"crashed": False, "from_cache": r.get("from_cache"),
                                              "text": (r.get("text") or "")[:30], "refetched": bool(calls)}
    except Exception as exc:  # noqa: BLE001
        part_d[f"text_invalid_json_{tag}"] = {"crashed": True, "exception": excinfo(exc), "refetched": bool(calls)}
for mod, tag in ((bdetail, "base"), (cdetail, "candidate")):
    notice, text = fresh_dirs(f"D_inv_invalid_json_{tag}")
    (notice / f"{NID}.resources.json").write_text("{not json")
    calls = mock_http(INV_BODY)
    try:
        r = mod.fetch_notice_resources(NID)
        part_d[f"inventory_invalid_json_{tag}"] = {"crashed": False, "from_cache": r.get("from_cache"),
                                                   "attachments_n": len(r.get("attachments") or []), "refetched": bool(calls)}
    except Exception as exc:  # noqa: BLE001
        part_d[f"inventory_invalid_json_{tag}"] = {"crashed": True, "exception": excinfo(exc), "refetched": bool(calls)}
part_d["base_run_searches_has_same_per_candidate_except"] = True  # git show 2d522f0:run_searches.py, 'except Exception ... FAILED' unchanged in diff
observed["D_invalid_json_context"] = part_d

# ---------------------------------------------------------------- Part E: producer's own tamper as control
notice, text = fresh_dirs("E_json_list_tamper")
mock_download(csat, {R1: b"Original requirement"})
csat.extract_public_attachment_text(public_file(R1, "SOW.txt"))
(text / f"{R1}.json").write_text("[]")
calls = mock_download(csat, {R1: b"Original requirement"})
r = csat.extract_public_attachment_text(public_file(R1, "SOW.txt"))
observed["E_producer_json_tamper_control"] = {"crashed": False, "from_cache": r.get("from_cache"),
                                               "collection_status": r.get("collection_status"), "refetched": bool(calls)}

# ---------------------------------------------------------------- verdict
notes = []
status = "PASS"
if cand_text_crashes or cand_inv_crashes:
    status = "FAIL"
    notes.append(f"AttributeError escapes _text_capture_valid for {cand_text_crashes} and _resource_capture_valid for {cand_inv_crashes}; base 2d522f0 crashed on none of these inputs")
if part_b["text_file1_raw_capture_str"]["status"] == "FAILED" and part_b["text_file1_raw_capture_str"]["file2_text_would_have_been_available"]:
    notes.append("run_searches marks the whole notice FAILED; the healthy second file is lost and no refetch of file 1 is attempted")
if part_b["text_file1_persistence"]["cache_bytes_unchanged_after_three_sweeps"] and part_b["text_file1_persistence"]["third_sweep_status"] == "FAILED":
    notes.append("the malformed text entry is never repaired: three consecutive sweeps FAILED with zero download attempts for file 1 (text cache has no TTL)")
if part_b["inventory_raw_capture_null"]["status"] == "FAILED" and part_b["inventory_raw_capture_null_after_ttl_expiry"]["status"] != "FAILED":
    notes.append(f"the malformed inventory entry sinks the notice until the {cdetail.RESOURCE_CACHE_TTL_SECONDS}s TTL expires, then the freshness check routes around the validator and the notice recovers")
if part_d["text_invalid_json_base"].get("crashed") and not part_d["text_invalid_json_candidate"].get("crashed"):
    notes.append("context: at base an INVALID-JSON cache file already sank a notice (ValueError uncaught); the candidate fixed that class but left the type-confusion class open")
notes.append("disclosure check: CONVENTIONS.md 2203 says 'Legacy/unbound/changed cache entries require a new bounded attempt'; no producer doc discloses a crash on malformed field types")
print(json.dumps({"probe": "ct1_malformed_cache_types", "status": status, "observed": observed, "notes": notes},
                 indent=1, sort_keys=True, default=str))
