"""Independent reproduction probe for finding CT-1.

Claim under test: a cache JSON whose raw_capture / text_capture is a non-dict,
or whose retrieved_at is int/null, raises AttributeError out of
extract_public_attachment_text / fetch_notice_resources (the validators only
catch KeyError/TypeError/ValueError/OSError), and inside
run_searches._enrich_sam_public_attachments that exception marks the whole
notice FAILED, losing the healthy second file and the retry download.
Base 2d522f0 did not crash on the same inputs.

Written without reading the original probe script. No network: socket connect
is blocked, _http._client is a MockTransport, _download_bytes is patched.
"""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
BASE_SHA = "2d522f0362e656e029986344d47e2e06b86a58f8"
NOTICE = "a" * 32
FILE1 = "b" * 32
FILE2 = "c" * 32

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
tmp_root = Path(tempfile.mkdtemp(prefix="ct1-", dir=str(PROBE_DIR)))
inv_dir = tmp_root / "inventory"
txt_dir = tmp_root / "text"
inv_dir.mkdir()
txt_dir.mkdir()
os.environ["LILA_NOTICE_CACHE_DIR"] = str(inv_dir)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(txt_dir)
sys.path.insert(0, str(REPO))


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.create_connection = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402

import tools.api._http as _http  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import tools.api.sam_notice_detail as detail  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402

observed: dict = {}
INVENTORY_BODY = {
    "_embedded": {"opportunityAttachmentList": [{"attachments": [
        {"resourceId": FILE1, "name": "SOW 1.txt", "mimeType": "text/plain",
         "accessLevel": "public"},
        {"resourceId": FILE2, "name": "SOW 2.txt", "mimeType": "text/plain",
         "accessLevel": "public"},
    ]}]}
}


def mock_client(body=INVENTORY_BODY, status=200):
    def handler(request):
        return httpx.Response(status, json=body)
    return lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


_http._client = mock_client()
sam_quota.calls_today = lambda: 0


def public_file(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


def call(fn, *a, **k):
    """Return (kind, value): kind in {'returned', 'raised'}."""
    try:
        return "returned", fn(*a, **k)
    except Exception as exc:  # noqa: BLE001 probe records everything
        return "raised", f"{type(exc).__name__}: {exc}"


def clear(directory: Path):
    for p in directory.rglob("*"):
        if p.is_file():
            p.unlink()


# ---------------------------------------------------------------- Part A
# Text cache: build a genuine cache, then corrupt one field's TYPE.
def genuine_text_cache(payload=b"Original requirement text"):
    clear(txt_dir)
    sat._download_bytes = lambda *a, **k: payload
    first = sat.extract_public_attachment_text(public_file(FILE1, "SOW 1.txt"))
    assert first["collection_status"] == "captured_discovery_only", first
    return json.loads((txt_dir / f"{FILE1}.json").read_text())


text_variants = {
    "raw_capture_str": ("raw_capture", "objects/deadbeef.bin"),
    "raw_capture_list": ("raw_capture", []),
    "raw_capture_int": ("raw_capture", 7),
    "raw_capture_null": ("raw_capture", None),
    "text_capture_str": ("text_capture", "x"),
    "text_capture_null": ("text_capture", None),
    "retrieved_at_int": ("retrieved_at", 1700000000),
    "retrieved_at_null": ("retrieved_at", None),
    "control_raw_capture_missing": ("raw_capture", "__DELETE__"),
    "control_retrieved_at_garbage_str": ("retrieved_at", "not a clock"),
}
part_a = {}
for label, (field, value) in text_variants.items():
    saved = genuine_text_cache()
    if value == "__DELETE__":
        saved.pop(field, None)
    else:
        saved[field] = value
    (txt_dir / f"{FILE1}.json").write_text(json.dumps(saved))
    sat._download_bytes = lambda *a, **k: b"REFETCHED requirement text"
    kind, out = call(sat.extract_public_attachment_text, public_file(FILE1, "SOW 1.txt"))
    if kind == "returned":
        part_a[label] = {"outcome": "returned", "from_cache": out.get("from_cache"),
                         "collection_status": out.get("collection_status"),
                         "text": out.get("text")}
    else:
        part_a[label] = {"outcome": "raised", "error": out}
observed["A_text_cache_unit"] = part_a

# ---------------------------------------------------------------- Part B
# Inventory cache: build a genuine cache, then corrupt raw_capture's TYPE.
def genuine_inventory_cache():
    clear(inv_dir)
    first = detail.fetch_notice_resources(NOTICE)
    assert first["collection_status"] == "inventory_captured", first
    return json.loads((inv_dir / f"{NOTICE}.resources.json").read_text())


inv_variants = {
    "raw_capture_str": "objects/deadbeef.bin",
    "raw_capture_list": [],
    "raw_capture_int": 7,
    "raw_capture_null": None,
    "control_raw_capture_missing": "__DELETE__",
}
part_b = {}
for label, value in inv_variants.items():
    saved = genuine_inventory_cache()
    if value == "__DELETE__":
        saved.pop("raw_capture", None)
    else:
        saved["raw_capture"] = value
    (inv_dir / f"{NOTICE}.resources.json").write_text(json.dumps(saved))
    kind, out = call(detail.fetch_notice_resources, NOTICE)
    if kind == "returned":
        part_b[label] = {"outcome": "returned", "from_cache": out.get("from_cache"),
                         "collection_status": out.get("collection_status"),
                         "attachments": len(out.get("attachments") or [])}
    else:
        part_b[label] = {"outcome": "raised", "error": out}
# received_at int inside a dict raw_capture: reachable or short-circuited?
saved = genuine_inventory_cache()
saved["raw_capture"]["received_at"] = 1700000000
(inv_dir / f"{NOTICE}.resources.json").write_text(json.dumps(saved))
kind, out = call(detail.fetch_notice_resources, NOTICE)
part_b["received_at_int_in_dict"] = (
    {"outcome": "returned", "from_cache": out.get("from_cache"),
     "collection_status": out.get("collection_status")}
    if kind == "returned" else {"outcome": "raised", "error": out})
observed["B_inventory_cache_unit"] = part_b

# ---------------------------------------------------------------- Part C
# run_searches propagation with the REAL fetch_notice_resources (mock client).
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

TERM = "network visibility"
taxonomy = CapabilityTaxonomy(client_name="Testco", version=1,
                              updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                           agency="NASA", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


texts = {FILE1: f"Buyer requires {TERM}. File one.".encode(),
         FILE2: f"Further {TERM} deliverables. File two.".encode()}
download_log: list[str] = []


def logged_download(rid, **k):
    download_log.append(rid)
    return texts[rid]


def run_enrich():
    download_log.clear()
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=8)
    receipt = stats["attachment_record_receipts"][NOTICE]
    return {
        "rows": len(rows),
        "status": receipt.get("status"),
        "errors": receipt.get("errors"),
        "files": [(f.get("resource_id", "")[:4], f.get("status"), f.get("reason"))
                  for f in receipt.get("files") or []],
        "downloads_attempted": [d[:4] for d in download_log],
        "attachment_enriched": stats["attachment_enriched"],
        "attachment_relevant": stats["attachment_relevant"],
    }


part_c = {}
# C0 control: clean caches, healthy run.
clear(inv_dir)
clear(txt_dir)
sat._download_bytes = logged_download
part_c["control_clean"] = run_enrich()
# C0b warm rerun: both caches intact and bound, so zero downloads proves the
# cache entries written by the clean run are the ones the loop reads.
part_c["control_warm_cache_hit"] = run_enrich()
# C1 malformed text cache for file1 (raw_capture str); file2 cache removed so
# it is healthy but needs a download. Cache written by the clean run carries
# the inventory-derived binding, so the validator reaches raw_capture.
saved = json.loads((txt_dir / f"{FILE1}.json").read_text())
saved["raw_capture"] = "objects/deadbeef.bin"
(txt_dir / f"{FILE1}.json").write_text(json.dumps(saved))
(txt_dir / f"{FILE2}.json").unlink()
part_c["malformed_text_cache_file1"] = run_enrich()
part_c["malformed_text_cache_file1"]["file2_lost_although_healthy"] = (
    FILE2 not in download_log)
# C1b same shape with retrieved_at null.
clear(txt_dir)
run_enrich()
saved = json.loads((txt_dir / f"{FILE1}.json").read_text())
saved["retrieved_at"] = None
(txt_dir / f"{FILE1}.json").write_text(json.dumps(saved))
(txt_dir / f"{FILE2}.json").unlink()
part_c["malformed_text_cache_retrieved_at_null"] = run_enrich()
part_c["malformed_text_cache_retrieved_at_null"]["file2_lost_although_healthy"] = (
    FILE2 not in download_log)
# C1c same malformed file1 entry but the file2 cache intact: shows the crash
# also loses an already collected, fully bound second file.
clear(txt_dir)
run_enrich()
saved = json.loads((txt_dir / f"{FILE1}.json").read_text())
saved["text_capture"] = None
(txt_dir / f"{FILE1}.json").write_text(json.dumps(saved))
part_c["malformed_text_cache_file1_file2_cached"] = run_enrich()
# C2 malformed inventory cache (raw_capture str, fresh retrieved_at).
clear(txt_dir)
saved = genuine_inventory_cache()
saved["raw_capture"] = "objects/deadbeef.bin"
(inv_dir / f"{NOTICE}.resources.json").write_text(json.dumps(saved))
part_c["malformed_inventory_cache"] = run_enrich()
observed["C_run_searches_propagation"] = part_c

# ---------------------------------------------------------------- Part D
# Base comparison: load the BASE versions of both modules from git into the
# probe dir (never touching the review clone) and feed identical inputs.
def load_base(path_in_repo: str, module_name: str):
    src = subprocess.run(
        ["git", "-C", str(REPO), "show", f"{BASE_SHA}:{path_in_repo}"],
        check=True, capture_output=True).stdout
    target = tmp_root / f"{module_name}.py"
    target.write_bytes(src)
    spec = importlib.util.spec_from_file_location(module_name, target)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


part_d = {}
try:
    base_sat = load_base("tools/api/sam_attachment_text.py", "base_sam_attachment_text")
    base_detail = load_base("tools/api/sam_notice_detail.py", "base_sam_notice_detail")
    # Text: identical malformed cache files as Part A, fed to base.
    base_text = {}
    for label, (field, value) in text_variants.items():
        saved = genuine_text_cache()
        if value == "__DELETE__":
            saved.pop(field, None)
        else:
            saved[field] = value
        (txt_dir / f"{FILE1}.json").write_text(json.dumps(saved))
        base_sat._download_bytes = lambda *a, **k: b"REFETCHED"
        kind, out = call(base_sat.extract_public_attachment_text, public_file(FILE1, "SOW 1.txt"))
        base_text[label] = ({"outcome": "returned", "from_cache": out.get("from_cache")}
                            if kind == "returned" else {"outcome": "raised", "error": out})
    part_d["base_text_cache"] = base_text
    base_inv = {}
    for label, value in inv_variants.items():
        saved = genuine_inventory_cache()
        if value == "__DELETE__":
            saved.pop("raw_capture", None)
        else:
            saved["raw_capture"] = value
        (inv_dir / f"{NOTICE}.resources.json").write_text(json.dumps(saved))
        kind, out = call(base_detail.fetch_notice_resources, NOTICE)
        base_inv[label] = ({"outcome": "returned", "from_cache": out.get("from_cache")}
                           if kind == "returned" else {"outcome": "raised", "error": out})
    part_d["base_inventory_cache"] = base_inv
except Exception:  # noqa: BLE001
    part_d["load_error"] = traceback.format_exc()
observed["D_base_comparison"] = part_d

# ---------------------------------------------------------------- verdict
cand_text_crashes = [k for k, v in part_a.items()
                     if v["outcome"] == "raised" and "AttributeError" in v["error"]]
cand_inv_crashes = [k for k, v in part_b.items()
                    if v["outcome"] == "raised" and "AttributeError" in v["error"]]
base_text_crashes = [k for k, v in part_d.get("base_text_cache", {}).items()
                     if v["outcome"] == "raised"]
base_inv_crashes = [k for k, v in part_d.get("base_inventory_cache", {}).items()
                    if v["outcome"] == "raised"]
c1 = part_c["malformed_text_cache_file1"]
c2 = part_c["malformed_inventory_cache"]
propagation = (c1["status"] == "FAILED" and c1["rows"] == 0
               and c1["file2_lost_although_healthy"] and c2["status"] == "FAILED")
reproduced = bool(cand_text_crashes) and bool(cand_inv_crashes) and propagation
observed["summary"] = {
    "candidate_text_variants_raising_AttributeError": cand_text_crashes,
    "candidate_inventory_variants_raising_AttributeError": cand_inv_crashes,
    "base_text_variants_raising": base_text_crashes,
    "base_inventory_variants_raising": base_inv_crashes,
    "run_searches_notice_FAILED_and_file2_lost": propagation,
    "control_clean_status": part_c["control_clean"]["status"],
}
print(json.dumps({"status": "FAIL" if reproduced else "PASS",
                  "finding": "CT-1", "reproduced": reproduced,
                  "observed": observed}, indent=2, default=str))
