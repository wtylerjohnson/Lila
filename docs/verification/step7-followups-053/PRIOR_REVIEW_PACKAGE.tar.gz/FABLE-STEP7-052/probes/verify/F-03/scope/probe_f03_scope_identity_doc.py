"""F-03 scope/classification probe: identity check breadth vs doc sentences.

Runs the candidate `tools.api.sam_notice_detail.fetch_notice_resources` and the
BASE (2d522f0) copy placed in this directory against the same mocked bodies.
No network: `_client` is replaced by a MockTransport client and socket.connect
is blocked. Prints ONE JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

import httpx

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
BODIES = REVIEW / "extracted" / "source-proof" / "public-inventory-001"
sys.path.insert(0, str(REPO))
os.chdir(REPO)


def _blocked_connect(*_a, **_k):
    raise RuntimeError("probe: real socket connect blocked")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]

import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as cand  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail_2d522f0", HERE / "base_sam_notice_detail_2d522f0.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)  # type: ignore[union-attr]

A = "0caab6e53d8b47d7850692b7684610bf"   # requested notice (real IHS amendment)
B = "213a2fe3a447465e8f30699c9f056ec4"   # other real notice
URL = cand.RESOURCES_URL_TPL
OFFHOST = "https://attachments.example.net/opps/v3/opportunities/{id}/resources"

observed: dict = {}


def strip_keys(obj, keys=("opportunityId", "noticeId", "notice_id")):
    if isinstance(obj, dict):
        return {k: strip_keys(v, keys) for k, v in obj.items() if k not in keys}
    if isinstance(obj, list):
        return [strip_keys(v, keys) for v in obj]
    return obj


def run(module, notice_id, handler):
    """Call fetch_notice_resources with a mocked transport and fresh cache dir."""
    tmp = tempfile.mkdtemp(prefix="f03_", dir=str(HERE / "_tmp"))
    os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
    original = _http._client
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), timeout=timeout,
        follow_redirects=True)
    try:
        out = module.fetch_notice_resources(notice_id, timeout_seconds=5.0)
    except Exception as exc:  # noqa: BLE001
        out = {"exception": repr(exc)}
    finally:
        _http._client = original
    cache_written = (Path(tmp) / f"{notice_id}.resources.json").exists()
    return {
        "collection_status": out.get("collection_status"),
        "resources_checked": out.get("resources_checked"),
        "attachment_count": len(out.get("attachments") or []),
        "errors": out.get("errors"),
        "raw_capture_source_url": (out.get("raw_capture") or {}).get("source_url"),
        "has_raw_capture": "raw_capture" in out,
        "cache_written": cache_written,
        "exception": out.get("exception"),
    }


def serve(body_bytes: bytes, status=200):
    def handler(request):
        return httpx.Response(status, content=body_bytes,
                              headers={"content-type": "application/hal+json"})
    return handler


# ---------------------------------------------------------------- doc sentences
cs = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
cv = (REPO / "docs/CONVENTIONS.md").read_text()
pp = (REPO / "docs/verification/step7-052/PRE_PATCH_REPORT.md").read_text()
cs_sentence = "Recognized inventories\nmust reject any conflicting original notice ID."
cv_sentence = "Explicit response notice-ID conflicts refuse the inventory, including depth\nreconciliation."
observed["doc_sentences"] = {
    "contract_surfaces_has_any_conflicting_sentence": cs_sentence in cs,
    "conventions_has_explicit_conflicts_sentence": cv_sentence in cv,
    "pre_patch_frames_defect_as_explicit": "accepts a response\nexplicitly identifying b*32" in pp,
    "contract_surfaces_source_url_mentions": cs.count("source_url"),
    "conventions_source_url_mentions_step7_section": cv[cv.index("## Step7 decision-changing collection"):].count("source_url"),
}
# base had no identity function at all
base_src = (HERE / "base_sam_notice_detail_2d522f0.py").read_text()
observed["base_has_identity_check"] = "_resource_identity_matches" in base_src

# ---------------------------------------------------------------- real body census
census = {"bodies": 0, "rowed": 0, "rowed_entries_all_have_opportunityId": 0,
          "self_href_names_own_id": 0, "links_only": 0}
real = {}
for path in sorted(BODIES.glob("*.body")):
    nid = path.stem
    raw = path.read_bytes()
    real[nid] = raw
    doc = json.loads(raw)
    census["bodies"] += 1
    href = ((doc.get("_links") or {}).get("self") or {}).get("href", "")
    if f"/opportunities/{nid}/resources" in href:
        census["self_href_names_own_id"] += 1
    emb = doc.get("_embedded")
    if emb is None:
        census["links_only"] += 1
        continue
    rows = emb.get("opportunityAttachmentList") or []
    if rows:
        census["rowed"] += 1
        if all(r.get("opportunityId") == nid for r in rows):
            census["rowed_entries_all_have_opportunityId"] += 1
observed["real_body_census"] = census

# ---------------------------------------------------------------- cases
(HERE / "_tmp").mkdir(exist_ok=True)
cases = {}

# 1. explicit conflicting opportunityId (the S7-IDENTITY-002 defect)
h = serve(real[B])
cases["1_explicit_B_keys_requested_as_A"] = {
    "candidate": run(cand, A, h), "base": run(base, A, h)}

# 2. same real body with explicit keys stripped; only _links.self.href names B
stripped = json.dumps(strip_keys(json.loads(real[B]))).encode()
h = serve(stripped)
cases["2_href_only_B_requested_as_A"] = {
    "candidate": run(cand, A, h), "base": run(base, A, h),
    "body_still_names_B_in_self_href": f"/opportunities/{B}/resources" in stripped.decode()}

# 3. contradictory: explicit key A but self href B (a body that names both)
contra = json.loads(real[B])
for row in contra["_embedded"]["opportunityAttachmentList"]:
    row["opportunityId"] = A
h = serve(json.dumps(contra).encode())
cases["3_key_A_but_self_href_B"] = {
    "candidate": run(cand, A, h), "base": run(base, A, h)}

# 4. redirect: A's URL 302 -> off-host B URL serving an id-less rowed body
idless = json.dumps({"attachments": [{"name": "x.pdf", "resourceId": "b" * 32,
                                       "mimeType": ".pdf"}]}).encode()


def redirect_handler(request):
    url = str(request.url)
    if url == URL.format(id=A):
        return httpx.Response(302, headers={"location": OFFHOST.format(id=B)})
    if url == OFFHOST.format(id=B):
        return httpx.Response(200, content=idless,
                              headers={"content-type": "application/hal+json"})
    return httpx.Response(404)


cases["4_redirect_offhost_idless_body"] = {
    "candidate": run(cand, A, redirect_handler), "base": run(base, A, redirect_handler),
    "requested_url": URL.format(id=A), "final_url_served": OFFHOST.format(id=B)}
c4 = cases["4_redirect_offhost_idless_body"]
c4["candidate_source_url_equals_requested"] = (
    c4["candidate"]["raw_capture_source_url"] == c4["requested_url"])

# 5. case: uppercase requested id against the real lowercase body of the same notice
h = serve(real[A])
cases["5_uppercase_request_same_notice"] = {
    "candidate": run(cand, A.upper(), h), "base": run(base, A.upper(), h)}

# 6. real 21 bodies under own id and under a foreign id (candidate only)
own = {}
foreign = {}
for nid, raw in real.items():
    h = serve(raw)
    st_own = run(cand, nid, h)["collection_status"]
    own[st_own] = own.get(st_own, 0) + 1
    other = A if nid != A else B
    st = run(cand, other, h)["collection_status"]
    foreign[st] = foreign.get(st, 0) + 1
cases["6_real_21_bodies_candidate"] = {"own_id_statuses": own, "foreign_id_statuses": foreign}

observed["cases"] = cases

# ---------------------------------------------------------------- verdict logic
gap_href = (cases["2_href_only_B_requested_as_A"]["candidate"]["collection_status"]
            == "inventory_captured")
explicit_refused = (cases["1_explicit_B_keys_requested_as_A"]["candidate"]["collection_status"]
                    == "identity_mismatch")
base_same_on_href = cases["2_href_only_B_requested_as_A"]["base"]["resources_checked"] is True
real_check_live = (census["rowed"] == census["rowed_entries_all_have_opportunityId"]
                   and foreign.get("identity_mismatch") == census["rowed"])
observed["assessment"] = {
    "explicit_conflict_refused_as_claimed": explicit_refused,
    "href_only_conflict_accepted": gap_href,
    "href_only_acceptance_identical_at_base": base_same_on_href,
    "identity_check_refuses_every_real_rowed_body_under_foreign_id": real_check_live,
    "contract_surfaces_sentence_broader_than_code": gap_href
        and observed["doc_sentences"]["contract_surfaces_has_any_conflicting_sentence"],
    "conventions_sentence_matches_code": explicit_refused
        and observed["doc_sentences"]["conventions_has_explicit_conflicts_sentence"],
    "receipt_source_url_is_requested_not_final": c4["candidate_source_url_equals_requested"],
    "base_receipt_for_redirect": c4["base"]["has_raw_capture"],
    "uppercase_new_refusal": (cases["5_uppercase_request_same_notice"]["candidate"]["collection_status"]
                              == "identity_mismatch"
                              and cases["5_uppercase_request_same_notice"]["base"]["resources_checked"] is True),
}
status = "FAIL" if observed["assessment"]["contract_surfaces_sentence_broader_than_code"] else "PASS"
print(json.dumps({"probe": "f03_scope_identity_doc", "status": status,
                  "observed": observed}, indent=1, default=str))
