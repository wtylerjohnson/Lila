"""Independent reproduction of BR-3 (H1): coherent text-cache rewrite.

Re-implemented from the finding description only. Steps:
  1. Produce one genuine .txt attachment cache with a stubbed downloader.
  2. Rewrite text + text_sha256 + text_locator + objects/<sha>.bin coherently.
  3. Replace the downloader with a raiser (any call = network attempt marker).
  4. Re-call extract_public_attachment_text; observe whether the invented text
     is served from cache as captured_discovery_only.
  5. Controls: text-only tamper (must fail), full rewrite (raw too), base file.
No network: socket.connect is blocked for the whole process.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
PROBE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

TMP = Path(tempfile.mkdtemp(prefix="br3_", dir=str(PROBE_DIR)))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "cand")


def _no_connect(*_a, **_k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

import tools.api.sam_attachment_text as sat  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402

ORIGINAL = b"Original SOW text: vendor neutral requirement."
INVENTED = "Invented requirement: vendor X is mandatory."
RID = "a" * 32
ATTACHMENT = {"resource_id": RID, "name": "SOW.txt", "type": "file",
              "size": len(ORIGINAL), "access_level": "public"}

observed: dict = {"tmp": str(TMP)}
calls = {"download": 0}


def stub_download(resource_id, *, deadline_monotonic=None):
    calls["download"] += 1
    return ORIGINAL


def raising_download(resource_id, *, deadline_monotonic=None):
    calls["download"] += 1
    raise RuntimeError("probe: network attempt")


def run(label, module, cache_dir):
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(cache_dir)
    calls["download"] = 0
    module._download_bytes = raising_download
    result = module.extract_public_attachment_text(dict(ATTACHMENT))
    observed[label] = {
        "from_cache": result.get("from_cache"),
        "text": result.get("text"),
        "collection_status": result.get("collection_status"),
        "sha256": result.get("sha256"),
        "error": result.get("error"),
        "download_calls": calls["download"],
    }
    return result


# 1. genuine cache
cand_dir = TMP / "cand"
sat._download_bytes = stub_download
genuine = sat.extract_public_attachment_text(dict(ATTACHMENT))
observed["genuine"] = {"from_cache": genuine.get("from_cache"),
                       "text": genuine.get("text"),
                       "collection_status": genuine.get("collection_status"),
                       "sha256": genuine.get("sha256")}
cache_file = cand_dir / f"{RID}.json"
genuine_json = cache_file.read_text()
original_sha = hashlib.sha256(ORIGINAL).hexdigest()

# 2. coherent text rewrite (text, text_sha256, text_locator, new object)
saved = json.loads(genuine_json)
saved["text"] = INVENTED
saved["text_capture"] = retain_bytes(cand_dir, INVENTED.encode("utf-8"))
saved["text_sha256"] = hashlib.sha256(INVENTED.encode("utf-8")).hexdigest()
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                         "start": 0, "end": len(INVENTED)}
cache_file.write_text(json.dumps(saved))
binding = saved["attachment_binding_sha256"]
observed["text_capture_valid_on_rewrite"] = sat._text_capture_valid(
    json.loads(cache_file.read_text()), RID, binding)
run("coherent_text_rewrite", sat, cand_dir)

# 3. control: text-only tamper (must be refused)
saved_ctrl = json.loads(genuine_json)
saved_ctrl["text"] = INVENTED
cache_file.write_text(json.dumps(saved_ctrl))
run("control_text_only_tamper", sat, cand_dir)

# 4. full rewrite (raw_capture + sha256 too)
saved_full = json.loads(genuine_json)
new_raw = b"Fabricated raw bytes"
saved_full["raw_capture"] = retain_bytes(cand_dir, new_raw)
saved_full["sha256"] = hashlib.sha256(new_raw).hexdigest()
saved_full["text"] = INVENTED
saved_full["text_capture"] = retain_bytes(cand_dir, INVENTED.encode("utf-8"))
saved_full["text_sha256"] = hashlib.sha256(INVENTED.encode("utf-8")).hexdigest()
saved_full["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                              "start": 0, "end": len(INVENTED)}
cache_file.write_text(json.dumps(saved_full))
run("coherent_full_rewrite", sat, cand_dir)

# 5. does re-deriving text from the retained raw bytes expose the rewrite?
cache_file.write_text(json.dumps(saved))
rederived = sat._text_from_bytes("SOW.txt", ORIGINAL)
observed["rederive_from_raw_detects_rewrite"] = rederived != INVENTED
observed["rederived_text"] = rederived

# 6. base 2d522f0 behaviour with the same rewritten cache
base_src = subprocess.run(
    ["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_attachment_text.py"],
    check=True, capture_output=True, text=True).stdout
base_path = TMP / "base_sam_attachment_text.py"
base_path.write_text(base_src)
spec = importlib.util.spec_from_file_location("base_sat", base_path)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)  # type: ignore[union-attr]
run("base_blind_cache", base, cand_dir)

# verdict
ok = (observed["genuine"]["text"] == ORIGINAL.decode()
      and observed["text_capture_valid_on_rewrite"] is True
      and observed["coherent_text_rewrite"]["from_cache"] is True
      and observed["coherent_text_rewrite"]["text"] == INVENTED
      and observed["coherent_text_rewrite"]["collection_status"] == "captured_discovery_only"
      and observed["coherent_text_rewrite"]["sha256"] == original_sha
      and observed["coherent_text_rewrite"]["download_calls"] == 0
      and observed["control_text_only_tamper"]["collection_status"] == "lookup_failed"
      and observed["control_text_only_tamper"]["from_cache"] is False
      and observed["coherent_full_rewrite"]["from_cache"] is True
      and observed["rederive_from_raw_detects_rewrite"] is True
      and observed["base_blind_cache"]["text"] == INVENTED)
observed["original_sha256"] = original_sha
print(json.dumps({"status": "FAIL" if ok else "INFO", "reproduced": ok,
                  "observed": observed}, indent=1, sort_keys=True))
