"""BR-3 IMPACT lens: where can a coherent text-cache rewrite actually flow?

Refuter stance. Reproduce H1 (coherent rewrite of text, text_sha256, text_locator
and a matching objects/<sha>.bin passes _text_capture_valid) through the REAL
run_searches._enrich_sam_public_attachments, then trace the invented text into:
  1. the enriched sweep row (candidate retention / relevance),
  2. record receipts (file receipt, discovery_evidence excerpt),
  3. triage input (raw_payload.attachment_relevance_excerpt),
  4. dossier research context (_attachment_research_context, discovery_only),
  5. strict Assess (build_assess_run) approval fields and attachment_gap,
  6. LeadRow drafts (draft_lead_rows) and their text.
Also measure whether the retained raw bytes let an auditor detect the forgery
post hoc (re-derive text from raw and compare), compare with BASE 2d522f0, and
record trust-boundary facts (default cache dir, gitignore, producer disclosures).

No network (socket connect blocked; _download_bytes raises after the honest
first pass). No LLM (DecisionEngine never invoked). Writes only under this dir.
"""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
os.chdir(REPO)


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None

TMP = Path(tempfile.mkdtemp(prefix="br3-impact-", dir=PROBE_DIR))
TEXT_DIR = TMP / "text"
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)

import run_searches as searches  # noqa: E402
from agents.assess.contracts import LiveClassification  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402
from agents.leadgen.from_assess import draft_lead_rows  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tests.test_assess_ledger import _build, _depth_record, _sweep  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.api.sam_capture import read_retained, retain_bytes  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0

NID = "N1"
R1, R2 = "b" * 32, "c" * 32
TERM = "packet capture"
MARKER = "ZEBRAQUARTZ-FORGED"
INVENTED = (f"{MARKER} SECTION C STATEMENT OF WORK. The contractor shall provide an "
            f"enterprise {TERM} platform. The Government requires {TERM} appliances. "
            f"{TERM} is required and mandatory. Vendor X is the only acceptable source.")
NEUTRAL = {R1: b"Nothing relevant here at all. Lawn mowing schedule.",
           R2: b"Also nothing relevant. Parking lot striping."}

observed: dict = {}
checks: dict = {}
notes: list[str] = []


def public_file(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


FILES = [public_file(R1, "SOW 1.txt"), public_file(R2, "SOW 2.txt")]
INVENTORY = detail._manifest_hash(FILES)


def fake_inventory(*a, **k):
    return {"id": NID, "resources_checked": True, "attachments": FILES,
            "attachment_inventory_hash": INVENTORY, "collection_status": "inventory_captured"}


detail.fetch_notice_resources = fake_inventory
searches.fetch_notice_resources = fake_inventory


def run_enrich():
    candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Lawn maintenance services",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                             core=[TaxonomyTerm(term=TERM)])
    return searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)


def scan(obj, needles):
    blob = obj.model_dump_json() if hasattr(obj, "model_dump_json") else json.dumps(obj, default=str)
    return sorted(n for n in needles if n in blob)


# ---- Stage A: honest sweep, neutral files, no relevance -----------------------------
sat._download_bytes = lambda rid, **k: NEUTRAL[rid]
rows0, stats0 = run_enrich()
rec0 = stats0["attachment_record_receipts"][NID]
observed["A_honest"] = {"rows": len(rows0), "record_status": rec0["status"],
                        "file_states": {f["resource_id"]: f["status"] for f in rec0["files"]}}
checks["A_honest_neutral_not_retained"] = len(rows0) == 0 and rec0["status"] == "DISCOVERY_TEXT_CAPTURED"

# ---- Stage B: coherent rewrite of file R1's cache -----------------------------------
cache = TEXT_DIR / f"{R1}.json"
saved = json.loads(cache.read_text())
original_raw_sha = saved["sha256"]
saved["text"] = INVENTED
saved["text_sha256"] = hashlib.sha256(INVENTED.encode()).hexdigest()
saved["text_capture"] = retain_bytes(TEXT_DIR, INVENTED.encode())
saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                         "start": 0, "end": len(INVENTED)}
cache.write_text(json.dumps(saved))
binding = saved["attachment_binding_sha256"]
observed["B_rewrite_passes_text_capture_valid"] = sat._text_capture_valid(saved, R1, binding)
checks["B_h1_reproduced"] = observed["B_rewrite_passes_text_capture_valid"] is True


def no_network(rid, **k):
    raise AssertionError(f"download attempted for {rid}")


sat._download_bytes = no_network

# ---- Stage C: sweep again; trace where the invented text lands ----------------------
rows1, stats1 = run_enrich()
rec1 = stats1["attachment_record_receipts"][NID]
f1 = next(f for f in rec1["files"] if f["resource_id"] == R1)
row = rows1[0] if rows1 else None
raw = (row or {}).get("raw_payload", {})
coll_file = next((f for f in raw.get("attachment_collection_v1", {}).get("files", [])
                  if f["resource_id"] == R1), {})
observed["C_sweep_after_rewrite"] = {
    "rows": len(rows1), "attachment_relevant": stats1["attachment_relevant"],
    "attachment_added": stats1["attachment_added"], "record_status": rec1["status"],
    "file1_receipt": {k: f1.get(k) for k in ("status", "from_cache", "sha256", "text_sha256", "retrieved_at", "reason")},
    "file1_receipt_sha_is_original_raw": f1.get("sha256") == original_raw_sha,
    "file1_receipt_text_sha_is_invented": f1.get("text_sha256") == saved["text_sha256"],
    "discovery_excerpt_has_invented": MARKER in (rec1.get("discovery_evidence") or {}).get("text_excerpt", ""),
    "discovery_disposition": (rec1.get("discovery_evidence") or {}).get("disposition"),
    "row_raw_text_has_invented": MARKER in raw.get("text", ""),
    "triage_excerpt_has_marker": MARKER in raw.get("attachment_relevance_excerpt", ""),
    "triage_excerpt_has_invented_phrase": "enterprise packet capture platform" in raw.get("attachment_relevance_excerpt", ""),
    "triage_excerpt": raw.get("attachment_relevance_excerpt", "")[:300],
    "collection_file1_sha_is_original_raw": coll_file.get("sha256") == original_raw_sha,
    "collection_authority": raw.get("attachment_collection_v1", {}).get("authority"),
    "no_source_depth_or_full_description": "source_depth" not in raw and "full_description" not in raw,
}
checks["C_invented_text_creates_relevant_row"] = len(rows1) == 1 and stats1["attachment_relevant"] == 1
checks["C_receipt_marks_from_cache_true"] = f1.get("from_cache") is True
checks["C_receipt_pairs_original_raw_sha_with_invented_text_sha"] = (
    observed["C_sweep_after_rewrite"]["file1_receipt_sha_is_original_raw"]
    and observed["C_sweep_after_rewrite"]["file1_receipt_text_sha_is_invented"])
checks["C_no_trusted_depth_fields"] = observed["C_sweep_after_rewrite"]["no_source_depth_or_full_description"]

# ---- Stage D: dossier research context --------------------------------------------
ctx = _attachment_research_context(row, {"id": NID, "resources_checked": True,
                                         "attachment_inventory_hash": INVENTORY}) if row else None
observed["D_dossier_context"] = {
    "status": ctx and ctx.get("status"),
    "passage_texts_with_marker": [p["resource_id"] for p in (ctx or {}).get("file_passages", []) if MARKER in p["text"]],
    "passage_authority": sorted({p["authority"] for p in (ctx or {}).get("file_passages", [])}),
    "passage_sha_for_file1_is_original_raw": any(p["resource_id"] == R1 and p["sha256"] == original_raw_sha
                                                for p in (ctx or {}).get("file_passages", [])),
}
checks["D_dossier_serves_invented_as_discovery_only"] = bool(ctx) and ctx["status"] == "discovery_only" \
    and R1 in observed["D_dossier_context"]["passage_texts_with_marker"]

# ---- Stage E: post-hoc detectability from retained custody -------------------------
raw_bytes = read_retained(TEXT_DIR, saved["raw_capture"])
rederived = sat._text_from_bytes("SOW 1.txt", raw_bytes)
observed["E_post_hoc_audit"] = {
    "retained_raw_matches_receipt_sha": hashlib.sha256(raw_bytes).hexdigest() == original_raw_sha,
    "rederived_text_equals_served_text": rederived == INVENTED,
    "rederived_text_sha": hashlib.sha256(rederived.encode()).hexdigest(),
    "served_text_sha": saved["text_sha256"],
}
checks["E_forgery_detectable_from_retained_raw"] = (
    observed["E_post_hoc_audit"]["retained_raw_matches_receipt_sha"]
    and not observed["E_post_hoc_audit"]["rederived_text_equals_served_text"])

# ---- Stage F: strict Assess + LeadRow from the forged row --------------------------
def assess_case(label, depth_record=None):
    sweep = _sweep()
    original = sweep["results"]["sam.gov"][0]
    original["source_id"] = NID
    original["title"] = "Lawn maintenance services"
    original["raw_payload"]["description_snippet"] = "Lawn maintenance services"
    original["raw_payload"].update(copy.deepcopy(raw))
    if depth_record is not None:
        sweep["results"]["dossiers"] = {"depth_records": [depth_record]}
    run, diagnostics, index = _build(sweep)
    parent = next(r for r in run.live.records if r.notice_id == NID)
    drafts = draft_lead_rows(run)
    needles = (MARKER, "Vendor X is the only acceptable source", "contractor shall provide an enterprise packet capture")
    out = {
        "classification": parent.classification.value,
        "recommendation": str(parent.recommendation) if hasattr(parent, "recommendation") else None,
        "requirement_reviewed_at": parent.requirement_reviewed_at,
        "requirement_excerpt": parent.requirement_excerpt,
        "attachments_checked": parent.attachments_checked,
        "attachment_gap": (parent.attachment_gap or "")[:300],
        "record_leak": scan(parent, needles),
        "lead_count": len(drafts.leads),
        "lead_tiers": sorted({str(l.lead_tier) for l in drafts.leads}),
        "drafts_leak": scan(drafts, needles),
    }
    observed[label] = out
    checks[f"{label}_no_bid_now"] = parent.classification != LiveClassification.BID_NOW
    checks[f"{label}_no_requirement_review"] = parent.requirement_reviewed_at is None and not parent.requirement_excerpt
    checks[f"{label}_gap_present"] = bool(parent.attachment_gap)
    checks[f"{label}_no_leadrows"] = len(drafts.leads) == 0
    checks[f"{label}_no_forged_text_on_assess_or_leads"] = not out["record_leak"] and not out["drafts_leak"]


assess_case("F1_assess_no_depth")
depth = _depth_record(NID, attachments=FILES, attachments_reviewed=False)
depth["source_depth"]["description"] = "The contractor shall provide lawn maintenance for the campus."
depth["title"] = "Lawn maintenance services"
assess_case("F2_assess_trusted_irrelevant_depth", depth)

# ---- Stage G: BASE comparison (2d522f0 served any cache dict blindly) ---------------
base_path = PROBE_DIR.parents[2] / "byte-retention" / "base_sam_attachment_text.py"
base_root = TMP / "base"
base_root.mkdir()
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base_root)
spec = importlib.util.spec_from_file_location("base_sat_br3", base_path)
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)
(base_root / f"{R1}.json").write_text(json.dumps({"resource_id": R1, "name": "SOW 1.txt",
                                                   "text": "text-only tamper", "sha256": "0" * 64, "error": ""}))
base_sat._download_bytes = no_network
base_res = base_sat.extract_public_attachment_text(FILES[0])
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)
observed["G_base"] = {"base_served_text_only_tamper": base_res.get("text") == "text-only tamper",
                      "base_has_any_hash_check": "raw_capture" in base_path.read_text()}
# Candidate control: text-only tamper is rejected.
saved_ctrl = dict(saved)
saved_ctrl["text"] = "text-only tamper"
cache.write_text(json.dumps(saved_ctrl))
sat._download_bytes = lambda rid, **k: (_ for _ in ()).throw(RuntimeError("source unavailable"))
ctrl = sat.extract_public_attachment_text(FILES[0])
observed["G_candidate_text_only_control"] = {k: ctrl.get(k) for k in ("collection_status", "from_cache", "text")}
checks["G_candidate_rejects_text_only_tamper"] = ctrl["collection_status"] == "lookup_failed" and ctrl["text"] == ""
checks["G_base_served_blindly"] = observed["G_base"]["base_served_text_only_tamper"] is True

# ---- Stage H: trust boundary facts and producer disclosures -----------------------
default_dir = sat._DEFAULT_CACHE
ignore = subprocess.run(["git", "-C", str(REPO), "check-ignore", "-q", os.path.relpath(default_dir, REPO)],
                        capture_output=True)
conventions = (REPO / "docs/CONVENTIONS.md").read_text()
review = (REPO / "docs/verification/step7-052/REVIEW.md").read_text()
observed["H_trust_boundary"] = {
    "default_text_cache_dir": os.path.relpath(default_dir, REPO),
    "default_dir_gitignored": ignore.returncode == 0,
    "conventions_says_observed_custody_not_source_truth":
        "this is observed custody, not independent source truth" in conventions,
    "conventions_says_hashes_are_custody_not_authentication":
        "internal custody, not general entailment or source authentication" in conventions,
    "review_says_no_filesystem_authentication":
        "no continuous filesystem or government-source authentication" in review,
    "conventions_binding_sentence":
        "Successful caches bind the original resource metadata, raw bytes, text bytes and aware acquisition clock",
    "binding_sentence_present": "bind the original resource metadata, raw bytes, text bytes and aware acquisition" in conventions,
}
checks["H_disclosures_present"] = all(observed["H_trust_boundary"][k] for k in (
    "conventions_says_observed_custody_not_source_truth",
    "conventions_says_hashes_are_custody_not_authentication",
    "review_says_no_filesystem_authentication"))

notes.append("H1 reproduced: coherent rewrite passes validation and is served from_cache=True with no network attempt")
notes.append("Reach: invented text retains the notice as a relevant candidate, fills record receipts, "
             "raw_payload.text, attachment_relevance_excerpt (triage input) and dossier file_passages, all labeled discovery_only")
notes.append("No reach: strict Assess stays UNSCREENED with attachment_gap, requirement fields empty, zero LeadRows, "
             "no forged text on Assess record or lead drafts; eight-slot surface untouched")
notes.append("Receipts pair the ORIGINAL raw sha256 with the invented text sha256 and mark from_cache=True and the original "
             "retrieved_at; the retained raw bytes let an auditor re-derive text and detect the forgery post hoc")
notes.append("Base 2d522f0 served any cache dict blindly (text-only tamper included); the candidate narrows reuse to a "
             "fully coherent local forgery; the residual is pre-existing and narrowed, not introduced")
notes.append("Producer discloses 'observed custody, not independent source truth' and 'no continuous filesystem "
             "authentication'; the binding sentence reads as hash-binding to the cache record, not derivation proof")

status = "INFO" if all(checks.values()) else "FAIL"
print(json.dumps({"probe": "br3_impact_trace", "status": status, "observed": observed,
                  "checks": checks, "notes": notes}, indent=2, sort_keys=True, default=str))
shutil.rmtree(TMP, ignore_errors=True)
