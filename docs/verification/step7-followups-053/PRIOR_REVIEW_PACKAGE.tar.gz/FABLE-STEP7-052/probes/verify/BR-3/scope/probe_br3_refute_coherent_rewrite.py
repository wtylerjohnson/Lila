"""BR-3 refutation probe: is the CONVENTIONS binding sentence broader than the code?

Doc sentence under test (docs/CONVENTIONS.md, Step7 section):
  "Successful caches bind the original resource metadata, raw bytes, text bytes and
   aware acquisition clock."

Plan
 1. Reproduce the finder's coherent text rewrite (text + text_sha256 + text_capture +
    text_locator) and confirm it is served from cache.
 2. Show each of the FOUR enumerated bindings is enforced when tampered alone:
    resource metadata, raw bytes, text bytes, aware clock (naive / future / missing).
 3. Show the retained raw remains auditable: re-extracting objects/<raw>.bin yields
    the original text, not the forged text, so custody exposes the forgery on audit.
 4. Show the finder's recommended fix (re-derive text from raw on reuse and compare)
    is defeated by a full rewrite whose raw bytes ARE the forged text, so the fix
    closes nothing against the writer the finder posits.
 5. Base 2d522f0 comparison: base served any cache dict blindly, no raw at all.

No network. No LLM. Writes only under this probe directory.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))


def _blocked(*args, **kwargs):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda seconds: None

root = Path(tempfile.mkdtemp(prefix="br3-", dir=HERE))
text_dir = root / "text"
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text_dir)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(root / "notice")

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api.sam_capture import read_retained, retain_bytes  # noqa: E402

RID = "b" * 32
PUBLIC = {"resource_id": RID, "name": "SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
ORIGINAL = b"Original requirement: packet capture."
INVENTED = "Invented requirement: vendor X is mandatory."
observed: dict = {}
checks: dict = {}


def no_network(rid, **k):
    raise AssertionError("network attempted")


def source_down(rid, **k):
    raise RuntimeError("source unavailable")


def capture_fresh() -> dict:
    """Wipe the text cache dir and produce one genuine capture."""
    shutil.rmtree(text_dir, ignore_errors=True)
    sat._download_bytes = lambda rid, **k: ORIGINAL
    result = sat.extract_public_attachment_text(dict(PUBLIC))
    assert result["collection_status"] == "captured_discovery_only", result
    return result


def reuse(attachment=None, downloader=source_down) -> dict:
    sat._download_bytes = downloader
    return sat.extract_public_attachment_text(dict(attachment or PUBLIC))


def cache_path() -> Path:
    return text_dir / f"{RID}.json"


def load() -> dict:
    return json.loads(cache_path().read_text())


def save(record) -> None:
    cache_path().write_text(json.dumps(record))


# 0. Genuine capture is internally coherent: record text == extraction of retained raw.
first = capture_fresh()
raw0 = read_retained(text_dir, first["raw_capture"])
checks["genuine_capture_text_matches_extraction_of_retained_raw"] = (
    sat._text_from_bytes("SOW.txt", raw0) == first["text"])
observed["genuine"] = {"sha256": first["sha256"], "text_sha256": first["text_sha256"]}

# 1. Finder's coherent text rewrite (raw untouched).
rec = load()
rec["text"] = INVENTED
rec["text_sha256"] = hashlib.sha256(INVENTED.encode()).hexdigest()
rec["text_capture"] = retain_bytes(text_dir, INVENTED.encode())
rec["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                       "start": 0, "end": len(INVENTED)}
save(rec)
try:
    served = reuse(downloader=no_network)
    observed["coherent_text_rewrite"] = {
        k: served.get(k) for k in ("collection_status", "from_cache", "text", "sha256")}
except AssertionError as exc:
    observed["coherent_text_rewrite"] = {"network_attempted": str(exc)}
    served = {}
checks["finder_reproduced_coherent_text_rewrite_served"] = (
    served.get("from_cache") is True and served.get("text") == INVENTED)

# 3. Audit: the retained raw still says what the source said. Custody exposes the forgery.
raw_after = read_retained(text_dir, served["raw_capture"])
reextracted = sat._text_from_bytes(served["name"], raw_after)
observed["audit_reextraction_of_retained_raw"] = reextracted
checks["retained_raw_exposes_forgery_on_audit"] = (
    raw_after == ORIGINAL and reextracted != INVENTED and reextracted == first["text"])

# 4. Full rewrite crafted so that re-deriving text from raw yields the forged text.
#    This is exactly the finder's recommended fix, applied to the finder's own writer.
fake_raw = INVENTED.encode()
rec["raw_capture"] = retain_bytes(text_dir, fake_raw)
rec["sha256"] = hashlib.sha256(fake_raw).hexdigest()
save(rec)
full = reuse(downloader=no_network)
rederived = sat._text_from_bytes(full["name"], read_retained(text_dir, full["raw_capture"]))
observed["full_rewrite"] = {"from_cache": full.get("from_cache"), "text": full.get("text"),
                            "rederived_from_raw_equals_forged_text": rederived == INVENTED}
checks["recommended_rederivation_fix_defeated_by_full_rewrite"] = (
    full.get("from_cache") is True and full.get("text") == INVENTED and rederived == INVENTED)

# 2. Each enumerated binding, tampered ALONE on a genuine capture, is rejected.
single: dict = {}

# 2a. original resource metadata
capture_fresh()
changed_meta = dict(PUBLIC, name="Changed SOW.txt")
r = reuse(changed_meta)
single["resource_metadata"] = (r["collection_status"], r["from_cache"], r["text"])

# 2b. raw bytes (object body altered under its own name)
capture_fresh()
rec = load()
(text_dir / rec["raw_capture"]["path"]).write_bytes(b"changed raw")
r = reuse()
single["raw_bytes"] = (r["collection_status"], r["from_cache"], r["text"])

# 2c. text bytes (object body altered under its own name; record untouched)
capture_fresh()
rec = load()
(text_dir / rec["text_capture"]["path"]).write_bytes(INVENTED.encode())
r = reuse()
single["text_bytes_object"] = (r["collection_status"], r["from_cache"], r["text"])

# 2c'. text field rewritten with matching sha but text object left original
capture_fresh()
rec = load()
rec["text"] = INVENTED
rec["text_sha256"] = hashlib.sha256(INVENTED.encode()).hexdigest()
save(rec)
r = reuse()
single["text_field_plus_sha_only"] = (r["collection_status"], r["from_cache"], r["text"])

# 2d. aware acquisition clock: naive, future, missing
for label, clock in (
        ("clock_naive", datetime.now().replace(tzinfo=None).isoformat()),
        ("clock_future", (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()),
        ("clock_missing", None)):
    capture_fresh()
    rec = load()
    if clock is None:
        rec.pop("retrieved_at", None)
    else:
        rec["retrieved_at"] = clock
    save(rec)
    r = reuse()
    single[label] = (r["collection_status"], r["from_cache"], r["text"])

observed["single_binding_tampers"] = single
checks["all_four_enumerated_bindings_enforced_alone"] = all(
    status == "lookup_failed" and fc is False and text == ""
    for status, fc, text in single.values())

# 5. Base 2d522f0 served any cache dict blindly (no raw, bogus sha).
base_root = Path(tempfile.mkdtemp(prefix="br3-base-", dir=HERE))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base_root)
spec = importlib.util.spec_from_file_location("base_sat", HERE / "base_sam_attachment_text.py")
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)
(base_root / f"{RID}.json").write_text(json.dumps(
    {"resource_id": RID, "name": "SOW.txt", "text": INVENTED, "sha256": "0" * 64, "error": ""}))
base_sat._download_bytes = no_network
b = base_sat.extract_public_attachment_text(dict(PUBLIC))
observed["base_2d522f0"] = {"from_cache": b.get("from_cache"), "text": b.get("text"),
                            "has_text_capture_valid": hasattr(base_sat, "_text_capture_valid")}
checks["base_served_blindly_without_any_binding"] = b.get("text") == INVENTED

# Verdict: PASS means each enumerated binding is enforced as the doc states; the coherent
# rewrite is recorded as an inherent property of unauthenticated local hashes, and the
# finder's proposed remedy is shown not to close the writer it posits.
status = "PASS" if all(checks.values()) else "FAIL"
print(json.dumps({"probe": "br3_refute_coherent_rewrite", "status": status,
                  "checks": checks, "observed": observed}, indent=2, sort_keys=True, default=str))

shutil.rmtree(root, ignore_errors=True)
shutil.rmtree(base_root, ignore_errors=True)
