"""F-10 IMPACT lens: where does a withdrawn (deletedFlag "1") attachment row
actually flow once _attachments projects it as live inventory?

Stages, all offline (socket.connect blocked, httpx MockTransport, quota 0):
  A  projection census on the 21 real captured bodies; candidate vs base
  B  run_searches._enrich_sam_public_attachments on the real IHS body
     (0caab6e5) and the PLM PWS body (6956ae1e) with synthetic file text
  C  dossier _attachment_research_context and the verbatim depth attachments
  D  strict Assess build via tests/test_assess_ledger helpers
  E  eight-slot LeadRow drafting from that Assess run
Prints one JSON object with status and observed.
"""
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import traceback
from pathlib import Path

ROOT = Path("/Users/wtjohnson/lila-step7-052")
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
HERE = REVIEW / "probes/verify/F-10/impact"
BODIES = REVIEW / "extracted/source-proof/public-inventory-001"
TMP = HERE / "tmp"
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice-cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text-cache-B1")
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)


def _deny(*a, **k):
    raise AssertionError("network blocked by probe")


socket.socket.connect = _deny  # type: ignore[assignment]
socket.create_connection = _deny  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402

spec = importlib.util.spec_from_file_location("base_detail", HERE / "base_sam_notice_detail.py")
base_detail = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_detail)

observed: dict = {}
IHS = "0caab6e53d8b47d7850692b7684610bf"
PLM = "6956ae1ef09c4baa987342b947ed6066"
SUPPORTED = {".pdf", ".docx", ".txt", ".csv", ".md"}


def deleted_ids(payload):
    out = {}
    stack = [payload]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            if "deletedFlag" in cur and str(cur.get("deletedFlag")) == "1":
                out[cur.get("resourceId")] = {
                    "name": cur.get("name"), "deletedDate": cur.get("deletedDate"),
                    "fileExists": cur.get("fileExists"), "accessLevel": cur.get("accessLevel")}
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)
    return out


# ---------------------------------------------------------------- Stage A
stage_a = {"bodies": 0, "recognized": 0, "rows_projected": 0, "deleted_projected": 0,
           "notices_with_deleted": 0, "notices_deleted_in_top3": 0, "per_notice": {},
           "candidate_equals_base_everywhere": True,
           "projected_record_keys": None, "deleted_marker_in_projection": False}
for body in sorted(BODIES.glob("*.body")):
    nid = body.stem
    payload = json.loads(body.read_bytes())
    stage_a["bodies"] += 1
    items, recognized = detail._attachment_inventory(payload, nid)
    base_items, base_recognized = base_detail._attachment_inventory(payload)
    if (items, recognized) != (base_items, base_recognized):
        stage_a["candidate_equals_base_everywhere"] = False
    if not recognized:
        continue
    stage_a["recognized"] += 1
    items = items or []
    stage_a["rows_projected"] += len(items)
    dels = deleted_ids(payload)
    if items and stage_a["projected_record_keys"] is None:
        stage_a["projected_record_keys"] = sorted(items[0].keys())
    if any(k in item for item in items for k in ("deleted", "deleted_flag", "deletedFlag", "deleted_date", "file_exists")):
        stage_a["deleted_marker_in_projection"] = True
    projected_deleted = [i for i in items if i.get("resource_id") in dels]
    if not dels:
        continue
    stage_a["notices_with_deleted"] += 1
    stage_a["deleted_projected"] += len(projected_deleted)
    ordered = sorted(items, key=sat.attachment_priority)
    top3 = [i for i in ordered if os.path.splitext(str(i.get("name") or ""))[1].lower() in SUPPORTED][:3]
    top3_deleted = [i["name"] for i in top3 if i.get("resource_id") in dels]
    if top3_deleted:
        stage_a["notices_deleted_in_top3"] += 1
    live_only = [i for i in items if i.get("resource_id") not in dels]
    stage_a["per_notice"][nid] = {
        "count_projected": len(items),
        "count_live_only": len(live_only),
        "hash_projected": detail._manifest_hash(items)[:16],
        "hash_live_only": detail._manifest_hash(live_only)[:16],
        "deleted": list(dels.values()),
        "top3": [i["name"] for i in top3],
        "top3_deleted": top3_deleted,
        "live_supported_left_unread": [
            i["name"] for i in ordered
            if os.path.splitext(str(i.get("name") or ""))[1].lower() in SUPPORTED
            and i not in top3 and i.get("resource_id") not in dels],
    }
observed["A_projection"] = stage_a


# ---------------------------------------------------------------- Stage B
def run_enrichment(nid: str, texts_by_rid: dict, term: str, text_dir: Path):
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text_dir)
    body = (BODIES / f"{nid}.body").read_bytes()
    http_calls = []

    def handler(request):
        http_calls.append(str(request.url))
        if str(request.url) == detail.RESOURCES_URL_TPL.format(id=nid):
            return httpx.Response(200, content=body)
        return httpx.Response(404, content=b"not found")

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    sam_quota.calls_today = lambda: 0
    downloads = []

    def fake_download(rid, **k):
        downloads.append(rid)
        return b"%PDF-synthetic:" + rid.encode()

    def fake_text(name, payload, **k):
        rid = payload.split(b":", 1)[1].decode()
        return texts_by_rid.get(rid, f"Boilerplate for {name}.")

    sat._download_bytes = fake_download
    sat._text_from_bytes = fake_text
    candidate = RawOpportunity(source="sam.gov", source_id=nid, title="Real notice", agency="HHS",
                               raw_payload={"type": "Combined Synopsis/Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term=term)])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
    return rows, stats, downloads, http_calls


stage_b = {}
try:
    ihs_body = json.loads((BODIES / f"{IHS}.body").read_bytes())
    ihs_dels = deleted_ids(ihs_body)
    deleted_sow = next(iter(ihs_dels))
    live_solicitation = "6fd9757987c7480e97102d49ac3f14c1"  # B01 - 75H70926R00002.pdf
    term = "revenue cycle management"
    # B1: only the WITHDRAWN SOW carries the capability term.
    rows, stats, downloads, http_calls = run_enrichment(
        IHS, {deleted_sow: f"SUPERSEDED DRAFT: contractor shall provide {term} for IHS."},
        term, TMP / "text-cache-B1")
    receipt = stats["attachment_record_receipts"][IHS]
    files = {f["resource_id"]: f for f in receipt["files"]}
    row = rows[0] if rows else None
    raw = (row or {}).get("raw_payload") or {}
    stage_b["B1_withdrawn_file_only_relevant"] = {
        "http_calls": http_calls,
        "downloads_in_order": downloads,
        "withdrawn_sow_downloaded": deleted_sow in downloads,
        "live_solicitation_downloaded": live_solicitation in downloads,
        "receipt_status": receipt["status"],
        "withdrawn_file_receipt": {k: files[deleted_sow].get(k) for k in ("name", "status", "reason", "authority")},
        "live_solicitation_receipt": {k: files[live_solicitation].get(k) for k in ("name", "status", "reason")},
        "any_receipt_mentions_deleted_or_withdrawn": any(
            "delet" in json.dumps(f).lower() or "withdraw" in json.dumps(f).lower() for f in receipt["files"]),
        "attachment_relevant": stats["attachment_relevant"],
        "attachment_added": stats["attachment_added"],
        "row_added_to_sweep": bool(rows),
        "raw_text_contains_superseded_marker": "SUPERSEDED DRAFT" in str(raw.get("text") or ""),
        "attachment_evidence_resource_ids": [e.get("resource_id") for e in raw.get("attachment_evidence") or []],
        "relevance_excerpt": str(raw.get("attachment_relevance_excerpt") or "")[:160],
        "inventory_hash_in_row": (raw.get("attachment_inventory_hash") or "")[:16],
    }
    stage_b["_B1_row"] = row
    stage_b["_B1_inventory_hash"] = raw.get("attachment_inventory_hash")
    # B2: fresh caches; only the LIVE solicitation PDF (left unread) carries the term.
    shutil.rmtree(TMP / "notice-cache", ignore_errors=True)
    rows2, stats2, downloads2, _ = run_enrichment(
        IHS, {live_solicitation: f"LIVE SOLICITATION: contractor shall provide {term}."},
        term, TMP / "text-cache-B2")
    receipt2 = stats2["attachment_record_receipts"][IHS]
    stage_b["B2_live_file_only_relevant"] = {
        "downloads_in_order": downloads2,
        "live_solicitation_downloaded": live_solicitation in downloads2,
        "attachment_relevant": stats2["attachment_relevant"],
        "attachment_added": stats2["attachment_added"],
        "receipt_status": receipt2["status"],
        "rows_returned": len(rows2),
    }
    # B3: PLM body, withdrawn DRAFT PWS ranks first.
    shutil.rmtree(TMP / "notice-cache", ignore_errors=True)
    plm_dels = deleted_ids(json.loads((BODIES / f"{PLM}.body").read_bytes()))
    rows3, stats3, downloads3, _ = run_enrichment(
        PLM, {next(iter(plm_dels)): "SUPERSEDED DRAFT PWS: packet capture requirement."},
        "packet capture", TMP / "text-cache-B3")
    receipt3 = stats3["attachment_record_receipts"][PLM]
    stage_b["B3_plm_draft_pws"] = {
        "downloads_in_order": [next(f["name"] for f in receipt3["files"] if f["resource_id"] == rid) for rid in downloads3],
        "first_download_is_withdrawn": downloads3[:1] == [next(iter(plm_dels))],
        "attachment_relevant": stats3["attachment_relevant"],
        "attachment_added": stats3["attachment_added"],
        "combined_text_starts_with_withdrawn_text": str((rows3[0]["raw_payload"].get("text") if rows3 else "")).startswith("SUPERSEDED DRAFT PWS"),
    }
except Exception:
    stage_b["error"] = traceback.format_exc()
observed["B_enrichment"] = {k: v for k, v in stage_b.items() if not k.startswith("_")}


# ---------------------------------------------------------------- Stage C
stage_c = {}
try:
    from agents.decisions.dossier import _attachment_research_context
    row = stage_b["_B1_row"]
    inventory_hash = stage_b["_B1_inventory_hash"]
    shutil.rmtree(TMP / "notice-cache", ignore_errors=True)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text-cache-B1")
    body = (BODIES / f"{IHS}.body").read_bytes()
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, content=body)))
    resources = detail.fetch_notice_resources(IHS)
    depth = {"id": IHS, "description": "Amendment One. Statement of Work has been updated. See B01- SOW v2.",
             "attachments": resources["attachments"], "resources_checked": resources["resources_checked"],
             "resources_schema": resources["resources_schema"],
             "attachment_inventory_hash": resources["attachment_inventory_hash"],
             "attachment_inventory_count": resources["attachment_inventory_count"], "errors": []}
    context = _attachment_research_context(row, depth)
    passages = context.get("file_passages") or []
    stage_c = {
        "status": context.get("status"),
        "inventory_binding": context.get("inventory_binding"),
        "inventory_hash_matches_fresh_fetch": inventory_hash == resources["attachment_inventory_hash"],
        "passage_names": [p["name"] for p in passages],
        "passage_from_withdrawn_file_text": [p["text"][:60] for p in passages if "SUPERSEDED" in p["text"]],
        "depth_attachments_passed_verbatim_to_dossier_context": [
            {"name": a["name"], "keys_present": sorted(a.keys())} for a in depth["attachments"]
            if a["name"].endswith("Service.pdf")],
        "dossier_context_marks_withdrawn": any(
            "delet" in json.dumps(a).lower() or "withdraw" in json.dumps(a).lower() for a in depth["attachments"]),
        "collection_status": resources["collection_status"],
        "attachment_inventory_count": resources["attachment_inventory_count"],
    }
except Exception:
    stage_c["error"] = traceback.format_exc()
observed["C_dossier"] = stage_c


# ---------------------------------------------------------------- Stage D
stage_d = {}
run_for_leadrow = None
try:
    from agents.assess.contracts import LiveClassification
    from tests.test_assess_ledger import (
        NOW, BINDING, _build, _build_with_requirement_review, _profile,
        _requirement_review_payload, _sweep)
    from agents.assess.ledger import build_assess_run

    def depth_record(attachments):
        return {"id": IHS, "title": "Packet capture platform", "source_depth": {
            "notice_id": IHS, "source_url": f"https://sam.gov/opp/{IHS}/view",
            "retrieved_at": "2026-07-10T11:00:00+00:00",
            "description": "The contractor shall provide an enterprise packet capture platform for CISA network operations.",
            "attachments": attachments, "description_checked": True, "resources_checked": True,
            "resources_schema": "recognized_v1", "attachment_inventory_count": len(attachments),
            "attachment_inventory_hash": detail._manifest_hash(attachments), "errors": []}}

    projected = depth["attachments"]
    live_only = [a for a in projected if a["resource_id"] not in ihs_dels]
    sweep = _sweep()
    original = sweep["results"]["sam.gov"][0]
    original["source_id"] = IHS
    original["raw_payload"]["notice_id"] = IHS
    original["api_url"] = f"https://sam.gov/opp/{IHS}/view"
    original["raw_payload"].update(stage_b["_B1_row"]["raw_payload"])
    sweep["results"]["triage"][IHS] = sweep["results"]["triage"].pop("N1")
    sweep["results"]["dossiers"] = {"records": [depth_record(projected)]}
    run, diagnostics, _ = _build(sweep)
    rec = next(r for r in run.live.records if r.notice_id == IHS)
    run_for_leadrow = run
    deleted_name = next(iter(ihs_dels.values()))["name"]
    stage_d["D1_unreviewed"] = {
        "classification": rec.classification.value,
        "attachment_inventory_count": rec.attachment_inventory_count,
        "attachment_names": [a.name for a in rec.attachments],
        "withdrawn_name_in_ledger_attachments": deleted_name in [a.name for a in rec.attachments],
        "attachments_checked": rec.attachments_checked,
        "requirement_reviewed_at": rec.requirement_reviewed_at,
        "attachment_gap": rec.attachment_gap,
        "withdrawn_name_in_gap": deleted_name in (rec.attachment_gap or ""),
    }
    reviewed, diag2, _ = _build_with_requirement_review(sweep, notice_id=IHS, attachments_reviewed=True)
    rec2 = next(r for r in reviewed.live.records if r.notice_id == IHS)
    stage_d["D2_human_attests_all_5_reviewed"] = {
        "classification": rec2.classification.value,
        "attachments_checked": rec2.attachments_checked,
        "attachment_inventory_count_attested": rec2.attachment_inventory_count,
        "diagnostics": list(diag2),
        "note": "approval reachable only through explicit human attestation covering the withdrawn row too",
    }
    # D3: same human review, but SAM later stops listing the withdrawn row.
    payload = _requirement_review_payload(sweep, notice_id=IHS, attachments_reviewed=True)
    sweep_live = json.loads(json.dumps(sweep))
    sweep_live["results"]["dossiers"] = {"records": [depth_record(live_only)]}
    blocked, diag3, _ = build_assess_run("Testco", sweep_live, _profile(), BINDING,
                                         requirement_reviews_payload=payload, as_of=NOW)
    rec3 = next(r for r in blocked.live.records if r.notice_id == IHS)
    stage_d["D3_row_later_dropped_by_sam"] = {
        "classification": rec3.classification.value,
        "attachment_gap": rec3.attachment_gap,
        "count_live_only": len(live_only),
    }
    stage_d["discovery_text_never_supplies_requirement"] = (
        "source_depth" not in original["raw_payload"] and "full_description" not in original["raw_payload"]
        and rec.requirement_reviewed_at is None)
except Exception:
    stage_d["error"] = traceback.format_exc()
observed["D_assess"] = stage_d


# ---------------------------------------------------------------- Stage E
stage_e = {}
try:
    from agents.leadgen.from_assess import draft_lead_rows
    rec = next(r for r in run_for_leadrow.live.records if r.notice_id == IHS)
    target_actions = {
        "version": "target_actions.v1.2026-08-06", "client": "Testco",
        "rows": [{
            "motion": "defend renewal", "motion_id": "renewal-buying-component-civilian",
            "decision_rule": "R1", "rule_id": "T1", "spec_id": "t1-01-dhs", "row_class": "renewal",
            "buying_agency": "DHS", "route_role": "unknown_route",
            "record_ids": [rec.record_id, IHS], "record_urls": [f"https://sam.gov/opp/{IHS}/view"],
            "notice_id": IHS, "solicitation_number": "75H70926R00002",
            "why_now": "The cited record's current period ends 2026-10-01.",
            "recommended_action": "Ask who owns the renewal decision on this record.",
            "name": "Apollo Person", "contact_source_class": "commercial enrichment",
            "source_url": f"https://sam.gov/opp/{IHS}/view"}],
        "groups": [], "motions": [{"motion_id": "renewal-buying-component-civilian", "row_class": "renewal",
                                   "specs": [{"spec_id": "t1-01-dhs", "rule_id": "T1"}]}],
    }
    batch = draft_lead_rows(run_for_leadrow, target_actions)
    deleted_name = next(iter(ihs_dels.values()))["name"]
    leads = list(batch.leads)
    stage_e = {
        "leads_drafted": len(leads),
        "lead_tier": [l.lead_tier.value for l in leads],
        "next_action_verb": [l.next_action.verb.value for l in leads],
        "next_action_object_names_withdrawn_file": [deleted_name in l.next_action.object for l in leads],
        "next_action_object": [l.next_action.object[:300] for l in leads],
        "blocked_by_names_withdrawn_file": [deleted_name in l.next_action.blocked_by for l in leads],
        "attachment_text_in_any_lead_field": [
            "SUPERSEDED" in json.dumps(l.model_dump(mode="json")) for l in leads],
    }
except Exception:
    stage_e["error"] = traceback.format_exc()
observed["E_leadrow"] = stage_e

status = "FAIL" if (
    stage_a["deleted_projected"] and stage_a["notices_deleted_in_top3"]
    and stage_b.get("B1_withdrawn_file_only_relevant", {}).get("withdrawn_sow_downloaded")
) else "INFO"
print(json.dumps({"probe": "f10_deleted_rows_impact", "status": status, "observed": observed},
                 indent=1, default=str))
shutil.rmtree(TMP, ignore_errors=True)
