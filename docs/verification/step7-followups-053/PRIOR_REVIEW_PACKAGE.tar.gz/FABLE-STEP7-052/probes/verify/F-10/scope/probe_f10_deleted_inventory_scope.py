"""F-10 scope/classification probe: withdrawn attachments (deletedFlag "1").

Questions answered, all offline:
  Q1 Does the CANDIDATE fetch_notice_resources project deletedFlag=1 rows as
     live inventory (counted in attachment_inventory_count/hash, projected
     record carries no deleted marker)?  Real bodies from the source proof.
  Q2 Does the BASE (2d522f0) module do the same?  -> pre_existing test.
  Q3 Does the PRODUCTION selection path (run_searches._enrich_sam_public_
     attachments, candidate code, real fetch + real extract with only the
     byte download and PDF parse stubbed) spend a download slot on the
     withdrawn IHS SOW, put its text into raw_payload.text and
     attachment_collection_v1, and leave a live file "not_fetched"?
  Q4 Synthetic all-deleted inventory: collection_status is inventory_captured
     rather than confirmed_empty (candidate-only state, new in Step7).
  Q5 Do the Step7 docs disclose deleted/withdrawn attachment handling?
  Q6 Corroboration from the producer's own replay receipt.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
REVIEW = HERE.parents[3]
INVENTORY_DIR = REVIEW / "extracted" / "source-proof" / "public-inventory-001"
REPLAY_RECEIPT = REVIEW / "extracted" / "producer-proof" / "native-ihs-replay-002" / "RECEIPT.json"
sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("NETWORK BLOCKED")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api.sam_attachment_text import attachment_priority  # noqa: E402

NOTICES = [
    "0caab6e53d8b47d7850692b7684610bf",  # IHS: superseded SOW deleted
    "6956ae1ef09c4baa987342b947ed6066",  # DRAFT PWS deleted
    "9d298434e39a41e2bde21329bf95b238",  # two deleted certs
    "3e6ef0d1090448dd97081f7c868447ff",  # deleted Q-A matrix (not in top3)
]
ALL_DELETED_ID = "f" * 32
BODIES = {nid: (INVENTORY_DIR / f"{nid}.body").read_bytes() for nid in NOTICES}
BODIES[ALL_DELETED_ID] = json.dumps({
    "_embedded": {"opportunityAttachmentList": [{"attachments": [{
        "name": "Withdrawn SOW.pdf", "resourceId": "e" * 32, "type": "file",
        "mimeType": ".pdf", "accessLevel": "public", "deletedFlag": "1",
        "deletedDate": "2026-09-10T00:00:00.000+00:00", "fileExists": "1"}]}]}}).encode()

SUPPORTED = {".pdf", ".docx", ".txt", ".csv", ".md"}
HEX32 = re.compile(r"[0-9a-f]{32}")


def handler(request: httpx.Request) -> httpx.Response:
    m = HEX32.search(str(request.url))
    nid = m.group(0) if m else None
    if nid in BODIES:
        return httpx.Response(200, content=BODIES[nid],
                              headers={"content-type": "application/json"})
    return httpx.Response(404, content=b"{}")


_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def deleted_rows(body: bytes) -> dict:
    payload = json.loads(body)
    rows = [a for w in ((payload.get("_embedded") or {}).get("opportunityAttachmentList") or [])
            for a in (w.get("attachments") or [])]
    dele = {a["resourceId"]: a for a in rows if str(a.get("deletedFlag")) == "1"}
    return {"rows": rows, "deleted": dele}


def load_base():
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", HERE / "base" / "sam_notice_detail_base.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def tmp(tag: str) -> Path:
    root = HERE / "tmp"
    root.mkdir(exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=tag + "-", dir=root))


def production_top3(items: list[dict]) -> list[dict]:
    ordered = sorted(items or [], key=attachment_priority)
    return [i for i in ordered
            if os.path.splitext(str(i.get("name") or ""))[1].lower() in SUPPORTED][:3]


observed: dict = {"q1_candidate": {}, "q2_base": {}, "q3_production": {},
                  "q4_all_deleted": {}, "q5_docs": {}, "q6_producer_replay": {}}
fails: list[str] = []

# Q1 candidate projection
base = load_base()
for nid in NOTICES + [ALL_DELETED_ID]:
    info = deleted_rows(BODIES[nid])
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp("cand"))
    res = detail.fetch_notice_resources(nid)
    items = res.get("attachments") or []
    projected_deleted = [i for i in items if i.get("resource_id") in info["deleted"]]
    marker_keys = sorted({k for i in projected_deleted for k in i.keys()
                          if "delet" in k.lower() or "exist" in k.lower()})
    top3 = production_top3(items)
    live_unread = [r["name"] for r in info["rows"]
                   if r["resourceId"] not in info["deleted"]
                   and os.path.splitext(r["name"])[1].lower() in SUPPORTED
                   and r["resourceId"] not in {t.get("resource_id") for t in top3}]
    observed["q1_candidate"][nid] = {
        "collection_status": res.get("collection_status"),
        "resources_checked": res.get("resources_checked"),
        "attachment_inventory_count": res.get("attachment_inventory_count"),
        "sam_rows": len(info["rows"]),
        "sam_deleted_rows": len(info["deleted"]),
        "deleted_projected_as_live": len(projected_deleted),
        "deleted_marker_keys_on_projection": marker_keys,
        "production_top3": [t["name"] for t in top3],
        "top3_deleted": [t["name"] for t in top3 if t.get("resource_id") in info["deleted"]],
        "live_supported_files_left_unread": live_unread,
        "hash_with_deleted": res.get("attachment_inventory_hash"),
        "hash_without_deleted": detail._manifest_hash(
            [i for i in items if i.get("resource_id") not in info["deleted"]]),
    }
    if projected_deleted and not marker_keys:
        fails.append(f"{nid[:8]}: {len(projected_deleted)} deleted row(s) projected live, no marker")
    # Q2 base projection through the BASE fetch_notice_resources
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp("base"))
    bres = base.fetch_notice_resources(nid)
    bitems = bres.get("attachments") or []
    observed["q2_base"][nid] = {
        "attachment_inventory_count": bres.get("attachment_inventory_count"),
        "deleted_projected_as_live": len([i for i in bitems if i.get("resource_id") in info["deleted"]]),
        "same_projection_as_candidate": bitems == items,
        "same_hash_as_candidate": bres.get("attachment_inventory_hash") == res.get("attachment_inventory_hash"),
        "has_collection_status_field": "collection_status" in bres,
    }

# Q4 summary
q4 = observed["q1_candidate"][ALL_DELETED_ID]
observed["q4_all_deleted"] = {
    "candidate_collection_status": q4["collection_status"],
    "expected_if_deleted_excluded": "confirmed_empty",
    "base_count": observed["q2_base"][ALL_DELETED_ID]["attachment_inventory_count"],
    "note": "collection_status is a Step7-introduced field; base has no such state",
}

# Q3 production path on the IHS notice (candidate code, real fetch + extract)
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402

sam_quota.calls_today = lambda: 0
ihs = "0caab6e53d8b47d7850692b7684610bf"
ihs_info = deleted_rows(BODIES[ihs])
deleted_sow_rid = next(iter(ihs_info["deleted"]))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp("prod-inv"))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp("prod-text"))
downloads: list[str] = []


def fake_download(resource_id: str, **kwargs) -> bytes:
    downloads.append(resource_id)
    return f"TEXT-FROM-{resource_id} revenue cycle billing".encode()


sat._download_bytes = fake_download
sat._pdf_text = lambda payload, **kwargs: payload.decode()
candidate = RawOpportunity(source="sam.gov", source_id=ihs, title="IHS Revenue Enhancement",
                           agency="HHS", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


rows, stats = searches._enrich_sam_public_attachments(
    [], Source(), object(),
    CapabilityTaxonomy(client_name="Probe", version=1, updated="2026-07-21",
                       core=[TaxonomyTerm(term="revenue cycle")]),
    None, limit=8)
receipt = stats["attachment_record_receipts"][ihs]
files = receipt.get("files") or []
by_rid = {f["resource_id"]: f for f in files}
row = rows[0] if rows else {}
raw = row.get("raw_payload", {}) if row else {}
coll = raw.get("attachment_collection_v1") or {}
observed["q3_production"] = {
    "record_status": receipt.get("status"),
    "inventory_count": receipt.get("inventory_count"),
    "downloads_in_order": downloads,
    "deleted_sow_downloaded": deleted_sow_rid in downloads,
    "deleted_sow_file_receipt": {k: by_rid.get(deleted_sow_rid, {}).get(k)
                                 for k in ("name", "status", "reason", "authority")},
    "deleted_sow_text_in_raw_payload_text": f"TEXT-FROM-{deleted_sow_rid}" in str(raw.get("text", "")),
    "deleted_sow_in_attachment_collection_v1": any(
        f.get("resource_id") == deleted_sow_rid for f in coll.get("files", [])),
    "live_files_not_fetched": [
        {"name": f["name"], "status": f["status"], "reason": f["reason"]}
        for f in files if f["status"] == "not_fetched"
        and f["resource_id"] not in ihs_info["deleted"]],
    "any_receipt_marks_withdrawn": any(
        "delet" in json.dumps(f).lower() or "withdraw" in json.dumps(f).lower() for f in files),
}
if observed["q3_production"]["deleted_sow_text_in_raw_payload_text"]:
    fails.append("production path placed withdrawn IHS SOW text into raw_payload.text")

# Q5 docs disclosure
doc_paths = [REPO / "docs/CONVENTIONS.md", REPO / "docs/CONTRACT_SURFACES.md"]
doc_paths += sorted((REPO / "docs/verification/step7-052").glob("*.md"))
doc_paths += sorted((REPO / "docs/verification/step7-052").glob("*.json"))
pattern = re.compile(r"deletedFlag|deletedDate|fileExists|withdrawn attachment|superseded (file|attachment|document)|soft-?delet", re.I)
hits = {}
for p in doc_paths:
    for n, line in enumerate(p.read_text(errors="replace").splitlines(), 1):
        if pattern.search(line):
            hits.setdefault(str(p.relative_to(REPO)), []).append(f"{n}: {line.strip()[:160]}")
observed["q5_docs"] = {
    "files_searched": len(doc_paths),
    "disclosure_hits": hits,
    "deletedFlag_in_tracked_code": bool(list(REPO.glob("tools/api/*.py")) and any(
        "deletedFlag" in p.read_text() for p in REPO.glob("tools/api/*.py"))),
}

# Q6 producer replay receipt
if REPLAY_RECEIPT.exists():
    rec = json.loads(REPLAY_RECEIPT.read_text())
    pfiles = (rec.get("attachment_record_receipts") or {}).get(ihs, {}).get("files") or []
    observed["q6_producer_replay"] = {
        "files_in_order": [{"name": f.get("name"), "status": f.get("status"),
                            "reason": str(f.get("reason"))[:90]} for f in pfiles],
        "deleted_sow_position": next((i for i, f in enumerate(pfiles)
                                      if f.get("resource_id") == deleted_sow_rid), None),
    }

status = "FAIL" if fails else "PASS"
print(json.dumps({"probe": "f10_deleted_inventory_scope", "status": status,
                  "fails": fails, "observed": observed}, indent=1, sort_keys=True, default=str))
