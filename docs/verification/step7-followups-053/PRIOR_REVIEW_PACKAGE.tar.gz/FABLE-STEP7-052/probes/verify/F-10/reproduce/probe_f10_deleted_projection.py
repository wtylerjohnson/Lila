#!/usr/bin/env python
"""F-10 independent reproduction: are soft-deleted SAM attachment rows
(deletedFlag "1", deletedDate set) projected as live inventory by the
candidate, counted in attachment_inventory_count/hash, and eligible for the
3-file download selection in run_searches._enrich_sam_public_attachments?

Written from the finding text only, before reading the member probe.
Offline: real captured bodies from SOURCE_PROOF public-inventory-001 are
parsed through the candidate's own projection functions; socket connect is
blocked; nothing is written into the review clone.
"""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
BODIES = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/"
              "extracted/source-proof/public-inventory-001")
IHS_NOTICE = "0caab6e53d8b47d7850692b7684610bf"

TMP = tempfile.mkdtemp(prefix="f10_", dir=str(HERE))
os.environ["LILA_NOTICE_CACHE_DIR"] = os.path.join(TMP, "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(TMP, "text")


def _no_network(*_args, **_kwargs):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_network  # type: ignore[assignment]
socket.socket.connect_ex = _no_network  # type: ignore[assignment]

sys.path.insert(0, str(REPO))
from tools.api import sam_notice_detail as cand  # noqa: E402
from tools.api.sam_attachment_text import attachment_priority  # noqa: E402

_spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(base)

# Copied verbatim from run_searches.py:182 and the selection at 237..247.
SUPPORTED = {".pdf", ".docx", ".txt", ".csv", ".md"}
DELETED_VALUES = {"1", "true", "yes", "y"}


def production_top3(items: list[dict]) -> list[dict]:
    ordered = sorted(items or [], key=attachment_priority)
    return [item for item in ordered
            if os.path.splitext(str(item.get("name") or ""))[1].lower()
            in SUPPORTED][:3]


def raw_rows(payload) -> list[dict]:
    """Walk the raw body; return every attachment-like row with its flags."""
    stack = [payload]
    rows = []
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            name = cur.get("name") or cur.get("fileName") or cur.get("resourceName")
            if name and (cur.get("resourceId") or cur.get("attachmentId")
                         or cur.get("uri") or cur.get("mimeType")):
                rows.append({
                    "resource_id": cur.get("resourceId") or cur.get("attachmentId"),
                    "name": name,
                    "deletedFlag": cur.get("deletedFlag"),
                    "deletedDate": cur.get("deletedDate"),
                    "fileExists": cur.get("fileExists"),
                })
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)
    return rows


def is_deleted(row: dict) -> bool:
    return str(row.get("deletedFlag") or "").strip().casefold() in DELETED_VALUES


def leak_keys(items: list[dict]) -> list[str]:
    keys = set()
    for item in items or []:
        keys.update(item.keys())
    return sorted(k for k in keys if "delet" in k.casefold()
                  or "exist" in k.casefold())


per_notice = []
totals = {"bodies_seen": 0, "notices_with_inventory": 0, "rows": 0,
          "deleted_rows": 0, "notices_with_deleted": 0,
          "deleted_in_top3_selection": 0, "same_as_base": 0,
          "count_includes_deleted": 0, "hash_changes_without_deleted": 0}
projected_keys_union: set[str] = set()

for body in sorted(BODIES.glob("*.body")):
    totals["bodies_seen"] += 1
    notice_id = body.stem
    try:
        payload = json.loads(body.read_bytes())
    except ValueError:
        per_notice.append({"notice_id": notice_id, "skipped": "not json"})
        continue
    rows = raw_rows(payload)
    cand_items, cand_rec = cand._attachment_inventory(payload, notice_id)
    base_items, base_rec = base._attachment_inventory(payload)
    if not cand_rec or not rows:
        per_notice.append({"notice_id": notice_id, "skipped": "no recognized inventory",
                           "candidate_recognized": cand_rec, "raw_rows": len(rows)})
        continue
    totals["notices_with_inventory"] += 1
    totals["rows"] += len(rows)
    deleted_ids = {str(r["resource_id"]) for r in rows if is_deleted(r)}
    deleted_names = [r["name"] for r in rows if is_deleted(r)]
    totals["deleted_rows"] += len(deleted_ids)
    if deleted_ids:
        totals["notices_with_deleted"] += 1
    for item in cand_items or []:
        projected_keys_union.update(item.keys())

    count = len(cand_items or [])
    manifest_hash = cand._manifest_hash(cand_items or [])
    live_items = [i for i in (cand_items or [])
                  if str(i.get("resource_id")) not in deleted_ids]
    live_hash = cand._manifest_hash(live_items)
    projected_deleted = [i["name"] for i in (cand_items or [])
                         if str(i.get("resource_id")) in deleted_ids]
    if projected_deleted:
        totals["count_includes_deleted"] += 1
    if manifest_hash != live_hash:
        totals["hash_changes_without_deleted"] += 1

    top3 = production_top3(cand_items or [])
    top3_deleted = [i["name"] for i in top3
                    if str(i.get("resource_id")) in deleted_ids]
    top3_live_only = production_top3(live_items)
    displaced_live = [i["name"] for i in top3_live_only
                      if i.get("resource_id") not in
                      {j.get("resource_id") for j in top3}]
    if top3_deleted:
        totals["deleted_in_top3_selection"] += 1
    same_as_base = (cand_items == base_items) and (cand_rec == base_rec)
    if same_as_base:
        totals["same_as_base"] += 1

    per_notice.append({
        "notice_id": notice_id,
        "raw_rows": len(rows),
        "deleted_rows": sorted(deleted_names),
        "deleted_flags_seen": sorted({str(r["deletedFlag"]) for r in rows}),
        "candidate_count": count,
        "candidate_count_equals_raw_rows_incl_deleted": count == len(rows),
        "projected_deleted_names": projected_deleted,
        "hash_differs_if_deleted_excluded": manifest_hash != live_hash,
        "top3_selected": [i["name"] for i in top3],
        "top3_selected_deleted": top3_deleted,
        "live_files_displaced_from_top3": displaced_live,
        "same_as_base": same_as_base,
    })

# Synthetic: a notice whose only remaining row is a deleted one.
sample = json.loads((BODIES / "6956ae1ef09c4baa987342b947ed6066.body").read_bytes())
only_deleted = json.loads(json.dumps(sample))
lst = only_deleted["_embedded"]["opportunityAttachmentList"][0]["attachments"]
only_deleted["_embedded"]["opportunityAttachmentList"][0]["attachments"] = [
    a for a in lst if str(a.get("deletedFlag")) == "1"]
od_items, od_rec = cand._attachment_inventory(only_deleted, "6956ae1ef09c4baa987342b947ed6066")
all_deleted = {
    "recognized": od_rec,
    "count": len(od_items or []),
    "collection_status_as_fetch_would_set": (
        "inventory_captured" if od_items else "confirmed_empty") if od_rec
    else "unrecognized_inventory",
}

# Producer's own SOURCE_PROOF projection for 6956: is the deleted DRAFT PWS listed?
meta = json.loads((BODIES / "6956ae1ef09c4baa987342b947ed6066.json").read_text())
producer_lists_deleted_draft = any(
    a.get("resource_id") == "33d849f11c7e43bf8ed8ff5346be18be"
    for a in meta.get("attachments") or [])

claim = {"notices": 17, "rows": 104, "deleted_rows": 5,
         "notices_with_deleted": 4, "deleted_in_top3_selection": 3}
measured = {"notices": totals["notices_with_inventory"], "rows": totals["rows"],
            "deleted_rows": totals["deleted_rows"],
            "notices_with_deleted": totals["notices_with_deleted"],
            "deleted_in_top3_selection": totals["deleted_in_top3_selection"]}
ihs = next((p for p in per_notice if p.get("notice_id") == IHS_NOTICE), None)
ihs_deleted_selected = bool(ihs and ihs.get("top3_selected_deleted"))

defect_shown = (totals["count_includes_deleted"] > 0
                and totals["deleted_in_top3_selection"] > 0
                and not leak_keys([{k: None} for k in projected_keys_union]))
same_everywhere = totals["same_as_base"] == totals["notices_with_inventory"]

print(json.dumps({
    "status": "FAIL" if defect_shown else "PASS",
    "observed": {
        "totals": totals,
        "claim_vs_measured": {"claim": claim, "measured": measured,
                              "match": claim == measured},
        "projected_record_keys": sorted(projected_keys_union),
        "projected_deleted_marker_keys": leak_keys(
            [{k: None} for k in projected_keys_union]),
        "same_as_base_everywhere": same_everywhere,
        "ihs_notice": ihs,
        "ihs_deleted_row_selected": ihs_deleted_selected,
        "all_deleted_synthetic": all_deleted,
        "producer_source_proof_lists_deleted_draft_pws": producer_lists_deleted_draft,
        "candidate_source_grep_deletedFlag": {
            f: (REPO / f).read_text().count("deletedFlag")
            for f in ("tools/api/sam_notice_detail.py",
                      "tools/api/sam_attachment_text.py", "run_searches.py")},
        "per_notice": per_notice,
        "tmp_dir": TMP,
    },
}, indent=1, sort_keys=True))
