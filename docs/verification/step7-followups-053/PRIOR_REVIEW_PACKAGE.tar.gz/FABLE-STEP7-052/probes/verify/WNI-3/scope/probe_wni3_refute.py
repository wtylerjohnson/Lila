"""WNI-3 refutation probe.

Question: does a wrong-notice resources body whose only foreign marker is a URL
(_links.self.href, per-row _links, downloadUrl path) get captured as the
requested notice's inventory, on the candidate AND on base 2d522f0, and does the
text reach run_searches/dossier bound to the requested notice?

Also measured, to test the finder's classification:
  * explicit keyed opportunityId=B body: candidate vs base (was base neutral or
    entirely guardless?)
  * a REAL captured HAL body served for a different requested id, with and
    without its opportunityId key (realism of the residual shape)
  * base-pure end to end (base run_searches + base fetch_notice_resources)

No network: sockets refused, every _http client rides MockTransport,
sam_attachment_text._download_bytes is replaced.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

SCOPE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
REAL_BODIES = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/"
                   "extracted/source-proof/public-inventory-001")
(SCOPE / "_tmp").mkdir(exist_ok=True)
TMP = Path(tempfile.mkdtemp(prefix="wni3-", dir=str(SCOPE / "_tmp")))

os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import tools.api.sam_notice_detail as cand  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import run_searches as cand_rs  # noqa: E402
from agents.decisions import dossier  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0


def load(name: str):
    spec = importlib.util.spec_from_file_location(name, SCOPE / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load("base_sam_notice_detail")
base_rs = load("base_run_searches")

A, B, C, D = "a" * 32, "b" * 32, "c" * 32, "d" * 32
TERM = "network visibility"
HOST = "https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"


def href(nid):
    return f"{HOST}/opps/v3/opportunities/{nid}/resources?withScanResult=false&excludeDeleted=false"


def row(resource_id=B, name="SOW.txt", **extra):
    out = {"resourceId": resource_id, "name": name, "mimeType": ".txt", "size": 10,
           "accessLevel": "public", "accessStatus": "public",
           "exportControlled": "0", "explicitAccess": "0"}
    out.update(extra)
    return out


def hal(notice_id, rows, self_notice=None, with_key=True):
    entry = {"attachments": rows}
    if with_key:
        entry = {"opportunityId": notice_id, **entry}
    h = href(self_notice or notice_id)
    return {"_embedded": {"opportunityAttachmentList": [entry]},
            "_links": {"self": {"href": h}, "opportunity:publish:latest": {"href": h}}}


def mock(body_bytes: bytes):
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=body_bytes)),
        follow_redirects=True)


def fresh(label):
    p = TMP / f"cache_{label}"
    p.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / f"text_{label}")


def fetch(module, body, label):
    fresh(label)
    mock(json.dumps(body).encode())
    out = module.fetch_notice_resources(A)
    return {"collection_status": out.get("collection_status"),
            "resources_checked": out.get("resources_checked"),
            "n_rows": len(out.get("attachments") or []),
            "errors": out.get("errors"), "id": out.get("id")}


# ---------------------------------------------------------------- unit cases
CASES = {
    "hal_no_id_key_self_href_B": hal(B, [row()], with_key=False),
    "download_url_names_B": {"attachments": [row(
        downloadUrl=f"https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources/files/{C}/download")]},
    "row_links_self_B": {"attachments": [row(_links={"self": {"href": href(B)}})]},
    "id_A_but_self_href_B": hal(A, [row()], self_notice=B),
    # control: the shape the delta was scoped to fix (S7-IDENTITY-002)
    "explicit_key_B": hal(B, [row()]),
    # control: correct body for A
    "positive_A": hal(A, [row()]),
}
unit = {}
for name, body in CASES.items():
    unit[name] = {"candidate": fetch(cand, body, f"c_{name}"),
                  "base": fetch(base, body, f"b_{name}")}

# ---------------------------------------------------------------- real bodies
real = {}
rowed = []
for body_path in sorted(REAL_BODIES.glob("*.body")):
    payload = json.loads(body_path.read_bytes())
    entries = (payload.get("_embedded") or {}).get("opportunityAttachmentList") or []
    if entries:
        rowed.append((body_path.stem, payload))
real["rowed_real_bodies"] = len(rowed)
real["rowed_real_bodies_with_opportunityId_on_every_entry"] = sum(
    1 for _, p in rowed if all("opportunityId" in e for e in p["_embedded"]["opportunityAttachmentList"]))
nid, real_body = rowed[0]
real["sample_real_notice"] = nid
real["real_body_served_for_A"] = {
    "candidate": fetch(cand, real_body, "c_real"), "base": fetch(base, real_body, "b_real")}
stripped = json.loads(json.dumps(real_body))
for e in stripped["_embedded"]["opportunityAttachmentList"]:
    e.pop("opportunityId", None)
real["real_body_key_stripped_served_for_A"] = {
    "candidate": fetch(cand, stripped, "c_real_stripped"), "base": fetch(base, stripped, "b_real_stripped")}

# ---------------------------------------------------------------- end to end
def taxonomy():
    return CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=A, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})]


sat._download_bytes = lambda rid, **k: f"Href-only body requires {TERM}.".encode()
body_h3 = json.dumps(hal(B, [row(C, "Href only SOW.txt")], with_key=False)).encode()


def e2e(rs_module, detail_fetch, label):
    fresh(label)
    mock(body_h3)
    saved = cand.fetch_notice_resources
    cand.fetch_notice_resources = detail_fetch  # run_searches imports from tools.api.sam_notice_detail
    try:
        rows, stats = rs_module._enrich_sam_public_attachments([], Source(), object(), taxonomy(), None, limit=8)
    finally:
        cand.fetch_notice_resources = saved
    receipt = (stats.get("attachment_record_receipts") or {}).get(A, {})
    raw = (rows[0].get("raw_payload") if rows else None) or {}
    out = {"rows": len(rows), "receipt_status": receipt.get("status"),
           "inventory_receipt_id": (receipt.get("inventory_receipt") or {}).get("id"),
           "row_text": (raw.get("text") or "")[:60] or None,
           "collection_notice_id": (raw.get("attachment_collection_v1") or {}).get("notice_id")}
    if rows:
        notice = {"source_id": A, "raw_payload": raw}
        depth = {"id": A, "attachment_inventory_hash": raw.get("attachment_inventory_hash")}
        ctx = dossier._attachment_research_context(notice, depth)
        out["dossier_status"] = (ctx or {}).get("status")
        out["dossier_notice_id"] = (ctx or {}).get("notice_id")
        out["dossier_text"] = ((ctx or {}).get("text") or "")[:60] or None
    return out


e2e_obs = {
    "candidate_rs_plus_candidate_detail": e2e(cand_rs, cand.fetch_notice_resources, "e2e_cand"),
    "base_rs_plus_base_detail": e2e(base_rs, base.fetch_notice_resources, "e2e_base"),
}

# ---------------------------------------------------------------- verdict
finder_cases = ["hal_no_id_key_self_href_B", "download_url_names_B", "row_links_self_B", "id_A_but_self_href_B"]
checks = {
    "finder_cases_captured_on_candidate": all(
        unit[c]["candidate"]["collection_status"] == "inventory_captured" and unit[c]["candidate"]["n_rows"] == 1
        for c in finder_cases),
    "finder_cases_captured_on_base": all(
        unit[c]["base"]["resources_checked"] is True and unit[c]["base"]["n_rows"] == 1 for c in finder_cases),
    "explicit_key_B_rejected_on_candidate": unit["explicit_key_B"]["candidate"]["collection_status"] == "identity_mismatch",
    "explicit_key_B_accepted_on_base (base had NO identity guard)": unit["explicit_key_B"]["base"]["resources_checked"] is True,
    "positive_A_captured_both": unit["positive_A"]["candidate"]["collection_status"] == "inventory_captured"
    and unit["positive_A"]["base"]["resources_checked"] is True,
    "real_wrong_body_rejected_on_candidate_accepted_on_base":
        real["real_body_served_for_A"]["candidate"]["collection_status"] == "identity_mismatch"
        and real["real_body_served_for_A"]["base"]["resources_checked"] is True,
    "real_body_needs_key_stripped_to_slip_through":
        real["real_body_key_stripped_served_for_A"]["candidate"]["collection_status"] == "inventory_captured",
    "all_real_rowed_bodies_carry_opportunityId":
        real["rowed_real_bodies"] == real["rowed_real_bodies_with_opportunityId_on_every_entry"],
    "e2e_candidate_text_bound_to_A_and_dossier_accepts":
        e2e_obs["candidate_rs_plus_candidate_detail"]["rows"] == 1
        and e2e_obs["candidate_rs_plus_candidate_detail"]["collection_notice_id"] == A
        and e2e_obs["candidate_rs_plus_candidate_detail"].get("dossier_status") == "discovery_only",
    "e2e_base_pure_text_bound_to_A": e2e_obs["base_rs_plus_base_detail"]["rows"] == 1,
}
status = "FAIL" if checks["finder_cases_captured_on_candidate"] else "PASS"
print(json.dumps({
    "probe": "wni3_refute", "status": status,
    "note": ("FAIL = the finder's href-only wrong-notice bodies are captured as A's inventory on the "
             "candidate (defect reproduced). Base captures them too, and base also captures the "
             "explicit keyed B body and a REAL wrong body, so base had no identity guard at all; the "
             "delta introduced a keyed-id-only guard. Residual shape needs the opportunityId key "
             "stripped from a real HAL body; none of the real rowed bodies lack it."),
    "checks": checks, "unit": unit, "real": real, "e2e": e2e_obs, "tmp_dir": str(TMP),
}, indent=2, sort_keys=True, default=str))
