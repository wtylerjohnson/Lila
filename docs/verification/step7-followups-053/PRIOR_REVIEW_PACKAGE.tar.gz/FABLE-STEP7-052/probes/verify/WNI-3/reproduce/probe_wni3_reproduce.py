"""Independent reproduction of WNI-3 (href-only wrong-notice identity).

Written without reading the original probe. Serves four bodies for notice A
whose only foreign identity marker is a URL (self href, per-row _links,
download URL) or a contradiction (keyed A, href B), and checks whether the
candidate accepts them as A's inventory, whether the base does the same, and
whether the text reaches a row bound to A end to end. Network is blocked.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
os.chdir(REPO)

import httpx  # noqa: E402

A = "a" * 32
B = "b" * 32
RID = "c" * 32
INTERNAL = ("https://86samdotgovopportunitiesmodern.prod.apps-internal."
            "prod-iae.bsp.gsa.gov/opps/v3/opportunities/{id}/resources"
            "?withScanResult=false&excludeDeleted=false")
FILE_TEXT = "Href-only body requires network visibility."


def _block_network():
    def deny(*_a, **_k):
        raise RuntimeError("network blocked by probe")
    socket.socket.connect = deny  # type: ignore[assignment]
    socket.create_connection = deny  # type: ignore[assignment]


def _row(extra: dict | None = None, opportunity_id: str | None = A) -> dict:
    entry: dict = {}
    if opportunity_id is not None:
        entry["opportunityId"] = opportunity_id
    entry["attachments"] = [{
        "attachmentId": "d" * 32, "resourceId": RID, "attachmentOrder": 1,
        "fileExists": "1", "name": "SOW.txt", "type": "file",
        "accessLevel": "public", "exportControlled": "0",
        "explicitAccess": "0", "mimeType": ".txt", "size": 64,
        **(extra or {}),
    }]
    return entry


def bodies() -> dict[str, dict]:
    links_b = {"self": {"href": INTERNAL.format(id=B)},
               "opportunity:publish:latest": {"href": INTERNAL.format(id=B)}}
    return {
        "hal_no_id_key_self_href_B": {
            "_embedded": {"opportunityAttachmentList": [_row(opportunity_id=None)]},
            "_links": links_b,
        },
        "download_url_names_B": {
            "_embedded": {"opportunityAttachmentList": [_row(
                {"downloadUrl": f"https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources/download/{RID}"},
                opportunity_id=None)]},
            "_links": {"self": {"href": INTERNAL.format(id=A)}},
        },
        "row_links_self_B": {
            "_embedded": {"opportunityAttachmentList": [{
                **_row(opportunity_id=None),
                "_links": {"self": {"href": INTERNAL.format(id=B)}},
            }]},
            "_links": {"self": {"href": INTERNAL.format(id=A)}},
        },
        "id_A_but_self_href_B": {
            "_embedded": {"opportunityAttachmentList": [_row(opportunity_id=A)]},
            "_links": links_b,
        },
        # control: keyed foreign id must be rejected by the candidate
        "control_keyed_opportunityId_B": {
            "_embedded": {"opportunityAttachmentList": [_row(opportunity_id=B)]},
            "_links": links_b,
        },
    }


def _serve(body: dict):
    payload = json.dumps(body).encode()
    calls: list[str] = []

    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=payload,
                              headers={"content-type": "application/hal+json"})
    from tools.api import _http
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def _load_base():
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def part_unit(detail_mod, label: str) -> dict:
    out = {}
    for name, body in bodies().items():
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
            calls = _serve(body)
            res = detail_mod.fetch_notice_resources(A)
            out[name] = {
                "collection_status": res.get("collection_status"),
                "resources_checked": res.get("resources_checked"),
                "attachment_count": len(res.get("attachments") or []),
                "id": res.get("id"),
                "errors": res.get("errors"),
                "requested_url_names_A": all(A in u for u in calls),
                "cache_written": Path(tmp, f"{A}.resources.json").exists(),
            }
    return out


def part_end_to_end() -> dict:
    """Real fetch_notice_resources (candidate) + mocked download, through run_searches."""
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.api import sam_attachment_text as sat, sam_quota
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    sam_quota.calls_today = lambda: 0
    results = {}
    for name, body in bodies().items():
        if name.startswith("control"):
            continue
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["LILA_NOTICE_CACHE_DIR"] = str(Path(tmp, "inv"))
            os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(Path(tmp, "txt"))
            _serve(body)
            sat._download_bytes = lambda rid, **k: FILE_TEXT.encode()
            candidate = RawOpportunity(source="sam.gov", source_id=A,
                                       title="Requirement", agency="NASA",
                                       raw_payload={"type": "Solicitation"})

            class Source:
                last_attachment_census = {"selected": 1}

                def attachment_candidates(self, *a, **k):
                    return [candidate]

            tax = CapabilityTaxonomy(client_name="Testco", version=1,
                                     updated="2026-07-21",
                                     core=[TaxonomyTerm(term="network visibility")])
            rows, stats = searches._enrich_sam_public_attachments(
                [], Source(), object(), tax, None, limit=8)
            receipt = stats["attachment_record_receipts"][A]
            entry = {
                "record_status": receipt.get("status"),
                "guard_tripped": receipt.get("status") == "IDENTITY_MISMATCH",
                "inventory_collection_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
                "rows_added": len(rows),
            }
            if rows:
                raw = rows[0]["raw_payload"]
                coll = raw.get("attachment_collection_v1") or {}
                entry.update({
                    "collection_notice_id": coll.get("notice_id"),
                    "collection_notice_is_A": coll.get("notice_id") == A,
                    "text_is_foreign_body_text": raw.get("text") == FILE_TEXT,
                    "file_resource_ids": [f.get("resource_id") for f in coll.get("files", [])],
                    "combined_sha_matches": coll.get("combined_text_sha256")
                    == hashlib.sha256(FILE_TEXT.encode()).hexdigest(),
                })
            results[name] = entry
    return results


def part_realism(detail_mod) -> dict:
    src = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/"
               "source-proof/public-inventory-001")
    summary = {"bodies": 0, "with_opportunityId_key": 0, "links_only": 0,
               "rows_missing_opportunityId": 0, "links_only_classification": set()}
    for path in sorted(src.glob("*.body")):
        try:
            body = json.loads(path.read_text())
        except ValueError:
            continue
        summary["bodies"] += 1
        text = path.read_text()
        if '"opportunityId"' in text:
            summary["with_opportunityId_key"] += 1
            rows = (body.get("_embedded") or {}).get("opportunityAttachmentList") or []
            summary["rows_missing_opportunityId"] += sum(
                1 for r in rows if isinstance(r, dict) and "opportunityId" not in r)
        elif set(body) == {"_links"}:
            summary["links_only"] += 1
            items, recognized = detail_mod._attachment_inventory(body, path.stem)
            summary["links_only_classification"].add(
                "unrecognized" if not recognized else ("confirmed_empty" if not items else "rows"))
    summary["links_only_classification"] = sorted(summary["links_only_classification"])
    return summary


def main() -> int:
    _block_network()
    from tools.api import sam_notice_detail as cand
    base = _load_base()

    cand_unit = part_unit(cand, "candidate")
    base_unit = part_unit(base, "base")
    e2e = part_end_to_end()
    realism = part_realism(cand)

    href_cases = ["hal_no_id_key_self_href_B", "download_url_names_B",
                  "row_links_self_B", "id_A_but_self_href_B"]
    cand_accepted = [n for n in href_cases
                     if cand_unit[n]["collection_status"] == "inventory_captured"
                     and cand_unit[n]["attachment_count"] > 0]
    base_accepted = [n for n in href_cases
                     if base_unit[n]["resources_checked"] is True
                     and base_unit[n]["attachment_count"] > 0]
    control_rejected = cand_unit["control_keyed_opportunityId_B"]["collection_status"] == "identity_mismatch"
    e2e_bound_to_A = [n for n in href_cases
                      if e2e[n].get("collection_notice_is_A") and e2e[n].get("text_is_foreign_body_text")]
    guard_never_trips = not any(e2e[n]["guard_tripped"] for n in href_cases)

    reproduced = (set(cand_accepted) == set(href_cases)
                  and set(e2e_bound_to_A) == set(href_cases)
                  and guard_never_trips and control_rejected)
    pre_existing = set(base_accepted) == set(href_cases)
    status = "FAIL" if reproduced else "PASS"
    print(json.dumps({
        "status": status,
        "finding": "WNI-3",
        "reproduced_as_described": reproduced,
        "base_behaves_identically": pre_existing,
        "observed": {
            "candidate_accepted_as_A_inventory": cand_accepted,
            "base_accepted_as_A_inventory": base_accepted,
            "control_keyed_B_rejected_by_candidate": control_rejected,
            "control_keyed_B_base": base_unit["control_keyed_opportunityId_B"],
            "end_to_end_text_bound_to_A": e2e_bound_to_A,
            "run_searches_guard_never_trips": guard_never_trips,
            "candidate_unit": cand_unit,
            "base_unit": base_unit,
            "end_to_end": e2e,
            "realism_real_bodies": realism,
        },
    }, indent=1, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
