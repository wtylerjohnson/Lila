"""F-13 scope/classification probe: does the dossier prompt carry research text twice,
and is that a Step7 delta effect, a base behaviour, a disclosed limit, or a doc overstatement?

Run from the repo root (cd /Users/wtjohnson/lila-step7-052). No network, no LLM call:
sockets are blocked, compose_dossier runs only against a recording engine.

Measures on the candidate (6b51f00 code) and on a base copy (git show 2d522f0) of
agents/decisions/dossier.py placed next to this script:
  1. text field length, file_passages text total, relevance_excerpt length, serialized size.
  2. distinct captured characters exposed (union of passage intervals vs text[:14000]).
  3. base: same row -> text length, excerpt, absence of passages; content parity with candidate.
  4. files 2/3 visibility: identical first-14000 window at base and candidate (ELD-07 lineage).
  5. per-file attribution: every passage is bound by a verified locator + text_sha256,
     so the SYSTEM_PROMPT "unless that mapping is independently given" clause is satisfied.
  6. doc sentences: the 14,000 sentence predates Step7 (present at base) and is unchanged;
     Step7 docs disclose per-file passages and prompt truncation.
"""
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))


def _no_network(*args, **kwargs):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_network  # type: ignore[assignment]

TMP = Path(tempfile.mkdtemp(prefix="f13_", dir=str(HERE)))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")

import run_searches as searches  # noqa: E402
from agents.decisions import dossier as dz  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

obs = {}
fails = []


def check(name, cond, detail_=None):
    obs[name] = {"ok": bool(cond), **({"detail": detail_} if detail_ is not None else {})}
    if not cond:
        fails.append(name)


def public_file(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


class RecordingEngine:
    def __init__(self):
        self.context = None
        self.system_prompt = None

    def deliberate(self, layer, system_prompt, context, schema):
        self.context = context
        self.system_prompt = system_prompt
        return None


def native_collection(notice_id, files, texts, term="network visibility"):
    inventory = detail._manifest_hash(files)
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id, title="Synthetic",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1, "scope": "f13 probe"}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    with patch("tools.api.sam_quota.calls_today", return_value=0), \
            patch.object(detail, "fetch_notice_resources", return_value={
                "id": notice_id, "resources_checked": True, "attachments": files,
                "attachment_inventory_hash": inventory}), \
            patch.object(sat, "_download_bytes", lambda rid, **k: texts[rid].encode()):
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(),
            CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                               core=[TaxonomyTerm(term=term)]), None, limit=1)
    return rows, stats, inventory


NID = "a" * 32
files = [public_file("b" * 32, "SOW 1.txt"), public_file("c" * 32, "PWS 2.txt"),
         public_file("d" * 32, "Spec 3.txt")]
# file 1 > 14000 so files 2/3 fall outside the window; term appears in every file so
# the relevance excerpt draws context from beyond the window as well.
texts = {"b" * 32: ("network visibility alpha " * 3000)[:50000],
         "c" * 32: ("network visibility beta PWS " * 3000)[:50000],
         "d" * 32: ("network visibility gamma Café Δ " * 3000)[:50000]}
rows, stats, inventory = native_collection(NID, files, texts)
check("0.row_produced", len(rows) == 1, {"rows": len(rows), "errors": stats.get("attachment_errors")})
row = rows[0]
raw = row["raw_payload"]
text = raw["text"]
depth = {"id": NID, "description": "Depth sentinel.", "attachments": [], "errors": [],
         "resources_checked": True, "attachment_inventory_hash": inventory}

# ---- 1. candidate measurement through compose_dossier -----------------------
eng = RecordingEngine()
dz.compose_dossier("Testco", "strategy", row, depth, engine=eng)
research = eng.context["attachment_research"]
passages = research.get("file_passages") or []
excerpt = research.get("relevance_excerpt") or ""
serialized_ctx = json.dumps(eng.context, indent=2, default=str, sort_keys=True)
serialized_research = json.dumps(research, indent=2, default=str, sort_keys=True)
literal_chars = len(research["text"]) + sum(len(p["text"]) for p in passages) + len(excerpt)
obs["1.candidate"] = {
    "status": research["status"], "captured_characters": research["captured_characters"],
    "text_field_len": len(research["text"]), "passages": len(passages),
    "passages_text_total": sum(len(p["text"]) for p in passages),
    "relevance_excerpt_len": len(excerpt),
    "literal_research_chars_in_prompt": literal_chars,
    "serialized_attachment_research_len": len(serialized_research),
    "serialized_context_len": len(serialized_ctx),
    "passage_shape": [{"name": p["name"], "start": p["locator"]["start"], "end": p["locator"]["end"],
                       "included_end": p["included_end"], "len_text": len(p["text"]),
                       "truncated": p["truncated"]} for p in passages],
}
check("1.text_field_capped_14000", len(research["text"]) == 14000 and research["text"] == text[:14000])
check("1.literal_chars_exceed_14000", literal_chars > 14000, literal_chars)

# ---- 2. distinct captured characters exposed -------------------------------
covered = set()
for p in passages:
    covered.update(range(p["locator"]["start"], p["included_end"]))
exposed_via_passages = "".join(p["text"] for p in passages)
distinct_exposed = len(set(range(0, len(research["text"]))) | covered)
check("2.passages_are_reslice_of_text_field",
      all(text[p["locator"]["start"]:p["included_end"]] == p["text"] for p in passages)
      and all(p["included_end"] <= 14000 for p in passages if p["text"]),
      {"nonempty_included_ends": [p["included_end"] for p in passages if p["text"]],
       "empty_passages": [p["name"] for p in passages if not p["text"]]})
check("2.distinct_captured_chars_exposed_is_14000", distinct_exposed == 14000, distinct_exposed)
check("2.excerpt_segments_all_in_text", all(seg.strip() in text for seg in excerpt.split("\n…\n")),
      {"excerpt_offsets": [text.find(seg.strip()) for seg in excerpt.split("\n…\n")]})
obs["2.excerpt_beyond_window"] = [text.find(seg.strip()) for seg in excerpt.split("\n…\n") if text.find(seg.strip()) >= 14000]

# ---- 3. base copy on the same row -----------------------------------------
spec = importlib.util.spec_from_file_location("base_dossier", str(HERE / "base_dossier.py"))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
b_eng = RecordingEngine()
base.compose_dossier("Testco", "strategy", copy.deepcopy(row), depth, engine=b_eng)
b_research = b_eng.context["attachment_research"]
b_excerpt = b_research.get("relevance_excerpt") or ""
b_literal = len(b_research["text"]) + len(b_excerpt)
obs["3.base"] = {
    "status": b_research["status"], "text_field_len": len(b_research["text"]),
    "has_file_passages": "file_passages" in b_research,
    "relevance_excerpt_len": len(b_excerpt), "literal_research_chars_in_prompt": b_literal,
    "serialized_attachment_research_len": len(json.dumps(b_research, indent=2, default=str, sort_keys=True)),
}
check("3.base_no_passages_text_plus_excerpt", "file_passages" not in b_research
      and len(b_research["text"]) == 14000 and b_literal > 14000, b_literal)
check("3.base_and_candidate_same_text_window", b_research["text"] == research["text"])
check("3.base_and_candidate_same_excerpt", b_excerpt == excerpt)
check("3.base_system_prompt_identical", b_eng.system_prompt == eng.system_prompt)
obs["3.duplication_is_delta_effect"] = {
    "candidate_literal_minus_base_literal": literal_chars - b_literal,
    "equals_passages_text_total": (literal_chars - b_literal) == sum(len(p["text"]) for p in passages),
}

# ---- 4. files 2/3 visibility (ELD-07 lineage) ------------------------------
file2_start = passages[1]["locator"]["start"]
check("4.files_2_3_outside_window_candidate",
      passages[1]["text"] == "" and passages[2]["text"] == "" and passages[1]["truncated"] and passages[2]["truncated"])
check("4.files_2_3_outside_window_base_identically",
      file2_start >= 14000 and texts["c" * 32][:20] not in b_research["text"]
      and texts["c" * 32][:20] not in research["text"],
      {"file2_start": file2_start, "window_end": 14000})
# marker check: the PWS marker of file 2 is absent from both prompts
check("4.pws_marker_absent_both", "beta PWS" not in b_research["text"] and "beta PWS" not in research["text"])

# ---- 5. per-file attribution is independently given -----------------------
bound = []
for p, ev in zip(passages, raw["attachment_evidence"]):
    loc = p["locator"]
    bound.append(hashlib.sha256(text[loc["start"]:loc["end"]].encode()).hexdigest() == ev["text_sha256"]
                 == p.get("sha256", None) or hashlib.sha256(text[loc["start"]:loc["end"]].encode()).hexdigest() == ev["text_sha256"])
check("5.every_passage_bound_by_locator_and_text_sha256", all(bound), bound)
clause = "do\nnot attribute a passage to one file unless that mapping is independently given"
check("5.system_prompt_has_unless_clause", clause in eng.system_prompt)
# tamper the locator of file 1 (shift end by one) and rehash the receipt: dossier must drop passages
tampered = copy.deepcopy(row)
tampered["raw_payload"]["attachment_collection_v1"]["files"][0]["combined_text_locator"]["end"] -= 1
tampered["raw_payload"]["attachment_collection_sha256"] = hashlib.sha256(json.dumps(
    tampered["raw_payload"]["attachment_collection_v1"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
t_res = dz._attachment_research_context(tampered, depth)
check("5.unverified_mapping_rejected", t_res["status"] == "unavailable", t_res.get("reason"))

# ---- 6. doc sentences -----------------------------------------------------
conv = (REPO / "docs/CONVENTIONS.md").read_text()
base_conv = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:docs/CONVENTIONS.md"],
                           capture_output=True, text=True, check=True).stdout
s14 = ("The prompt includes at most 14,000 captured characters, original length and\n"
       "  truncation status, plus a bounded relevance excerpt only when every segment\n"
       "  occurs in the captured text. Text is associated with the file bundle, not\n"
       "  falsely attributed to an individual file.")
check("6.14000_sentence_present_candidate", s14 in conv)
check("6.14000_sentence_present_base_unchanged", s14 in base_conv)
step7 = ("Dossier research validates the new\nlocator binding before exposing per-file passages, "
         "marks prompt truncation,\nand remains `discovery_only`.")
check("6.step7_discloses_per_file_passages_and_truncation", step7 in conv and step7 not in base_conv)
cs = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
cs_sent = ("Dossier research verifies notice/inventory/file/text/offset binding before\n"
           "attribution, remains discovery_only, and preserves legacy research readability.")
check("6.contract_surfaces_discloses_attribution_after_binding", cs_sent in cs)
ver_dir = REPO / "docs/verification/step7-052"
disclosure_hits = {}
for path in sorted(ver_dir.glob("*")):
    if path.suffix in {".md", ".json", ".py"}:
        body = path.read_text(errors="replace")
        hits = [w for w in ("file_passages", "twice", "duplicate", "28879", "prompt size") if w in body]
        if hits:
            disclosure_hits[path.name] = hits
obs["6.verification_dir_mentions"] = disclosure_hits
lv = json.loads((ver_dir / "LOCAL_VERIFICATION.json").read_text())
obs["6.local_verification_dossier_characters"] = lv["extra_probes"]["text_boundaries"]["dossier_characters"]
ptb = (ver_dir / "probe_text_boundaries.py").read_text()
check("6.producer_probe_asserts_both_text_and_passages_14000",
      "assert context['status'] == 'discovery_only' and len(context['text']) == 14000" in ptb
      and "assert sum(len(item['text']) for item in context['file_passages']) == 14000" in ptb)

shutil.rmtree(TMP, ignore_errors=True)
status = "INFO" if not fails else "FAIL"
print(json.dumps({"status": status, "probe": "f13_scope", "failed_checks": fails, "observed": obs},
                 indent=2, ensure_ascii=False, default=str))
