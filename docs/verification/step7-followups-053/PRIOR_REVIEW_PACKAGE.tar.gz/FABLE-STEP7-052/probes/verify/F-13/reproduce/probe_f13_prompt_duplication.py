"""F-13 independent reproduction: does the dossier prompt carry research text twice?

Claim under test (merged finding F-13, members ELD-04 / ELD-07):
  * result['text'] (<= 14000) + file_passages[*]['text'] (<= 14000, same chars) +
    relevance_excerpt (<= 1200) => about 28.9k research characters reach the model.
  * With defaults (3 x 50000 -> 150000 combined) files 2 and 3 get empty passages
    whenever file 1 has >= 14000 chars.
  * Base (2d522f0) carried only text (14000) + excerpt.
  * SYSTEM_PROMPT says not to attribute a passage to one file; file_passages now do.

No network, no LLM: compose_dossier gets a stub engine whose deliberate() records
the rendered user turn via DecisionEngine._render and returns a fixed PursuitDossier.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import sys
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
os.chdir(REPO)
sys.path.insert(0, str(REPO))


def _no_connect(*_a, **_k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

from agents.decisions import dossier as cand  # noqa: E402
from agents.decisions.engine import DecisionEngine  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_dossier_2d522f0", HERE / "base_dossier_2d522f0.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)  # type: ignore[union-attr]

NOTICE_ID = "f13probe0001"
INVENTORY = hashlib.sha256(b"inventory-f13").hexdigest()


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _filler(tag: str, n: int) -> str:
    # Distinct, non-periodic plain-ASCII filler per file (deterministic LCG words) so a
    # long substring occurs exactly once in the bundle.
    words = ["scope", "clause", "offeror", "deliverable", "period", "evaluation",
             "factor", "submission", "page", "limit", "vendor", "brand", "system"]
    state = sum(ord(c) for c in tag) or 1
    out = [f"{tag} performance work statement "]
    total = len(out[0])
    while total < n:
        state = (state * 1103515245 + 12345) % (2 ** 31)
        w = f"{words[state % len(words)]}{state % 9973} "
        out.append(w)
        total += len(w)
    return "".join(out)[:n]


def build_bundle(per_file: tuple[int, int, int]) -> tuple[dict, dict]:
    """Mirror run_searches._enrich_sam_public_attachments for a 3-file bundle."""
    texts: list[str] = []
    evidence: list[dict] = []
    for i, n in enumerate(per_file):
        raw_text = _filler(f"FILE{i + 1}", n)
        start = sum(len(t) for t in texts) + 2 * len(texts)
        file_text = raw_text[:max(0, 150000 - start)]
        texts.append(file_text)
        rid = f"{i + 1:032x}"
        evidence.append({
            "resource_id": rid,
            "name": f"attachment_{i + 1}.pdf",
            "sha256": _sha(f"bytes-{i}"),
            "retrieved_at": "2026-09-10T12:00:00+00:00",
            "source_url": f"https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{rid}/download",
            "raw_capture": None, "text_capture": None, "extraction_limits": None,
            "authority": "discovery_only",
            "text_sha256": _sha(file_text),
            "file_text_locator": {"unit": "unicode_characters", "start": 0, "end": len(file_text)},
            "file_text_truncated": len(file_text) < len(raw_text),
            "combined_text_locator": {"unit": "unicode_characters", "start": start,
                                      "end": start + len(file_text)},
        })
    combined = "\n\n".join(texts)[:150000]
    basis = {
        "files": sorted([{"resource_id": e["resource_id"], "sha256": e["sha256"]} for e in evidence],
                        key=lambda it: (it["resource_id"], it["sha256"])),
        "text_sha256": _sha(combined),
    }
    raw: dict = {
        "text": combined,
        "attachment_evidence": evidence,
        "attachment_inventory_hash": INVENTORY,
        "attachment_evidence_sha256": hashlib.sha256(json.dumps(
            basis, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest(),
    }
    raw["attachment_collection_v1"] = {
        "notice_id": NOTICE_ID, "inventory_hash": INVENTORY, "files": evidence,
        "authority": "discovery_only", "combined_text_sha256": basis["text_sha256"],
    }
    raw["attachment_collection_sha256"] = hashlib.sha256(json.dumps(
        raw["attachment_collection_v1"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    # Relevance excerpt: segments drawn from file 3 (beyond the 14000 cap), joined the
    # producer's way, capped at 1200 like run_searches.py line 345.
    seg_a = combined[100004 + 30000:100004 + 30000 + 700].strip()
    seg_b = combined[100004 + 45000:100004 + 45000 + 700].strip()
    raw["attachment_relevance_excerpt"] = "\n…\n".join([seg_a, seg_b])[:1200]
    notice = {"source_id": NOTICE_ID, "id": NOTICE_ID, "title": "F13 probe",
              "agency": "PROBE", "raw_payload": raw}
    depth = {"id": NOTICE_ID, "attachment_inventory_hash": INVENTORY,
             "resources_checked": True, "description": "short description",
             "attachments": [{"name": e["name"]} for e in evidence], "errors": []}
    return notice, depth


class StubEngine:
    """Captures the rendered user turn; never talks to a model."""

    def __init__(self):
        self.captured = None

    def deliberate(self, *, layer, system_prompt, context, schema, now=None):
        self.captured = {
            "context": context,
            "system_prompt": system_prompt,
            "user_content": DecisionEngine._render(layer, context),
        }
        return schema(id=context["notice"]["id"], title="stub", scope_summary="stub",
                      evaluation_criteria=[], submission_requirements=[],
                      incumbent_signals=[], fit_verdict="stretch", win_themes=[],
                      red_flags=[], next_action="none")


def measure(result: dict) -> dict:
    passages = result.get("file_passages") or []
    text_len = len(result.get("text", ""))
    pass_total = sum(len(p["text"]) for p in passages)
    exc_len = len(result.get("relevance_excerpt", ""))
    return {
        "status": result.get("status"),
        "text_field_chars": text_len,
        "file_passages_present": "file_passages" in result,
        "file_passages_text_total": pass_total,
        "relevance_excerpt_chars": exc_len,
        "research_text_chars_total": text_len + pass_total + exc_len,
        "passages_concat_equals_text_field": (
            "".join(p["text"] for p in passages) == result.get("text", "")
            if passages else None),
        "passages": [{"i": i, "start": p["locator"]["start"], "end": p["locator"]["end"],
                      "included_end": p["included_end"], "text_len": len(p["text"]),
                      "truncated": p["truncated"]} for i, p in enumerate(passages)],
        "excerpt_segments_all_beyond_14000": (
            all(result["text"].find(seg.strip()) == -1 for seg in
                result.get("relevance_excerpt", "").split("\n…\n") if seg.strip())
            if exc_len else None),
        "len_json_dumps_compact": len(json.dumps(result)),
    }


def main() -> None:
    observed: dict = {}
    checks: dict[str, bool] = {}

    # A. Default shape 3 x 50000 (combined 150000).
    notice, depth = build_bundle((50000, 50000, 50000))
    observed["combined_chars"] = len(notice["raw_payload"]["text"])
    cand_res = cand._attachment_research_context(notice, depth)
    base_res = base._attachment_research_context(notice, depth)
    observed["candidate_default"] = measure(cand_res)
    observed["base_default"] = measure(base_res)
    m = observed["candidate_default"]
    checks["A1_candidate_status_discovery_only"] = m["status"] == "discovery_only"
    checks["A2_text_field_14000"] = m["text_field_chars"] == 14000
    checks["A3_passages_total_14000"] = m["file_passages_text_total"] == 14000
    checks["A4_passages_duplicate_text_field"] = m["passages_concat_equals_text_field"] is True
    checks["A5_excerpt_le_1200_and_positive"] = 0 < m["relevance_excerpt_chars"] <= 1200
    checks["A6_total_between_28000_and_29200"] = 28000 <= m["research_text_chars_total"] <= 29200
    checks["A7_files_2_3_empty_passages"] = (
        len(m["passages"]) == 3
        and all(p["text_len"] == 0 and p["included_end"] == p["start"] and p["truncated"]
                for p in m["passages"][1:]))
    checks["A8_excerpt_drawn_beyond_text_field"] = m["excerpt_segments_all_beyond_14000"] is True
    bm = observed["base_default"]
    checks["A9_base_has_no_passages"] = bm["file_passages_present"] is False
    checks["A10_base_total_is_text_plus_excerpt"] = (
        bm["research_text_chars_total"] == 14000 + bm["relevance_excerpt_chars"])

    # B. Rendered prompt through compose_dossier with a stub engine.
    stub = StubEngine()
    cand.compose_dossier("ProbeClient", "strategy", notice, depth, engine=stub)
    ctx = stub.captured["context"]
    ar = ctx.get("attachment_research")
    observed["compose"] = {
        "attachment_research_in_context": ar is not None,
        "context_equals_direct_result": ar == cand_res,
        "user_content_chars": len(stub.captured["user_content"]),
        "user_content_without_research_chars": len(DecisionEngine._render(
            cand.LAYER, {k: v for k, v in ctx.items() if k != "attachment_research"})),
        "text_field_occurrences_in_user_content": stub.captured["user_content"].count(
            json.dumps(cand_res["text"])[1:-1]),
        "system_prompt_has_no_attribute_sentence": (
            "do not attribute a passage to one file unless that mapping is independently given"
            in " ".join(stub.captured["system_prompt"].split())),
    }
    oc = observed["compose"]
    checks["B1_research_reaches_rendered_prompt_unchanged"] = oc["context_equals_direct_result"] is True
    checks["B2_full_text_field_appears_exactly_twice_in_prompt"] = (
        oc["text_field_occurrences_in_user_content"] == 2)
    checks["B3_system_prompt_sentence_present"] = oc["system_prompt_has_no_attribute_sentence"]

    # C. Small first file: passages split across files and stop duplicating separators.
    notice2, depth2 = build_bundle((5000, 50000, 50000))
    r2 = cand._attachment_research_context(notice2, depth2)
    observed["candidate_small_first_file"] = measure(r2)
    m2 = observed["candidate_small_first_file"]
    checks["C1_small_first_file_passage_split"] = (
        m2["passages"][0]["text_len"] == 5000 and m2["passages"][1]["text_len"] == 14000 - 5002
        and m2["passages"][2]["text_len"] == 0)
    checks["C2_small_first_file_passages_total_13998"] = m2["file_passages_text_total"] == 13998

    # D. Exactly 14000 in file 1 boundary (finding says >= 14000).
    notice3, depth3 = build_bundle((14000, 50000, 50000))
    r3 = cand._attachment_research_context(notice3, depth3)
    observed["candidate_first_file_exactly_14000"] = measure(r3)
    m3 = observed["candidate_first_file_exactly_14000"]
    checks["D1_exactly_14000_files_2_3_empty"] = all(
        p["text_len"] == 0 for p in m3["passages"][1:])

    # E. Doc claims as written in the candidate checkout.
    conv_all = (REPO / "docs/CONVENTIONS.md").read_text(encoding="utf-8")
    # Restrict to the two dossier research paragraphs (2026-09-09 section and the
    # Step7 amendment paragraph naming per-file passages).
    conv = " ".join(conv_all.split())
    i1 = conv.find("## Pursuit dossier attachment research")
    i2 = conv.find("run_searches._enrich_sam_public_attachments retains every listed")
    conv = conv[i1:i1 + 1600] + " " + conv[i2:i2 + 1200]
    observed["doc_paragraphs_chars"] = len(conv)
    observed["doc"] = {
        "conv_says_at_most_14000_captured": "at most 14,000 captured characters" in conv,
        "conv_says_not_falsely_attributed": "not\n  falsely attributed to an individual file" in conv
        or "not falsely attributed to an individual file" in conv.replace("\n  ", " "),
        "conv_mentions_per_file_passages": "exposing per-file passages" in conv,
        "conv_mentions_passage_duplication_or_28k": any(
            s in conv for s in ("28,000", "28000", "twice", "duplicat")),
    }
    checks["E1_doc_claims_14000_but_not_duplication"] = (
        observed["doc"]["conv_says_at_most_14000_captured"]
        and not observed["doc"]["conv_mentions_passage_duplication_or_28k"])

    failed = [k for k, v in checks.items() if not v]
    status = "FAIL" if not failed else "INFO"
    # FAIL here means: the claimed behavior reproduces (doc narrower than code).
    # INFO means some part of the claim did not reproduce; see failed_checks.
    print(json.dumps({"status": status, "finding": "F-13",
                      "meaning": ("FAIL = every claimed quantity reproduced; doc says at most "
                                  "14,000 captured chars + excerpt while the prompt carries "
                                  "text and identical per-file passages"),
                      "checks": checks, "failed_checks": failed,
                      "observed": observed}, indent=1, default=str))


if __name__ == "__main__":
    main()
