"""WNI-4 refutation probe: stale fallback path and _resource_capture_valid.

Scope/classification questions answered by measurement:
  S1  Does the candidate stale path return a planted wrong-notice (B) entry under A
      as stale_inventory when the refresh fails?  (finder claim)
  S2  Does BASE 2d522f0 do the same on the same probe?  (pre_existing proof)
  S3  Does a legacy (no raw_capture) entry take the same path?  (default-config reach)
  S4  Does a fresh-window entry that the candidate itself rejected via
      _resource_capture_valid come back on the stale path when the refresh fails?
  S5  End to end through run_searches._enrich_sam_public_attachments (candidate and
      base): does any wrong-notice text/row reach relevance, and what does the new
      inventory_receipt carry (hash / raw sha / status)?
  S6  Would the finder's recommended fix (require _resource_capture_valid on the
      stale path) change anything the sweep actually uses?  Measured as: the stale
      entry is already excluded before any relevance use, in both base and candidate.
No network: sockets blocked, every _http client rides MockTransport.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
WNI_DIR = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/wrong-notice-identity")
TMP = Path(tempfile.mkdtemp(prefix="wni4-", dir=str(HERE)))

os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*args, **kwargs):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import run_searches as cand_rs  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

A, B, C, D = "a" * 32, "b" * 32, "c" * 32, "d" * 32
TERM = "network visibility"
sam_quota.calls_today = lambda: 0


def load_base(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, WNI_DIR / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# Base copies were written by the finder from `git show 2d522f0:<path>`; verify that
# claim by hashing them against the repo's own git object before trusting them.
import subprocess  # noqa: E402


def git_show_sha(path: str) -> str:
    out = subprocess.run(["git", "-C", str(REPO), "show", f"2d522f0:{path}"],
                         capture_output=True, check=True).stdout
    return hashlib.sha256(out).hexdigest()


base_file_ok = {
    "base_sam_notice_detail.py": hashlib.sha256((WNI_DIR / "base_sam_notice_detail.py").read_bytes()).hexdigest()
    == git_show_sha("tools/api/sam_notice_detail.py"),
    "base_run_searches.py": hashlib.sha256((WNI_DIR / "base_run_searches.py").read_bytes()).hexdigest()
    == git_show_sha("run_searches.py"),
}
base = load_base("base_sam_notice_detail", "base_sam_notice_detail.py")
base_rs = load_base("base_run_searches", "base_run_searches.py")


def install_mock(handler) -> list:
    calls: list = []

    def logged(request):
        calls.append(str(request.url))
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(logged), follow_redirects=True)
    return calls


def serve(payload: bytes, status: int = 200) -> list:
    return install_mock(lambda request: httpx.Response(status, content=payload))


def serve_transport_error() -> list:
    def handler(request):
        raise httpx.ConnectError("refused", request=request)
    return install_mock(handler)


def row(resource_id: str, name: str) -> dict:
    return {"resourceId": resource_id, "name": name, "mimeType": ".txt", "size": 10,
            "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}


def hal_body(notice_id: str, rows: list[dict]) -> bytes:
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return json.dumps({
        "_embedded": {"opportunityAttachmentList": [{"opportunityId": notice_id, "attachments": rows}]},
        "_links": {"self": {"href": href}},
    }).encode()


BODY_A = hal_body(A, [row(C, "A notice SOW.txt")])
BODY_B = hal_body(B, [row(D, "B notice SOW.txt")])


def cache_dir(label: str) -> Path:
    path = TMP / f"cache_{label}"
    path.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / f"text_{label}")
    return path


def plant_b_under_a(module, cdir: Path) -> dict:
    """Legit B cache built by the module itself, then copied to A's file with id=A."""
    serve(BODY_B)
    out = module.fetch_notice_resources(B)
    assert out.get("resources_checked") is True, out
    data = json.loads((cdir / f"{B}.resources.json").read_text())
    data["id"] = A
    (cdir / f"{A}.resources.json").write_text(json.dumps(data))
    return data


def age(cdir: Path, notice_id: str, hours: float) -> None:
    path = cdir / f"{notice_id}.resources.json"
    data = json.loads(path.read_text())
    stamp = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    data["retrieved_at"] = stamp
    if isinstance(data.get("raw_capture"), dict):
        data["raw_capture"]["received_at"] = stamp
    path.write_text(json.dumps(data))


def summarize(out: dict, calls: list) -> dict:
    return {
        "collection_status": out.get("collection_status"),
        "from_cache": out.get("from_cache"), "stale_cache": out.get("stale_cache"),
        "resources_checked": out.get("resources_checked"), "id": out.get("id"),
        "attachment_names": [a.get("name") for a in (out.get("attachments") or [])],
        "attachment_inventory_hash": out.get("attachment_inventory_hash"),
        "raw_sha256": ((out.get("raw_capture") or {}).get("sha256")),
        "refresh_attempt_status": ((out.get("refresh_attempt") or {}).get("collection_status")),
        "network_calls": len(calls), "errors": out.get("errors"),
    }


observed: dict = {"base_file_matches_git_2d522f0": base_file_ok}
b_hash = cand._manifest_hash(cand._attachment_inventory(json.loads(BODY_B), B)[0])
observed["expected_B_inventory_hash"] = b_hash

# S1 / S2: planted B under A, aged 7h, refresh transport error (candidate and base)
for label, module in (("cand", cand), ("base", base)):
    cdir = cache_dir(f"s1_{label}")
    plant_b_under_a(module, cdir)
    age(cdir, A, 7)
    calls = serve_transport_error()
    out = module.fetch_notice_resources(A)
    observed[f"S1_planted_stale_refresh_fails_{label}"] = summarize(out, calls)

# S1b: same plant, refresh answers with explicit B body
for label, module in (("cand", cand), ("base", base)):
    cdir = cache_dir(f"s1b_{label}")
    plant_b_under_a(module, cdir)
    age(cdir, A, 7)
    calls = serve(BODY_B)
    out = module.fetch_notice_resources(A)
    observed[f"S1b_planted_stale_refresh_mismatch_{label}"] = summarize(out, calls)

# S3: legacy entry (base-format, no raw_capture) aged 7h, refresh fails, candidate
cdir = cache_dir("s3_legacy_cand")
serve(BODY_A)
legacy = base.fetch_notice_resources(A)   # base writes a legacy-format cache file
assert "raw_capture" not in json.loads((cdir / f"{A}.resources.json").read_text())
age(cdir, A, 7)
calls = serve_transport_error()
out = cand.fetch_notice_resources(A)
observed["S3_legacy_unbound_stale_refresh_fails_cand"] = summarize(out, calls)
observed["S3_legacy_unbound_stale_refresh_fails_cand"]["capture_valid_says"] = cand._resource_capture_valid(
    json.loads((cdir / f"{A}.resources.json").read_text()))

# S4: FRESH-window entry (age 0) that the candidate rejects via _resource_capture_valid
# (rows edited), refresh fails -> does the rejected entry come back as stale_inventory?
for label, module in (("cand", cand), ("base", base)):
    cdir = cache_dir(f"s4_{label}")
    serve(BODY_A)
    module.fetch_notice_resources(A)
    path = cdir / f"{A}.resources.json"
    data = json.loads(path.read_text())
    data["attachments"][0]["name"] = "Invented.txt"
    path.write_text(json.dumps(data))
    calls = serve_transport_error()
    out = module.fetch_notice_resources(A)
    observed[f"S4_fresh_invalid_refresh_fails_{label}"] = summarize(out, calls)
observed["S4_fresh_invalid_refresh_fails_cand"]["capture_valid_says"] = cand._resource_capture_valid(
    json.loads((TMP / "cache_s4_cand" / f"{A}.resources.json").read_text()))


# S5: end to end through run_searches, planted stale B under A, refresh fails
def taxonomy():
    return CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=A, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})]


download_calls: list = []


def fake_download(resource_id, **kwargs):
    download_calls.append(resource_id)
    return f"Buyer requires {TERM} from notice B.".encode()


sat._download_bytes = fake_download


def run_sweep(rs_module, detail_module, label):
    cdir = cache_dir(f"s5_{label}")
    plant_b_under_a(detail_module, cdir)
    age(cdir, A, 7)
    calls = serve_transport_error()
    rows, stats = rs_module._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy(), None, limit=8)
    receipt = (stats.get("attachment_record_receipts") or {}).get(A, {})
    inv = receipt.get("inventory_receipt") or {}
    return {
        "rows_added": len(rows),
        "receipt_status": receipt.get("status"),
        "receipt_errors": receipt.get("errors"),
        "receipt_has_files_key": "files" in receipt,
        "receipt_has_discovery_evidence": "discovery_evidence" in receipt,
        "inventory_receipt_present": bool(inv),
        "inventory_receipt_id": inv.get("id"),
        "inventory_receipt_status": inv.get("collection_status"),
        "inventory_receipt_hash": inv.get("attachment_inventory_hash"),
        "inventory_receipt_hash_is_B": inv.get("attachment_inventory_hash") == b_hash,
        "inventory_receipt_raw_sha": (inv.get("raw_capture") or {}).get("sha256"),
        "inventory_receipt_raw_sha_is_B_body": (inv.get("raw_capture") or {}).get("sha256")
        == hashlib.sha256(BODY_B).hexdigest(),
        "inventory_receipt_refresh_status": (inv.get("refresh_attempt") or {}).get("collection_status"),
        "file_downloads_attempted": len(download_calls),
        "network_calls": len(calls),
        "stats_errors_for_A": [e for e in (stats.get("errors") or []) if A in e][:4],
    }


download_calls.clear()
observed["S5_e2e_cand"] = run_sweep(cand_rs, cand, "cand")
download_calls.clear()
observed["S5_e2e_base"] = run_sweep(base_rs, base, "base")

# S6: consumers of inventory_receipt outside tests (static)
consumers = subprocess.run(
    ["grep", "-rln", "inventory_receipt", "--include=*.py", "--exclude-dir=.venv",
     "--exclude-dir=tests", str(REPO)], capture_output=True, text=True).stdout.split()
observed["S6_inventory_receipt_consumers_outside_tests"] = sorted(
    str(Path(p).relative_to(REPO)) for p in consumers)

s1c = observed["S1_planted_stale_refresh_fails_cand"]
s1b = observed["S1_planted_stale_refresh_fails_base"]
s5c = observed["S5_e2e_cand"]
s5b = observed["S5_e2e_base"]
checks = {
    "finder_claim_cand_stale_returns_B_rows_under_A": (
        s1c["collection_status"] == "stale_inventory" and s1c["id"] == A
        and s1c["attachment_names"] == ["B notice SOW.txt"] and s1c["attachment_inventory_hash"] == b_hash),
    "base_same_probe_returns_B_rows_under_A_stale": (
        s1b["stale_cache"] is True and s1b["id"] == A and s1b["attachment_names"] == ["B notice SOW.txt"]),
    "base_accepts_explicit_B_body_as_fresh_A_inventory": (
        observed["S1b_planted_stale_refresh_mismatch_base"]["from_cache"] is False
        and observed["S1b_planted_stale_refresh_mismatch_base"]["attachment_names"] == ["B notice SOW.txt"]),
    "cand_refuses_explicit_B_body_falls_to_stale": (
        observed["S1b_planted_stale_refresh_mismatch_cand"]["refresh_attempt_status"] == "identity_mismatch"
        and observed["S1b_planted_stale_refresh_mismatch_cand"]["collection_status"] == "stale_inventory"),
    "legacy_unbound_entry_returns_as_stale_inventory": (
        observed["S3_legacy_unbound_stale_refresh_fails_cand"]["collection_status"] == "stale_inventory"
        and observed["S3_legacy_unbound_stale_refresh_fails_cand"]["capture_valid_says"] is False),
    "cand_fresh_rejected_entry_returns_as_stale_inventory": (
        observed["S4_fresh_invalid_refresh_fails_cand"]["collection_status"] == "stale_inventory"
        and observed["S4_fresh_invalid_refresh_fails_cand"]["network_calls"] == 1),
    "base_fresh_edited_entry_served_from_cache_no_network": (
        observed["S4_fresh_invalid_refresh_fails_base"]["from_cache"] is True
        and observed["S4_fresh_invalid_refresh_fails_base"]["network_calls"] == 0),
    "e2e_cand_no_row_no_download_no_research": (
        s5c["rows_added"] == 0 and s5c["file_downloads_attempted"] == 0
        and s5c["receipt_status"] == "STALE_INVENTORY" and not s5c["receipt_has_discovery_evidence"]),
    "e2e_cand_inventory_receipt_carries_B_hash_and_B_raw_labelled_stale": (
        s5c["inventory_receipt_hash_is_B"] and s5c["inventory_receipt_raw_sha_is_B_body"]
        and s5c["inventory_receipt_status"] == "stale_inventory"
        and s5c["inventory_receipt_refresh_status"] == "lookup_failed"),
    "e2e_base_no_row_no_download_no_receipt_detail": (
        s5b["rows_added"] == 0 and s5b["file_downloads_attempted"] == 0
        and s5b["receipt_status"] == "STALE_INVENTORY" and not s5b["inventory_receipt_present"]),
}
status = "PASS"
if checks["finder_claim_cand_stale_returns_B_rows_under_A"]:
    status = "FAIL"   # the stale path does return unrebound wrong-notice rows (finder claim holds)
if not checks["e2e_cand_no_row_no_download_no_research"]:
    status = "FAIL"
print(json.dumps({
    "probe": "wni4_stale_fallback_scope",
    "status": status,
    "checks": checks,
    "observed": observed,
    "tmp_dir": str(TMP),
    "note": ("FAIL here means the finder's stale-path observation reproduces. Classification "
             "rests on checks base_same_probe_* (pre_existing), e2e_cand_no_row_* (no research "
             "or relevance reach) and e2e_cand_inventory_receipt_* (receipt is labelled "
             "stale_inventory with lookup_failed refresh; raw bytes retained name B)."),
}, indent=2, sort_keys=True, default=str))
