"""Independent reproduction of WNI-4: does the stale fallback in
fetch_notice_resources return a planted wrong-notice cache entry as
stale_inventory under the requested id, bypassing _resource_capture_valid?

Written from the finding text only. Compares candidate vs base (2d522f0).
No network (socket.connect blocked, httpx MockTransport). No LLM calls.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import types
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CACHE = HERE / "tmp_cache"
os.environ["LILA_NOTICE_CACHE_DIR"] = str(CACHE)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(HERE / "tmp_text_cache")
sys.path.insert(0, os.getcwd())

import httpx  # noqa: E402


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as snd  # noqa: E402

A = "a" * 32
B = "b" * 32
MODE = {"value": "fail503"}
CALLS: list[str] = []


def body_for(notice_id: str, name: str, rid: str) -> bytes:
    return json.dumps({
        "_embedded": {"opportunityAttachmentList": [{
            "opportunityId": notice_id,
            "attachments": [{
                "resourceId": rid, "name": name,
                "mimeType": "application/pdf", "accessLevel": "public",
                "size": 1234,
            }],
        }]},
        "_links": {"self": {"href": f"/api/prod/opportunities/v2/{notice_id}/resources"}},
    }).encode()


def handler(request: httpx.Request) -> httpx.Response:
    CALLS.append(str(request.url))
    mode = MODE["value"]
    if mode == "fail503":
        return httpx.Response(503, content=b"throttled")
    if mode == "B_body":
        return httpx.Response(200, content=body_for(B, "B notice SOW.pdf", "res-b-1"),
                              headers={"content-type": "application/hal+json"})
    if mode == "A_body":
        return httpx.Response(200, content=body_for(A, "A real file.pdf", "res-a-1"),
                              headers={"content-type": "application/hal+json"})
    raise AssertionError(mode)


_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def reset_cache() -> None:
    shutil.rmtree(CACHE, ignore_errors=True)
    CACHE.mkdir(parents=True)


def load_base():
    spec = importlib.util.spec_from_file_location(
        "base_snd", HERE / "base_sam_notice_detail.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def build_legit_B() -> dict:
    MODE["value"] = "B_body"
    res = snd.fetch_notice_resources(B)
    assert res["collection_status"] == "inventory_captured", res
    return json.loads((CACHE / f"{B}.resources.json").read_text())


def plant_A_from_B(b_cache: dict, age: timedelta, keep_hash=True) -> dict:
    planted = json.loads(json.dumps(b_cache))
    planted["id"] = A
    stamp = (datetime.now(timezone.utc) - age).isoformat()
    planted["retrieved_at"] = stamp
    if isinstance(planted.get("raw_capture"), dict):
        planted["raw_capture"]["received_at"] = stamp
    (CACHE / f"{A}.resources.json").write_text(json.dumps(planted))
    return planted


def summarize(res: dict) -> dict:
    rc = res.get("raw_capture") or {}
    ra = res.get("refresh_attempt") or {}
    return {
        "id": res.get("id"),
        "collection_status": res.get("collection_status"),
        "from_cache": res.get("from_cache"),
        "stale_cache": res.get("stale_cache"),
        "resources_checked": res.get("resources_checked"),
        "attachment_names": [a.get("name") for a in (res.get("attachments") or [])],
        "attachment_inventory_hash": res.get("attachment_inventory_hash"),
        "raw_capture_sha256": rc.get("sha256"),
        "raw_capture_source_url": rc.get("source_url"),
        "refresh_attempt_status": ra.get("collection_status"),
        "errors": [str(e)[:120] for e in (res.get("errors") or [])],
    }


observed: dict = {}
checks: dict[str, bool] = {}

# ---- candidate ---------------------------------------------------------
reset_cache()
b_cache = build_legit_B()
b_hash = b_cache["attachment_inventory_hash"]
b_raw_sha = b_cache["raw_capture"]["sha256"]
observed["legit_B"] = {"hash": b_hash, "raw_sha": b_raw_sha,
                       "names": [a["name"] for a in b_cache["attachments"]]}

# c: planted, stale (7h > 6h TTL, < 7d), refresh fails
planted = plant_A_from_B(b_cache, timedelta(hours=7))
observed["capture_valid_on_plant"] = snd._resource_capture_valid(planted)
checks["capture_valid_rejects_plant"] = observed["capture_valid_on_plant"] is False
MODE["value"] = "fail503"
n0 = len(CALLS)
res_c = snd.fetch_notice_resources(A)
observed["c_planted_stale_refresh_fails"] = summarize(res_c)
observed["c_refresh_calls"] = len(CALLS) - n0
checks["c_returns_stale_inventory_with_B_rows"] = (
    res_c.get("collection_status") == "stale_inventory"
    and res_c.get("id") == A
    and [a.get("name") for a in res_c.get("attachments") or []] == ["B notice SOW.pdf"]
    and res_c.get("attachment_inventory_hash") == b_hash
    and (res_c.get("raw_capture") or {}).get("sha256") == b_raw_sha)

# d: planted, stale, refresh returns B's body for A's URL (identity_mismatch)
plant_A_from_B(b_cache, timedelta(hours=7))
MODE["value"] = "B_body"
res_d = snd.fetch_notice_resources(A)
observed["d_planted_stale_refresh_mismatch"] = summarize(res_d)
checks["d_returns_stale_inventory_after_identity_mismatch"] = (
    res_d.get("collection_status") == "stale_inventory"
    and (res_d.get("refresh_attempt") or {}).get("collection_status") == "identity_mismatch"
    and [a.get("name") for a in res_d.get("attachments") or []] == ["B notice SOW.pdf"])

# a: planted, FRESH (1 min), refresh succeeds with A's real body: should be replaced
plant_A_from_B(b_cache, timedelta(minutes=1))
MODE["value"] = "A_body"
res_a = snd.fetch_notice_resources(A)
observed["a_planted_fresh_refresh_ok"] = summarize(res_a)
checks["a_fresh_plant_dropped_and_refetched"] = (
    res_a.get("collection_status") == "inventory_captured"
    and res_a.get("from_cache") is False
    and [a.get("name") for a in res_a.get("attachments") or []] == ["A real file.pdf"])

# e: planted, FRESH (1 min), refresh FAILS: does the stale path still hand back B?
plant_A_from_B(b_cache, timedelta(minutes=1))
MODE["value"] = "fail503"
res_e = snd.fetch_notice_resources(A)
observed["e_planted_fresh_refresh_fails"] = summarize(res_e)
checks["e_fresh_invalid_plant_also_returned_as_stale"] = (
    res_e.get("collection_status") == "stale_inventory"
    and [a.get("name") for a in res_e.get("attachments") or []] == ["B notice SOW.pdf"])

# f: legit A cache with rows edited, stale, refresh fails
MODE["value"] = "A_body"
(CACHE / f"{A}.resources.json").unlink(missing_ok=True)
snd.fetch_notice_resources(A)
a_cache = json.loads((CACHE / f"{A}.resources.json").read_text())
a_cache["attachments"][0]["name"] = "Invented.pdf"
stamp = (datetime.now(timezone.utc) - timedelta(hours=7)).isoformat()
a_cache["retrieved_at"] = stamp
a_cache["raw_capture"]["received_at"] = stamp
(CACHE / f"{A}.resources.json").write_text(json.dumps(a_cache))
observed["f_capture_valid_on_edited"] = snd._resource_capture_valid(a_cache)
MODE["value"] = "fail503"
res_f = snd.fetch_notice_resources(A)
observed["f_legit_edited_rows_stale_refresh_fails"] = summarize(res_f)
checks["f_edited_rows_returned_as_stale"] = (
    res_f.get("collection_status") == "stale_inventory"
    and observed["f_capture_valid_on_edited"] is False
    and [a.get("name") for a in res_f.get("attachments") or []] == ["Invented.pdf"])

# g: stale over 7d: must be lookup_failed
plant_A_from_B(b_cache, timedelta(days=8))
MODE["value"] = "fail503"
res_g = snd.fetch_notice_resources(A)
observed["g_planted_over_7d"] = summarize(res_g)
checks["g_over_7d_not_returned"] = res_g.get("collection_status") == "lookup_failed"

# ---- run_searches consumer -------------------------------------------
plant_A_from_B(b_cache, timedelta(hours=7))
MODE["value"] = "fail503"
import run_searches  # noqa: E402
from tools.api import sam_quota  # noqa: E402
sam_quota.calls_today = lambda: 0
cand = types.SimpleNamespace(source_id=A)
source = types.SimpleNamespace(
    attachment_candidates=lambda q, t, e, limit: [cand],
    last_attachment_census={})
rows, meta = run_searches._enrich_sam_public_attachments(
    [{"source_id": A}], source, None, None, None, limit=5)
receipt = (meta.get("attachment_record_receipts") or {}).get(A) or {}
inv = receipt.get("inventory_receipt") or {}
observed["run_searches_receipt"] = {
    "status": receipt.get("status"),
    "inventory_receipt_id": inv.get("id"),
    "inventory_receipt_status": inv.get("collection_status"),
    "inventory_receipt_hash": inv.get("attachment_inventory_hash"),
    "inventory_receipt_raw_sha": (inv.get("raw_capture") or {}).get("sha256"),
    "inventory_receipt_raw_source_url": (inv.get("raw_capture") or {}).get("source_url"),
    "refresh_attempt_status": (inv.get("refresh_attempt") or {}).get("collection_status"),
    "has_files_or_discovery_evidence": bool(receipt.get("files") or receipt.get("discovery_evidence")),
    "rows_unchanged": rows == [{"source_id": A}],
}
checks["run_searches_excludes_from_relevance"] = (
    receipt.get("status") == "STALE_INVENTORY"
    and not receipt.get("files") and not receipt.get("discovery_evidence")
    and rows == [{"source_id": A}])
checks["run_searches_receipt_carries_B_hash_and_raw_under_A"] = (
    inv.get("id") == A and inv.get("attachment_inventory_hash") == b_hash
    and (inv.get("raw_capture") or {}).get("sha256") == b_raw_sha)
checks["receipt_source_url_reveals_B"] = (
    B in str((inv.get("raw_capture") or {}).get("source_url")))

# ---- base 2d522f0 comparison --------------------------------------------
base = load_base()
reset_cache()
# base has no raw_capture; build a base-shaped B cache via base code itself
MODE["value"] = "B_body"
base_b = base.fetch_notice_resources(B)
base_b_cache = json.loads((CACHE / f"{B}.resources.json").read_text())
planted_base = json.loads(json.dumps(base_b_cache))
planted_base["id"] = A
planted_base["retrieved_at"] = (datetime.now(timezone.utc) - timedelta(hours=7)).isoformat()
(CACHE / f"{A}.resources.json").write_text(json.dumps(planted_base))
MODE["value"] = "fail503"
base_stale = base.fetch_notice_resources(A)
observed["base_planted_stale_refresh_fails"] = {
    "id": base_stale.get("id"), "stale_cache": base_stale.get("stale_cache"),
    "names": [a.get("name") for a in base_stale.get("attachments") or []],
    "hash": base_stale.get("attachment_inventory_hash"),
    "has_collection_status": "collection_status" in base_stale,
}
checks["base_also_returns_planted_stale"] = (
    base_stale.get("stale_cache") is True
    and [a.get("name") for a in base_stale.get("attachments") or []] == ["B notice SOW.pdf"])
# base fresh plant: returned directly without any validation (worse than candidate)
planted_base["retrieved_at"] = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
(CACHE / f"{A}.resources.json").write_text(json.dumps(planted_base))
MODE["value"] = "A_body"
base_fresh = base.fetch_notice_resources(A)
observed["base_planted_fresh"] = {
    "from_cache": base_fresh.get("from_cache"),
    "names": [a.get("name") for a in base_fresh.get("attachments") or []]}
checks["base_fresh_plant_accepted_unvalidated"] = (
    base_fresh.get("from_cache") is True
    and [a.get("name") for a in base_fresh.get("attachments") or []] == ["B notice SOW.pdf"])

shutil.rmtree(CACHE, ignore_errors=True)
shutil.rmtree(HERE / "tmp_text_cache", ignore_errors=True)

defect_reproduced = all(checks[k] for k in (
    "capture_valid_rejects_plant", "c_returns_stale_inventory_with_B_rows",
    "d_returns_stale_inventory_after_identity_mismatch", "f_edited_rows_returned_as_stale",
    "run_searches_excludes_from_relevance",
    "run_searches_receipt_carries_B_hash_and_raw_under_A"))
pre_existing = checks["base_also_returns_planted_stale"]
print(json.dumps({
    "status": "FAIL" if defect_reproduced else "PASS",
    "finding": "WNI-4",
    "defect_reproduced": defect_reproduced,
    "pre_existing_at_base": pre_existing,
    "network_calls_all_mocked": all("sam.gov" in u for u in CALLS),
    "checks": checks,
    "observed": observed,
}, indent=2, sort_keys=True))
