"""Independent reproduction probe for WNI-5.

Claim under test: on the candidate, fetch_notice_depth (fresh and cached
reconciliation) refuses a resources body that names another notice, but records
the refusal only as "unrecognized resources schema (non-fatal)"; the distinct
identity_mismatch state appears only in fetch_notice_resources. On the base,
the depth paths accepted B's rows into A's depth.

Network is blocked at the socket layer and the HTTP client is a MockTransport.
No LLM calls. Writes only under the probe directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = "/Users/wtjohnson/lila-step7-052"
if REPO not in sys.path:
    sys.path.insert(0, REPO)
TMP_ROOT = PROBE_DIR / "_tmp"
if TMP_ROOT.exists():
    shutil.rmtree(TMP_ROOT)
TMP_ROOT.mkdir()
os.environ["LILA_SAM_LEDGER"] = str(TMP_ROOT / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402

import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as cand  # noqa: E402

NOTICE_A = "a" * 32
NOTICE_B = "b" * 32
RESOURCE_ID = "c" * 32


def body_naming(notice_id: str) -> dict:
    return {
        "_embedded": {
            "opportunityAttachmentList": [
                {
                    "opportunityId": notice_id,
                    "attachments": [
                        {"name": "sow.pdf", "resourceId": RESOURCE_ID,
                         "mimeType": "application/pdf", "size": 10},
                    ],
                }
            ]
        },
        "_links": {"self": {"href": f"/api/prod/opps/v3/opportunities/{notice_id}/resources"}},
    }


def install_transport(resources_body: dict) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if url.startswith(cand.DESC_URL):
            return httpx.Response(200, json={"description": "<p>Notice A description body</p>"})
        if url.endswith(f"/opportunities/{NOTICE_A}/resources"):
            return httpx.Response(200, json=resources_body)
        return httpx.Response(404, json={"error": "unexpected url " + url})

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def load_base_module():
    path = PROBE_DIR / "base_sam_notice_detail.py"
    spec = importlib.util.spec_from_file_location("base_sam_notice_detail", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["base_sam_notice_detail"] = mod
    spec.loader.exec_module(mod)
    return mod


def summarize(result: dict) -> dict:
    atts = result.get("attachments")
    return {
        "resources_checked": result.get("resources_checked"),
        "resources_schema": result.get("resources_schema"),
        "collection_status": result.get("collection_status"),
        "attachment_names": [a.get("name") for a in atts] if isinstance(atts, list) else atts,
        "errors": list(result.get("errors") or []),
    }


def seed_depth_cache(cache_dir: Path) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / f"{NOTICE_A}.json").write_text(json.dumps({
        "id": NOTICE_A,
        "description": "cached description",
        "attachments": None,
        "from_cache": False,
        "retrieved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "description_checked": True,
        "resources_checked": False,
        "resources_schema": None,
        "attachment_inventory_count": None,
        "attachment_inventory_hash": None,
        "errors": ["resources fetch failed (non-fatal): earlier"],
    }))


def run_scenarios(mod, label: str) -> dict:
    out = {}
    install_transport(body_naming(NOTICE_B))

    # 1. resources path (fetch_notice_resources) sees a body naming B.
    d1 = TMP_ROOT / f"{label}_res"
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d1)
    out["1_resources_gets_B_body"] = summarize(mod.fetch_notice_resources(NOTICE_A))

    # 2. cached depth reconciliation: description cached, resources not yet recognized.
    d2 = TMP_ROOT / f"{label}_cached"
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d2)
    seed_depth_cache(d2)
    out["2_cached_reconcile_gets_B_body"] = summarize(mod.fetch_notice_depth(NOTICE_A, api_key="probe-key"))

    # 3. fresh depth: description + resources both fetched now.
    d3 = TMP_ROOT / f"{label}_fresh"
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d3)
    out["3_fresh_depth_gets_B_body"] = summarize(mod.fetch_notice_depth(NOTICE_A, api_key="probe-key"))

    # 4. control: body naming A must be accepted by both depth paths.
    install_transport(body_naming(NOTICE_A))
    d4 = TMP_ROOT / f"{label}_control"
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d4)
    out["4_control_fresh_depth_gets_A_body"] = summarize(mod.fetch_notice_depth(NOTICE_A, api_key="probe-key"))
    return out


def main() -> int:
    observed = {"candidate": run_scenarios(cand, "cand")}
    base = load_base_module()
    observed["base"] = run_scenarios(base, "base")

    c = observed["candidate"]
    b = observed["base"]

    def refused_as_unrecognized(s: dict) -> bool:
        return (s["resources_checked"] is False and not s["attachment_names"]
                and any("unrecognized resources schema" in e for e in s["errors"])
                and not any("identity" in e.lower() for e in s["errors"])
                and s["collection_status"] is None)

    checks = {
        "cand_resources_path_reports_identity_mismatch":
            c["1_resources_gets_B_body"]["collection_status"] == "identity_mismatch",
        "cand_cached_reconcile_refuses_B_rows":
            c["2_cached_reconcile_gets_B_body"]["resources_checked"] is False
            and not c["2_cached_reconcile_gets_B_body"]["attachment_names"],
        "cand_fresh_depth_refuses_B_rows":
            c["3_fresh_depth_gets_B_body"]["resources_checked"] is False
            and not c["3_fresh_depth_gets_B_body"]["attachment_names"],
        "cand_cached_reconcile_labels_only_unrecognized":
            refused_as_unrecognized(c["2_cached_reconcile_gets_B_body"]),
        "cand_fresh_depth_labels_only_unrecognized":
            refused_as_unrecognized(c["3_fresh_depth_gets_B_body"]),
        "cand_control_accepts_matching_body":
            c["4_control_fresh_depth_gets_A_body"]["resources_checked"] is True
            and c["4_control_fresh_depth_gets_A_body"]["attachment_names"] == ["sow.pdf"],
        "base_cached_reconcile_accepted_B_rows":
            b["2_cached_reconcile_gets_B_body"]["resources_checked"] is True
            and b["2_cached_reconcile_gets_B_body"]["attachment_names"] == ["sow.pdf"],
        "base_fresh_depth_accepted_B_rows":
            b["3_fresh_depth_gets_B_body"]["resources_checked"] is True
            and b["3_fresh_depth_gets_B_body"]["attachment_names"] == ["sow.pdf"],
        "base_resources_path_has_no_identity_state":
            b["1_resources_gets_B_body"]["collection_status"] is None,
    }
    finding_reproduced = all(checks.values())
    status = "FAIL" if finding_reproduced else "INFO"
    print(json.dumps({
        "probe": "WNI-5 reproduction (depth identity conflict labelling)",
        "status": status,
        "finding_reproduced": finding_reproduced,
        "checks": checks,
        "observed": observed,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
