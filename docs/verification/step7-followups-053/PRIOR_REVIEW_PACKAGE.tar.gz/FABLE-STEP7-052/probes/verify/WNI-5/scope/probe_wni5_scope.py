"""WNI-5 scope/classification probe.

Question: does any producer document claim that fetch_notice_depth records a
distinct identity_mismatch state, such that recording the depth-path identity
refusal as 'unrecognized resources schema (non-fatal)' is a doc overstatement?

Measures, on candidate and base (2d522f0):
  1. fresh depth path, resources body names notice B while A is requested
  2. cached-branch reconciliation, same wrong body
  3. positive control (A body)
  4. whether fetch_notice_depth output carries a collection_status key at all
  5. exact scoping of every collection_status / identity_mismatch sentence in
     docs/CONVENTIONS.md, docs/CONTRACT_SURFACES.md, docs/verification/step7-052
  6. whether any non-test consumer branches on the error label string
No network, no LLM, writes only under this directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni5-", dir=str(HERE)))

os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)

sam_quota.note_call = lambda purpose: 0
cand.sam_quota.note_call = lambda purpose: 0
base.sam_quota.note_call = lambda purpose: 0

A, B, C, D = "a" * 32, "b" * 32, "c" * 32, "d" * 32
LABEL = "unrecognized resources schema (non-fatal)"


def row(resource_id, name):
    return {"resourceId": resource_id, "name": name, "mimeType": ".pdf", "size": 10,
            "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}


def hal_body(notice_id, rows):
    href = (f"https://example.invalid/opps/v3/opportunities/{notice_id}/resources")
    return {"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": notice_id, "attachments": rows}]},
        "_links": {"self": {"href": href}}}


BODY_B = hal_body(B, [row(C, "B notice SOW.pdf")])
BODY_A = hal_body(A, [row(D, "A notice SOW.pdf")])


def install(resources_body):
    payload = json.dumps(resources_body).encode()
    calls = []

    def handler(request):
        url = str(request.url)
        calls.append(url)
        if "noticedesc" in url:
            return httpx.Response(200, json={"description": "<p>Probe requirement.</p>"})
        if url.endswith("/resources"):
            return httpx.Response(200, content=payload)
        return httpx.Response(404)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    return calls


def cache_dir(label):
    path = TMP / f"cache_{label}"
    path.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path)
    return path


def view(d, calls):
    return {"resources_checked": d.get("resources_checked"),
            "resources_schema": d.get("resources_schema"),
            "attachment_names": [a.get("name") for a in (d.get("attachments") or [])],
            "errors": d.get("errors"),
            "has_collection_status_key": "collection_status" in d,
            "keys": sorted(d.keys()),
            "network_calls": len(calls)}


now = datetime.now(timezone.utc).isoformat(timespec="seconds")
observed: dict = {}

for label, mod in (("cand", cand), ("base", base)):
    cache_dir(f"fresh_{label}")
    calls = install(BODY_B)
    observed[f"fresh_B_body_{label}"] = view(mod.fetch_notice_depth(A, api_key="probe-key"), calls)

    cdir = cache_dir(f"reconcile_{label}")
    (cdir / f"{A}.json").write_text(json.dumps({
        "id": A, "description": "A description", "attachments": None, "retrieved_at": now,
        "description_checked": True, "resources_checked": False, "resources_schema": None,
        "errors": []}))
    calls = install(BODY_B)
    observed[f"reconcile_B_body_{label}"] = view(mod.fetch_notice_depth(A), calls)

cache_dir("positive_cand")
calls = install(BODY_A)
observed["positive_A_body_cand"] = view(cand.fetch_notice_depth(A, api_key="probe-key"), calls)

# fetch_notice_resources on the candidate, for contrast: this is where the
# distinct identity_mismatch state lives, and where the docs scope it.
cache_dir("resources_cand")
calls = install(BODY_B)
res = cand.fetch_notice_resources(A)
observed["fetch_notice_resources_B_body_cand"] = {
    "collection_status": res.get("collection_status"), "resources_checked": res.get("resources_checked"),
    "errors": res.get("errors")}

# Doc scoping
conv = (REPO / "docs/CONVENTIONS.md").read_text()
cs = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
step7_conv = conv[conv.index("## Step7 decision-changing collection (052)"):]
step7_cs = cs[cs.index("## Step7 discovery collection and file locator extension (052)"):]
depth_sentence = ("Explicit response notice-ID conflicts refuse the inventory, including depth\n"
                  "reconciliation.")
status_sentence_prefix = "`collection_status` distinguishes captured discovery text"
paras = step7_conv.split("\n\n")
status_para = next((p for p in paras if status_sentence_prefix in p), "")
cs_scope_sentence = ("`sam_notice_detail.fetch_notice_resources` adds internal\n"
                     "original-response custody and explicit collection state.")

ver_dir = REPO / "docs/verification/step7-052"
ver_hits = {}
for path in sorted(ver_dir.iterdir()):
    if path.suffix in (".md", ".json", ".py"):
        text = path.read_text(errors="replace")
        if "fetch_notice_depth" in text or "notice depth" in text.lower():
            ver_hits[path.name] = [ln.strip() for ln in text.splitlines()
                                   if "fetch_notice_depth" in ln or "notice depth" in ln.lower()]
docs_mentioning_depth_states = {
    "CONVENTIONS_step7_mentions_fetch_notice_depth": "fetch_notice_depth" in step7_conv,
    "CONTRACT_SURFACES_step7_mentions_fetch_notice_depth": "fetch_notice_depth" in step7_cs,
    "verification_docs_mentioning_fetch_notice_depth": ver_hits,
}

# Consumer check: who branches on the label string outside the module and tests
consumers = []
for path in REPO.rglob("*.py"):
    rel = path.relative_to(REPO).as_posix()
    if rel.startswith(".venv/") or rel.startswith("tests/") or rel == "tools/api/sam_notice_detail.py":
        continue
    text = path.read_text(errors="replace")
    if "unrecognized resources schema" in text or "identity_mismatch" in text:
        consumers.append(rel)

# Base label sites: the same string exists at base in fetch_notice_depth
base_src = (HERE / "base_sam_notice_detail.py").read_text()
cand_src = (REPO / "tools/api/sam_notice_detail.py").read_text()


def depth_label_sites(src):
    start = src.index("def fetch_notice_depth")
    return src[start:].count(LABEL)


findings = {
    "cand_fresh_refuses_B_body": observed["fresh_B_body_cand"]["resources_checked"] is False
    and not observed["fresh_B_body_cand"]["attachment_names"],
    "cand_reconcile_refuses_B_body": observed["reconcile_B_body_cand"]["resources_checked"] is False
    and not observed["reconcile_B_body_cand"]["attachment_names"],
    "base_fresh_accepts_B_body": observed["fresh_B_body_base"]["resources_checked"] is True,
    "base_reconcile_accepts_B_body": observed["reconcile_B_body_base"]["resources_checked"] is True,
    "positive_control_ok": observed["positive_A_body_cand"]["resources_checked"] is True,
    "cand_depth_label_is_unrecognized": LABEL in (observed["fresh_B_body_cand"]["errors"] or [])
    and LABEL in (observed["reconcile_B_body_cand"]["errors"] or []),
    "depth_output_has_collection_status_key_cand": observed["fresh_B_body_cand"]["has_collection_status_key"],
    "depth_output_has_collection_status_key_base": observed["fresh_B_body_base"]["has_collection_status_key"],
    "fetch_notice_resources_distinct_state": observed["fetch_notice_resources_B_body_cand"]["collection_status"],
    "conventions_depth_refusal_sentence_present": depth_sentence in step7_conv,
    "conventions_collection_status_sentence_in_file_extraction_paragraph":
        status_para.startswith("File extraction retains"),
    "conventions_collection_status_paragraph": status_para,
    "contract_surfaces_scopes_collection_state_to_fetch_notice_resources": cs_scope_sentence in step7_cs,
    "docs_mentioning_depth_states": docs_mentioning_depth_states,
    "non_test_consumers_branching_on_label_or_identity_mismatch": consumers,
    "depth_label_sites_base": depth_label_sites(base_src),
    "depth_label_sites_cand": depth_label_sites(cand_src),
    "depth_delta_lines_touching_labels": [
        ln for ln in os.popen(
            f"git -C {REPO} diff 2d522f0..6b51f00 -- tools/api/sam_notice_detail.py").read().splitlines()
        if ln.startswith(("+", "-")) and ("_attachment_inventory(res" in ln or LABEL in ln)],
}

claim_true = findings["cand_fresh_refuses_B_body"] and findings["cand_reconcile_refuses_B_body"] \
    and findings["positive_control_ok"] and findings["conventions_depth_refusal_sentence_present"]
no_depth_state_claim = (
    not findings["depth_output_has_collection_status_key_cand"]
    and not findings["depth_output_has_collection_status_key_base"]
    and findings["conventions_collection_status_sentence_in_file_extraction_paragraph"]
    and findings["contract_surfaces_scopes_collection_state_to_fetch_notice_resources"]
    and not docs_mentioning_depth_states["CONVENTIONS_step7_mentions_fetch_notice_depth"]
    and not docs_mentioning_depth_states["CONTRACT_SURFACES_step7_mentions_fetch_notice_depth"]
    and not docs_mentioning_depth_states["verification_docs_mentioning_fetch_notice_depth"])

status = "PASS" if (claim_true and no_depth_state_claim) else "FAIL"
print(json.dumps({
    "probe": "wni5_scope", "status": status,
    "verdict_basis": {
        "producer_depth_claim_holds": claim_true,
        "no_document_claims_distinct_identity_state_on_depth_path": no_depth_state_claim,
        "label_string_predates_step7": findings["depth_label_sites_base"] == findings["depth_label_sites_cand"] == 2,
    },
    "findings": findings, "observed": observed, "tmp_dir": str(TMP),
}, indent=2, sort_keys=True, default=str))
