"""WNI-7 refutation probe: is the run_searches identity guard's None branch dead
with the real adapter, and does the candidate close a hole that base left open?

Part 1  Candidate fetch_notice_resources: every return path, assert id == requested.
Part 2  Base fetch_notice_resources: poisoned cache (id=B, id missing) is returned
        as-is; base run_searches has no guard so wrong-notice text is enriched.
        Candidate adapter + candidate run_searches over the same poisoned cache.
Part 3  Candidate run_searches with monkeypatched doubles (id=B, id missing, id=A),
        reproducing the finder's a/b/c cases.
Part 4  Static census: pre-existing test doubles that omit id (unchanged since base).
No network (sockets refused; MockTransport). No LLM. Writes only under this dir.
"""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCOPE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni7-", dir=str(SCOPE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import tools.api.sam_notice_detail as detail  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import run_searches as cand_rs  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

A, B, D = "a" * 32, "b" * 32, "d" * 32
TERM = "network visibility"
sam_quota.calls_today = lambda: 0
REAL_FETCH = detail.fetch_notice_resources


def load(name: str):
    spec = importlib.util.spec_from_file_location(name, SCOPE / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


base_detail = load("base_sam_notice_detail")
base_rs = load("base_run_searches")


def mock(handler):
    calls = []

    def logged(request):
        calls.append(str(request.url))
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(logged), follow_redirects=True)
    return calls


def cache_dir(label: str) -> Path:
    p = TMP / f"cache_{label}"
    p.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p)
    return p


def att_row(resource_id=D, name="Wrong notice SOW.txt"):
    return {"resourceId": resource_id, "name": name, "mimeType": ".txt", "size": 10,
            "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}


def hal_body(notice_id, rows):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_embedded": {"opportunityAttachmentList": [{"opportunityId": notice_id, "attachments": rows}]},
            "_links": {"self": {"href": href}}}


def links_only(notice_id):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_links": {"self": {"href": href}}}


ok_body = json.dumps(hal_body(A, [att_row()])).encode()
b_body = json.dumps(hal_body(B, [att_row()])).encode()
links_body = json.dumps(links_only(A)).encode()


def serve(content, status=200):
    return mock(lambda request: httpx.Response(status, content=content))


def summarize(res: dict):
    return {"id": res.get("id"), "collection_status": res.get("collection_status"),
            "from_cache": res.get("from_cache"), "stale_cache": res.get("stale_cache"),
            "resources_checked": res.get("resources_checked"),
            "n_attachments": len(res.get("attachments") or []) if res.get("attachments") is not None else None,
            "has_id_key": "id" in res}


# ---------------- Part 1: candidate adapter id invariant across every return path
part1 = {}
cache_dir("p1_success"); serve(ok_body)
part1["s1_fresh_inventory_captured"] = summarize(REAL_FETCH(A))
serve(b"", 500)
part1["s5_cache_hit_no_network"] = summarize(REAL_FETCH(A))

cache_dir("p1_links"); serve(links_body)
part1["s2_links_only_unrecognized"] = summarize(REAL_FETCH(A))

cache_dir("p1_bbody"); serve(b_body)
part1["s3_explicit_B_body_identity_mismatch"] = summarize(REAL_FETCH(A))

cache_dir("p1_500"); serve(b"", 500)
part1["s4_http500_lookup_failed"] = summarize(REAL_FETCH(A))

# s6/s7: poisoned cache files (id=B, id missing) for notice A, network down
cd = cache_dir("p1_poison_seed"); serve(ok_body); REAL_FETCH(A)
good_cache = json.loads((cd / f"{A}.resources.json").read_text())
good_cache.pop("from_cache", None); good_cache.pop("stale_cache", None)


def poison(label, mutate, body=None, status=500):
    p = cache_dir(label)
    doc = json.loads(json.dumps(good_cache))
    mutate(doc)
    (p / f"{A}.resources.json").write_text(json.dumps(doc))
    # objects/ dir for raw_capture validity: copy from the seed dir
    objs = cd / "objects"
    if objs.exists():
        (p / "objects").mkdir(exist_ok=True)
        for f in objs.iterdir():
            (p / "objects" / f.name).write_bytes(f.read_bytes())
    serve(body if body is not None else b"", status)
    return p


poison("p1_cache_id_B_netdown", lambda d: d.__setitem__("id", B))
part1["s6_cache_id_B_network_down"] = summarize(REAL_FETCH(A))
poison("p1_cache_id_B_netup", lambda d: d.__setitem__("id", B), ok_body, 200)
part1["s6b_cache_id_B_network_up"] = summarize(REAL_FETCH(A))
poison("p1_cache_noid_netdown", lambda d: d.pop("id"))
part1["s7_cache_no_id_network_down"] = summarize(REAL_FETCH(A))
poison("p1_cache_noid_netup", lambda d: d.pop("id"), ok_body, 200)
part1["s7b_cache_no_id_network_up"] = summarize(REAL_FETCH(A))

# s8: stale inventory (valid cache, past TTL, within max stale, network down)
old = (datetime.now(timezone.utc) - timedelta(seconds=detail.RESOURCE_CACHE_TTL_SECONDS + 600)
       ).isoformat(timespec="seconds")
poison("p1_stale", lambda d: d.__setitem__("retrieved_at", old))
part1["s8_stale_inventory"] = summarize(REAL_FETCH(A))

# s9: stale path where cached id is B (should be dropped, not reused)
poison("p1_stale_idB", lambda d: (d.__setitem__("retrieved_at", old), d.__setitem__("id", B)))
part1["s9_stale_cache_id_B"] = summarize(REAL_FETCH(A))

part1_ids_ok = all(v["id"] == A and v["has_id_key"] for v in part1.values())

# ---------------- Part 2: base adapter over poisoned cache; base vs cand run_searches


def taxonomy():
    return CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=A, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})]


sat._download_bytes = lambda rid, **k: f"Buyer requires {TERM} from the OTHER notice.".encode()


def run_rs(module, label):
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / f"text_{label}")
    rows, stats = module._enrich_sam_public_attachments([], Source(), object(), taxonomy(), None, limit=8)
    receipt = (stats.get("attachment_record_receipts") or {}).get(A, {})
    raw = (rows[0].get("raw_payload") or {}) if rows else {}
    return {"rows": len(rows), "receipt_status": receipt.get("status"),
            "receipt_errors": receipt.get("errors"),
            "inventory_receipt_id": (receipt.get("inventory_receipt") or {}).get("id"),
            "inventory_receipt_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
            "row_text_excerpt": (raw.get("text") or "")[:60] or None,
            "collection_notice_id": (raw.get("attachment_collection_v1") or {}).get("notice_id")}


part2 = {}
# base adapter alone over poisoned caches (fresh retrieved_at, network down)
poison("p2_base_idB", lambda d: d.__setitem__("id", B))
part2["base_adapter_cache_id_B"] = summarize(base_detail.fetch_notice_resources(A))
poison("p2_base_noid", lambda d: d.pop("id"))
part2["base_adapter_cache_no_id"] = summarize(base_detail.fetch_notice_resources(A))

# base run_searches + base adapter over cache id=B: does wrong-notice text land?
detail.fetch_notice_resources = base_detail.fetch_notice_resources
poison("p2_base_rs_idB", lambda d: d.__setitem__("id", B))
part2["base_rs_base_adapter_cache_id_B"] = run_rs(base_rs, "p2a")
poison("p2_base_rs_noid", lambda d: d.pop("id"))
part2["base_rs_base_adapter_cache_no_id"] = run_rs(base_rs, "p2b")
# candidate run_searches + candidate adapter over the same poisoned caches
detail.fetch_notice_resources = REAL_FETCH
poison("p2_cand_rs_idB", lambda d: d.__setitem__("id", B))
part2["cand_rs_cand_adapter_cache_id_B"] = run_rs(cand_rs, "p2c")
poison("p2_cand_rs_noid", lambda d: d.pop("id"))
part2["cand_rs_cand_adapter_cache_no_id"] = run_rs(cand_rs, "p2d")
# candidate run_searches + BASE adapter (isolates the guard's own contribution)
detail.fetch_notice_resources = base_detail.fetch_notice_resources
poison("p2_cand_rs_base_ad_idB", lambda d: d.__setitem__("id", B))
part2["cand_rs_BASE_adapter_cache_id_B"] = run_rs(cand_rs, "p2e")
poison("p2_cand_rs_base_ad_noid", lambda d: d.pop("id"))
part2["cand_rs_BASE_adapter_cache_no_id"] = run_rs(cand_rs, "p2f")
detail.fetch_notice_resources = REAL_FETCH

# ---------------- Part 3: monkeypatched doubles (finder's a/b/c)
files = [{"resource_id": D, "name": "Wrong notice SOW.txt", "access_level": "public",
          "access_status": "public", "export_controlled": "0", "explicit_access": "0",
          "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=D)}]
inv_hash = detail._manifest_hash(files)
part3 = {}
for label, double in (
        ("a_double_id_B", {"id": B, "resources_checked": True, "attachments": files,
                           "attachment_inventory_hash": inv_hash, "collection_status": "inventory_captured"}),
        ("b_double_no_id", {"resources_checked": True, "attachments": files,
                            "attachment_inventory_hash": inv_hash}),
        ("c_double_id_A", {"id": A, "resources_checked": True, "attachments": files,
                           "attachment_inventory_hash": inv_hash, "collection_status": "inventory_captured"})):
    cache_dir(f"p3_{label}")
    detail.fetch_notice_resources = lambda *a, **k: dict(double)
    part3[label] = run_rs(cand_rs, f"p3_{label}")
detail.fetch_notice_resources = REAL_FETCH

# ---------------- Part 4: static census of id-less doubles, base vs candidate
part4 = {}
for f in ("tests/test_sam_attachment_text.py", "tests/test_step4_temporal_evidence.py"):
    cand_src = (REPO / f).read_text()
    base_src = subprocess.run(["git", "-C", str(REPO), "show", f"2d522f0:{f}"],
                              capture_output=True, text=True, check=True).stdout
    part4[f] = {"identical_to_base": cand_src == base_src,
                "doubles": cand_src.count("'fetch_notice_resources'") + cand_src.count('"fetch_notice_resources"')}
part4["delta_touched_only"] = subprocess.run(
    ["git", "-C", str(REPO), "diff", "--name-only", "2d522f0..6b51f00", "--", "tests/"],
    capture_output=True, text=True, check=True).stdout.split()

checks = {
    "p1_every_real_adapter_return_carries_requested_id": part1_ids_ok,
    "p1_poisoned_cache_dropped_by_candidate_adapter": (
        part1["s6_cache_id_B_network_down"]["collection_status"] == "lookup_failed"
        and part1["s7_cache_no_id_network_down"]["collection_status"] == "lookup_failed"
        and part1["s9_stale_cache_id_B"]["collection_status"] == "lookup_failed"),
    "p2_base_adapter_returns_foreign_or_idless_cache": (
        part2["base_adapter_cache_id_B"]["id"] == B and part2["base_adapter_cache_no_id"]["has_id_key"] is False),
    "p2_base_pipeline_enriches_wrong_notice_from_cache": (
        part2["base_rs_base_adapter_cache_id_B"]["rows"] == 1
        and part2["base_rs_base_adapter_cache_no_id"]["rows"] == 1),
    "p2_candidate_pipeline_blocks_both_poisoned_caches": (
        part2["cand_rs_cand_adapter_cache_id_B"]["rows"] == 0
        and part2["cand_rs_cand_adapter_cache_no_id"]["rows"] == 0),
    "p2_guard_alone_catches_id_B_but_not_idless": (
        part2["cand_rs_BASE_adapter_cache_id_B"]["receipt_status"] == "IDENTITY_MISMATCH"
        and part2["cand_rs_BASE_adapter_cache_no_id"]["rows"] == 1),
    "p3_finder_a_b_c_reproduced": (
        part3["a_double_id_B"]["receipt_status"] == "IDENTITY_MISMATCH" and part3["a_double_id_B"]["rows"] == 0
        and part3["b_double_no_id"]["rows"] == 1 and part3["c_double_id_A"]["rows"] == 1),
    "p4_idless_doubles_pre_existing_and_untouched": all(
        v["identical_to_base"] for k, v in part4.items() if k.endswith(".py")),
}
status = "INFO" if all(checks.values()) else "FAIL"
print(json.dumps({"probe": "wni7_guard_reachability", "status": status, "checks": checks,
                  "observed": {"part1_candidate_adapter": part1, "part2_base_vs_candidate": part2,
                               "part3_doubles": part3, "part4_test_census": part4},
                  "tmp_dir": str(TMP)}, indent=2, sort_keys=True, default=str))
