"""Independent reproduction of WNI-7: run_searches identity guard admits an
inventory with no id key; unreachable through the real fetch_notice_resources.

Prints one JSON object. status PASS means the finding reproduces exactly as
described (guard admits id-less inventory; production adapter always sets id
to the requested notice, so the guard branch is dead with the real adapter).
"""
from __future__ import annotations

import ast
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

TMP = Path(tempfile.mkdtemp(prefix="wni7_", dir=str(Path(__file__).parent)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "30"

# No live network, ever.
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402
from tools.api import _http, sam_quota, sam_notice_detail as detail, sam_attachment_text as sat  # noqa: E402
from tools import env  # noqa: E402
env.load_env = lambda *a, **k: None
import run_searches as rs  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

A = "a" * 32
B = "b" * 32
sam_quota.calls_today = lambda *a, **k: 0

observed: dict = {}


def make_candidate(nid: str) -> RawOpportunity:
    return RawOpportunity(source="sam.gov", source_id=nid, title="Requirement",
                          agency="NASA", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}
    def __init__(self, cand):
        self.cand = cand
    def attachment_candidates(self, *a, **k):
        return [self.cand]


TAX = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                         core=[TaxonomyTerm(term="network visibility")])

STUB_EXTRACT = lambda item, **k: {  # noqa: E731
    "resource_id": item["resource_id"], "name": item["name"],
    "text": "Buyer requires network visibility.", "sha256": "0" * 64,
    "retrieved_at": "2026-09-01T00:00:00+00:00", "source_url": "https://sam.gov/x",
    "error": "", "collection_status": "captured_discovery_only"}


def run(cand, inventory_fn, extract_fn=STUB_EXTRACT):
    saved = (detail.fetch_notice_resources, sat.extract_public_attachment_text)
    if inventory_fn is not None:
        detail.fetch_notice_resources = inventory_fn
    sat.extract_public_attachment_text = extract_fn
    try:
        rows, stats = rs._enrich_sam_public_attachments(
            [], Source(cand), object(), TAX, None, limit=1)
    finally:
        detail.fetch_notice_resources, sat.extract_public_attachment_text = saved
    receipt = stats["attachment_record_receipts"][str(cand.source_id)]
    return {"rows": len(rows), "status": receipt.get("status"),
            "errors": receipt.get("errors"),
            "inventory_receipt_id": (receipt.get("inventory_receipt") or {}).get("id"),
            "inventory_collection_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
            "collection_notice_id": (rows[0]["raw_payload"].get("attachment_collection_v1", {}).get("notice_id")
                                     if rows else None)}


files = [{"name": "SOW.txt", "resource_id": "c" * 32}]

# Case 1: monkeypatched inventory with NO id key (as several suite tests do).
observed["case1_id_missing"] = run(make_candidate(A), lambda *a, **k: {
    "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": "h"})

# Case 2: monkeypatched inventory whose id names another notice.
observed["case2_id_other_notice"] = run(make_candidate(A), lambda *a, **k: {
    "id": B, "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": "h"})

# Case 3: monkeypatched inventory with id == None explicitly.
observed["case3_id_none"] = run(make_candidate(A), lambda *a, **k: {
    "id": None, "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": "h"})

# Case 4: REAL adapter, mocked transport returns a body that names notice B.
BODY_B = {"opportunityId": B, "_embedded": {"opportunityAttachmentList": [
    {"attachments": [{"name": "SOW.txt", "resourceId": "c" * 32,
                      "mimeType": "text/plain", "accessLevel": "public"}]}]}}
hits: list[str] = []
def handler(request: httpx.Request) -> httpx.Response:
    hits.append(str(request.url))
    return httpx.Response(200, json=BODY_B)
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
observed["case4_real_adapter_body_B"] = run(make_candidate(A), None)
observed["case4_transport_hits"] = len(hits)
direct = detail.fetch_notice_resources(A)
observed["case4_direct_fetch"] = {"id": direct.get("id"), "id_equals_requested": direct.get("id") == A,
                                  "collection_status": direct.get("collection_status"),
                                  "resources_checked": direct.get("resources_checked")}

# Case 5: REAL adapter, cache file for A whose stored id is B -> dropped.
cache_dir = Path(os.environ["LILA_NOTICE_CACHE_DIR"]); cache_dir.mkdir(parents=True, exist_ok=True)
(cache_dir / f"{A}.resources.json").write_text(json.dumps({
    "id": B, "resources_checked": True, "attachments": [], "attachment_inventory_hash": "x",
    "retrieved_at": "2099-01-01T00:00:00+00:00"}))
hits.clear()
direct5 = detail.fetch_notice_resources(A)
observed["case5_cache_id_B"] = {"id": direct5.get("id"), "id_equals_requested": direct5.get("id") == A,
                                "from_cache": direct5.get("from_cache"), "transport_hits": len(hits),
                                "collection_status": direct5.get("collection_status")}

# Case 6: REAL adapter, transport failure with a good cache for A -> stale path returns cached (id A).
BODY_A = {"opportunityId": A, "_embedded": {"opportunityAttachmentList": [{"attachments": [
    {"name": "SOW.txt", "resourceId": "c" * 32, "mimeType": "text/plain", "accessLevel": "public"}]}]}}
def handler_a(request):
    return httpx.Response(200, json=BODY_A)
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler_a))
(cache_dir / f"{A}.resources.json").unlink()
good = detail.fetch_notice_resources(A)
observed["case6_good_errors"] = good.get("errors")
def handler_fail(request):
    return httpx.Response(503, text="down")
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler_fail))
# Force refresh: age the capture clock past the fresh TTL but inside the stale window.
raw = json.loads((cache_dir / f"{A}.resources.json").read_text())
from datetime import datetime, timedelta, timezone
old = (datetime.now(timezone.utc) - timedelta(seconds=detail.RESOURCE_CACHE_TTL_SECONDS + 60)).isoformat()
raw["raw_capture"]["received_at"] = old; raw["retrieved_at"] = old
(cache_dir / f"{A}.resources.json").write_text(json.dumps(raw))
stale = detail.fetch_notice_resources(A)
observed["case6_stale_path"] = {"good_id": good.get("id"), "good_status": good.get("collection_status"),
                                "stale_id": stale.get("id"), "stale_id_equals_requested": stale.get("id") == A,
                                "stale_cache": stale.get("stale_cache"),
                                "collection_status": stale.get("collection_status")}

# Static: every dict literal returned by fetch_notice_resources carries id == notice_id.
src = (REPO / "tools/api/sam_notice_detail.py").read_text()
tree = ast.parse(src)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "fetch_notice_resources")
returns = [ast.get_source_segment(src, r.value) for r in ast.walk(fn) if isinstance(r, ast.Return)]
observed["static_returns_in_fetch_notice_resources"] = returns
observed["static_id_assigned_from_notice_id"] = '"id": notice_id' in ast.get_source_segment(src, fn)
observed["static_cache_id_check"] = 'cached.get("id") != notice_id' in ast.get_source_segment(src, fn)

# Static: guard text in candidate run_searches and absence in base.
rs_src = (REPO / "run_searches.py").read_text()
observed["guard_text_present"] = 'resources.get("id") not in (None, candidate.source_id)' in rs_src
base_rs = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:run_searches.py"],
                         capture_output=True, text=True, check=True).stdout
observed["guard_in_base"] = "IDENTITY_MISMATCH" in base_rs or 'resources.get("id")' in base_rs

# Census of test doubles that monkeypatch fetch_notice_resources and omit 'id'.
census = {}
for path in sorted((REPO / "tests").glob("test_*.py")):
    text = path.read_text()
    for m in re.finditer(r"setattr\([^\n]*fetch_notice_resources[^\n]*lambda[^\n]*", text):
        line_no = text[:m.start()].count("\n") + 1
        # Look at the next 6 lines for the dict body.
        snippet = "\n".join(text.splitlines()[line_no - 1:line_no + 6])
        census.setdefault(path.name, []).append({"line": line_no, "declares_id": "'id'" in snippet or '"id"' in snippet})
observed["test_double_census"] = census
omit_files = sorted(f for f, sites in census.items() if any(not s["declares_id"] for s in sites))
observed["test_files_with_id_less_doubles"] = omit_files

# Verdict.
c1, c2, c4 = observed["case1_id_missing"], observed["case2_id_other_notice"], observed["case4_real_adapter_body_B"]
repro = (
    c1["status"] == "DISCOVERY_TEXT_CAPTURED" and c1["rows"] == 1 and c1["collection_notice_id"] == A
    and c2["status"] == "IDENTITY_MISMATCH" and c2["rows"] == 0
    and c4["status"] == "INVENTORY_UNAVAILABLE" and c4["inventory_collection_status"] == "identity_mismatch"
    and observed["case4_direct_fetch"]["id_equals_requested"]
    and observed["case5_cache_id_B"]["id_equals_requested"]
    and observed["case6_stale_path"]["stale_id_equals_requested"]
    and observed["static_id_assigned_from_notice_id"] and observed["static_cache_id_check"]
    and observed["guard_text_present"] and not observed["guard_in_base"]
    and {"test_sam_attachment_text.py", "test_step4_temporal_evidence.py"} <= set(omit_files)
)
observed["git_status_porcelain"] = subprocess.run(
    ["git", "-C", str(REPO), "status", "--porcelain"], capture_output=True, text=True).stdout
print(json.dumps({"status": "PASS" if repro else "FAIL", "finding": "WNI-7",
                  "note": "PASS = finding reproduces as described (harness-only dead branch, no production defect)",
                  "observed": observed}, indent=1, default=str))
