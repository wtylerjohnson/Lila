"""F-14 independent reproduction: per-file extractor-cap truncation signal.

Claim under test: a 60000-character public file is cut to 50000 characters by
the extractor, yet file_text_truncated is False, the receipt reason is
'collected within declared budget', and no per-file key says the cap bit.
Also tests the finding's side claims: (a) the only inference route is raw
bytes vs text length for .txt (does an equality route exist for all types?),
(b) base had no flag at all, (c) PDF page cap leaves no signature.

Offline: sockets blocked, _download_bytes replaced, fetch_notice_resources
replaced, quota ledger replaced. Writes only under this probe directory.
"""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import shutil
import socket
import sys
import tempfile
import zipfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

TMP = Path(tempfile.mkdtemp(prefix="f14_", dir=str(PROBE_DIR)))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
os.environ["LILA_SUITE_OFFLINE"] = "1"


def _blocked_connect(*a, **k):  # noqa: D401
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]

observed: dict = {}
status = "PASS"
failures: list[str] = []

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

MAX = sat.MAX_ATTACHMENT_TEXT_CHARS
observed["max_text_characters_default"] = MAX


def trunc_keys(d: dict) -> list[str]:
    return sorted(k for k in d if "trunc" in k.lower())


def public_file(rid: str, name: str) -> dict:
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


def make_docx(text: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml",
                   '<w:document xmlns:w="http://schemas.openxmlformats.org/'
                   'wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>'
                   + text + "</w:t></w:r></w:p></w:body></w:document>")
    return buf.getvalue()


def make_pdf(pages: int, line: str) -> bytes:
    """Minimal valid multi-page PDF with one Helvetica text line per page."""
    objs: list[bytes] = []
    # 1 catalog, 2 pages, 3 font, then per page: page obj + content obj
    kids = " ".join(f"{4 + 2 * i} 0 R" for i in range(pages))
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(f"<< /Type /Pages /Kids [{kids}] /Count {pages} >>".encode())
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    for i in range(pages):
        content = f"BT /F1 12 Tf 72 720 Td ({line} page {i + 1}) Tj ET".encode()
        objs.append(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            f"/Resources << /Font << /F1 3 0 R >> >> "
            f"/Contents {5 + 2 * i} 0 R >>".encode())
        objs.append(b"<< /Length %d >>\nstream\n" % len(content)
                    + content + b"\nendstream")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for n, body in enumerate(objs, start=1):
        offsets.append(out.tell())
        out.write(f"{n} 0 obj\n".encode() + body + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objs) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\n"
              f"startxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


# ---------- A: direct extractor, 60000-character .txt ----------
txt_60k = ("network visibility requirement line. " * 2000)[:60000]
assert len(txt_60k) == 60000
sat._download_bytes = lambda rid, **k: txt_60k.encode()
res_a = sat.extract_public_attachment_text(public_file("b" * 32, "SOW.txt"))
observed["A_txt_60k"] = {
    "collection_status": res_a.get("collection_status"),
    "error": res_a.get("error"),
    "len_text": len(res_a.get("text") or ""),
    "text_locator": res_a.get("text_locator"),
    "extraction_limits": res_a.get("extraction_limits"),
    "raw_capture_bytes": (res_a.get("raw_capture") or {}).get("bytes"),
    "text_capture_bytes": (res_a.get("text_capture") or {}).get("bytes"),
    "result_keys": sorted(res_a),
    "truncation_keys": trunc_keys(res_a),
    "cap_equality_route": (res_a.get("text_locator") or {}).get("end")
    == (res_a.get("extraction_limits") or {}).get("max_text_characters"),
}
if len(res_a.get("text") or "") != MAX:
    failures.append("A: extractor did not cut to MAX")
if trunc_keys(res_a):
    failures.append("A: an explicit truncation key exists (claim wrong)")

# ---------- B: DOCX 60000 chars, raw bytes are compressed ----------
docx_bytes = make_docx(txt_60k)
sat._download_bytes = lambda rid, **k: docx_bytes
res_b = sat.extract_public_attachment_text(public_file("c" * 32, "SOW.docx"))
observed["B_docx_60k"] = {
    "collection_status": res_b.get("collection_status"),
    "error": res_b.get("error"),
    "len_text": len(res_b.get("text") or ""),
    "raw_capture_bytes": (res_b.get("raw_capture") or {}).get("bytes"),
    "text_capture_bytes": (res_b.get("text_capture") or {}).get("bytes"),
    "truncation_keys": trunc_keys(res_b),
    "raw_vs_text_inference_possible": (
        (res_b.get("raw_capture") or {}).get("bytes", 0)
        > (res_b.get("text_capture") or {}).get("bytes", 0)),
    "cap_equality_route": (res_b.get("text_locator") or {}).get("end")
    == (res_b.get("extraction_limits") or {}).get("max_text_characters"),
}

# ---------- C: PDF page cap (120 pages, tiny text) ----------
pdf_bytes = make_pdf(120, "Requirement")
sat._download_bytes = lambda rid, **k: pdf_bytes
res_c = sat.extract_public_attachment_text(public_file("d" * 32, "SOW.pdf"))
text_c = res_c.get("text") or ""
observed["C_pdf_120_pages"] = {
    "collection_status": res_c.get("collection_status"),
    "error": res_c.get("error"),
    "len_text": len(text_c),
    "pages_seen_in_text": sum(1 for i in range(1, 121)
                              if f"page {i}" in text_c),
    "max_pdf_pages": (res_c.get("extraction_limits") or {}).get("max_pdf_pages"),
    "truncation_keys": trunc_keys(res_c),
    "any_page_count_key": sorted(k for k in res_c if "page" in k.lower()),
    "cap_equality_route": (res_c.get("text_locator") or {}).get("end")
    == (res_c.get("extraction_limits") or {}).get("max_text_characters"),
}

# ---------- D: run_searches path, one 60000-character file ----------
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
import tools.api.sam_quota as quota  # noqa: E402

quota.calls_today = lambda: 0
shutil.rmtree(TMP / "text", ignore_errors=True)


def run_enrich(files: list[dict], texts: dict[str, str], notice_id="a" * 32):
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": notice_id, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}
    sat._download_bytes = lambda rid, **k: texts[rid].encode()
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id,
                               title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1,
                             updated="2026-07-21",
                             core=[TaxonomyTerm(term="network visibility")])
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), tax, None, limit=8)
    return rows, stats


rows_d, stats_d = run_enrich([public_file("b" * 32, "SOW 1.txt")],
                             {"b" * 32: txt_60k})
receipt_d = None
for key in ("record_receipts", "receipts", "attachment_receipts"):
    if isinstance(stats_d, dict) and key in stats_d:
        receipt_d = stats_d[key]
        break
if receipt_d is None:
    # search any dict value holding a files list
    for v in (stats_d.values() if isinstance(stats_d, dict) else []):
        if isinstance(v, dict):
            for vv in v.values():
                if isinstance(vv, dict) and "files" in vv:
                    receipt_d = v
                    break
rec = (receipt_d or {}).get("a" * 32, {}) if isinstance(receipt_d, dict) else {}
file_rec = (rec.get("files") or [{}])[0]
raw_d = rows_d[0].get("raw_payload", {}) if rows_d else {}
ev_d = (raw_d.get("attachment_evidence") or [{}])[0]
observed["D_run_searches_60k"] = {
    "stats_keys": sorted(stats_d) if isinstance(stats_d, dict) else str(type(stats_d)),
    "rows_returned": len(rows_d),
    "record_status": rec.get("status"),
    "file_receipt_status": file_rec.get("status"),
    "file_receipt_reason": file_rec.get("reason"),
    "file_receipt_text_locator": file_rec.get("text_locator"),
    "file_receipt_extraction_limits": file_rec.get("extraction_limits"),
    "file_receipt_truncation_keys": trunc_keys(file_rec),
    "file_receipt_keys": sorted(file_rec),
    "evidence_file_text_truncated": ev_d.get("file_text_truncated"),
    "evidence_file_text_locator": ev_d.get("file_text_locator"),
    "evidence_combined_text_locator": ev_d.get("combined_text_locator"),
    "evidence_extraction_limits": ev_d.get("extraction_limits"),
    "evidence_keys": sorted(ev_d),
    "combined_text_len": len(raw_d.get("text") or ""),
    "raw_capture_bytes": (ev_d.get("raw_capture") or {}).get("bytes"),
    "text_capture_bytes": (ev_d.get("text_capture") or {}).get("bytes"),
    "evidence_cap_equality_route": (ev_d.get("file_text_locator") or {}).get("end")
    == (ev_d.get("extraction_limits") or {}).get("max_text_characters"),
}
if ev_d.get("file_text_truncated") is not False:
    failures.append("D: file_text_truncated is not False (claim not reproduced)")
if file_rec.get("reason") != "collected within declared budget":
    failures.append("D: receipt reason differs from claim")
if (ev_d.get("combined_text_locator") or {}).get("end") != MAX:
    failures.append("D: combined locator end is not MAX")

# ---------- E: control, three 50000-char files; flag measures bundle cap ----------
shutil.rmtree(TMP / "text", ignore_errors=True)
t50 = ("network visibility requirement. " * 2000)[:50000]
files_e = [public_file("b" * 32, "SOW 1.txt"), public_file("c" * 32, "SOW 2.txt"),
           public_file("d" * 32, "SOW 3.txt")]
rows_e, stats_e = run_enrich(files_e, {"b" * 32: t50, "c" * 32: t50, "d" * 32: t50})
ev_e = (rows_e[0].get("raw_payload", {}).get("attachment_evidence") or []) if rows_e else []
observed["E_three_files_control"] = {
    "file_text_truncated": [e.get("file_text_truncated") for e in ev_e],
    "combined_locators": [e.get("combined_text_locator") for e in ev_e],
    "file_locators": [e.get("file_text_locator") for e in ev_e],
}
if [e.get("file_text_truncated") for e in ev_e] != [False, False, True]:
    failures.append("E: control flag pattern unexpected")

# ---------- F: base extractor (2d522f0), same 60000-char .txt ----------
shutil.rmtree(TMP / "text", ignore_errors=True)
spec = importlib.util.spec_from_file_location(
    "base_sat", str(PROBE_DIR / "base_sam_attachment_text.py"))
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)  # type: ignore[union-attr]
base_sat._download_bytes = lambda rid, **k: txt_60k.encode()
res_f = base_sat.extract_public_attachment_text(public_file("b" * 32, "SOW.txt"))
observed["F_base_extractor_60k"] = {
    "len_text": len(res_f.get("text") or ""),
    "error": res_f.get("error"),
    "result_keys": sorted(res_f),
    "truncation_keys": trunc_keys(res_f),
    "has_extraction_limits": "extraction_limits" in res_f,
    "has_text_locator": "text_locator" in res_f,
}
base_rs = os.popen(
    "git -C /Users/wtjohnson/lila-step7-052 show 2d522f0:run_searches.py"
).read()
observed["F_base_run_searches_has_file_text_truncated"] = (
    "file_text_truncated" in base_rs)
observed["F_base_run_searches_has_extraction_limits"] = (
    "extraction_limits" in base_rs)

# ---------- G: does anything read file_text_truncated? ----------
readers = os.popen(
    "grep -rln --include='*.py' 'file_text_truncated' "
    "/Users/wtjohnson/lila-step7-052 --exclude-dir=.venv").read().split()
observed["G_file_text_truncated_readers"] = sorted(
    p.replace("/Users/wtjohnson/lila-step7-052/", "") for p in readers)

# ---------- verdict ----------
core_reproduced = (
    observed["A_txt_60k"]["len_text"] == MAX
    and not observed["A_txt_60k"]["truncation_keys"]
    and observed["D_run_searches_60k"]["evidence_file_text_truncated"] is False
    and observed["D_run_searches_60k"]["file_receipt_reason"]
    == "collected within declared budget"
)
side_claim_only_txt_route_overstated = (
    observed["A_txt_60k"]["cap_equality_route"]
    and observed["B_docx_60k"]["cap_equality_route"]
    and observed["D_run_searches_60k"]["evidence_cap_equality_route"]
)
observed["core_claim_reproduced"] = core_reproduced
observed["side_claim_only_txt_inference_route_overstated"] = (
    side_claim_only_txt_route_overstated)
observed["pdf_page_cap_has_no_signature"] = (
    observed["C_pdf_120_pages"]["pages_seen_in_text"] < 120
    and not observed["C_pdf_120_pages"]["truncation_keys"]
    and not observed["C_pdf_120_pages"]["cap_equality_route"])
observed["probe_failures"] = failures
if failures:
    status = "INFO"
elif core_reproduced:
    status = "FAIL"  # defect/overstatement demonstrated as described
shutil.rmtree(TMP, ignore_errors=True)
print(json.dumps({"status": status, "observed": observed}, indent=1,
                 default=str))
