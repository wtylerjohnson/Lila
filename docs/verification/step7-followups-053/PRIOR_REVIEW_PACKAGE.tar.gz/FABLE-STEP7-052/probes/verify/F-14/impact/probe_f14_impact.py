"""F-14 IMPACT refutation probe (ELD-01: file_text_truncated vs the 50000-char extractor cap).

Traces where the flag value can flow and whether any trusted surface reads it:
  A. run_searches receipts + saved-sweep row for a 60000-char .txt (default config)
  B. 120-page PDF with defaults: page cap bites, what the receipt discloses
  C. dossier research context + compose_dossier prompt context (RecordingEngine)
  D. requirement_support attachment_context (triage/research evidence carrier)
  E. strict Assess build via tests/test_assess_ledger helpers with the enriched row
  F. base (2d522f0) extractor on the same 60000-char file (pre-existing cap?)
  G. static: repo readers of file_text_truncated / extraction_limits; docs claims
No network (sockets blocked), no LLM, all writes under this probe dir.
"""
from __future__ import annotations

import importlib.util
import io
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]

TMP = HERE / "tmp"
TMP.mkdir(exist_ok=True)


def fresh_dirs(tag):
    base = Path(tempfile.mkdtemp(prefix=f"f14-{tag}-", dir=str(TMP)))
    (base / "notice").mkdir()
    (base / "text").mkdir()
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(base / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base / "text")
    return base


fresh_dirs("boot")
import run_searches as searches  # noqa: E402
from agents.decisions import dossier as dz  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from tools.relevance.requirement_support import requirement_support  # noqa: E402

obs: dict = {}
fails: list[str] = []


def check(name, cond, detail_=None):
    obs[name] = {"ok": bool(cond), **({"detail": detail_} if detail_ is not None else {})}
    if not cond:
        fails.append(name)


def public_file(rid, name, **extra):
    row = {"resource_id": rid, "name": name, "access_level": "public",
           "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
    row.update(extra)
    return row


def native_collection(notice_id, files, payloads, term="network visibility"):
    sam_quota.calls_today = lambda: 0
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": notice_id, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}
    sat._download_bytes = lambda rid, **k: payloads[rid]
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term=term)])
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=8)
    return rows, stats, inventory, taxonomy


def keys_with(d, needle):
    return sorted(k for k in d if needle in k.lower())


# ---------------------------------------------------------------- A. 60000-char txt
NID = "a" * 32
RID = "b" * 32
body = ("network visibility requirement " * 2500)[:60000]
body = body[:40000] + "INSIDECAPTOKEN" + body[40014:55000] + "BEYONDCAPTOKEN" + body[55014:]
assert len(body) == 60000
fresh_dirs("A")
rows, stats, inventory, taxonomy = native_collection(NID, [public_file(RID, "SOW.txt")], {RID: body.encode()})
check("A.row_produced", len(rows) == 1, {"rows": len(rows), "errors": stats.get("attachment_errors")})
raw = rows[0]["raw_payload"]
ev = raw["attachment_evidence"][0]
rr = stats["attachment_record_receipts"][NID]
fr = rr["files"][0]
obs["A.evidence_entry"] = {k: (v if k not in ("raw_capture", "text_capture") else {"bytes": v.get("bytes")})
                           for k, v in ev.items()}
obs["A.file_receipt_keys"] = sorted(fr)
obs["A.file_receipt_status_reason"] = {"status": fr["status"], "reason": fr["reason"]}
check("A.extracted_text_is_50000_and_inside_token_kept",
      ev["file_text_locator"] == {"unit": "unicode_characters", "start": 0, "end": 50000}
      and "INSIDECAPTOKEN" in raw["text"] and "BEYONDCAPTOKEN" not in raw["text"],
      {"combined_len": len(raw["text"])})
check("A.flag_false_although_extractor_cut_10000", ev["file_text_truncated"] is False)
check("A.flag_absent_from_file_receipt", keys_with(fr, "trunc") == [], keys_with(fr, "trunc"))
check("A.receipt_reason_generic", fr["reason"] == "collected within declared budget")
# What the SAME receipt/evidence entry does disclose (inference routes)
limits = ev["extraction_limits"]
check("A.extraction_limits_discloses_bound_and_completeness",
      limits == {"max_text_characters": 50000, "max_pdf_pages": 100,
                 "completeness": "bounded_extraction_not_full_document_proof"}, limits)
check("A.text_locator_end_equals_cap_is_inferable",
      fr["text_locator"]["end"] == limits["max_text_characters"] == 50000,
      {"text_locator": fr["text_locator"]})
check("A.raw_bytes_exceed_text_bytes_inferable_for_txt",
      ev["raw_capture"]["bytes"] == 60000 and ev["text_capture"]["bytes"] == 50000,
      {"raw": ev["raw_capture"]["bytes"], "text": ev["text_capture"]["bytes"]})
raw_bytes = read_retained(sat._cache_dir(), ev["raw_capture"])
check("A.full_60000_bytes_retained_recoverable", raw_bytes.decode() == body and "BEYONDCAPTOKEN" in raw_bytes.decode())
# same list travels as attachment_collection_v1.files and discovery_evidence.files
check("A.same_flag_in_collection_v1_and_discovery_evidence",
      raw["attachment_collection_v1"]["files"][0]["file_text_truncated"] is False
      and rr["discovery_evidence"]["files"][0]["file_text_truncated"] is False)

# ---------------------------------------------------------------- B. 120-page PDF, defaults


def make_pdf(pages: int) -> bytes:
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>"]
    kids = " ".join(f"{3 + 2 * i} 0 R" for i in range(pages))
    objects.append(f"<< /Type /Pages /Kids [{kids}] /Count {pages} >>".encode())
    font_obj = 3 + 2 * pages
    for i in range(pages):
        content = f"BT /F1 24 Tf 72 700 Td (Page {i + 1} marker) Tj ET".encode()
        objects.append(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 {font_obj} 0 R >> >> "
            f"/Contents {4 + 2 * i} 0 R >>".encode())
        objects.append(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for n, obj in enumerate(objects, start=1):
        offsets.append(out.tell())
        out.write(f"{n} 0 obj\n".encode() + obj + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objects) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


fresh_dirs("B")
pdf = make_pdf(120)
RID2 = "c" * 32
rows_b, stats_b, inv_b, _ = native_collection(NID, [public_file(RID2, "Spec.pdf")], {RID2: pdf}, term="marker")
check("B.pdf_row_produced", len(rows_b) == 1, {"errors": stats_b.get("attachment_errors")})
if rows_b:
    evb = rows_b[0]["raw_payload"]["attachment_evidence"][0]
    frb = stats_b["attachment_record_receipts"][NID]["files"][0]
    txt = rows_b[0]["raw_payload"]["text"]
    check("B.page_cap_bit_pages_101_to_120_dropped",
          "Page 100 marker" in txt and "Page 101 marker" not in txt, {"len": len(txt)})
    check("B.flag_false_for_page_cap", evb["file_text_truncated"] is False)
    check("B.no_page_count_or_cap_hit_signal_in_receipt",
          keys_with(frb, "page") == [] and keys_with(frb, "trunc") == []
          and frb["text_locator"]["end"] < 50000,
          {"receipt_keys": sorted(frb), "text_locator_end": frb["text_locator"]["end"],
           "raw_bytes": evb["raw_capture"]["bytes"], "text_bytes": evb["text_capture"]["bytes"]})
    check("B.completeness_disclaimer_present", evb["extraction_limits"]["completeness"]
          == "bounded_extraction_not_full_document_proof")

# ---------------------------------------------------------------- C. dossier context
depth = {"id": NID, "attachment_inventory_hash": inventory, "resources_checked": True,
         "description": "authoritative description", "attachments": [public_file(RID, "SOW.txt")],
         "errors": []}
ctx = dz._attachment_research_context(rows[0], depth)
check("C.research_status_discovery_only", ctx.get("status") == "discovery_only", ctx.get("reason"))
fp = ctx["file_passages"][0]
check("C.file_passage_keys_exclude_flag_and_limits",
      keys_with(fp, "trunc") == ["truncated"] and "extraction_limits" not in fp
      and "file_text_truncated" not in fp, sorted(fp))
check("C.files_fields_exclude_flag", all("file_text_truncated" not in f and "extraction_limits" not in f
                                         for f in ctx["files"]), sorted(ctx["files"][0]))
check("C.truncated_means_prompt_cap_14000",
      ctx["truncated"] is True and ctx["included_characters"] == 14000 and ctx["captured_characters"] == 50000
      and fp["truncated"] is True and fp["included_end"] == 14000)
check("C.dossier_text_lacks_both_tokens", "INSIDECAPTOKEN" not in ctx["text"] and "BEYONDCAPTOKEN" not in ctx["text"])


class RecordingEngine:
    def deliberate(self, *, layer, system_prompt, context, schema, now=None):
        self.context = context
        return schema(id=context["notice"]["id"], title="t", scope_summary="s", evaluation_criteria=[],
                      submission_requirements=[], incumbent_signals=[], fit_verdict="stretch",
                      win_themes=["w"], red_flags=[], next_action="n")


eng = RecordingEngine()
dz.compose_dossier("Testco", "strategy", rows[0], depth, engine=eng)
prompt_json = json.dumps(eng.context, default=str)
check("C.prompt_context_never_carries_flag_or_limits",
      "file_text_truncated" not in prompt_json and "extraction_limits" not in prompt_json
      and "max_text_characters" not in prompt_json)
check("C.prompt_context_carries_captured_len_and_prompt_truncation",
      eng.context["attachment_research"]["captured_characters"] == 50000
      and eng.context["attachment_research"]["truncated"] is True)
check("C.full_description_from_depth_not_attachment",
      eng.context["full_description"] == "authoritative description")

# ---------------------------------------------------------------- D. requirement_support carrier
sup = requirement_support(rows[0], taxonomy)
ac = sup["attachment_context"]
check("D.requirement_support_carries_raw_evidence_with_flag",
      ac["files"][0].get("file_text_truncated") is False
      and ac["authority"] == "DISCOVERY_ONLY_NOT_REQUIREMENT_APPROVAL"
      and sup["qualification"] == "NOT_ESTABLISHED",
      {"state": sup["state"], "requested_support": sup["requested_support"]})

# ---------------------------------------------------------------- E. strict Assess build
import tests.test_assess_ledger as T  # noqa: E402

sweep = T._sweep()
n1 = sweep["results"]["sam.gov"][0]
# graft the enriched raw_payload (attachment text/evidence/collection) onto the trusted N1 row
for key, value in raw.items():
    if key != "type":
        n1["raw_payload"][key] = value
sweep["results"]["dossiers"] = {"records": [T._depth_record(attachments=[public_file(RID, "SOW.txt")])]}
proposed, second, third = T._build(sweep)
dump = json.dumps(proposed.model_dump(mode="json"), default=str)
rec = next(r for r in proposed.live.records if r.notice_id == "N1")
check("E.assess_ledger_never_carries_flag_limits_or_evidence",
      "file_text_truncated" not in dump and "extraction_limits" not in dump
      and "attachment_evidence" not in dump and "INSIDECAPTOKEN" not in dump)
check("E.n1_not_bid_now_and_requirement_not_reviewed",
      rec.classification.value != "BID_NOW" and rec.requirement_reviewed_at is None
      and not (rec.requirement_excerpt or "").count("INSIDECAPTOKEN"),
      {"classification": rec.classification.value, "excerpt": (rec.requirement_excerpt or "")[:80]})
# sanity: the ledger reads the sweep at all (row is present)
check("E.n1_record_present", rec is not None)

# ---------------------------------------------------------------- F. base extractor
base_src = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_attachment_text.py"],
                          capture_output=True, text=True, check=True).stdout
base_path = HERE / "tmp" / "base_sam_attachment_text.py"
base_path.write_text(base_src)
fresh_dirs("F")
spec = importlib.util.spec_from_file_location("base_sat", base_path)
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)
base_sat._download_bytes = lambda rid, **k: body.encode()
rb = base_sat.extract_public_attachment_text(public_file(RID, "SOW.txt"))
check("F.base_silently_capped_at_50000_no_signal_at_all",
      len(rb["text"]) == 50000 and "BEYONDCAPTOKEN" not in rb["text"]
      and keys_with(rb, "trunc") == [] and "extraction_limits" not in rb and "text_locator" not in rb,
      {"base_keys": sorted(rb), "len": len(rb["text"])})
base_rs = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:run_searches.py"],
                         capture_output=True, text=True, check=True).stdout
check("F.base_run_searches_had_no_flag_or_limits",
      "file_text_truncated" not in base_rs and "extraction_limits" not in base_rs)

# ---------------------------------------------------------------- G. static readers + docs
readers = subprocess.run(
    ["grep", "-rn", "--include=*.py", "-e", "file_text_truncated", "-e", "extraction_limits", str(REPO),
     "--exclude-dir=.venv", "--exclude-dir=.git"], capture_output=True, text=True).stdout.strip().splitlines()
readers = [ln.replace(str(REPO) + "/", "") for ln in readers]
obs["G.repo_mentions"] = readers
non_writer = [ln for ln in readers if not ln.startswith(("run_searches.py", "tools/api/sam_attachment_text.py",
                                                           "docs/verification/step7-052/probe_text_boundaries.py"))]
check("G.no_code_reads_the_flag_or_limits", non_writer == [], non_writer)
docs = subprocess.run(["grep", "-rn", "-i", "-e", "file_text_truncated", "-e", "per-file truncation",
                       "-e", "extractor cap", str(REPO / "docs" / "CONVENTIONS.md"),
                       str(REPO / "docs" / "CONTRACT_SURFACES.md"), str(REPO / "docs" / "verification" / "step7-052")],
                      capture_output=True, text=True).stdout.strip().splitlines()
obs["G.doc_claims_about_flag"] = [ln.replace(str(REPO) + "/", "") for ln in docs]
producer_probe = (REPO / "docs/verification/step7-052/probe_text_boundaries.py").read_text()
check("G.producer_defines_flag_as_bundle_cap_semantics",
      "[False, False, True]" in producer_probe and "third_file_truncated_characters': 4" in producer_probe)
conv = (REPO / "docs/CONVENTIONS.md").read_text()
check("G.docs_disclaim_full_document_completeness",
      "bounded extraction, not a full-document completeness claim" in conv)

status = "FAIL" if fails else "PASS"
print(json.dumps({"probe": "probe_f14_impact", "status": status, "fails": fails, "observed": obs},
                 indent=2, default=str, sort_keys=True))
