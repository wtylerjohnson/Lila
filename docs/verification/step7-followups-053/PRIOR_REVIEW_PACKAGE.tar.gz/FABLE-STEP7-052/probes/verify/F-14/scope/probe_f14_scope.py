"""F-14 SCOPE / CLASSIFICATION refutation probe.

Claim under test (ELD-01 / F-14): for a 60000-character public .txt file the
extractor cap cuts text to 50000, yet `file_text_truncated` is False and no
per-file key says the cap bit; `extraction_limits` only names bounds.

What this probe measures, on the REAL candidate functions (network blocked,
`_download_bytes` mocked, probe-local cache dirs):
 A. candidate extract_public_attachment_text on a 60000-char .txt
 B. candidate run_searches._enrich_sam_public_attachments on the same file
 C. the inference route the receipt DOES carry: text_locator.end ==
    extraction_limits.max_text_characters (char cap), plus its edge case
    (a file of exactly 50000 chars) and the page-cap case where NO inference
    exists (120-page PDF, small text)
 D. BASE copies (git show 2d522f0:...) placed in this dir: same 60000 .txt
    through base extract + base run_searches evidence keys
 E. downstream consumers of `file_text_truncated` in the candidate tree
 F. the doc sentences that disclose (or mandate) cap truncation visibility

No network, no LLM, no writes outside this directory.
"""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]

(PROBE_DIR / "tmp").mkdir(exist_ok=True)


def fresh_dirs(tag):
    base = Path(tempfile.mkdtemp(prefix=f"f14-{tag}-", dir=str(PROBE_DIR / "tmp")))
    (base / "notice").mkdir()
    (base / "text").mkdir()
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(base / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(base / "text")
    return base


def public_file(rid, name, **extra):
    row = {"resource_id": rid, "name": name, "access_level": "public",
           "access_status": "public", "export_controlled": "0", "explicit_access": "0"}
    row.update(extra)
    return row


def make_pdf(pages: int) -> bytes:
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>"]
    kids = " ".join(f"{3 + 2 * i} 0 R" for i in range(pages))
    objects.append(f"<< /Type /Pages /Kids [{kids}] /Count {pages} >>".encode())
    font_obj = 3 + 2 * pages
    for i in range(pages):
        content = f"BT /F1 24 Tf 72 700 Td (Page {i + 1} marker) Tj ET".encode()
        objects.append(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources "
            f"<< /Font << /F1 {font_obj} 0 R >> >> /Contents {4 + 2 * i} 0 R >>".encode())
        objects.append(b"<< /Length " + str(len(content)).encode()
                       + b" >>\nstream\n" + content + b"\nendstream")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for n, body in enumerate(objects, start=1):
        offsets.append(out.tell())
        out.write(f"{n} 0 obj\n".encode() + body + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objects) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


obs: dict = {}
checks: dict = {}


def check(name, cond, detail=None):
    checks[name] = {"ok": bool(cond), **({"detail": detail} if detail is not None else {})}


from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

REAL_RUN = subprocess.run
BIG = ("network visibility requirement " * 2500)[:60000]
EXACT = ("network visibility requirement " * 2500)[:50000]
PDF120 = make_pdf(120)

# ---- A. candidate extractor on the 60000-char txt --------------------------
fresh_dirs("cand-extract")
sat._download_bytes = lambda rid, **k: BIG.encode()
a = sat.extract_public_attachment_text(public_file("b" * 32, "SOW.txt"))
obs["A.candidate_extract"] = {
    "text_len": len(a["text"]), "collection_status": a["collection_status"],
    "raw_capture_bytes": a["raw_capture"]["bytes"], "text_capture_bytes": a["text_capture"]["bytes"],
    "text_locator": a["text_locator"], "extraction_limits": a["extraction_limits"],
    "keys": sorted(a), "keys_with_trunc": [k for k in a if "trunc" in k.lower()],
    "raw_bytes_intact": read_retained(sat._cache_dir(), a["raw_capture"]) == BIG.encode(),
}
check("A.text_cut_to_50000_no_trunc_key", len(a["text"]) == 50000
      and obs["A.candidate_extract"]["keys_with_trunc"] == [])


# ---- B. candidate run_searches on the same file ------------------------------
def native_collection(module, *, notice_id, files, texts, term="network visibility"):
    sam_quota.calls_today = lambda: 0
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": notice_id, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}
    sat._download_bytes = lambda rid, **k: texts[rid]
    candidate = RawOpportunity(source="sam.gov", source_id=notice_id, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term=term)])
    rows, stats = module._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
    return rows, stats, inventory


fresh_dirs("cand-rs")
rows, stats, inv = native_collection(searches, notice_id="a" * 32,
                                     files=[public_file("b" * 32, "SOW.txt")],
                                     texts={"b" * 32: BIG.encode()})
ev = rows[0].raw_payload["attachment_evidence"][0] if hasattr(rows[0], "raw_payload") else rows[0]["raw_payload"]["attachment_evidence"][0]
rc = stats["attachment_record_receipts"]["a" * 32]["files"][0]
obs["B.candidate_run_searches"] = {
    "file_text_truncated": ev["file_text_truncated"],
    "file_text_locator": ev["file_text_locator"],
    "combined_text_locator": ev["combined_text_locator"],
    "raw_capture_bytes": ev["raw_capture"]["bytes"],
    "text_capture_bytes": ev["text_capture"]["bytes"],
    "extraction_limits_in_evidence": ev.get("extraction_limits"),
    "evidence_keys": sorted(ev),
    "receipt_status": rc["status"], "receipt_reason": rc["reason"],
    "receipt_has_extraction_limits": "extraction_limits" in rc,
    "receipt_has_text_locator": "text_locator" in rc,
    "receipt_keys_with_trunc": [k for k in rc if "trunc" in k.lower()],
}
check("B.flag_false_for_cap_cut_file", ev["file_text_truncated"] is False,
      "confirms member observation: flag measures bundle cap only")

# ---- C. inference routes present in the receipt -----------------------------
def cap_bit_inferable(item: dict) -> bool:
    # receipt rows carry text_locator (all extract keys but text); evidence rows
    # carry file_text_locator (end == len(file_text)); both sit beside
    # extraction_limits.max_text_characters in the same dict.
    loc = item.get("text_locator") or item.get("file_text_locator") or {}
    lim = item.get("extraction_limits") or {}
    return loc.get("end") == lim.get("max_text_characters")


obs["C.char_cap_inference"] = {
    "evidence_has_text_locator": "text_locator" in ev,
    "evidence_file_text_locator_end": (ev.get("file_text_locator") or {}).get("end"),
    "receipt_text_locator_end": (rc.get("text_locator") or {}).get("end"),
    "evidence_max_text_characters": (ev.get("extraction_limits") or {}).get("max_text_characters"),
    "inferable_from_evidence": cap_bit_inferable(ev),
    "inferable_from_receipt": cap_bit_inferable(rc),
    "completeness_flag": (ev.get("extraction_limits") or {}).get("completeness"),
}
check("C.char_cap_bite_inferable_from_same_receipt", cap_bit_inferable(ev) and cap_bit_inferable(rc))

# edge: a file of exactly 50000 chars looks identical to a capped one
fresh_dirs("cand-exact")
sat._download_bytes = lambda rid, **k: EXACT.encode()
c_exact = sat.extract_public_attachment_text(public_file("c" * 32, "Exact.txt"))
obs["C.exact_50000_edge"] = {"text_len": len(c_exact["text"]),
                             "inference_says_capped": cap_bit_inferable(c_exact),
                             "actually_capped": False}

# whitespace collapse makes raw-bytes vs text-length an unreliable route even for txt
fresh_dirs("cand-ws")
WS = ("word    " * 8000)[:60000]  # 60000 bytes, collapses well below 50000 chars
sat._download_bytes = lambda rid, **k: WS.encode()
c_ws = sat.extract_public_attachment_text(public_file("d" * 32, "Spaces.txt"))
obs["C.txt_raw_vs_text_route_unreliable"] = {
    "raw_bytes": c_ws["raw_capture"]["bytes"], "text_len": len(c_ws["text"]),
    "raw_gt_text_but_not_capped": c_ws["raw_capture"]["bytes"] > len(c_ws["text"])
    and len(c_ws["text"]) < sat.MAX_ATTACHMENT_TEXT_CHARS}

# page cap: 120-page PDF, tiny text, NO inference route at all
fresh_dirs("cand-pdf")
sat._download_bytes = lambda rid, **k: PDF120
c_pdf = sat.extract_public_attachment_text(public_file("a1" * 16, "Spec.pdf"))
obs["C.page_cap_no_inference"] = {
    "collection_status": c_pdf["collection_status"], "error": c_pdf.get("error"),
    "text_len": len(c_pdf["text"]),
    "has_page_100": "Page 100 marker" in c_pdf["text"],
    "has_page_101": "Page 101 marker" in c_pdf["text"],
    "char_cap_inference": cap_bit_inferable(c_pdf),
    "keys_with_page_count": [k for k in c_pdf if "page" in k.lower() and k != "extraction_limits"],
    "extraction_limits": c_pdf.get("extraction_limits"),
}
check("C.page_cap_bite_not_inferable", c_pdf["collection_status"] == "captured_discovery_only"
      and "Page 101 marker" not in c_pdf["text"] and not cap_bit_inferable(c_pdf)
      and obs["C.page_cap_no_inference"]["keys_with_page_count"] == [])

# ---- D. BASE behaviour (2d522f0 copies in this dir) --------------------------
spec = importlib.util.spec_from_file_location("base_sat", str(PROBE_DIR / "base_sam_attachment_text.py"))
base_sat = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_sat)
fresh_dirs("base-extract")
base_sat.subprocess.run = lambda argv, **kw: REAL_RUN(argv, **{**kw, "cwd": str(REPO)})
base_sat._download_bytes = lambda rid, **k: BIG.encode()
d = base_sat.extract_public_attachment_text(public_file("b" * 32, "SOW.txt"))
obs["D.base_extract"] = {
    "text_len": len(d["text"]), "keys": sorted(d),
    "keys_with_trunc": [k for k in d if "trunc" in k.lower()],
    "has_extraction_limits": "extraction_limits" in d, "has_text_locator": "text_locator" in d,
    "base_MAX_ATTACHMENT_TEXT_CHARS": base_sat.MAX_ATTACHMENT_TEXT_CHARS,
    "base_MAX_PDF_PAGES": base_sat.MAX_PDF_PAGES,
}
check("D.base_same_cut_no_signal_at_all", len(d["text"]) == 50000
      and obs["D.base_extract"]["keys_with_trunc"] == [] and "extraction_limits" not in d)

# base run_searches evidence keys (module loaded from this dir; consumes the repo's
# current extractor, but base evidence only projects 5 fixed keys from it)
base_rs_info: dict = {}
try:
    spec2 = importlib.util.spec_from_file_location("base_run_searches", str(PROBE_DIR / "base_run_searches.py"))
    base_rs = importlib.util.module_from_spec(spec2)
    spec2.loader.exec_module(base_rs)
    fresh_dirs("base-rs")
    b_rows, b_stats, _ = native_collection(base_rs, notice_id="a" * 32,
                                           files=[public_file("b" * 32, "SOW.txt")],
                                           texts={"b" * 32: BIG.encode()})
    b_raw = b_rows[0].raw_payload if hasattr(b_rows[0], "raw_payload") else b_rows[0]["raw_payload"]
    b_ev = b_raw["attachment_evidence"][0]
    base_rs_info = {"evidence_keys": sorted(b_ev), "keys_with_trunc": [k for k in b_ev if "trunc" in k.lower()],
                    "has_extraction_limits": "extraction_limits" in b_ev,
                    "record_receipt_has_files": "files" in b_stats["attachment_record_receipts"]["a" * 32],
                    "combined_text_len": len(b_raw["text"])}
except Exception as exc:  # noqa: BLE001
    base_rs_info = {"error": f"{type(exc).__name__}: {str(exc)[:300]}"}
obs["D.base_run_searches"] = base_rs_info

# ---- E. consumers of file_text_truncated in the candidate tree ---------------
consumers = []
for path in REPO.rglob("*.py"):
    if ".venv" in path.parts:
        continue
    try:
        for n, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
            if "file_text_truncated" in line:
                consumers.append(f"{path.relative_to(REPO)}:{n}")
    except OSError:
        pass
obs["E.file_text_truncated_references"] = consumers
readers = [c for c in consumers if not c.startswith("run_searches.py") and "docs/verification" not in c]
check("E.no_downstream_reader_of_flag", readers == [], {"readers": readers})

# ---- F. doc disclosure sentences ---------------------------------------------
def grep(path: Path, pattern: str):
    hits = []
    for n, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
        if re.search(pattern, line):
            hits.append(f"{path.relative_to(REPO)}:{n}: {line.strip()}")
    return hits


docs = REPO / "docs"
obs["F.disclosures"] = {
    "LOCAL_VERIFICATION.residuals": grep(docs / "verification/step7-052/LOCAL_VERIFICATION.json",
                                         r"Character/page caps can omit later source text"),
    "FABLE_HANDOFF": grep(docs / "verification/step7-052/FABLE_HANDOFF.md", r"Bounded extraction can omit later text"),
    "CONVENTIONS_pdf_limits": grep(docs / "CONVENTIONS.md", r"PDF limits remain bounded extraction"),
    "CONTRACT_SURFACES_parse_limits": grep(docs / "CONTRACT_SURFACES.md", r"parse limits and"),
    "PRE_PATCH_mandate": grep(docs / "verification/step7-052/PRE_PATCH_REPORT.md", r"truncation and collection clocks explicit"),
    "CONVENTIONS_marks_prompt_truncation": grep(docs / "CONVENTIONS.md", r"marks prompt truncation"),
    "producer_probe_flag_semantics": grep(docs / "verification/step7-052/probe_text_boundaries.py", r"file_text_truncated"),
    "any_doc_defines_file_text_truncated": [
        h for p in [docs / "CONVENTIONS.md", docs / "CONTRACT_SURFACES.md",
                    *sorted((docs / "verification/step7-052").glob("*.md")),
                    *sorted((docs / "verification/step7-052").glob("*.json"))]
        for h in grep(p, r"file_text_truncated")],
}
check("F.cap_omission_disclosed", bool(obs["F.disclosures"]["LOCAL_VERIFICATION.residuals"])
      and bool(obs["F.disclosures"]["FABLE_HANDOFF"]))
check("F.no_doc_claims_flag_means_extractor_cap",
      obs["F.disclosures"]["any_doc_defines_file_text_truncated"] == [])

failed = [k for k, v in checks.items() if not v["ok"]]
obs["checks"] = checks
obs["failed_checks"] = failed
# INFO: member's mechanism reproduces, base had the identical cut with strictly
# less signal, the omission is disclosed in producer residuals; the naming nit
# has no downstream reader.
status = "INFO" if not failed else "FAIL"
print(json.dumps({"probe": "f14_scope", "status": status, "observed": obs},
                 indent=2, default=str, sort_keys=True))
