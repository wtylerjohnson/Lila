"""F-16 SCOPE/CLASSIFICATION refutation probe.

Question: is the merged F-16 finding (research_evidence labels an attachment
text only row 'stored_source_text' / can classify a vehicle_route claim as
'channel_fact'; golden_press notice_bridge requirement leg satisfiable by
attachment text alone) a NEW defect of the Step7 delta, PRE_EXISTING at base
2d522f0, a DISCLOSED residual, or a DOC overstatement?

Method (no network, no LLM):
  A. Produce an attachment-only row through the REAL candidate
     run_searches._enrich_sam_public_attachments (download + inventory mocked).
  B. Run agents.decisions.research_evidence at CANDIDATE and the BASE copy
     (git show 2d522f0:... written to ./base/) on the same row.
  C. Run tools.relevance.requirement_support at CANDIDATE and BASE copy on the
     exact `checked` shape notice_bridge.decision() builds.
  D. Run the FULL NoticeReadContext.decision() at CANDIDATE and BASE copy on a
     persisted synthetic Assess fixture whose only requirement language is in
     the attachment text; record admitted flag and gaps.
  E. Static: prove base run_searches wrote the same raw_payload["text"] key.
  F. Controls: same row with raw_payload.text removed.
Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

REPO = "/Users/wtjohnson/lila-step7-052"
HERE = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.join(HERE, "base")
if REPO not in sys.path:
    sys.path.insert(0, REPO)
os.chdir(REPO)


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]

TMP = tempfile.mkdtemp(prefix="f16-tmp-", dir=HERE)
os.environ["LILA_NOTICE_CACHE_DIR"] = os.path.join(TMP, "notice-cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(TMP, "text-cache")
os.makedirs(os.environ["LILA_NOTICE_CACHE_DIR"], exist_ok=True)
os.makedirs(os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"], exist_ok=True)

MARKER = "F16MARKER"
TEXT_1 = (f"{MARKER} SECTION C STATEMENT OF WORK. The contractor shall provide an "
          "enterprise packet capture platform for CISA network operations. "
          "The Government requires packet capture appliances at every site.")
TEXT_2 = (f"{MARKER} SECTION L. Offerors shall submit proposals via SAM.gov. "
          "This is a Combined Synopsis/Solicitation for packet capture.")
QUOTE_VEH = "This is a Combined Synopsis/Solicitation for packet capture."
QUOTE_REQ = "The contractor shall provide an enterprise packet capture platform for CISA network operations."
AS_OF = datetime(2026, 7, 10, 12, 0, tzinfo=timezone.utc)
LAWN = "The contractor shall provide lawn maintenance for the campus."

result = {"probe": "f16_scope", "status": "INFO", "observed": {}, "problems": []}
obs = result["observed"]


def load_base(name, rel):
    path = os.path.join(BASE_DIR, name)
    with open(path, "wb") as fh:
        fh.write(subprocess.run(["git", "-C", REPO, "show", f"2d522f0:{rel}"],
                                check=True, capture_output=True).stdout)
    spec = importlib.util.spec_from_file_location(name[:-3], path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name[:-3]] = mod
    spec.loader.exec_module(mod)
    return mod


def public_file(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


# ---------------------------------------------------------------- A. row
def enrich_row():
    import pytest
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.api import sam_attachment_text as sat
    from tools.api import sam_notice_detail as detail
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    mp = pytest.MonkeyPatch()
    mp.setattr("tools.api.sam_quota.calls_today", lambda: 0)
    files = [public_file("b" * 32, "SOW 1.txt"), public_file("c" * 32, "SOW 2.txt")]
    inventory = detail._manifest_hash(files)
    mp.setattr(detail, "fetch_notice_resources",
               lambda *a, **k: {"id": "N1", "resources_checked": True,
                                "attachments": files, "attachment_inventory_hash": inventory})
    texts = {"b" * 32: TEXT_1, "c" * 32: TEXT_2}
    mp.setattr(sat, "_download_bytes", lambda rid, **k: texts[rid].encode())
    candidate = RawOpportunity(source="sam.gov", source_id="N1", title="Lawn maintenance services",
                               agency="DHS", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term="packet capture")])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
    mp.undo()
    return rows[0], taxonomy


row, taxonomy = enrich_row()
raw = row["raw_payload"]
obs["enriched_row"] = {
    "raw_text_present": isinstance(raw.get("text"), str) and MARKER in raw["text"],
    "raw_keys_written": sorted(k for k in raw if k == "text" or k.startswith("attachment_")),
    "explicit_retrieval_status_or_evidence_status_written": any(
        k in raw for k in ("retrieval_status", "evidence_status", "attachment_text_authority")),
}
raw.update({"notice_id": "N1", "description_snippet": "Lawn maintenance services", "active": "Yes",
            "url": "https://sam.gov/opp/N1/view", "retrieved_at": "2026-07-10T11:00:00+00:00"})
row["api_url"] = "https://sam.gov/opp/N1/view"
row["response_deadline"] = "2026-08-01"
row["title"] = "Lawn maintenance services"

# ------------------------------------------------- B. research_evidence
from agents.decisions import research_evidence as re_cand  # noqa: E402
re_base = load_base("research_evidence_base.py", "agents/decisions/research_evidence.py")
for m in (re_base.EvidenceRef, re_base.ResearchClaim, re_base.EvidenceSource):
    m.model_rebuild()


def run_re(mod, the_row):
    src = mod.source_record("sam.gov", "results.sam.gov[0]", the_row)
    claims = [mod.ResearchClaim(kind=k, statement="x", evidence=[
        mod.EvidenceRef(source_id="N1", passage_id="raw_payload.text", quote=q)])
        for k, q in (("vehicle_route", QUOTE_VEH), ("procurement_state", QUOTE_REQ),
                     ("offering_fit", QUOTE_REQ), ("next_action", QUOTE_REQ))]
    checked = [mod.checked_claim(c, {"N1": src})[1] for c in claims]
    return {
        "retrieval_status": src.retrieval_status,
        "text_authority": src.passage_authority.get("raw_payload.text", {}).get("authority"),
        "text_passage_present": "raw_payload.text" in src.passages,
        "classification": mod.classification(src, claims, AS_OF, taxonomy),
        "current_notice": mod.current_notice(src, claims, AS_OF, taxonomy),
        "claim_prefix": mod.claim_text(claims[0], {"N1": src}).split(":")[0],
        "checked_claim_errors": checked,
    }


stripped = copy.deepcopy(row)
for k in list(stripped["raw_payload"]):
    if k == "text" or k.startswith("attachment_"):
        stripped["raw_payload"].pop(k)
obs["research_evidence"] = {
    "candidate": run_re(re_cand, row), "base": run_re(re_base, row),
    "control_no_text_candidate": run_re(re_cand, stripped),
}
obs["research_evidence"]["identical_base_candidate"] = (
    obs["research_evidence"]["candidate"] == obs["research_evidence"]["base"])

# ----------------------------------------------- C. requirement_support leg
from tools.relevance.requirement_support import requirement_support as rs_cand  # noqa: E402
rs_base_mod = load_base("requirement_support_base.py", "tools/relevance/requirement_support.py")
rs_base = rs_base_mod.requirement_support


def leg(fn, original, description):
    checked = copy.deepcopy(original)
    checked["description"] = description
    support = fn(checked, taxonomy)
    return {"requested_support": support.get("requested_support"), "state": support.get("state"),
            "span_fields": sorted({s["field"] for s in support.get("spans", [])}),
            "attachment_context_authority": (support.get("attachment_context") or {}).get("authority"),
            "qualification": support.get("qualification")}


obs["bridge_requirement_leg"] = {
    "candidate_with_text": leg(rs_cand, row, LAWN), "base_with_text": leg(rs_base, row, LAWN),
    "candidate_without_text": leg(rs_cand, stripped, LAWN),
}
obs["bridge_requirement_leg"]["identical_base_candidate"] = (
    obs["bridge_requirement_leg"]["candidate_with_text"] == obs["bridge_requirement_leg"]["base_with_text"])

# ---------------------------------------------- D. full NoticeReadContext
from tests.test_native_notice_bridge import original_fixture  # noqa: E402
from tests.test_assess_ledger import NOW  # noqa: E402
from agents.golden_press import notice_bridge as nb_cand  # noqa: E402
nb_base = load_base("notice_bridge_base.py", "agents/golden_press/notice_bridge.py")


def mutate(sweep):
    notice = sweep["results"]["sam.gov"][0]
    notice["title"] = "Lawn maintenance services"
    notice["raw_payload"]["description_snippet"] = "Lawn maintenance services"
    notice["raw_payload"].update({k: copy.deepcopy(v) for k, v in raw.items()
                                  if k == "text" or k.startswith("attachment_")})
    depth = sweep["results"]["dossiers"]["depth_records"][0]
    depth["title"] = "Lawn maintenance services"
    depth["source_depth"]["description"] = LAWN + " Submit proposals by August 1, 2026 at 17:00 UTC."


def full_decision(mod, label):
    root = Path(TMP) / label
    root.mkdir(parents=True, exist_ok=True)
    sweep = original_fixture(root, mutate)
    persisted_text = sweep["results"]["sam.gov"][0]["raw_payload"].get("text", "")
    ctx = mod.NoticeReadContext(root, "Testco", "testco", NOW)
    dec = ctx.decision({"record_id": "N1"})
    return {
        "context_gaps": ctx.gaps, "parents": sorted(ctx.parents),
        "fixture_row_has_marker_text": MARKER in persisted_text,
        "admitted": dec["admitted"], "gaps": dec["gaps"],
        "requirement_leg_gap_present": "Original source does not establish requested capability work" in dec["gaps"],
        "assess_leg_gap_present": "No current bound Assess BID_NOW/PURSUE requirement approval" in dec["gaps"],
        "requirement_block": {
            "requested_support": (dec.get("requirement") or {}).get("requested_support"),
            "span_fields": sorted({s["field"] for s in (dec.get("requirement") or {}).get("spans", [])}),
            "attachment_context_authority": ((dec.get("requirement") or {}).get("attachment_context") or {}).get("authority"),
            "qualification": (dec.get("requirement") or {}).get("qualification"),
        },
        "response_action_supported": (dec.get("response_action") or {}).get("supported"),
    }


try:
    obs["full_bridge"] = {"candidate": full_decision(nb_cand, "cand"), "base": full_decision(nb_base, "base")}
    obs["full_bridge"]["identical_base_candidate"] = obs["full_bridge"]["candidate"] == obs["full_bridge"]["base"]
except Exception as exc:  # noqa: BLE001
    obs["full_bridge"] = {"error": f"{type(exc).__name__}: {exc}"}
    result["problems"].append("full bridge decision could not be driven; see error")

# ------------------------------------------------------ E. static base grep
base_rs = subprocess.run(["git", "-C", REPO, "show", "2d522f0:run_searches.py"],
                         check=True, capture_output=True, text=True).stdout
diffstat = subprocess.run(["git", "-C", REPO, "diff", "--stat", "2d522f0..6b51f00", "--",
                           "agents/decisions/research_evidence.py", "agents/golden_press/notice_bridge.py",
                           "tools/relevance/requirement_support.py", "tools/relevance/engine.py",
                           "agents/assess", "agents/decisions/research_picture.py"],
                          check=True, capture_output=True, text=True).stdout.strip()
obs["static"] = {
    "base_run_searches_writes_raw_text": 'raw["text"] = combined_text' in base_rs,
    "consumer_diffstat_base_to_candidate": diffstat or "(no changes)",
}
for rel in ("agents/decisions/research_evidence.py", "agents/golden_press/notice_bridge.py",
            "tools/relevance/requirement_support.py"):
    base_bytes = subprocess.run(["git", "-C", REPO, "show", f"2d522f0:{rel}"], check=True,
                                capture_output=True).stdout
    obs["static"][f"byte_identical:{rel}"] = base_bytes == Path(REPO, rel).read_bytes()

# ------------------------------------------------------ F. disclosure grep
hits = {}
docdir = Path(REPO, "docs/verification/step7-052")
for p in sorted(docdir.glob("*")):
    if p.suffix in {".md", ".json"}:
        txt = p.read_text(errors="replace")
        found = [w for w in ("research_evidence", "stored_source_text", "channel_fact", "notice_bridge",
                             "requirement leg", "Research Picture") if w in txt]
        if found:
            hits[p.name] = found
obs["disclosure_grep_step7_docs"] = hits or "no step7-052 doc names research_evidence/stored_source_text/channel_fact/notice_bridge"

# ----------------------------------------------------------------- verdict
re_o, leg_o, fb = obs["research_evidence"], obs["bridge_requirement_leg"], obs.get("full_bridge", {})
finding_reproduced = (re_o["candidate"]["retrieval_status"] == "stored_source_text"
                      and re_o["candidate"]["classification"] == "channel_fact"
                      and re_o["candidate"]["text_authority"] == "discovery_only"
                      and leg_o["candidate_with_text"]["requested_support"] is True
                      and leg_o["candidate_with_text"]["span_fields"] == ["raw_payload.text"])
pre_existing = (re_o["identical_base_candidate"] and leg_o["identical_base_candidate"]
                and obs["static"]["base_run_searches_writes_raw_text"]
                and all(v for k, v in obs["static"].items() if k.startswith("byte_identical")))
boundary_holds = (re_o["candidate"]["current_notice"] is False
                  and re_o["candidate"]["claim_prefix"] == "Discovery excerpt (not requirement approval)"
                  and (not isinstance(fb.get("candidate"), dict) or (
                      fb["candidate"]["admitted"] is False and fb["candidate"]["assess_leg_gap_present"])))
obs["verdict_inputs"] = {"finding_reproduced_at_candidate": finding_reproduced,
                         "identical_at_base": pre_existing, "trust_boundary_holds": boundary_holds}
if not finding_reproduced:
    result["status"] = "FAIL"
    result["problems"].append("member observation did not reproduce at candidate")
elif not pre_existing:
    result["status"] = "FAIL"
    result["problems"].append("behaviour differs at base: not pre_existing")
elif not boundary_holds:
    result["status"] = "FAIL"
    result["problems"].append("trust boundary breached: discovery text reached a trusted surface")
else:
    result["status"] = "INFO"
    result["classification"] = "pre_existing"

shutil.rmtree(TMP, ignore_errors=True)
print(json.dumps(result, indent=1, default=str, ensure_ascii=False))
