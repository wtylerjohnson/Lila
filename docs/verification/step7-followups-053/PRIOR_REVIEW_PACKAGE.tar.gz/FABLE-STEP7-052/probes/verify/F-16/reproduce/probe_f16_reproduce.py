"""Independent reproduction of merged finding F-16 (members AAP-2, AAP-3, AAP-4, AAP-5).

Written from the finding text only, before reading any member probe script.
Read-only against the review clone; all scratch state lives under this file's directory.
No network (socket.connect is blocked), no LLM calls, no pkill.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/wtjohnson/lila-step7-052')
BASE = '2d522f0362e656e029986344d47e2e06b86a58f8'
sys.path.insert(0, str(REPO))
os.chdir(REPO)

SCRATCH = Path(tempfile.mkdtemp(prefix='f16-', dir=HERE))
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(SCRATCH / 'attachment_text')
os.environ['LILA_NOTICE_CACHE_DIR'] = str(SCRATCH / 'notice_cache')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'


def _no_network(*args, **kwargs):
    raise RuntimeError('network blocked by probe')


socket.socket.connect = _no_network  # type: ignore[assignment]
socket.socket.connect_ex = _no_network  # type: ignore[assignment]

observed: dict = {'checks': {}}
checks = observed['checks']


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def base_file(rel: str) -> Path:
    out = HERE / 'base_files' / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    data = subprocess.run(['git', '-C', str(REPO), 'show', f'{BASE}:{rel}'],
                          check=True, capture_output=True).stdout
    out.write_bytes(data)
    return out


NID = 'a' * 32
ATTACHMENT_TEXT = ('The contractor shall provide packet capture appliances for the '
                   'agency network. Orders will be placed against the NASA SEWP V vehicle.')

# ---------------------------------------------------------------- Part A: AAP-2
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

TAX = CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-10',
                         core=[TaxonomyTerm(term='packet capture')])


def public_file(resource_id, name):
    return {'resource_id': resource_id, 'name': name, 'access_level': 'public',
            'access_status': 'public', 'export_controlled': '0', 'explicit_access': '0'}


files = [public_file('b' * 32, 'SOW.txt')]
inventory = detail._manifest_hash(files)
sam_quota.calls_today = lambda: 0
detail.fetch_notice_resources = lambda *a, **k: {
    'id': NID, 'resources_checked': True, 'attachments': files,
    'attachment_inventory_hash': inventory}
sat._download_bytes = lambda rid, **k: ATTACHMENT_TEXT.encode()
candidate = RawOpportunity(source='sam.gov', source_id=NID, title='Requirement',
                           agency='NASA', api_url=f'https://sam.gov/opp/{NID}/view',
                           raw_payload={'type': 'Solicitation', 'active': 'Yes',
                                        'notice_id': NID})


class Source:
    last_attachment_census = {'selected': 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


rows, stats = searches._enrich_sam_public_attachments(
    [], Source(), object(), TAX, None, limit=8)
row = rows[0]
raw = row['raw_payload']
checks['A0_enrichment_status'] = stats['attachment_record_receipts'][NID]['status']
checks['A0_row_text_keys_present'] = sorted(
    k for k in ('description', 'description_snippet', 'full_text', 'text',
                'source_depth', 'full_description', 'summary')
    if k in row or k in raw)
checks['A0_supplied_status_keys'] = sorted(
    k for k in ('retrieval_status', 'evidence_status') if k in row or k in raw)
checks['A0_attachment_text_authority_key'] = raw.get('attachment_text_authority')
checks['A0_attachment_evidence_authority'] = [e.get('authority') for e in raw.get('attachment_evidence', [])]
checks['A0_collection_authority'] = (raw.get('attachment_collection_v1') or {}).get('authority')

from datetime import datetime, timezone  # noqa: E402

from agents.decisions import research_evidence as re_mod  # noqa: E402

AS_OF = datetime(2026, 7, 10, 12, 0, tzinfo=timezone.utc)
source = re_mod.source_record('sam.gov', 'sam.gov[0]', row)
checks['A1_retrieval_status'] = source.retrieval_status
checks['A1_passage_fields'] = sorted(source.passages)
checks['A1_text_authority'] = source.passage_authority.get('raw_payload.text', {}).get('authority')
checks['A1_primary_notice'] = source.primary_notice
checks['A1_binding_issues'] = source.binding_issues

claim = re_mod.ResearchClaim(
    kind='vehicle_route', statement='Orders ride NASA SEWP V.', basis='source_fact',
    evidence=[re_mod.EvidenceRef(source_id=source.source_id, passage_id='raw_payload.text',
                                 quote='NASA SEWP V')])
checked, issue = re_mod.checked_claim(claim, {source.source_id: source})
checks['A2_checked_claim_issue'] = issue
checks['A2_classification'] = re_mod.classification(source, [claim], AS_OF, TAX)
checks['A2_current_notice'] = re_mod.current_notice(source, [claim], AS_OF, TAX)
checks['A2_claim_text_prefix'] = re_mod.claim_text(claim, {source.source_id: source}).split(':')[0]

# Control: same row but the passage is a trusted description instead of attachment text.
control = deepcopy(row)
control['raw_payload'].pop('text')
control['raw_payload']['description'] = ATTACHMENT_TEXT
ctl = re_mod.source_record('sam.gov', 'sam.gov[0]', control)
checks['A3_control_description_status'] = ctl.retrieval_status
# Control: row with neither description nor text.
bare = deepcopy(row)
bare['raw_payload'].pop('text')
checks['A3_control_no_text_status'] = re_mod.source_record('sam.gov', 'sam.gov[0]', bare).retrieval_status
# Does the registry path change the status?
registry, gaps = re_mod.build_registry({'sam.gov': [row]}, {'pursue_notices': [{'id': NID}]})
checks['A4_registry_status'] = {k: v.retrieval_status for k, v in registry.items()}
checks['A4_registry_gaps'] = gaps

# Base comparison for research_evidence.py
base_re = base_file('agents/decisions/research_evidence.py')
checks['A5_research_evidence_identical_to_base'] = sha(base_re) == sha(REPO / 'agents/decisions/research_evidence.py')
spec = importlib.util.spec_from_file_location('base_research_evidence', base_re)
base_mod = importlib.util.module_from_spec(spec)
sys.modules['base_research_evidence'] = base_mod
spec.loader.exec_module(base_mod)
base_mod.EvidenceRef.model_rebuild()
base_mod.ResearchClaim.model_rebuild()
base_mod.EvidenceSource.model_rebuild()
bsrc = base_mod.source_record('sam.gov', 'sam.gov[0]', row)
bclaim = base_mod.ResearchClaim(
    kind='vehicle_route', statement='x', basis='source_fact',
    evidence=[base_mod.EvidenceRef(source_id=bsrc.source_id, passage_id='raw_payload.text', quote='NASA SEWP V')])
checks['A5_base_retrieval_status'] = bsrc.retrieval_status
checks['A5_base_classification'] = base_mod.classification(bsrc, [bclaim], AS_OF, TAX)

# ---------------------------------------------------------------- Part B: AAP-3
from agents.golden_press.notice_bridge import NoticeReadContext  # noqa: E402
from tests.test_assess_ledger import NOW  # noqa: E402
from tests.test_native_notice_bridge import original_fixture  # noqa: E402

IRRELEVANT_DEPTH = ('This notice concerns landscaping services at the facility. '
                    'Submit proposals by August 1, 2026 at 17:00 UTC.')


def bridge_case(name, *, with_text):
    root = SCRATCH / f'bridge_{name}'
    root.mkdir(parents=True)

    def mutate(sweep):
        notice = sweep['results']['sam.gov'][0]
        sweep['results']['dossiers']['depth_records'][0]['source_depth']['description'] = IRRELEVANT_DEPTH
        if with_text:
            notice['raw_payload']['text'] = ATTACHMENT_TEXT
            notice['raw_payload']['attachment_evidence'] = [{
                'resource_id': 'b' * 32, 'name': 'SOW.txt', 'authority': 'discovery_only'}]
    original_fixture(root, mutate)
    context = NoticeReadContext(root, 'Testco', 'testco', NOW)
    decision = context.decision({'record_id': 'N1'})
    support = decision.get('requirement') or {}
    return {
        'context_gaps': context.gaps,
        'admitted': decision['admitted'],
        'requested_support': support.get('requested_support'),
        'requested_support_not_true': support.get('requested_support') is not True,
        'support_state': support.get('state'),
        'span_fields': sorted({s['field'] for s in support.get('spans', [])}),
        'span_roles': sorted({s['role'] for s in support.get('spans', [])}),
        'requirement_leg_gap_present': 'Original source does not establish requested capability work' in decision['gaps'],
        'assess_leg_gap_present': 'No current bound Assess BID_NOW/PURSUE requirement approval' in decision['gaps'],
        'gaps': decision['gaps'],
    }


checks['B1_bridge_with_attachment_text'] = bridge_case('with_text', with_text=True)
checks['B2_bridge_without_attachment_text'] = bridge_case('without_text', with_text=False)
# Positive control: relevant depth, no attachment text (fixture default) admits.
root_ctl = SCRATCH / 'bridge_control'
root_ctl.mkdir(parents=True)
original_fixture(root_ctl)
ctl_ctx = NoticeReadContext(root_ctl, 'Testco', 'testco', NOW)
ctl_dec = ctl_ctx.decision({'record_id': 'N1'})
checks['B3_bridge_positive_control'] = {'admitted': ctl_dec['admitted'], 'gaps': ctl_dec['gaps'],
                                        'context_gaps': ctl_ctx.gaps}
# Hostile: relevant depth AND attachment text, is anything about admission changed by text?
root_both = SCRATCH / 'bridge_both'
root_both.mkdir(parents=True)


def mutate_both(sweep):
    notice = sweep['results']['sam.gov'][0]
    notice['raw_payload']['text'] = ATTACHMENT_TEXT


original_fixture(root_both, mutate_both)
both_ctx = NoticeReadContext(root_both, 'Testco', 'testco', NOW)
both_dec = both_ctx.decision({'record_id': 'N1'})
checks['B4_bridge_relevant_depth_plus_text'] = {
    'admitted': both_dec['admitted'], 'gaps': both_dec['gaps'],
    'span_fields': sorted({s['field'] for s in (both_dec.get('requirement') or {}).get('spans', [])})}
for rel in ('agents/golden_press/notice_bridge.py', 'tools/relevance/requirement_support.py'):
    checks[f'B5_identical_to_base:{rel}'] = sha(base_file(rel)) == sha(REPO / rel)

# ---------------------------------------------------------------- Part C: AAP-4
from tests.test_assess_ledger import _build, _build_with_requirement_review, _depth_record, _sweep  # noqa: E402

sweep_c = _sweep()
depth_c = _depth_record()
depth_c['source_depth']['description'] = ATTACHMENT_TEXT  # a producer copies attachment text into depth
sweep_c['results']['dossiers'] = {'depth_records': [depth_c]}
proposed, _, _ = _build(sweep_c)
rec = next(r for r in proposed.live.records if r.notice_id == 'N1')
checks['C1_depth_copy_no_review'] = {'classification': rec.classification.value,
                                     'excerpt_from_copy': bool(rec.requirement_excerpt) and rec.requirement_excerpt in ATTACHMENT_TEXT}
reviewed, _, _ = _build_with_requirement_review(sweep_c)
rec2 = next(r for r in reviewed.live.records if r.notice_id == 'N1')
checks['C2_depth_copy_with_review'] = {'classification': rec2.classification.value,
                                       'recommendation': rec2.recommendation.value}
# Counter-check: attachment text on the census row WITHOUT depth never mints an excerpt or approval.
sweep_d = _sweep()
sweep_d['results']['sam.gov'][0]['raw_payload']['text'] = ATTACHMENT_TEXT
sweep_d['results']['sam.gov'][0]['raw_payload']['description_snippet'] = 'Facility services'
sweep_d['results']['sam.gov'][0]['title'] = 'Facility services'
proposed_d, _, _ = _build(sweep_d)
rec_d = next(r for r in proposed_d.live.records if r.notice_id == 'N1')
checks['C3_row_text_only_no_depth'] = {'classification': rec_d.classification.value,
                                       'requirement_excerpt': rec_d.requirement_excerpt}
for rel in ('agents/assess/ledger.py',):
    checks[f'C4_identical_to_base:{rel}'] = sha(base_file(rel)) == sha(REPO / rel)

# ---------------------------------------------------------------- Part D: AAP-5
from tools.relevance.engine import record_text_fields, score_record  # noqa: E402
from tools.relevance.requirement_support import requirement_support  # noqa: E402

checks['D1_record_text_fields_has_raw_text'] = 'raw_payload.text' in dict(record_text_fields(row))
verdict = score_record(row, TAX)
checks['D1_score_relevant'] = verdict.relevant
sup = requirement_support(row, TAX)
checks['D1_requirement_support'] = {'requested_support': sup['requested_support'], 'state': sup['state'],
                                    'fields': sorted({s['field'] for s in sup['spans']}),
                                    'attachment_authority': sup['attachment_context']['authority'],
                                    'qualification': sup['qualification']}
from agents.decisions.triage import deterministic_prefilter  # noqa: E402

eligible, screenings, _ = deterministic_prefilter([row], TAX)
checks['D2_prefilter_eligible_ids'] = [r.get('source_id') for r in eligible]
scr = screenings.get(NID) or {}
checks['D2_prefilter_screen_state'] = scr.get('screen_state')
for rel in ('tools/relevance/engine.py', 'agents/decisions/triage.py'):
    checks[f'D3_identical_to_base:{rel}'] = sha(base_file(rel)) == sha(REPO / rel)

# ---------------------------------------------------------------- verdict
expect = {
    'A1_retrieval_status': 'stored_source_text',
    'A1_text_authority': 'discovery_only',
    'A2_classification': 'channel_fact',
    'A2_current_notice': False,
    'A5_research_evidence_identical_to_base': True,
    'A5_base_classification': 'channel_fact',
    'C2_depth_copy_with_review.classification': 'bid_now',
    'B1_bridge_with_attachment_text.requested_support': True,
    'B1_bridge_with_attachment_text.requirement_leg_gap_present': False,
    'B1_bridge_with_attachment_text.assess_leg_gap_present': True,
    'B1_bridge_with_attachment_text.admitted': False,
    'B2_bridge_without_attachment_text.requested_support_not_true': True,
    'B2_bridge_without_attachment_text.requirement_leg_gap_present': True,
    'B5_identical_to_base:agents/golden_press/notice_bridge.py': True,
    'D1_record_text_fields_has_raw_text': True,
}


def get(path):
    if path in checks:
        return checks[path]
    head, *rest = path.split('.')
    value = checks.get(head)
    for part in rest:
        value = (value or {}).get(part)
    return value


mismatches = {k: {'expected': v, 'observed': get(k)} for k, v in expect.items() if get(k) != v}
observed['mismatches'] = mismatches
observed['scratch_removed'] = False
shutil.rmtree(SCRATCH, ignore_errors=True)
observed['scratch_removed'] = not SCRATCH.exists()
# FAIL here means the finding reproduced (defect/overstatement demonstrated against the candidate).
status = 'FAIL' if not mismatches else 'INFO'
print(json.dumps({'status': status, 'finding': 'F-16', 'members': ['AAP-2', 'AAP-3', 'AAP-4', 'AAP-5'],
                  'observed': observed}, indent=2, default=str))
