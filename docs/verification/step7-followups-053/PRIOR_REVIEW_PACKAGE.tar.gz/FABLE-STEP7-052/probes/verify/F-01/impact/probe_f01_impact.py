"""F-01 IMPACT probe: where does a retention (custody) failure actually flow?

Runs the real run_searches._enrich_sam_public_attachments with the real
fetch_notice_resources / extract_public_attachment_text against an httpx
MockTransport (no socket), under six storage conditions, then traces each
outcome through: run_searches receipts, the saved-sweep row, the dossier
research context, the triage deterministic prefilter, the strict Assess
build (tests.test_assess_ledger._sweep/_build), and the Assess-trusted
fetch_notice_depth lane that shares the same cache directory.

Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import errno
import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import types
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
PROBE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
os.chdir(REPO)
os.environ.setdefault("LILA_SUITE_OFFLINE", "1")

import httpx  # noqa: E402

# Hard network block: any real connect attempt is a probe failure.
def _no_connect(*_a, **_k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

from tools.api import _http, sam_capture, sam_attachment_text as sat, sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402
from agents.decisions.triage import deterministic_prefilter  # noqa: E402

NOTICE = "a" * 32
FILE_ID = "b" * 32
TERM = "packet capture"
FILE_BYTES = b"\xef\xbb\xbfBuyer requires packet capture across the enclave.   \n\n"
INVENTORY_BODY = json.dumps({"attachments": [
    {"name": "SOW.txt", "resourceId": FILE_ID, "accessLevel": "public",
     "accessStatus": "public", "exportControlled": "0", "explicitAccess": "0"}
]}).encode()

sam_quota.calls_today = lambda: 0  # type: ignore[assignment]

BASE_SHA = "2d522f0362e656e029986344d47e2e06b86a58f8"


def load_base_module(rel_path: str, name: str):
    src = subprocess.run(["git", "-C", str(REPO), "show", f"{BASE_SHA}:{rel_path}"],
                         check=True, capture_output=True).stdout
    target = PROBE_DIR / f"base_{Path(rel_path).name}"
    target.write_bytes(src)
    spec = importlib.util.spec_from_file_location(name, target)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class Http:
    def __init__(self):
        self.calls: list[str] = []
        self.native = _http._request

    def install(self, body=INVENTORY_BODY, status=200):
        def handler(request):
            self.calls.append(str(request.url))
            return httpx.Response(status, content=body)
        _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
        _http._request = self.native


HTTP = Http()
HTTP.install()

downloads: list[str] = []
def fake_download(rid, **_k):
    downloads.append(rid)
    return FILE_BYTES
sat._download_bytes = fake_download  # type: ignore[assignment]


def taxonomy():
    return CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


def candidate_row():
    return RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                          agency="NASA", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}
    def __init__(self, cand): self.cand = cand
    def attachment_candidates(self, *a, **k): return [self.cand]


@contextmanager
def cache_dirs():
    with tempfile.TemporaryDirectory(dir=PROBE_DIR) as ndir, tempfile.TemporaryDirectory(dir=PROBE_DIR) as tdir:
        os.environ["LILA_NOTICE_CACHE_DIR"] = ndir
        os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = tdir
        yield Path(ndir), Path(tdir)


def poison(directory: Path, payload: bytes):
    digest = hashlib.sha256(payload).hexdigest()
    (directory / "objects").mkdir(parents=True, exist_ok=True)
    (directory / "objects" / f"{digest}.bin").write_bytes(b"POISON " + digest.encode()[:8])
    return digest


def run_stage(sam_rows: list[dict]):
    HTTP.calls.clear(); downloads.clear()
    cand = candidate_row()
    rows, stats = searches._enrich_sam_public_attachments(
        sam_rows, Source(cand), object(), taxonomy(), None, limit=8)
    return rows, stats


def receipt_view(stats):
    rec = stats["attachment_record_receipts"][NOTICE]
    inv = rec.get("inventory_receipt") or {}
    return {
        "status": rec.get("status"),
        "inventory_collection_status": inv.get("collection_status"),
        "inventory_has_raw_capture": bool(inv.get("raw_capture")),
        "errors": rec.get("errors"),
        "files": [{k: r.get(k) for k in ("resource_id", "status", "reason", "collection_status")}
                  for r in rec.get("files") or []],
        "attachment_added": stats["attachment_added"],
        "attachment_relevant": stats["attachment_relevant"],
        "stage_errors": stats["attachment_errors"],
        "http_calls": len(HTTP.calls), "downloads": len(downloads),
    }


def row_view(rows):
    if not rows:
        return {"rows": 0}
    raw = rows[0].get("raw_payload") or {}
    return {"rows": len(rows),
            "has_collection_v1": "attachment_collection_v1" in raw,
            "has_text": bool(raw.get("text")),
            "attachment_relevance": (raw.get("attachment_relevance") or {}).get("relevant"),
            "source_depth_in_raw": "source_depth" in raw,
            "full_description_in_raw": "full_description" in raw}


def dossier_view(rows, inventory_hash):
    if not rows:
        return {"attachment_research": None, "reason": "no row was added by the attachment stage"}
    ctx = _attachment_research_context(rows[0], {"id": NOTICE, "resources_checked": True,
                                                  "attachment_inventory_hash": inventory_hash})
    if ctx is None:
        return {"attachment_research": None}
    return {"attachment_research": ctx.get("status"),
            "passages": len(ctx.get("file_passages") or []),
            "reason": ctx.get("reason")}


def triage_view(rows, stats, original):
    notices = rows or [json.loads(original.model_dump_json())]
    model, verdicts, receipt = deterministic_prefilter(
        notices, taxonomy(), engagement_scope=None,
        attachment_receipts=stats["attachment_record_receipts"])
    screen = (receipt.get("screening") or receipt.get("screening_records") or {})
    state = None
    for k, v in (screen.items() if isinstance(screen, dict) else []):
        if k == NOTICE and isinstance(v, dict):
            state = v.get("screen_state")
    if state is None:
        def find(o):
            if isinstance(o, dict):
                if o.get("source_id") == NOTICE and "screen_state" in o:
                    return o["screen_state"]
                for v in o.values():
                    r = find(v)
                    if r: return r
            elif isinstance(o, list):
                for v in o:
                    r = find(v)
                    if r: return r
            return None
        state = find(receipt)
    return {"in_model_lane": any(str(n.get("source_id")) == NOTICE for n in model),
            "screen_state": state}


def assess_view(rows):
    from tests.test_assess_ledger import _sweep, _build
    from agents.assess.contracts import LiveClassification
    sweep = _sweep()
    original = sweep["results"]["sam.gov"][0]
    original["source_id"] = NOTICE
    original["raw_payload"]["notice_id"] = NOTICE
    original["api_url"] = f"https://sam.gov/opp/{NOTICE}/view"
    sweep["results"]["triage"][NOTICE] = sweep["results"]["triage"].pop("N1")
    if rows:
        original["raw_payload"].update(rows[0]["raw_payload"])
    run, diagnostics, index = _build(sweep)
    parent = next(r for r in run.live.records if r.notice_id == NOTICE)
    return {"classification": str(parent.classification),
            "is_bid_now": parent.classification == LiveClassification.BID_NOW,
            "requirement_reviewed_at": parent.requirement_reviewed_at,
            "attachment_gap": parent.attachment_gap,
            "attachment_inventory_count": parent.attachment_inventory_count}


def depth_lane_view():
    """Assess-trusted lane (fetch_notice_depth, keyless path) in the SAME cache dir."""
    HTTP.calls.clear()
    # Placeholder string only: sockets are blocked, MockTransport answers, and
    # the quota ledger write is disabled so nothing touches the review clone.
    sam_quota.note_call = lambda *a, **k: None  # type: ignore[assignment]
    out = detail.fetch_notice_depth(NOTICE, api_key="probe-dummy-key")
    return {"resources_checked": out.get("resources_checked"),
            "attachment_inventory_count": out.get("attachment_inventory_count"),
            "errors": out.get("errors"), "http_calls": len(HTTP.calls)}


def scenario(name, setup, sam_rows=None, base_detail=None):
    with cache_dirs() as (ndir, tdir):
        setup(ndir, tdir)
        cand = candidate_row()
        rows, stats = run_stage(list(sam_rows or []))
        inventory_hash = detail._manifest_hash(detail._attachment_inventory(json.loads(INVENTORY_BODY), NOTICE)[0])
        result = {
            "receipt": receipt_view(stats),
            "row": row_view(rows),
            "dossier": dossier_view(rows, inventory_hash),
            "triage": triage_view(rows, stats, cand),
            "assess": assess_view(rows),
            "depth_lane_same_cache": depth_lane_view(),
            "objects_in_notice_cache": sorted(p.name for p in (ndir / "objects").glob("*")) if (ndir / "objects").exists() else [],
            "resources_json_written": (ndir / f"{NOTICE}.resources.json").exists(),
        }
        # second sweep on the same cache dir: does it self-heal or refetch?
        rows2, stats2 = run_stage(list(sam_rows or []))
        result["second_sweep"] = {"status": stats2["attachment_record_receipts"][NOTICE].get("status"),
                                  "http_calls": len(HTTP.calls), "downloads": len(downloads),
                                  "attachment_added": stats2["attachment_added"]}
        if base_detail is not None:
            HTTP.calls.clear()
            b = base_detail.fetch_notice_resources(NOTICE)
            result["base_inventory"] = {"resources_checked": b.get("resources_checked"),
                                        "count": b.get("attachment_inventory_count"),
                                        "errors": b.get("errors")}
        return name, result


def main():
    base_detail = load_base_module("tools/api/sam_notice_detail.py", "base_sam_notice_detail")
    base_sat = load_base_module("tools/api/sam_attachment_text.py", "base_sam_attachment_text")
    base_sat._download_bytes = fake_download

    text_of_file = sat._text_from_bytes("SOW.txt", FILE_BYTES)
    text_digest = hashlib.sha256(text_of_file.encode("utf-8")).hexdigest()
    raw_digest = hashlib.sha256(FILE_BYTES).hexdigest()

    results = {}
    checks = {}

    # S0 healthy
    n, r = scenario("S0_healthy", lambda nd, td: None, base_detail=base_detail)
    results[n] = r
    checks["s0_row_added_and_bound"] = r["receipt"]["status"] == "DISCOVERY_TEXT_CAPTURED" and r["row"]["has_collection_v1"] and r["dossier"]["attachment_research"] == "discovery_only"
    checks["s0_assess_never_bid_now_even_when_healthy"] = (not r["assess"]["is_bid_now"]) and r["assess"]["requirement_reviewed_at"] is None and bool(r["assess"]["attachment_gap"])
    checks["s0_second_sweep_served_from_cache"] = r["second_sweep"]["http_calls"] == 0 and r["second_sweep"]["downloads"] == 0

    # S1 poisoned inventory blob under the true digest
    n, r = scenario("S1_poisoned_inventory_blob", lambda nd, td: poison(nd, INVENTORY_BODY), base_detail=base_detail)
    results[n] = r
    checks["s1_inventory_lookup_failed"] = r["receipt"]["status"] == "INVENTORY_UNAVAILABLE" and r["receipt"]["inventory_collection_status"] == "lookup_failed"
    checks["s1_error_text_names_true_cause"] = any("retained SAM bytes changed" in e for e in r["receipt"]["errors"] or [])
    checks["s1_no_row_added_yield_loss"] = r["row"]["rows"] == 0 and r["receipt"]["attachment_added"] == 0
    checks["s1_no_wrong_evidence_in_dossier"] = r["dossier"]["attachment_research"] is None
    checks["s1_assess_identical_to_healthy"] = r["assess"] == results["S0_healthy"]["assess"]
    checks["s1_depth_lane_unaffected_by_poison"] = r["depth_lane_same_cache"]["resources_checked"] is True and r["depth_lane_same_cache"]["attachment_inventory_count"] == 1
    checks["s1_refetches_every_sweep_no_self_heal"] = r["second_sweep"]["status"] == "INVENTORY_UNAVAILABLE" and r["second_sweep"]["http_calls"] >= 1
    checks["s1_base_would_have_returned_inventory"] = r["base_inventory"]["resources_checked"] is True

    # S2 poisoned raw file blob
    n, r = scenario("S2_poisoned_file_raw_blob", lambda nd, td: poison(td, FILE_BYTES))
    results[n] = r
    f = r["receipt"]["files"][0] if r["receipt"]["files"] else {}
    checks["s2_file_lookup_failed_with_true_cause"] = f.get("status") == "lookup_failed" and "retained SAM bytes changed" in str(f.get("reason"))
    checks["s2_receipt_text_unavailable_no_row"] = r["receipt"]["status"] == "TEXT_UNAVAILABLE" and r["row"]["rows"] == 0
    checks["s2_assess_identical_to_healthy"] = r["assess"] == results["S0_healthy"]["assess"]

    # S3 poisoned text blob (raw retain succeeds, text retain fails after a good parse)
    n, r = scenario("S3_poisoned_text_blob", lambda nd, td: poison(td, text_of_file.encode("utf-8")))
    results[n] = r
    results[n]["digests_distinct"] = text_digest != raw_digest
    f = r["receipt"]["files"][0] if r["receipt"]["files"] else {}
    checks["s3_text_and_raw_digests_distinct"] = text_digest != raw_digest
    checks["s3_status_unreadable_though_parse_succeeded"] = f.get("status") == "unreadable" and "retained SAM bytes changed" in str(f.get("reason"))
    checks["s3_no_row_added"] = r["row"]["rows"] == 0

    # S4 no hardlink support
    real_link = os.link
    def no_link(*a, **k):
        raise OSError(errno.ENOTSUP, "Operation not supported (probe: no hardlinks)")
    def setup_nolink(nd, td):
        os.link = no_link
    try:
        n, r = scenario("S4_no_hardlink_support", setup_nolink, base_detail=base_detail)
    finally:
        os.link = real_link
    results[n] = r
    checks["s4_inventory_lookup_failed_no_row"] = r["receipt"]["status"] == "INVENTORY_UNAVAILABLE" and r["row"]["rows"] == 0
    checks["s4_error_text_names_filesystem"] = any("Operation not supported" in e for e in r["receipt"]["errors"] or [])
    checks["s4_base_inventory_ok_without_hardlinks"] = r["base_inventory"]["resources_checked"] is True
    checks["s4_assess_identical_to_healthy"] = r["assess"] == results["S0_healthy"]["assess"]
    checks["s4_depth_lane_unaffected"] = r["depth_lane_same_cache"]["resources_checked"] is True

    # S5 disk full during retention fsync (inventory path) : compare base inventory and base text
    real_fsync = os.fsync
    def full_fsync(fd):
        raise OSError(errno.ENOSPC, "No space left on device (probe)")
    def setup_full(nd, td):
        os.fsync = full_fsync
    try:
        n, r = scenario("S5_disk_full_fsync", setup_full, base_detail=base_detail)
        # base text path under the same fault
        with cache_dirs() as (nd, td):
            bt = base_sat.extract_public_attachment_text(
                {"resource_id": FILE_ID, "name": "SOW.txt", "access_level": "public",
                 "access_status": "public", "export_controlled": "0", "explicit_access": "0"})
    finally:
        os.fsync = real_fsync
    results[n] = r
    results[n]["base_text_under_disk_full"] = {"text_len": len(bt.get("text") or ""), "error": bt.get("error")}
    checks["s5_candidate_inventory_lookup_failed"] = r["receipt"]["status"] == "INVENTORY_UNAVAILABLE"
    checks["s5_error_text_names_enospc"] = any("No space left" in e for e in r["receipt"]["errors"] or [])
    checks["s5_base_inventory_returned_with_error"] = r["base_inventory"]["resources_checked"] is True and bool(r["base_inventory"]["errors"])
    checks["s5_base_text_ALSO_dropped_pre_existing"] = (bt.get("text") or "") == ""
    checks["s5_assess_identical_to_healthy"] = r["assess"] == results["S0_healthy"]["assess"]

    # S6 stale window: healthy cache first, then blob corrupted; then clock moved 8 days
    with cache_dirs() as (nd, td):
        run_stage([])
        digest = hashlib.sha256(INVENTORY_BODY).hexdigest()
        (nd / "objects" / f"{digest}.bin").write_bytes(b"CORRUPT")
        rows, stats = run_stage([])
        rec = stats["attachment_record_receipts"][NOTICE]
        stale = {"status": rec["status"], "collection_status": (rec.get("inventory_receipt") or {}).get("collection_status"),
                 "http_calls": len(HTTP.calls), "errors": rec.get("errors")}
        cache = nd / f"{NOTICE}.resources.json"
        saved = json.loads(cache.read_text())
        old = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
        saved["retrieved_at"] = old
        saved["raw_capture"]["received_at"] = old
        cache.write_text(json.dumps(saved))
        rows, stats = run_stage([])
        rec = stats["attachment_record_receipts"][NOTICE]
        expired = {"status": rec["status"], "collection_status": (rec.get("inventory_receipt") or {}).get("collection_status")}
    results["S6_corrupt_blob_after_healthy_cache"] = {"within_7_days": stale, "after_8_days": expired}
    checks["s6_stale_then_lookup_failed"] = stale["status"] == "STALE_INVENTORY" and stale["collection_status"] == "stale_inventory" and expired["collection_status"] == "lookup_failed"

    # Default cache dirs (env not set): are they on the repo APFS volume?
    for k in ("LILA_NOTICE_CACHE_DIR", "LILA_SAM_ATTACHMENT_TEXT_DIR"):
        os.environ.pop(k, None)
    defaults = {"notice": str(detail._cache_dir()), "text": str(sat._cache_dir())}
    probe_dir_dev = os.stat(REPO).st_dev
    results["default_cache_dirs"] = {**defaults,
                                     "same_volume_as_repo": all(os.stat(Path(p).resolve().parents[0] if not Path(p).exists() else p).st_dev == probe_dir_dev for p in defaults.values())}

    failed = [k for k, v in checks.items() if not v]
    # PASS means the candidate behaved as the producer claims; here the producer never
    # claimed retention resilience, but F-01 claims a Medium defect. We report the impact
    # boundary: FAIL only if a trusted surface was affected.
    trusted_affected = not (checks["s1_assess_identical_to_healthy"] and checks["s2_assess_identical_to_healthy"]
                            and checks["s4_assess_identical_to_healthy"] and checks["s5_assess_identical_to_healthy"]
                            and checks["s1_depth_lane_unaffected_by_poison"] and checks["s4_depth_lane_unaffected"]
                            and checks["s1_no_wrong_evidence_in_dossier"])
    status = "FAIL" if trusted_affected else ("INFO" if not failed else "INFO")
    print(json.dumps({"status": status, "trusted_surface_affected": trusted_affected,
                      "checks": checks, "checks_not_met": failed, "observed": results},
                     indent=1, default=str))


if __name__ == "__main__":
    main()
