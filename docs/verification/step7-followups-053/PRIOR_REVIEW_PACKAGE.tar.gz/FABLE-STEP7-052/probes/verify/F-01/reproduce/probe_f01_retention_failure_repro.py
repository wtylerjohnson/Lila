"""Independent reproduction probe for merged finding F-01 (retention failure).

Written from the finding text only, before consulting any member probe.
Claims checked against candidate 67f644b (code 6b51f00) and base 2d522f0:
  C1  os.link unsupported: every inventory and file collection is lookup_failed,
      acquired bytes dropped, base returned inventory/text under same conditions.
  C2  disk full during retain: inventory lookup_failed, body dropped.
  C3  poisoned objects/<sha>.bin (different bytes under the true digest), no
      cache json: inventory lookup_failed, file lookup_failed, a fresh network
      call every sweep, never self-heals.
  C4  poisoned blob after a good capture: stale_inventory within 7 days, then
      lookup_failed after the stale window; file redownload lookup_failed.
  C5  text retain fails after a good parse: collection_status unreadable, text ''.
  C6  the failure is recorded under a source-failure state (lookup_failed or
      unreadable); no state names retention.
No network: socket connect is blocked, HTTP rides httpx.MockTransport and
sam_attachment_text._download_bytes is replaced. No LLM. Writes only under
this directory's work/ subfolder.
"""
from __future__ import annotations

import contextlib
import errno
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
sys.path.insert(0, str(REPO))


def _deny(*_a, **_k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _deny  # type: ignore[assignment]
socket.socket.connect_ex = _deny  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_capture  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

NOTICE = "a" * 32
RES = "b" * 32
INVENTORY = json.dumps({"attachments": [{"name": "SOW.txt", "resourceId": RES,
                                          "mimeType": "text/plain"}]}).encode()
FILE_BYTES = b"Statement of work: packet capture required.\n"
ATTACHMENT = {"resource_id": RES, "name": "SOW.txt", "access_level": "public",
              "access_status": "public", "export_controlled": "0",
              "explicit_access": "0"}


def _load_base(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BASE_DETAIL = _load_base("base_sam_notice_detail", "base_sam_notice_detail.py")
BASE_SAT = _load_base("base_sam_attachment_text", "base_sam_attachment_text.py")


class Harness:
    def __init__(self, label: str):
        self.root = WORK / label
        if self.root.exists():
            shutil.rmtree(self.root)
        self.inv_dir = self.root / "notice_cache"
        self.txt_dir = self.root / "text_cache"
        self.inv_dir.mkdir(parents=True)
        self.txt_dir.mkdir(parents=True)
        os.environ["LILA_NOTICE_CACHE_DIR"] = str(self.inv_dir)
        os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(self.txt_dir)
        self.http_calls: list[str] = []
        self.downloads: list[str] = []

        def handler(request):
            self.http_calls.append(str(request.url))
            return httpx.Response(200, content=INVENTORY)

        _http._client = lambda timeout: httpx.Client(
            transport=httpx.MockTransport(handler))

        def fake_download(resource_id, *, deadline_monotonic=None):
            self.downloads.append(resource_id)
            return FILE_BYTES

        sat._download_bytes = fake_download
        BASE_SAT._download_bytes = fake_download

    def objects(self, which: str) -> list[str]:
        directory = (self.inv_dir if which == "inv" else self.txt_dir) / "objects"
        return sorted(p.name for p in directory.iterdir()) if directory.exists() else []

    def poison(self, which: str, payload: bytes, junk: bytes = b"junk bytes") -> str:
        directory = (self.inv_dir if which == "inv" else self.txt_dir) / "objects"
        directory.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(payload).hexdigest()
        (directory / f"{digest}.bin").write_bytes(junk)
        return digest


@contextlib.contextmanager
def link_raises(code: int, only_call: int | None = None):
    """os.link raises OSError(code); with only_call, only that 1-based call."""
    real = os.link
    counter = {"n": 0}

    def fake(*args, **kwargs):
        counter["n"] += 1
        if only_call is None or counter["n"] == only_call:
            raise OSError(code, os.strerror(code) + " (probe)", str(args[1]))
        return real(*args, **kwargs)

    os.link = fake
    try:
        yield counter
    finally:
        os.link = real


@contextlib.contextmanager
def disk_full():
    real = sam_capture.tempfile.NamedTemporaryFile

    class Full:
        def __init__(self, *a, **k):
            self._h = real(*a, **k)
            self.name = self._h.name

        def __enter__(self):
            self._h.__enter__()
            return self

        def __exit__(self, *exc):
            return self._h.__exit__(*exc)

        def write(self, _data):
            raise OSError(errno.ENOSPC, "No space left on device", self.name)

        def __getattr__(self, item):
            return getattr(self._h, item)

    sam_capture.tempfile.NamedTemporaryFile = Full
    try:
        yield
    finally:
        sam_capture.tempfile.NamedTemporaryFile = real


def inv_view(result: dict) -> dict:
    return {
        "collection_status": result.get("collection_status"),
        "resources_checked": result.get("resources_checked"),
        "attachment_count": len(result.get("attachments") or []) if result.get("attachments") else 0,
        "attachments_is_none": result.get("attachments") is None,
        "from_cache": result.get("from_cache"),
        "stale_cache": result.get("stale_cache"),
        "has_raw_capture": "raw_capture" in result,
        "errors": [str(e)[:200] for e in (result.get("errors") or [])],
        "refresh_attempt_status": (result.get("refresh_attempt") or {}).get("collection_status"),
        "refresh_attempt_errors": [str(e)[:200] for e in ((result.get("refresh_attempt") or {}).get("errors") or [])],
    }


def file_view(result: dict) -> dict:
    return {
        "collection_status": result.get("collection_status"),
        "text": result.get("text"),
        "error": str(result.get("error") or "")[:200],
        "has_raw_capture": "raw_capture" in result,
        "has_text_capture": "text_capture" in result,
        "from_cache": result.get("from_cache"),
    }


def base_inv_view(result: dict) -> dict:
    return {"resources_checked": result.get("resources_checked"),
            "attachment_count": len(result.get("attachments") or []),
            "errors": [str(e)[:200] for e in (result.get("errors") or [])]}


def base_file_view(result: dict) -> dict:
    return {"text": result.get("text"), "error": str(result.get("error") or "")[:200]}


observed: dict = {}
checks: dict[str, bool] = {}

# ---------------------------------------------------------------- C0 healthy
h = Harness("c0_healthy")
inv1 = detail.fetch_notice_resources(NOTICE)
inv2 = detail.fetch_notice_resources(NOTICE)
f1 = sat.extract_public_attachment_text(ATTACHMENT)
f2 = sat.extract_public_attachment_text(ATTACHMENT)
observed["c0_healthy"] = {
    "inventory_first": inv_view(inv1), "inventory_second": inv_view(inv2),
    "file_first": file_view(f1), "file_second": file_view(f2),
    "http_calls": len(h.http_calls), "downloads": len(h.downloads),
    "inv_objects": h.objects("inv"), "txt_objects": h.objects("txt")}
checks["c0_inventory_captured_and_cached"] = (
    inv1["collection_status"] == "inventory_captured" and inv2["from_cache"] is True
    and len(h.http_calls) == 1)
checks["c0_file_captured_and_cached"] = (
    f1["collection_status"] == "captured_discovery_only" and f2["from_cache"] is True
    and len(h.downloads) == 1 and f1["text"] == FILE_BYTES.decode().strip())

# ------------------------------------------------ C1 no hardlink support (H7)
c1: dict = {}
for code in (errno.EPERM, errno.ENOTSUP, errno.EXDEV):
    h = Harness(f"c1_nolink_{code}")
    with link_raises(code):
        inv = detail.fetch_notice_resources(NOTICE)
        inv_again = detail.fetch_notice_resources(NOTICE)
        fil = sat.extract_public_attachment_text(ATTACHMENT)
        cache_written_by_candidate = (h.inv_dir / f"{NOTICE}.resources.json").exists()
        # base under the same os.link failure (base never links)
        bh_inv = BASE_DETAIL.fetch_notice_resources(NOTICE)
        bh_file = BASE_SAT.extract_public_attachment_text(ATTACHMENT)
    c1[str(code)] = {
        "candidate_inventory": inv_view(inv),
        "candidate_inventory_second_sweep": inv_view(inv_again),
        "candidate_file": file_view(fil),
        "base_inventory": base_inv_view(bh_inv),
        "base_file": base_file_view(bh_file),
        "http_calls_total": len(h.http_calls), "downloads_total": len(h.downloads),
        "inv_objects": h.objects("inv"), "txt_objects": h.objects("txt"),
        "cache_json_written_by_candidate": cache_written_by_candidate,
    }
    checks[f"c1_{code}_candidate_inventory_lookup_failed_no_inventory"] = (
        inv["collection_status"] == "lookup_failed" and inv["attachments"] is None
        and inv["resources_checked"] is False and "raw_capture" not in inv)
    checks[f"c1_{code}_candidate_file_lookup_failed_text_dropped"] = (
        fil["collection_status"] == "lookup_failed" and fil["text"] == "")
    checks[f"c1_{code}_base_returned_inventory_and_text"] = (
        bh_inv.get("resources_checked") is True and len(bh_inv.get("attachments") or []) == 1
        and bh_file.get("text") == FILE_BYTES.decode().strip())
    checks[f"c1_{code}_every_sweep_recalls_network"] = len(h.http_calls) == 3  # 2 cand + 1 base
observed["c1_no_hardlink_support"] = c1

# --------------------------------------------------------------- C2 disk full
h = Harness("c2_disk_full")
with disk_full():
    inv = detail.fetch_notice_resources(NOTICE)
    fil = sat.extract_public_attachment_text(ATTACHMENT)
observed["c2_disk_full"] = {"inventory": inv_view(inv), "file": file_view(fil),
                            "http_calls": len(h.http_calls), "downloads": len(h.downloads),
                            "inv_objects": h.objects("inv")}
checks["c2_inventory_lookup_failed_body_dropped"] = (
    inv["collection_status"] == "lookup_failed" and inv["attachments"] is None
    and any("No space left" in e for e in inv["errors"]) and len(h.http_calls) == 1)
checks["c2_file_lookup_failed_text_dropped"] = (
    fil["collection_status"] == "lookup_failed" and fil["text"] == ""
    and "No space left" in fil["error"])

# ------------------------------------------ C3 poisoned blob, no cache json yet
h = Harness("c3_poisoned_fresh")
inv_digest = h.poison("inv", INVENTORY)
txt_digest = h.poison("txt", FILE_BYTES)
sweeps = [inv_view(detail.fetch_notice_resources(NOTICE)) for _ in range(3)]
files = [file_view(sat.extract_public_attachment_text(ATTACHMENT)) for _ in range(3)]
base_inv = BASE_DETAIL.fetch_notice_resources(NOTICE)
base_file = BASE_SAT.extract_public_attachment_text(ATTACHMENT)
observed["c3_poisoned_blob_fresh"] = {
    "poisoned_inv_digest": inv_digest, "poisoned_txt_digest": txt_digest,
    "candidate_sweeps": sweeps, "candidate_files": files,
    "http_calls_candidate": len(h.http_calls) - 1, "downloads_candidate": len(h.downloads) - 1,
    "base_inventory": base_inv_view(base_inv), "base_file": base_file_view(base_file),
    "blob_still_junk": (h.inv_dir / "objects" / f"{inv_digest}.bin").read_bytes() == b"junk bytes"}
checks["c3_inventory_lookup_failed_every_sweep_with_network_call"] = (
    all(s["collection_status"] == "lookup_failed" and s["attachments_is_none"]
        and any("retained SAM bytes changed" in e for e in s["errors"]) for s in sweeps)
    and len(h.http_calls) - 1 == 3)
checks["c3_file_lookup_failed_every_sweep"] = (
    all(f["collection_status"] == "lookup_failed" and f["text"] == ""
        and "retained SAM bytes changed" in f["error"] for f in files)
    and len(h.downloads) - 1 == 3)
checks["c3_base_unaffected"] = (
    base_inv.get("resources_checked") is True and base_file.get("text") == FILE_BYTES.decode().strip())
checks["c3_never_self_heals"] = observed["c3_poisoned_blob_fresh"]["blob_still_junk"]

# ------------------------------- C4 blob corrupted after a good capture (cache json)
h = Harness("c4_poisoned_after_capture")
good = detail.fetch_notice_resources(NOTICE)
good_file = sat.extract_public_attachment_text(ATTACHMENT)
inv_blob = h.inv_dir / good["raw_capture"]["path"]
txt_raw_blob = h.txt_dir / good_file["raw_capture"]["path"]
inv_blob.write_bytes(b"corrupt")
txt_raw_blob.write_bytes(b"corrupt")
calls_before = len(h.http_calls)
within = detail.fetch_notice_resources(NOTICE)
within_again = detail.fetch_notice_resources(NOTICE)
calls_within = len(h.http_calls) - calls_before
file_after = sat.extract_public_attachment_text(ATTACHMENT)
# age the cache past the 7 day stale window
cache_path = h.inv_dir / f"{NOTICE}.resources.json"
saved = json.loads(cache_path.read_text())
old = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
saved["raw_capture"]["received_at"] = old
saved["retrieved_at"] = old
cache_path.write_text(json.dumps(saved))
calls_before = len(h.http_calls)
expired = detail.fetch_notice_resources(NOTICE)
calls_expired = len(h.http_calls) - calls_before
observed["c4_poisoned_after_capture"] = {
    "good": inv_view(good), "within_window": inv_view(within),
    "within_window_second": inv_view(within_again), "network_calls_within": calls_within,
    "after_window": inv_view(expired), "network_calls_after": calls_expired,
    "file_good": file_view(good_file), "file_after_corruption": file_view(file_after),
    "downloads_total": len(h.downloads)}
checks["c4_within_window_stale_inventory_with_network_call_each_sweep"] = (
    within["collection_status"] == "stale_inventory" and within["stale_cache"] is True
    and within_again["collection_status"] == "stale_inventory" and calls_within == 2
    and within.get("refresh_attempt", {}).get("collection_status") == "lookup_failed"
    and any("retained SAM bytes changed" in e for e in within.get("errors", [])))
# note: the refresh reason lands in cached["errors"], not refresh_attempt["errors"]
checks["c4_after_window_lookup_failed"] = (
    expired["collection_status"] == "lookup_failed" and expired["attachments"] is None
    and calls_expired == 1)
checks["c4_file_redownload_lookup_failed"] = (
    file_after["collection_status"] == "lookup_failed" and file_after["text"] == ""
    and "retained SAM bytes changed" in str(file_after.get("error")) and len(h.downloads) == 2)

# ------------------------------------- C5 text retain fails after a good parse
h = Harness("c5_text_retain_fails")
with link_raises(errno.EPERM, only_call=2) as counter:
    fil = sat.extract_public_attachment_text(ATTACHMENT)
observed["c5_text_retain_fails_after_parse"] = {
    "file": file_view(fil), "os_link_calls": counter["n"], "txt_objects": h.objects("txt"),
    "cache_json_written": (h.txt_dir / f"{RES}.json").exists()}
checks["c5_unreadable_with_empty_text_despite_good_parse"] = (
    fil["collection_status"] == "unreadable" and fil["text"] == "" and "raw_capture" in fil
    and "text_capture" not in fil and counter["n"] == 2)

# ------------------------------------------ C6 no state names retention anywhere
import re  # noqa: E402
states_in_code = set()
for path in ("tools/api/sam_notice_detail.py", "tools/api/sam_attachment_text.py",
             "tools/api/sam_capture.py", "run_searches.py"):
    states_in_code |= set(re.findall(r'collection_status"?\]?\s*[:=]\s*"([a-z_]+)"', (REPO / path).read_text()))
    states_in_code |= set(re.findall(r'collection_status="([a-z_]+)"', (REPO / path).read_text()))
observed["c6_collection_states_assigned_in_code"] = sorted(states_in_code)
checks["c6_no_retention_state_exists"] = not any(
    "retain" in s or "custody" in s or "storage" in s for s in states_in_code)

# git cleanliness of the review clone
import subprocess  # noqa: E402
porcelain = subprocess.run(["git", "-C", str(REPO), "status", "--porcelain"],
                           capture_output=True, text=True).stdout
observed["review_clone_porcelain_empty"] = porcelain.strip() == ""

failed = sorted(k for k, v in checks.items() if not v)
status = "FAIL" if not failed else "INFO"
# FAIL here means: defect reproduced exactly as the finding describes.
print(json.dumps({"status": status, "finding": "F-01",
                  "meaning": "FAIL = finding reproduced; INFO = some claim did not reproduce",
                  "checks": checks, "checks_not_reproduced": failed,
                  "observed": observed}, indent=2, default=str))
