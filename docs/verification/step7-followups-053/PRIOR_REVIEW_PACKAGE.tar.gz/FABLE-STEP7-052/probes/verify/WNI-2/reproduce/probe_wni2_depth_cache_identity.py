"""Independent reproduction probe for WNI-2.

Claim: fetch_notice_depth's cached branch never compares data['id'] with the
requested notice id, so a <A>.json file holding notice B's record is served
as A's depth with from_cache=True, zero errors, zero network; run_dossiers.py
then projects source_depth with notice_id=A and the ledger identity check
passes. Claimed identical on base 2d522f0.
"""
import importlib.util
import json
import os
import socket
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
os.chdir(REPO)

A = "a" * 32
B = "b" * 32

tmp = tempfile.mkdtemp(prefix="wni2_", dir=str(HERE))
os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = tmp
os.environ.pop("SAM_GOV_API_KEY", None)

observed = {"network_calls": 0, "socket_connects": 0}

# Hard network block: any real socket connect and any httpx request are counted and refused.
_orig_connect = socket.socket.connect
def _no_connect(self, *a, **k):
    observed["socket_connects"] += 1
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect

import httpx
import tools.api._http as _http
def _handler(request):
    observed["network_calls"] += 1
    raise RuntimeError("network blocked by probe: " + str(request.url))
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(_handler))

now = datetime.now(timezone.utc)
b_record = {
    "id": B,
    "description": "NOTICE B DESCRIPTION: unrelated procurement for widgets.",
    "attachments": [{"name": "B notice SOW.pdf", "resource_id": "rB1"}],
    "from_cache": False,
    "retrieved_at": (now - timedelta(minutes=5)).isoformat(timespec="seconds"),
    "description_checked": True,
    "resources_checked": True,
    "resources_schema": "recognized_v1",
    "attachment_inventory_count": 1,
    "attachment_inventory_hash": "deadbeef",
    "errors": [],
}
# min_retrieved_at older than retrieved_at, so the cached branch treats it as current.
posted = (now - timedelta(days=2)).isoformat(timespec="seconds")

def load_base():
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

import tools.api.sam_notice_detail as cand
base = load_base()

def run(mod, label):
    Path(tmp, f"{A}.json").write_text(json.dumps(b_record))
    before = dict(observed)
    err = None
    data = None
    try:
        data = mod.fetch_notice_depth(A, min_retrieved_at=posted)
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    res = {
        "exception": err,
        "network_calls": observed["network_calls"] - before["network_calls"],
        "socket_connects": observed["socket_connects"] - before["socket_connects"],
    }
    if data is not None:
        res.update({
            "returned_id": data.get("id"),
            "from_cache": data.get("from_cache"),
            "description_prefix": (data.get("description") or "")[:30],
            "attachment_names": [a.get("name") for a in data.get("attachments") or []],
            "errors": data.get("errors"),
            "description_checked": data.get("description_checked"),
            "resources_checked": data.get("resources_checked"),
        })
    # Downstream projection copied from run_dossiers.py main loop (lines 102-116).
    if data is not None:
        source_depth = {
            "notice_id": A,
            "source_url": f"https://api.sam.gov/prod/opportunities/v2/search?noticeid={A}",
            "retrieved_at": data.get("retrieved_at"),
            "description": data.get("description"),
            "attachments": data.get("attachments"),
            "description_checked": bool(data.get("description_checked")),
            "resources_checked": bool(data.get("resources_checked")),
            "resources_schema": data.get("resources_schema"),
            "attachment_inventory_count": data.get("attachment_inventory_count"),
            "attachment_inventory_hash": data.get("attachment_inventory_hash"),
            "errors": data.get("errors") or [],
        }
        from agents.assess import ledger
        res["source_depth_notice_id"] = source_depth["notice_id"]
        res["source_depth_attachments"] = [a.get("name") for a in source_depth["attachments"] or []]
        res["ledger_depth_matches_posting_A"] = ledger._depth_matches_posting(source_depth, A)
        res["ledger_depth_matches_posting_B"] = ledger._depth_matches_posting(source_depth, B)
    return res

out = {"candidate": run(cand, "cand"), "base": run(base, "base")}

def is_defect(r):
    return (r.get("exception") is None and r.get("returned_id") == B
            and r.get("from_cache") is True and r.get("network_calls") == 0
            and r.get("socket_connects") == 0 and not r.get("errors")
            and r.get("attachment_names") == ["B notice SOW.pdf"]
            and r.get("ledger_depth_matches_posting_A") is True)

cand_defect = is_defect(out["candidate"])
base_defect = is_defect(out["base"])
# Does the candidate source even attempt an id comparison in the depth branch?
src = (REPO / "tools/api/sam_notice_detail.py").read_text()
depth_src = src[src.index("def fetch_notice_depth"):]
out["candidate_depth_branch_checks_id"] = ('data.get("id")' in depth_src) or ("data['id']" in depth_src)
out["status"] = "FAIL" if cand_defect else "PASS"
out["kind"] = "pre_existing" if (cand_defect and base_defect) else ("new_defect" if cand_defect else "n/a")
out["observed"] = {
    "candidate_serves_foreign_record_as_A": cand_defect,
    "base_serves_foreign_record_as_A": base_defect,
    "cache_dir": tmp,
}
print(json.dumps(out, indent=2, default=str))
import shutil
shutil.rmtree(tmp, ignore_errors=True)
