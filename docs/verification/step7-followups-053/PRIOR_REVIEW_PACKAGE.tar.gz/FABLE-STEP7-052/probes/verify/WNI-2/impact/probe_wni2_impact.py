"""WNI-2 IMPACT probe: where does a foreign depth record under <A>.json flow?

Stance: try to refute or narrow the finding. Traces the poisoned depth cache
through fetch_notice_depth (candidate and base), the exact run_dossiers.py
source_depth projection, the strict Assess ledger (identity gate, requirement
excerpt, human approval, BID_NOW), and the leadgen draft bridge. Also measures
the precondition: writer paths for <id>.json and whether a legacy-shaped or
stale foreign record is trusted. No network, no LLM, probe-local caches only.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
(HERE / "_tmp").mkdir(exist_ok=True)
TMP = Path(tempfile.mkdtemp(prefix="wni2-", dir=str(HERE / "_tmp")))

os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*args, **kwargs):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402

CALLS: list = []


def install_mock(handler):
    CALLS.clear()

    def logged(request):
        CALLS.append({"method": request.method, "url": str(request.url)})
        return handler(request)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(logged), follow_redirects=True)


def deny(request):
    return httpx.Response(404)


install_mock(deny)
sam_quota.note_call = lambda purpose: 0
cand.sam_quota.note_call = lambda purpose: 0

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)
base.sam_quota.note_call = lambda purpose: 0

A = "a" * 32
B = "b" * 32
C = "c" * 32

# Poisoned record: notice B's modern depth record (id=B, B's requirement text,
# B's attachment inventory) sitting under <A>.json. retrieved_at is chosen
# inside the test ledger's clock window (posting 2026-07-01, as_of 2026-07-10).
B_DESCRIPTION = ("The contractor shall provide an enterprise packet capture "
                 "platform for CISA network operations.")


def hal_body(notice_id, rows):
    href = (f"https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": notice_id, "attachments": rows}]},
        "_links": {"self": {"href": href}}}


ROW_B = {"resourceId": C, "name": "B notice SOW.pdf", "mimeType": ".pdf", "size": 10,
         "accessLevel": "public", "accessStatus": "public",
         "exportControlled": "0", "explicitAccess": "0"}
B_ATTACHMENTS, recognized = cand._attachment_inventory(hal_body(B, [ROW_B]), B)
assert recognized and B_ATTACHMENTS


def foreign_record(**overrides):
    rec = {"id": B, "description": B_DESCRIPTION, "attachments": B_ATTACHMENTS,
           "from_cache": False, "retrieved_at": "2026-07-10T11:00:00+00:00",
           "description_checked": True, "resources_checked": True,
           "resources_schema": "recognized_v1",
           "attachment_inventory_count": len(B_ATTACHMENTS),
           "attachment_inventory_hash": cand._manifest_hash(B_ATTACHMENTS),
           "errors": []}
    rec.update(overrides)
    return rec


def fresh_cache(label):
    path = TMP / f"cache_{label}"
    path.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(path)
    return path


def view(data):
    return {"id": data.get("id"), "from_cache": data.get("from_cache"),
            "description": data.get("description"),
            "description_checked": data.get("description_checked"),
            "resources_checked": data.get("resources_checked"),
            "attachment_names": [a.get("name") for a in (data.get("attachments") or [])],
            "errors": data.get("errors"), "network_calls": len(CALLS)}


observed: dict = {}

# ---- Stage 1: fetch_notice_depth on the poisoned file, candidate and base ----
for label, module in (("cand", cand), ("base", base)):
    cache_dir = fresh_cache(f"s1_{label}")
    (cache_dir / f"{A}.json").write_text(json.dumps(foreign_record()))
    install_mock(deny)
    depth = module.fetch_notice_depth(A, min_retrieved_at="2026-07-01")
    observed[f"1_fetch_depth_poisoned_{label}"] = view(depth)
    if label == "cand":
        DEPTH_POISONED = depth

# ---- Stage 2: the exact run_dossiers.py source_depth projection ----
sys.path.insert(0, str(REPO / "tests"))
from tests.test_assess_ledger import (  # noqa: E402
    BINDING, NOW, _notice, _profile, _sweep,
)
from agents.assess.contracts import LiveClassification  # noqa: E402
from agents.assess.ledger import build_assess_run  # noqa: E402

notice_a = _notice(A, "Packet capture platform")
nid = notice_a.get("source_id") or notice_a.get("id")


def run_dossiers_projection(n, depth):
    # Verbatim field mapping from run_dossiers.py (notice_id comes from the
    # sweep row, never from depth["id"]).
    return {
        "notice_id": n.get("source_id") or n.get("id"),
        "source_url": n.get("api_url") or n.get("url"),
        "retrieved_at": depth.get("retrieved_at"),
        "description": depth.get("description"),
        "attachments": depth.get("attachments"),
        "description_checked": bool(depth.get("description_checked")),
        "resources_checked": bool(depth.get("resources_checked")),
        "resources_schema": depth.get("resources_schema"),
        "attachment_inventory_count": depth.get("attachment_inventory_count"),
        "attachment_inventory_hash": depth.get("attachment_inventory_hash"),
        "errors": depth.get("errors") or [],
    }


source_depth = run_dossiers_projection(notice_a, DEPTH_POISONED)
observed["2_source_depth_projection"] = {
    "notice_id": source_depth["notice_id"], "source_url": source_depth["source_url"],
    "description_is_B_text": source_depth["description"] == B_DESCRIPTION,
    "attachments": [a.get("name") for a in source_depth["attachments"] or []],
    "depth_id_consulted": False,
}


# ---- Stage 3: strict Assess ledger with the poisoned depth record ----
def sweep_with_depth(depth_record):
    sweep = _sweep()
    sweep["results"]["sam.gov"][0] = notice_a
    triage = sweep["results"]["triage"]
    triage[A] = triage.pop("N1")
    sweep["results"]["dossiers"] = {
        "built": [{"id": A, "title": "Packet capture platform"}],
        "records": [],
        "depth_records": [{"id": A, "source_depth": depth_record}],
        "artifact": "x.md", "as_of": "2026-07-10",
    }
    return sweep


def record_view(proposed, notice_id):
    rec = next((r for r in proposed.live.records if r.notice_id == notice_id), None)
    if rec is None:
        return {"present": False}
    return {
        "present": True,
        "classification": str(rec.classification),
        "recommendation": str(rec.recommendation),
        "requirement_excerpt": rec.requirement_excerpt,
        "requirement_reviewed_at": (rec.requirement_reviewed_at.isoformat()
                                    if rec.requirement_reviewed_at else None),
        "attachments": [a.name for a in rec.attachments],
        "attachment_inventory_count": rec.attachment_inventory_count,
        "attachment_gap": rec.attachment_gap,
        "evidence_excerpts_containing_B_text": sum(
            1 for e in rec.authoritative_evidence
            if e.excerpt and "enterprise packet capture platform" in e.excerpt),
        "evidence_urls": sorted({str(e.source_url) for e in rec.authoritative_evidence}),
    }


def approval_payload(proposed, notice_id, attachments_reviewed=True):
    rec = next(r for r in proposed.live.records if r.notice_id == notice_id)
    evidence = next(row for row in reversed(rec.authoritative_evidence)
                    if rec.requirement_excerpt and rec.requirement_excerpt in row.excerpt)
    return {
        "schema_version": 1, "client": "Testco", "binding": dict(BINDING),
        "reviews": [{
            "notice_id": notice_id, "evidence_id": evidence.evidence_id,
            "excerpt": rec.requirement_excerpt, "capability_terms": ["packet capture"],
            "decision": "approved",
            "attachment_inventory_count": rec.attachment_inventory_count,
            "attachment_inventory_hash": rec.attachment_inventory_hash,
            "attachments_reviewed": attachments_reviewed,
            "reviewed_by": "operator", "reviewed_at": NOW.isoformat(),
        }],
    }


sweep_poisoned = sweep_with_depth(source_depth)
proposed, _, diagnostics = build_assess_run("Testco", copy.deepcopy(sweep_poisoned), _profile(), BINDING, as_of=NOW)
observed["3a_ledger_poisoned_no_review"] = record_view(proposed, A)
observed["3a_identity_diagnostics"] = [d for d in diagnostics if "depth" in str(d).lower()]

approved = None
try:
    payload = approval_payload(proposed, A)
    approved, _, diag2 = build_assess_run(
        "Testco", copy.deepcopy(sweep_poisoned), _profile(), BINDING,
        requirement_reviews_payload=payload, as_of=NOW)
    observed["3b_ledger_poisoned_after_operator_approval"] = record_view(approved, A)
    observed["3b_review_diagnostics"] = [d for d in diag2 if A in str(d)]
except Exception as exc:  # noqa: BLE001
    observed["3b_ledger_poisoned_after_operator_approval"] = {"error": repr(exc)}

# leadgen bridge: does the BID_NOW row mint a live parent carrying B's span?
try:
    from agents.leadgen.from_assess import draft_lead_rows
    batch = draft_lead_rows(approved, None)
    live_parents = [p for p in batch.parents if str(p.subject_id) == A]
    observed["3c_leadgen_parents_for_A"] = [
        {"subject_kind": str(p.subject_kind), "requirement_span": getattr(p, "requirement_span", None),
         "lifecycle": str(getattr(p, "lifecycle_stage", None))}
        for p in live_parents]
except Exception as exc:  # noqa: BLE001
    observed["3c_leadgen_parents_for_A"] = {"error": repr(exc)[:300]}

# ---- Stage 4: finder's fix (notice_id from depth["id"]) closes the gate ----
fixed_depth = dict(source_depth, notice_id=DEPTH_POISONED.get("id"))
proposed_fixed, _, diag_fixed = build_assess_run(
    "Testco", copy.deepcopy(sweep_with_depth(fixed_depth)), _profile(), BINDING, as_of=NOW)
observed["4_ledger_with_depth_id_as_notice_id"] = record_view(proposed_fixed, A)

# ---- Stage 5: honest control (A's own record) is indistinguishable ----
honest_depth = run_dossiers_projection(notice_a, foreign_record(id=A))
proposed_honest, _, _ = build_assess_run(
    "Testco", copy.deepcopy(sweep_with_depth(honest_depth)), _profile(), BINDING, as_of=NOW)
observed["5_ledger_honest_control"] = record_view(proposed_honest, A)

# ---- Stage 6: precondition narrowing ----
# 6a: legacy-shaped foreign record (no description_checked) without an API key
cache_dir = fresh_cache("s6a")
legacy = foreign_record()
legacy.pop("description_checked")
(cache_dir / f"{A}.json").write_text(json.dumps(legacy))
install_mock(deny)
depth_legacy = cand.fetch_notice_depth(A)
sd_legacy = run_dossiers_projection(notice_a, depth_legacy)
p_legacy, _, _ = build_assess_run("Testco", copy.deepcopy(sweep_with_depth(sd_legacy)), _profile(), BINDING, as_of=NOW)
observed["6a_legacy_shaped_foreign_record"] = {"fetch": view(depth_legacy), "ledger": record_view(p_legacy, A)}

# 6b: foreign record older than the posting modification (stale for posting)
cache_dir = fresh_cache("s6b")
(cache_dir / f"{A}.json").write_text(json.dumps(foreign_record(retrieved_at="2026-06-01T00:00:00+00:00")))
install_mock(deny)
depth_stale = cand.fetch_notice_depth(A, min_retrieved_at="2026-07-01")
sd_stale = run_dossiers_projection(notice_a, depth_stale)
p_stale, _, _ = build_assess_run("Testco", copy.deepcopy(sweep_with_depth(sd_stale)), _profile(), BINDING, as_of=NOW)
observed["6b_stale_foreign_record"] = {"fetch": view(depth_stale), "ledger": record_view(p_stale, A)}

# 6c: does fetch_notice_depth's own writer ever produce id != file stem?
cache_dir = fresh_cache("s6c")


def sam_ok(request):
    url = str(request.url)
    if "noticedesc" in url:
        return httpx.Response(200, json={"description": "<p>A text</p>"})
    if url.endswith("/resources"):
        return httpx.Response(200, json=hal_body(A, []))
    return httpx.Response(404)


install_mock(sam_ok)
cand.fetch_notice_depth(A, api_key="probe-key-not-real")
written = json.loads((cache_dir / f"{A}.json").read_text())
observed["6c_native_writer_binds_id_to_filename"] = {
    "file_stem": A, "written_id": written.get("id"), "match": written.get("id") == A}

# 6d: static census of code paths that write <id>.json into the depth cache
grep = subprocess.run(
    ["grep", "-rn", "--include=*.py", "-e", "sam_notice", "-e", "LILA_NOTICE_CACHE_DIR",
     "-e", "_cache_dir() / f\"{notice_id}.json\"", str(REPO / "tools"), str(REPO / "agents"),
     str(REPO / "run_dossiers.py"), str(REPO / "run_searches.py")],
    capture_output=True, text=True)
writer_lines = [line.replace(str(REPO) + "/", "") for line in grep.stdout.splitlines()
                if "write" in line or ".json\"" in line]
observed["6d_depth_cache_writer_census"] = writer_lines

# 6e: gitignore status of the default cache dir (tracked files could carry a mixup)
ign = subprocess.run(["git", "-C", str(REPO), "check-ignore", "-v", "data/cache/sam_notice/x.json"],
                     capture_output=True, text=True)
observed["6e_default_cache_gitignored"] = ign.stdout.strip() or ign.stderr.strip()

status = subprocess.run(["git", "-C", str(REPO), "status", "--porcelain"], capture_output=True, text=True)
observed["clone_status_porcelain"] = status.stdout

c1 = observed["1_fetch_depth_poisoned_cand"]
b1 = observed["1_fetch_depth_poisoned_base"]
l3a = observed["3a_ledger_poisoned_no_review"]
l3b = observed["3b_ledger_poisoned_after_operator_approval"]
l4 = observed["4_ledger_with_depth_id_as_notice_id"]
findings = {
    "cached_branch_returns_foreign_id_no_network": c1["id"] == B and c1["from_cache"] is True and c1["network_calls"] == 0,
    "identical_on_base": b1["id"] == B and b1["from_cache"] is True and b1["network_calls"] == 0,
    "ledger_trusts_B_description_as_A_requirement": l3a.get("requirement_excerpt") is not None
        and "enterprise packet capture platform" in (l3a.get("requirement_excerpt") or ""),
    "ledger_lists_B_attachment_under_A": "B notice SOW.pdf" in (l3a.get("attachments") or []),
    "ledger_identity_gap_fired": "does not match the current SAM notice id" in str(l3a.get("attachment_gap")),
    "operator_approval_reaches_BID_NOW": l3b.get("classification") == str(LiveClassification.BID_NOW),
    "finder_fix_closes_gate": l4.get("requirement_excerpt") is None
        and "does not match the current SAM notice id" in str(l4.get("attachment_gap")),
    "legacy_shaped_foreign_record_untrusted": observed["6a_legacy_shaped_foreign_record"]["ledger"].get("requirement_excerpt") is None,
    "stale_foreign_record_untrusted": observed["6b_stale_foreign_record"]["ledger"].get("requirement_excerpt") is None,
    "native_writer_binds_id": observed["6c_native_writer_binds_id_to_filename"]["match"],
    "clone_pristine": status.stdout == "",
}
status_word = "FAIL" if (findings["cached_branch_returns_foreign_id_no_network"]
                         and findings["ledger_trusts_B_description_as_A_requirement"]) else "PASS"
print(json.dumps({"probe": "wni2_impact", "status": status_word, "findings": findings,
                  "observed": observed, "tmp_dir": str(TMP)}, indent=2, sort_keys=True, default=str))
