"""WNI-2 refutation probe: fetch_notice_depth cached branch and notice identity.

Questions answered, each measured on candidate (repo) and base (2d522f0 copy):
  S1  Does a <A>.json holding notice B's self-consistent record come back from
      fetch_notice_depth(A) as from_cache with id=B, no error, no network?
  S2  Writer census: does ANY code path write a foreign id into <A>.json?
      (fresh path answered with B's description/resources; cached-branch rewrite)
  S3  Efficacy of the finder's recommended fix (data['id'] != notice_id): does
      it catch a tamperer who writes B's content under id=A?
  S4  Downstream reach: the run_dossiers projection of S1's record, pushed
      through a real strict Assess build (tests/test_assess_ledger helpers).
  S5  Grounding: run_dossiers.py sets notice_id from nid and never reads depth id.
  S6  Disclosure: do the delta docs disclose the cached-depth identity gap?
No network (sockets blocked, httpx MockTransport). No LLM. Writes only under
this probe's own directory.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni2-", dir=str(HERE)))

os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)

sam_quota.note_call = lambda purpose: 0
cand.sam_quota.note_call = lambda purpose: 0
base.sam_quota.note_call = lambda purpose: 0

A = "a" * 32
B = "b" * 32
C = "c" * 32
NOW = "2026-07-10T11:00:00+00:00"
DESC_B = ("FOREIGN NOTICE B: the contractor shall provide an enterprise packet "
          "capture platform for TSA airport networks.")
DESC_A = ("The contractor shall provide an enterprise packet capture platform "
          "for CISA network operations.")


def hal_body(notice_id, rows):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_embedded": {"opportunityAttachmentList": [
                {"opportunityId": notice_id, "attachments": rows}]},
            "_links": {"self": {"href": href}}}


def row(resource_id, name):
    return {"resourceId": resource_id, "name": name, "mimeType": ".pdf", "size": 10,
            "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}


BODY_B = hal_body(B, [row(C, "B notice SOW.pdf")])


def install_mock(desc_text, resources_body):
    calls = []
    payload = json.dumps(resources_body).encode()

    def handler(request):
        calls.append(str(request.url))
        url = str(request.url)
        if "noticedesc" in url:
            return httpx.Response(200, json={"description": desc_text})
        if url.endswith("/resources"):
            return httpx.Response(200, content=payload)
        return httpx.Response(404)

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    return calls


def fresh_dir(label):
    p = TMP / f"cache_{label}"
    p.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p)
    return p


def foreign_record(module):
    """Notice B's own depth record, exactly as the fresh path would write it."""
    atts, recognized = module._attachment_inventory(BODY_B, B) \
        if module is cand else module._attachment_inventory(BODY_B)
    assert recognized
    return {"id": B, "description": DESC_B, "attachments": atts, "from_cache": False,
            "retrieved_at": NOW, "description_checked": True, "resources_checked": True,
            "resources_schema": "recognized_v1", "attachment_inventory_count": len(atts),
            "attachment_inventory_hash": module._manifest_hash(atts), "errors": []}


def view(d):
    return {"id": d.get("id"), "from_cache": d.get("from_cache"),
            "description": d.get("description"),
            "resources_checked": d.get("resources_checked"),
            "attachment_names": [a.get("name") for a in (d.get("attachments") or [])],
            "errors": d.get("errors")}


observed = {}

# S1: cached <A>.json holds B's self-consistent record
for label, module in (("cand", cand), ("base", base)):
    d = fresh_dir(f"s1_{label}")
    (d / f"{A}.json").write_text(json.dumps(foreign_record(module)))
    calls = install_mock(DESC_A, hal_body(A, []))
    out = module.fetch_notice_depth(A)
    observed[f"S1_{label}"] = {**view(out), "network_calls": len(calls)}

# S2: writer census. Fresh path for A answered with B's description and B's
# resources body; then the cached-branch rewrite. What id lands on disk?
for label, module in (("cand", cand), ("base", base)):
    d = fresh_dir(f"s2_{label}")
    calls = install_mock(DESC_B, BODY_B)
    out = module.fetch_notice_depth(A, api_key="probe-key-not-real")
    on_disk = json.loads((d / f"{A}.json").read_text())
    # cached-branch rewrite (resources not recognized on cand, so it retries)
    calls2 = install_mock(DESC_B, BODY_B)
    out2 = module.fetch_notice_depth(A)
    on_disk2 = json.loads((d / f"{A}.json").read_text())
    observed[f"S2_{label}"] = {
        "fresh_written_id": on_disk.get("id"), "fresh_network_calls": len(calls),
        "fresh_resources_checked": out.get("resources_checked"),
        "fresh_attachment_names": [a.get("name") for a in (out.get("attachments") or [])],
        "rewrite_written_id": on_disk2.get("id"), "rewrite_network_calls": len(calls2),
        "rewrite_resources_checked": out2.get("resources_checked"),
    }
src_detail = (REPO / "tools/api/sam_notice_detail.py").read_text()
writers = [m.start() for m in re.finditer(r"atomic_write_json\(cache, ", src_detail)]
observed["S2_code_writers_of_depth_cache"] = {
    "atomic_write_json_calls_in_sam_notice_detail": len(writers),
    "depth_fresh_out_id_literal": '"id": notice_id,' in src_detail,
    "other_repo_modules_naming_notice_cache_dir": sorted(
        str(p.relative_to(REPO)) for p in REPO.rglob("*.py")
        if ".venv" not in p.parts and "tests" not in p.parts
        and "LILA_NOTICE_CACHE_DIR" in p.read_text(errors="ignore")),
}

# S3: efficacy of the recommended guard against a tamperer who sets id=A
def recommended_guard(data, notice_id):
    return isinstance(data, dict) and data.get("id") == notice_id


mixup = foreign_record(cand)
tamper = dict(mixup, id=A)
observed["S3_recommended_fix"] = {
    "catches_accidental_mixup_id_B_under_A": not recommended_guard(mixup, A),
    "catches_tamper_B_content_under_id_A": not recommended_guard(tamper, A),
}

# S4: downstream reach through a real strict Assess build
import test_assess_ledger as tal  # noqa: E402
from agents.assess.contracts import LiveClassification  # noqa: E402
from agents.assess.ledger import _depth_matches_posting  # noqa: E402

depth_b_under_a = dict(foreign_record(cand), from_cache=True)
sweep = tal._sweep()
n1 = sweep["results"]["sam.gov"][0]
nid = n1["source_id"]
# verbatim shape of run_dossiers.py lines 102-116 (grounded in S5 below)
source_depth = {
    "notice_id": nid,
    "source_url": n1.get("api_url") or n1.get("url"),
    "retrieved_at": depth_b_under_a.get("retrieved_at"),
    "description": depth_b_under_a.get("description"),
    "attachments": depth_b_under_a.get("attachments"),
    "description_checked": bool(depth_b_under_a.get("description_checked")),
    "resources_checked": bool(depth_b_under_a.get("resources_checked")),
    "resources_schema": depth_b_under_a.get("resources_schema"),
    "attachment_inventory_count": depth_b_under_a.get("attachment_inventory_count"),
    "attachment_inventory_hash": depth_b_under_a.get("attachment_inventory_hash"),
    "errors": depth_b_under_a.get("errors") or [],
}
sweep["results"]["dossiers"] = {"depth_records": [{"id": nid, "source_depth": source_depth}]}
run, _, _ = tal._build(sweep)
rec = next(r for r in run.live.records if r.notice_id == nid)
excerpts = [e.excerpt for e in rec.authoritative_evidence]
observed["S4_strict_assess"] = {
    "ledger_depth_matches_posting": _depth_matches_posting(source_depth, nid),
    "foreign_description_in_authoritative_evidence": any("FOREIGN NOTICE B" in x for x in excerpts),
    "requirement_excerpt": rec.requirement_excerpt,
    "classification_without_review": str(rec.classification),
    "attachment_gap": rec.attachment_gap,
}
# with the human requirement review approving the (foreign) excerpt and empty inventory:
sweep_empty = tal._sweep()
d_empty = dict(depth_b_under_a, attachments=[], attachment_inventory_count=0,
               attachment_inventory_hash=cand._manifest_hash([]))
sd_empty = dict(source_depth, attachments=[], attachment_inventory_count=0,
                attachment_inventory_hash=d_empty["attachment_inventory_hash"])
sweep_empty["results"]["dossiers"] = {"depth_records": [{"id": nid, "source_depth": sd_empty}]}
run2, _, _ = tal._build_with_requirement_review(sweep_empty)
rec2 = next(r for r in run2.live.records if r.notice_id == nid)
observed["S4_strict_assess_with_review_and_empty_inventory"] = {
    "classification": str(rec2.classification),
    "requirement_excerpt_is_foreign": "FOREIGN NOTICE B" in (rec2.requirement_excerpt or ""),
    "bid_now": rec2.classification == LiveClassification.BID_NOW,
}

# S5: grounding of the projection in run_dossiers.py (candidate == base for this file)
rd = (REPO / "run_dossiers.py").read_text()
rd_base = (HERE / "base_run_dossiers.py").read_text()
observed["S5_run_dossiers"] = {
    "sets_notice_id_from_nid": '"notice_id": nid,' in rd,
    "reads_depth_id_anywhere": bool(re.search(r"depth(\.get\(|\[)[\"']id[\"']", rd)),
    "candidate_equals_base": rd == rd_base,
}

# S6: disclosure search in the delta docs and the producer verification pack
docs = []
for rel in ("docs/CONTRACT_SURFACES.md", "docs/CONVENTIONS.md"):
    docs.append((rel, (REPO / rel).read_text()))
for p in sorted((REPO / "docs/verification/step7-052").glob("*")):
    if p.suffix in (".md", ".json"):
        docs.append((str(p.relative_to(REPO)), p.read_text(errors="ignore")))
hits = {}
for rel, text in docs:
    for line in text.splitlines():
        low = line.lower()
        if "depth" in low and ("cache" in low or "identity" in low or "notice-id" in low
                               or "notice id" in low):
            hits.setdefault(rel, []).append(line.strip()[:200])
observed["S6_disclosure_lines"] = hits

# verdict logic
s1c, s1b = observed["S1_cand"], observed["S1_base"]
f = {
    "cand_returns_foreign_record_from_cache": s1c["id"] == B and s1c["from_cache"] is True
        and s1c["network_calls"] == 0 and not s1c["errors"],
    "base_identical": s1b["id"] == B and s1b["from_cache"] is True and s1b["network_calls"] == 0,
    "no_code_writer_produces_foreign_id": all(
        observed[f"S2_{l}"]["fresh_written_id"] == A and observed[f"S2_{l}"]["rewrite_written_id"] == A
        for l in ("cand", "base")),
    "recommended_fix_blind_to_id_preserving_tamper": not observed["S3_recommended_fix"][
        "catches_tamper_B_content_under_id_A"],
    "foreign_text_reaches_strict_assess_as_trusted": observed["S4_strict_assess"][
        "foreign_description_in_authoritative_evidence"] and observed["S4_strict_assess"][
        "ledger_depth_matches_posting"],
    "foreign_text_can_be_bid_now_with_review": observed[
        "S4_strict_assess_with_review_and_empty_inventory"]["bid_now"],
    "run_dossiers_unchanged_and_never_reads_depth_id": observed["S5_run_dossiers"]["candidate_equals_base"]
        and not observed["S5_run_dossiers"]["reads_depth_id_anywhere"],
    "disclosed_in_docs": any("cache" in l.lower() and "depth" in l.lower()
                             for ls in hits.values() for l in ls),
}
status = "FAIL" if (f["cand_returns_foreign_record_from_cache"] and f["base_identical"]) else "PASS"
print(json.dumps({"probe": "wni2_depth_cache_identity", "status": status, "findings": f,
                  "observed": observed, "tmp_dir": str(TMP)},
                 indent=2, sort_keys=True, default=str))
