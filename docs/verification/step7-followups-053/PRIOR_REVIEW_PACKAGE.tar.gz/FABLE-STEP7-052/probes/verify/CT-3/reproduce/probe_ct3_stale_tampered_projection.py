"""CT-3 independent reproduction: does the stale inventory fallback serve a
projection-only tampered cache unvalidated, and does the tampered hash land in
inventory_receipt next to the ORIGINAL raw_capture?

Written from the finding description only, before reading the original probe.
No network (socket.connect blocked), no LLM calls, probe-local cache dirs.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import types
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
WORK = HERE / "_work"
if WORK.exists():
    shutil.rmtree(WORK)
WORK.mkdir(parents=True)

# Hard network block before anything imports httpx.
def _blocked_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _blocked_connect  # type: ignore[assignment]
socket.socket.connect_ex = _blocked_connect  # type: ignore[assignment]

os.chdir(REPO)
sys.path.insert(0, str(REPO))
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["LILA_NOTICE_CACHE_DIR"] = str(WORK / "cache_candidate")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(WORK / "text_cache")

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

NOTICE = "a" * 32
RID = "b" * 32
ORIGINAL_BODY = json.dumps({
    "_embedded": {"opportunityAttachmentList": [{
        "attachments": [{"name": "SOW.pdf", "resourceId": RID, "mimeType": "application/pdf",
                         "size": 1234, "accessLevel": "public"}],
        "opportunityId": NOTICE,
    }]},
}).encode()

observed: dict = {}
results: list[dict] = []


def mock_http(body: bytes | None, status: int = 200):
    """body None means transport raises ConnectError (refresh failure)."""
    calls = []
    def handler(request):
        calls.append(str(request.url))
        if body is None:
            raise httpx.ConnectError("simulated outage", request=request)
        return httpx.Response(status, content=body)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def check(name: str, ok: bool, **details):
    results.append({"check": name, "ok": bool(ok), **details})


# ---------------------------------------------------------------- candidate
cache_dir = Path(os.environ["LILA_NOTICE_CACHE_DIR"])
mock_http(ORIGINAL_BODY)
first = detail.fetch_notice_resources(NOTICE)
cache_file = cache_dir / f"{NOTICE}.resources.json"
check("legit_capture", first["collection_status"] == "inventory_captured"
      and cache_file.exists(), status=first["collection_status"])
original_hash = first["attachment_inventory_hash"]
original_raw_sha = first["raw_capture"]["sha256"]
saved_original = json.loads(cache_file.read_text())


def tamper(mutator, label: str, expect_served_stale: bool = True):
    """Write a projection-only tamper, then try fresh reuse and stale fallback."""
    saved = json.loads(json.dumps(saved_original))
    mutator(saved)
    # Keep the derived fields coherent with the tampered projection so the
    # tamper is a plausible local edit (hash + count follow the attachments).
    if saved.get("attachments") is not None:
        saved["attachment_inventory_count"] = len(saved["attachments"])
        saved["attachment_inventory_hash"] = detail._manifest_hash(saved["attachments"])
    cache_file.write_text(json.dumps(saved))
    valid = detail._resource_capture_valid(saved)
    fresh = detail._resource_cache_fresh(saved)
    # Fresh path: a healthy network would re-fetch; refuse-as-fresh means the
    # cached tampered projection is not returned with stale_cache False.
    calls = mock_http(ORIGINAL_BODY)
    fresh_result = detail.fetch_notice_resources(NOTICE)
    served_fresh_tampered = (fresh_result.get("from_cache") is True
                             and fresh_result.get("stale_cache") is False
                             and fresh_result.get("attachments") == saved.get("attachments"))
    # Rewrite tamper (fresh path with network refetched and overwrote it).
    cache_file.write_text(json.dumps(saved))
    mock_http(None)  # refresh fails
    stale_result = detail.fetch_notice_resources(NOTICE)
    served_stale_tampered = (stale_result.get("stale_cache") is True
                             and stale_result.get("collection_status") == "stale_inventory"
                             and stale_result.get("attachments") == saved.get("attachments"))
    entry = {
        "case": label,
        "capture_valid": valid,
        "clock_fresh": fresh,
        "fresh_refetched": len(calls) == 1,
        "served_fresh_tampered": served_fresh_tampered,
        "served_stale_tampered": served_stale_tampered,
        "stale_status": stale_result.get("collection_status"),
        "stale_hash": stale_result.get("attachment_inventory_hash"),
        "stale_raw_capture_sha256": (stale_result.get("raw_capture") or {}).get("sha256"),
    }
    observed.setdefault("tamper_cases", []).append(entry)
    check(f"stale_serves_tampered[{label}]",
          (served_stale_tampered is expect_served_stale) and not valid and not served_fresh_tampered,
          **entry)
    return stale_result, saved


# 1. Invented file appended.
def t_append(s):
    s["attachments"].append({"name": "Invented Award Notice.pdf", "type": "application/pdf",
                             "resource_id": "c" * 32,
                             "source_url": detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id="c" * 32),
                             "size": 999, "access_level": "public", "access_status": None,
                             "export_controlled": "0", "explicit_access": "0"})
stale_append, tampered_append = tamper(t_append, "invented_file_appended")

# 2. File removed (inventory becomes an empty list, i.e. claims confirmed empty).
def t_remove(s):
    s["attachments"] = []
tamper(t_remove, "file_removed_to_empty")

# 3. Name edited.
def t_name(s):
    s["attachments"][0]["name"] = "Renamed.docx"
tamper(t_name, "name_edited")

# 4. resource_id edited (points at another object).
def t_rid(s):
    s["attachments"][0]["resource_id"] = "d" * 32
tamper(t_rid, "resource_id_edited")

# 5. source_url pointing at another notice's raw file.
def t_url(s):
    s["attachments"][0]["source_url"] = detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id="e" * 32)
tamper(t_url, "source_url_edited")

# 6. Naive received_at (no tz) on an otherwise untouched projection.
def t_naive(s):
    s["raw_capture"]["received_at"] = datetime.now().replace(tzinfo=None).isoformat()
tamper(t_naive, "naive_received_at")

# 7. Control: untouched cache must be reused fresh and never refetched.
cache_file.write_text(json.dumps(saved_original))
calls = mock_http(ORIGINAL_BODY)
ctrl = detail.fetch_notice_resources(NOTICE)
check("control_untampered_reused_fresh",
      ctrl.get("from_cache") is True and ctrl.get("stale_cache") is False and len(calls) == 0,
      calls=len(calls))

# 8. Stale-age boundary: tampered projection older than 7 days must NOT be served.
def t_old(s):
    s["attachments"].append({"name": "Old Invented.pdf", "type": None, "resource_id": "f" * 32,
                             "source_url": None, "size": None, "access_level": None,
                             "access_status": None, "export_controlled": "0", "explicit_access": "0"})
    old = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
    s["raw_capture"]["received_at"] = old
    s["retrieved_at"] = old
tamper(t_old, "invented_file_older_than_7d", expect_served_stale=False)

# ------------------------------------------------- run_searches receipt path
import run_searches  # noqa: E402

sam_quota.calls_today = lambda: 0


class _Cand:
    def __init__(self, sid):
        self.source_id = sid


class _Source:
    last_attachment_census = {"candidates": 1}
    def attachment_candidates(self, query, taxonomy, engagement_scope, *, limit):
        return [_Cand(NOTICE)]


# Rewrite the appended-file tamper and force the refresh to fail.
cache_file.write_text(json.dumps(tampered_append))
mock_http(None)
rows, census = run_searches._enrich_sam_public_attachments(
    [], _Source(), None, None, None, limit=5)
receipt = census["attachment_record_receipts"][NOTICE]
inv = receipt.get("inventory_receipt") or {}
rs_entry = {
    "record_status": receipt.get("status"),
    "inventory_receipt_status": inv.get("collection_status"),
    "inventory_receipt_hash": inv.get("attachment_inventory_hash"),
    "tampered_hash": tampered_append["attachment_inventory_hash"],
    "original_hash": original_hash,
    "inventory_receipt_raw_sha256": (inv.get("raw_capture") or {}).get("sha256"),
    "original_raw_sha256": original_raw_sha,
    "rows_returned": len(rows),
    "attachment_enriched": census.get("attachment_enriched"),
    "errors": census.get("attachment_errors"),
}
observed["run_searches"] = rs_entry
# Recompute what the retained original bytes actually project to.
raw_bytes = read_retained(cache_dir, inv["raw_capture"])
items, recognized = detail._attachment_inventory(json.loads(raw_bytes), NOTICE)
hash_from_raw = detail._manifest_hash(items or [])
rs_entry["hash_recomputed_from_receipt_raw_capture"] = hash_from_raw
check("run_searches_stale_excluded_from_relevance",
      receipt.get("status") == "STALE_INVENTORY" and census.get("attachment_enriched") == 0
      and len(rows) == 0)
check("inventory_receipt_hash_is_tampered_not_original",
      inv.get("attachment_inventory_hash") == tampered_append["attachment_inventory_hash"]
      and inv.get("attachment_inventory_hash") != original_hash)
check("inventory_receipt_raw_capture_is_original_and_irreconcilable",
      (inv.get("raw_capture") or {}).get("sha256") == original_raw_sha
      and raw_bytes == ORIGINAL_BODY and hash_from_raw == original_hash
      and hash_from_raw != inv.get("attachment_inventory_hash"))
check("no_projection_unverified_flag_in_receipt",
      "projection_unverified" not in json.dumps(inv) and "projection_unverified" not in json.dumps(receipt))

# ------------------------------------------------------------- base 2d522f0
base_src = subprocess.run(
    ["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_notice_detail.py"],
    capture_output=True, text=True, check=True).stdout
base_path = WORK / "base_sam_notice_detail.py"
base_path.write_text(base_src)
spec = importlib.util.spec_from_file_location("base_sam_notice_detail", base_path)
base = importlib.util.module_from_spec(spec)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(WORK / "cache_base")
spec.loader.exec_module(base)
base_dir = Path(os.environ["LILA_NOTICE_CACHE_DIR"])
mock_http(ORIGINAL_BODY)
b_first = base.fetch_notice_resources(NOTICE)
b_cache = base_dir / f"{NOTICE}.resources.json"
b_saved = json.loads(b_cache.read_text())
b_saved["attachments"].append({"name": "Invented Award Notice.pdf", "type": "application/pdf",
                               "resource_id": "c" * 32, "source_url": None, "size": 999,
                               "access_level": "public", "access_status": None,
                               "export_controlled": "0", "explicit_access": "0"})
b_saved["attachment_inventory_count"] = 2
b_saved["attachment_inventory_hash"] = base._manifest_hash(b_saved["attachments"])
b_cache.write_text(json.dumps(b_saved))
calls = mock_http(ORIGINAL_BODY)
b_fresh = base.fetch_notice_resources(NOTICE)
b_served_fresh = (b_fresh.get("from_cache") is True and b_fresh.get("stale_cache") is False
                  and b_fresh.get("attachments") == b_saved["attachments"] and len(calls) == 0)
# Force the stale path: push received clock past 6h TTL but within 7d.
old = (datetime.now(timezone.utc) - timedelta(hours=7)).isoformat()
b_saved["retrieved_at"] = old
b_cache.write_text(json.dumps(b_saved))
mock_http(None)
b_stale = base.fetch_notice_resources(NOTICE)
b_served_stale = (b_stale.get("stale_cache") is True
                  and b_stale.get("attachments") == b_saved["attachments"])
observed["base_2d522f0"] = {
    "base_has_raw_capture": "raw_capture" in b_first,
    "served_fresh_tampered": b_served_fresh,
    "served_stale_tampered": b_served_stale,
}
check("base_served_tampered_both_fresh_and_stale", b_served_fresh and b_served_stale,
      **observed["base_2d522f0"])

# Candidate fresh path on the same tamper with a healthy network (improvement).
cand_fresh_improved = all(not c["served_fresh_tampered"] and c["fresh_refetched"]
                          for c in observed["tamper_cases"])
check("candidate_fresh_path_refuses_and_refetches_all_cases", cand_fresh_improved)

# ---------------------------------------------------------------- summary
failed = [r for r in results if not r["ok"]]
defect_reproduced = (
    all(c["served_stale_tampered"] for c in observed["tamper_cases"]
        if c["case"] != "invented_file_older_than_7d")
    and rs_entry["record_status"] == "STALE_INVENTORY"
    and rs_entry["inventory_receipt_hash"] == rs_entry["tampered_hash"]
    and rs_entry["inventory_receipt_raw_sha256"] == rs_entry["original_raw_sha256"]
    and observed["base_2d522f0"]["served_stale_tampered"]
)
status = "FAIL" if defect_reproduced and not failed else ("INFO" if not failed else "FAIL")
print(json.dumps({
    "probe": "CT-3 reproduce: stale fallback serves tampered projection unvalidated",
    "status": status,
    "defect_reproduced_as_described": defect_reproduced,
    "checks_failed": [r["check"] for r in failed],
    "candidate_sha": subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD"],
                                    capture_output=True, text=True).stdout.strip(),
    "observed": observed,
    "checks": results,
}, indent=1, default=str))
shutil.rmtree(WORK, ignore_errors=True)
