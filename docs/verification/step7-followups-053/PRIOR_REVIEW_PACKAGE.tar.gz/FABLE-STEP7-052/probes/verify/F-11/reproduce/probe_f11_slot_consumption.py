"""F-11 independent reproduction: do gate-rejected files consume the [:3]
slots before the pure _public_file gate, so a public readable file ranked
fourth is never attempted? Runs against candidate and base run_searches.
No network (socket.connect blocked), no LLM, no quota spend."""
import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
os.chdir(REPO)

tmp = tempfile.mkdtemp(prefix="f11_", dir=str(HERE))
os.environ["LILA_NOTICE_CACHE_DIR"] = os.path.join(tmp, "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(tmp, "text")
os.environ["LILA_SUITE_OFFLINE"] = "1"


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

import run_searches as cand  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_run_searches", HERE / "base_run_searches.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

sam_quota.calls_today = lambda: 0
NOTICE = "a" * 32
TERM = "network visibility"


def pub(rid, name, **over):
    row = {"resource_id": rid, "name": name, "type": os.path.splitext(name)[1],
           "size": 1024, "access_level": "public", "access_status": "public",
           "export_controlled": "0", "explicit_access": "0"}
    row.update(over)
    return row


def run(module, files, label):
    """Run one enrichment and return the file receipts + download attempts."""
    attempts = []
    inventory = detail._manifest_hash(files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": NOTICE, "resources_checked": True, "attachments": files,
        "attachment_inventory_hash": inventory}

    def fake_download(rid, **k):
        attempts.append(rid)
        return f"Buyer requires {TERM}. Amendment text.".encode()

    sat._download_bytes = fake_download
    # Fresh cache dirs per run so a text cache written by one scenario can
    # never satisfy a later scenario's file without a download attempt.
    run.counter = getattr(run, "counter", 0) + 1
    for d in ("notice", "text"):
        fresh = Path(tmp, f"{d}_{run.counter}")
        fresh.mkdir(parents=True, exist_ok=True)
        os.environ["LILA_NOTICE_CACHE_DIR" if d == "notice"
                   else "LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(fresh)
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE,
                               title="Requirement", agency="NASA",
                               raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1,
                             updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])
    rows, stats = module._enrich_sam_public_attachments(
        [], Source(), object(), tax, None, limit=8)
    receipt = (stats.get("attachment_record_receipts") or {}).get(NOTICE, {})
    return {
        "label": label,
        "download_attempts": list(attempts),
        "record_status": receipt.get("status"),
        "files": [{"name": f.get("name"), "status": f.get("status"),
                   "reason": f.get("reason")} for f in receipt.get("files", [])],
        "errors": list(stats.get("attachment_errors") or [])[:10],
        "stats_keys": sorted(stats.keys()),
    }


# Scenario A: three top-ranked names rejected by the pure gate (controlled,
# export-controlled, over-size); public amendment ranked fourth.
files_a = [
    pub("1" * 32, "Statement of Work.pdf", access_level="controlled"),
    pub("2" * 32, "PWS.docx", export_controlled="1"),
    pub("3" * 32, "Requirements.pdf", size=6 * 1024 * 1024),
    pub("4" * 32, "Amendment 0001.txt"),
]
# Scenario B: invalid resource id variant in one slot.
files_b = [
    pub("1" * 32, "Statement of Work.pdf", access_level="controlled"),
    pub("../bad", "PWS.docx"),
    pub("3" * 32, "Requirements.pdf", explicit_access="1"),
    pub("4" * 32, "Amendment 0001.txt"),
]
# Control C: same public amendment alone must be attempted and captured.
files_c = [pub("4" * 32, "Amendment 0001.txt")]
# Control D: amendment plus two rejected files -> fits in slots, attempted.
files_d = [
    pub("1" * 32, "Statement of Work.pdf", access_level="controlled"),
    pub("3" * 32, "Requirements.pdf", size=6 * 1024 * 1024),
    pub("4" * 32, "Amendment 0001.txt"),
]

observed = {}
for tag, files in (("A_three_rejected", files_a), ("B_badid_variant", files_b),
                   ("C_control_alone", files_c), ("D_two_rejected", files_d)):
    observed[f"candidate_{tag}"] = run(cand, files, f"candidate {tag}")
    observed[f"base_{tag}"] = run(base, files, f"base {tag}")

# Gate is pure: confirm _public_file rejects each of the 3 without any download.
observed["gate_pure"] = {
    f["name"]: sat._public_file(f) for f in files_a[:3]}

# Static: is the [:3] slice before or after the gate in both sources?
def slice_before_gate(src: str) -> bool:
    i_slice = src.find("][:3]")
    i_extract = src.find("extract_public_attachment_text(\n", i_slice)
    return 0 < i_slice < i_extract


observed["static_slice_before_gate"] = {
    "candidate": slice_before_gate(Path(REPO, "run_searches.py").read_text()),
    "base": slice_before_gate(Path(HERE, "base_run_searches.py").read_text()),
}

cA = observed["candidate_A_three_rejected"]
cB = observed["candidate_B_badid_variant"]
bA = observed["base_A_three_rejected"]
cC = observed["candidate_C_control_alone"]
cD = observed["candidate_D_two_rejected"]


def amendment(rec):
    return next(f for f in rec["files"] if f["name"] == "Amendment 0001.txt")


checks = {
    "cand_A_no_downloads": cA["download_attempts"] == [],
    "cand_A_amendment_not_fetched_budget": amendment(cA) == {
        "name": "Amendment 0001.txt", "status": "not_fetched",
        "reason": "outside file/type budget"},
    "cand_A_record_text_unavailable": cA["record_status"] == "TEXT_UNAVAILABLE",
    "cand_B_no_downloads": cB["download_attempts"] == [],
    "cand_B_amendment_not_fetched": amendment(cB)["status"] == "not_fetched",
    "base_A_no_downloads": bA["download_attempts"] == [],
    "control_C_attempted_and_captured": (
        cC["download_attempts"] == ["4" * 32]
        and cC["record_status"] == "DISCOVERY_TEXT_CAPTURED"),
    "control_D_attempted": cD["download_attempts"] == ["4" * 32],
    "base_C_attempted": observed["base_C_control_alone"]["download_attempts"] == ["4" * 32],
    "base_D_attempted": observed["base_D_two_rejected"]["download_attempts"] == ["4" * 32],
    "base_has_no_file_receipts": bA["files"] == [],
    "gate_rejects_all_three": all(not ok for ok, _ in observed["gate_pure"].values()),
}
status = "FAIL" if all(checks.values()) else "INFO"
print(json.dumps({"status": status, "meaning": (
    "FAIL = defect reproduced exactly as described (slots consumed before the "
    "pure gate, fourth public file never attempted, identical at base)"),
    "checks": checks, "observed": observed}, indent=1, default=str))

import shutil  # noqa: E402
shutil.rmtree(tmp, ignore_errors=True)
