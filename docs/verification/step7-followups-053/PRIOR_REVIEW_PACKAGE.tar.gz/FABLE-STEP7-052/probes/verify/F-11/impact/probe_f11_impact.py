"""F-11 IMPACT refutation probe.

Claim under test: gate-rejected files (restricted / export-controlled /
over-size / invalid id) consume the three file slots in
run_searches._enrich_sam_public_attachments before _public_file runs, so a
public readable file ranked fourth is never attempted.

IMPACT lens: (1) does the defect reproduce on the candidate; (2) is it present
at base 2d522f0; (3) how often does the shape occur in the 17 real captured
inventories; (4) where does the defective outcome flow: receipts, saved sweep
rows, triage prefilter, Assess ledger, dossier research context, LeadRow.

Offline: sockets blocked, fetch_notice_resources and _download_bytes replaced,
quota counter pinned. Writes only under this probe directory.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO))
os.chdir(REPO)

TMP = Path(tempfile.mkdtemp(prefix="f11-", dir=PROBE_DIR))
(TMP / "text").mkdir()
(TMP / "notice").mkdir()
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")


def _deny(*a, **k):
    raise RuntimeError("probe blocked network")


socket.socket.connect = _deny  # type: ignore[method-assign]
socket.socket.connect_ex = _deny  # type: ignore[method-assign]
socket.create_connection = _deny  # type: ignore[assignment]

import run_searches as searches  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

observed: dict = {}
problems: list[str] = []

# ---------------------------------------------------------------- 1. census
census = {"inventories": 0, "with_more_than_3_supported": 0,
          "top3_contains_gate_rejected": 0,
          "gate_rejected_in_top3_displaces_fetchable": 0,
          "gate_reasons_seen": {}, "displaced_examples": []}
supported = {".pdf", ".docx", ".txt", ".csv", ".md"}
for body in sorted((REVIEW / "extracted/source-proof/public-inventory-001").glob("*.body")):
    try:
        payload = json.loads(body.read_text())
    except Exception:
        continue
    items = detail._attachments(payload) or []
    if not items:
        continue
    census["inventories"] += 1
    ranked = [a for a in sorted(items, key=sat.attachment_priority)
              if os.path.splitext(str(a.get("name") or ""))[1].lower() in supported]
    if len(ranked) > 3:
        census["with_more_than_3_supported"] += 1
    gates = [sat._public_file(a) for a in ranked]
    top3_bad = [g[1] for g in gates[:3] if not g[0]]
    for reason in top3_bad:
        census["gate_reasons_seen"][reason] = census["gate_reasons_seen"].get(reason, 0) + 1
    if top3_bad:
        census["top3_contains_gate_rejected"] += 1
        displaced = [ranked[i]["name"] for i in range(3, len(ranked)) if gates[i][0]]
        if displaced:
            census["gate_rejected_in_top3_displaces_fetchable"] += 1
            census["displaced_examples"].append(
                {"body": body.name, "rejected": top3_bad,
                 "displaced_fetchable": displaced[:3]})
observed["real_inventory_census"] = census

# ------------------------------------------------------------ 2. scenario
NOTICE = "a" * 32
TERM = "network visibility"
def rid(n): return f"{n:032x}"
def public_file(r, name, **extra):
    item = {"resource_id": r, "name": name, "type": None, "source_url": None,
            "size": 10, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0"}
    item.update(extra)
    return item

FILES = [
    public_file(rid(1), "Statement of Work.pdf", access_level="private"),
    public_file(rid(2), "PWS.docx", export_controlled="1"),
    public_file(rid(3), "Requirements.pdf", size=6 * 1024 * 1024),
    public_file(rid(4), "Amendment 0001.txt"),
]
INVENTORY_HASH = detail._manifest_hash(FILES)
PAYLOADS = {rid(4): f"Amendment 0001. The contractor shall provide {TERM} for the enterprise network.".encode()}
attempted: list[str] = []


def fake_download(resource_id, *, deadline_monotonic=None):
    attempted.append(resource_id)
    return PAYLOADS[resource_id]


def fake_resources(*a, **k):
    return {"id": NOTICE, "resources_checked": True, "attachments": copy.deepcopy(FILES),
            "attachment_inventory_hash": INVENTORY_HASH, "resources_schema": "recognized_v1"}


sat._download_bytes = fake_download
detail.fetch_notice_resources = fake_resources
sam_quota.calls_today = lambda: 0
taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])
candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                           agency="NASA", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}
    def attachment_candidates(self, *a, **k): return [candidate]


def run(module, sam_rows, priority_key=None):
    attempted.clear()
    # run_searches imports attachment_priority inside the function body, so
    # the sat module attribute is the seam for both candidate and base.
    saved = sat.attachment_priority
    if priority_key is not None:
        sat.attachment_priority = priority_key
    try:
        for p in (TMP / "text").glob("*"):
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        rows, stats = module._enrich_sam_public_attachments(
            copy.deepcopy(sam_rows), Source(), object(), taxonomy, None, limit=8)
    finally:
        sat.attachment_priority = saved
    return rows, stats, list(attempted)


def summary(rows, stats, tried):
    receipt = stats["attachment_record_receipts"][NOTICE]
    return {
        "attempted_downloads": [t[-1] for t in tried],
        "public_amendment_attempted": rid(4) in tried,
        "record_status": receipt["status"],
        "files": [{k: r.get(k) for k in ("name", "status", "reason")} for r in receipt.get("files", [])],
        "errors": [e[:120] for e in stats["attachment_errors"]],
        "rows_returned": [r["source_id"][:4] for r in rows],
        "row_has_attachment_text": any("text" in (r.get("raw_payload") or {}) for r in rows),
        "attachment_enriched": stats["attachment_enriched"],
        "attachment_added": stats["attachment_added"],
    }


# candidate, near-match candidate NOT in the description-matched census
rows_c, stats_c, tried_c = run(searches, [])
observed["candidate_near_match"] = summary(rows_c, stats_c, tried_c)
# candidate, notice already in the census (description-matched row)
census_row = json.loads(candidate.model_dump_json())
rows_c2, stats_c2, tried_c2 = run(searches, [census_row])
observed["candidate_in_census"] = summary(rows_c2, stats_c2, tried_c2)

# counterfactual: gate before slice, emulated by ranking gate-rejected files last
_real_priority = sat.attachment_priority
def gated_priority(a):
    return (0 if sat._public_file(a)[0] else 1,) + tuple(_real_priority(a))
rows_f, stats_f, tried_f = run(searches, [], priority_key=gated_priority)
observed["counterfactual_gate_before_slice"] = summary(rows_f, stats_f, tried_f)

# ------------------------------------------------------------- 3. base
base_src = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:run_searches.py"],
                          check=True, capture_output=True, text=True).stdout
base_rs = importlib.util.module_from_spec(
    importlib.util.spec_from_loader("base_run_searches", loader=None))
base_rs.__file__ = str(REPO / "run_searches.py")
exec(compile(base_src, "<git show 2d522f0:run_searches.py>", "exec"), base_rs.__dict__)
rows_b, stats_b, tried_b = run(base_rs, [])
observed["base_2d522f0_near_match"] = summary(rows_b, stats_b, tried_b)

# ----------------------------------------------------------- 4. downstream
flow: dict = {}
# 4a. triage prefilter with the defective receipt vs the counterfactual row
try:
    from agents.decisions.triage import deterministic_prefilter
    notice_row = json.loads(candidate.model_dump_json())
    cands, ruled, receipt = deterministic_prefilter(
        [notice_row], taxonomy, attachment_receipts=stats_c["attachment_record_receipts"])
    flow["triage_defective"] = {
        "model_review_candidates": len(cands),
        "ruled": {k: {kk: v[kk] for kk in ("verdict", "screen_state", "reason")} for k, v in ruled.items()},
    }
    fixed_row = rows_f[0] if rows_f else notice_row
    cands2, ruled2, _ = deterministic_prefilter(
        [fixed_row], taxonomy, attachment_receipts=stats_f["attachment_record_receipts"])
    flow["triage_counterfactual"] = {
        "model_review_candidates": len(cands2),
        "ruled": {k: {kk: v[kk] for kk in ("verdict", "screen_state", "reason")} for k, v in ruled2.items()},
    }
except Exception as exc:  # noqa: BLE001
    flow["triage_error"] = f"{type(exc).__name__}: {exc}"[:300]

# 4b. Assess ledger: receipts and even captured discovery text change nothing
try:
    sys.path.insert(0, str(REPO / "tests"))
    import test_assess_ledger as tal
    from agents.assess.contracts import LiveClassification

    def snapshot(searches_dict):
        proposed, _, _ = tal._build(searches_dict)
        out = {}
        for rec in proposed.live.records:
            out[rec.notice_id] = {
                "classification": str(rec.classification),
                "requirement_reviewed_at": rec.requirement_reviewed_at,
                "attachment_gap": rec.attachment_gap,
                "attachments_checked": rec.attachments_checked,
                "requirement_excerpt": rec.requirement_excerpt,
            }
        return out

    plain = tal._sweep()
    base_snap = snapshot(copy.deepcopy(plain))
    with_receipts = copy.deepcopy(plain)
    rc = copy.deepcopy(stats_c["attachment_record_receipts"][NOTICE])
    with_receipts["results"]["sam_census"]["attachment_record_receipts"] = {"N1": rc}
    with_receipts["results"]["sam.gov"][0]["raw_payload"]["attachment_lookup"] = rc
    receipts_snap = snapshot(with_receipts)
    with_text = copy.deepcopy(plain)
    fixed_raw = (rows_f[0].get("raw_payload") if rows_f else {}) or {}
    for key in ("text", "attachment_evidence", "attachment_evidence_sha256",
                "attachment_inventory_hash", "attachment_collection_v1",
                "attachment_collection_sha256", "attachment_relevance"):
        if key in fixed_raw:
            with_text["results"]["sam.gov"][0]["raw_payload"][key] = copy.deepcopy(fixed_raw[key])
    text_snap = snapshot(with_text)
    flow["assess"] = {
        "baseline_N1": base_snap.get("N1"),
        "identical_with_defective_receipts": receipts_snap == base_snap,
        "identical_with_counterfactual_attachment_text": text_snap == base_snap,
        "any_bid_now": any(v["classification"] == str(LiveClassification.BID_NOW)
                           for s in (base_snap, receipts_snap, text_snap) for v in s.values()),
        "any_requirement_reviewed_at": any(v["requirement_reviewed_at"]
                                           for s in (base_snap, receipts_snap, text_snap) for v in s.values()),
    }
except Exception as exc:  # noqa: BLE001
    flow["assess_error"] = f"{type(exc).__name__}: {exc}"[:300]

# 4c. dossier research context from the defective outcome
try:
    from agents.decisions.dossier import _attachment_research_context
    defective_row = rows_c2[0]
    ctx = _attachment_research_context(defective_row, fake_resources())
    ctx_fixed = _attachment_research_context(rows_f[0], fake_resources()) if rows_f else None
    flow["dossier"] = {
        "defective_row_context": ctx,
        "counterfactual_status": (ctx_fixed or {}).get("status"),
        "counterfactual_passages": len((ctx_fixed or {}).get("file_passages") or []),
    }
except Exception as exc:  # noqa: BLE001
    flow["dossier_error"] = f"{type(exc).__name__}: {exc}"[:300]

# 4d. LeadRow / seller copy: static reader check
lead_src = "\n".join((REPO / "agents/leadgen" / n).read_text()
                     for n in ("from_assess.py", "qualify.py", "press.py", "contracts.py"))
flow["leadrow_static"] = {
    "reads_attachment_record_receipts": "attachment_record_receipts" in lead_src,
    "reads_attachment_evidence_or_text": any(
        s in lead_src for s in ("attachment_evidence", "attachment_collection", "raw_payload\"][\"text")),
    "reads_only_assess_attachment_gap": "attachment_gap" in lead_src,
}
observed["downstream_flow"] = flow

# ------------------------------------------------------------- verdict
c = observed["candidate_near_match"]
f = observed["counterfactual_gate_before_slice"]
b = observed["base_2d522f0_near_match"]
defect_reproduced = (not c["public_amendment_attempted"] and c["record_status"] == "TEXT_UNAVAILABLE"
                     and f["public_amendment_attempted"] and f["record_status"] == "DISCOVERY_TEXT_CAPTURED"
                     and f["attachment_added"] == 1 and c["attachment_added"] == 0)
pre_existing = not b["public_amendment_attempted"] and b["record_status"] == "TEXT_UNAVAILABLE"
reaches_trust = (flow.get("assess", {}).get("identical_with_defective_receipts") is False
                 or flow.get("assess", {}).get("any_bid_now") is True
                 or flow.get("leadrow_static", {}).get("reads_attachment_record_receipts") is True)
status = "FAIL" if defect_reproduced else "PASS"
print(json.dumps({
    "probe": "f11_impact",
    "status": status,
    "defect_reproduced_on_candidate": defect_reproduced,
    "present_at_base_2d522f0": pre_existing,
    "reaches_trusted_surface": reaches_trust,
    "observed": observed,
}, indent=1, sort_keys=True, default=str))
shutil.rmtree(TMP, ignore_errors=True)
