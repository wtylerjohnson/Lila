"""F-11 refutation probe: do gate-rejected files consume the three file slots
before the pure _public_file gate runs, so a public readable file ranked
fourth is never attempted?  Candidate vs BASE (2d522f0), plus a realism scan
over the 21 real inventories in the producer SOURCE_PROOF (no network).

Writes only under this probe directory. No network, no LLM, no pkill.
"""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
import types
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
PROOF = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/"
             "source-proof/public-inventory-001/RESULTS.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
os.chdir(REPO)

TMP = Path(tempfile.mkdtemp(prefix="f11-", dir=PROBE_DIR))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
(TMP / "text").mkdir()
(TMP / "notice").mkdir()
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "60"


class _NoNetwork(RuntimeError):
    pass


def _deny(self, *args, **kwargs):  # noqa: ANN001
    raise _NoNetwork(f"probe blocked socket connect {args!r}")


socket.socket.connect = _deny  # type: ignore[method-assign]
socket.socket.connect_ex = _deny  # type: ignore[method-assign]
socket.create_connection = _deny  # type: ignore[assignment]

import run_searches as cand_rs  # noqa: E402
from tools.api import sam_attachment_text as cand_sat  # noqa: E402
from tools.api import sam_notice_detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance import engine as rel_engine  # noqa: E402


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


base_sat = _load("base_sat", PROBE_DIR / "base_sam_attachment_text.py")
base_rs = _load("base_run_searches", PROBE_DIR / "base_run_searches.py")

NOTICE = "1234567890abcdef1234567890abcdef"
RID = {
    "sow": "a" * 32, "pws": "b" * 32, "req": "c" * 32, "amd": "d" * 32,
}


def _row(name: str, rid: str, **extra) -> dict:
    item = {"name": name, "type": os.path.splitext(name)[1] or None,
            "resource_id": rid,
            "source_url": f"https://sam.gov/api/prod/opps/v3/opportunities/"
                          f"resources/files/{rid}/download",
            "size": 1000, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0"}
    item.update(extra)
    return item


# Scenario: three requirements-bearing files that fail the pure gate on three
# distinct branches (non-public access, export-controlled, oversize) and one
# public readable amendment that attachment_priority ranks fourth.
SCENARIO = [
    _row("Amendment 0001.txt", RID["amd"]),
    _row("Statement of Work.pdf", RID["sow"], access_level="controlled",
         access_status="controlled"),
    _row("PWS.pdf", RID["pws"], export_controlled="1"),
    _row("Requirements.pdf", RID["req"], size=6 * 1024 * 1024),
]
# Control: same amendment ranked inside the top three (only two gate-rejected
# files present) so the download seam is provably live.
CONTROL = [
    _row("Amendment 0001.txt", RID["amd"]),
    _row("Statement of Work.pdf", RID["sow"], access_level="controlled",
         access_status="controlled"),
    _row("Requirements.pdf", RID["req"], size=6 * 1024 * 1024),
]


class _Candidate:
    def __init__(self, source_id: str) -> None:
        self.source_id = source_id

    def model_dump_json(self) -> str:
        return json.dumps({"source_id": self.source_id, "raw_payload": {},
                           "title": "probe"})


class _Source:
    last_attachment_census = {"probe": True}

    def attachment_candidates(self, query, taxonomy, engagement_scope, *, limit):
        return [_Candidate(NOTICE)]


def _fake_resources(attachments: list[dict]):
    def fetch(notice_id, *, timeout_seconds=None, **_):
        return {"id": notice_id, "errors": [], "stale_cache": False,
                "resources_checked": True, "attachments": attachments,
                "attachment_inventory_hash": "deadbeef",
                "retrieved_at": "2026-09-13T00:00:00+00:00",
                "collection_status": "inventory_captured"}
    return fetch


class _Verdict:
    relevant = False
    score = 0.0
    core_terms: list = []
    adjacent_terms: list = []
    spans: list = []
    excluded_by_code = False
    scope_basis = "probe"


def _drive(rs_module, sat_module, attachments: list[dict]) -> dict:
    attempted: list[str] = []

    def fake_download(resource_id, **_):
        attempted.append(resource_id)
        return b"Amendment text: public readable content for the probe.\n"

    saved_sat = sys.modules.get("tools.api.sam_attachment_text")
    saved_fetch = sam_notice_detail.fetch_notice_resources
    saved_calls = sam_quota.calls_today
    saved_score = rel_engine.score_record
    saved_dl = sat_module._download_bytes
    try:
        sys.modules["tools.api.sam_attachment_text"] = sat_module
        sam_notice_detail.fetch_notice_resources = _fake_resources(attachments)
        sam_quota.calls_today = lambda: 0
        rel_engine.score_record = lambda row, taxonomy, engagement_scope=None: _Verdict()
        sat_module._download_bytes = fake_download
        # fresh text cache per drive so no cache hit hides a download
        for p in (TMP / "text").iterdir():
            if p.is_file():
                p.unlink()
            else:
                shutil.rmtree(p, ignore_errors=True)
        rows, summary = rs_module._enrich_sam_public_attachments(
            [], _Source(), types.SimpleNamespace(), None, None, limit=5)
    finally:
        if saved_sat is not None:
            sys.modules["tools.api.sam_attachment_text"] = saved_sat
        sam_notice_detail.fetch_notice_resources = saved_fetch
        sam_quota.calls_today = saved_calls
        rel_engine.score_record = saved_score
        sat_module._download_bytes = saved_dl
    receipt = summary["attachment_record_receipts"][NOTICE]
    files = receipt.get("files")
    return {
        "attempted_download_resource_ids": attempted,
        "amendment_attempted": RID["amd"] in attempted,
        "record_status": receipt["status"],
        "record_errors": receipt.get("errors"),
        "file_receipts": (
            [{k: r.get(k) for k in ("name", "status", "reason")} for r in files]
            if files is not None else "no per-file receipts at this version"),
        "attachment_errors": summary["attachment_errors"],
    }


def _selection_rule(sat_module, attachments: list[dict]) -> list[dict]:
    """The exact candidate rule: priority sort, supported suffix, [:3]."""
    supported = {".pdf", ".docx", ".txt", ".csv", ".md"}
    ordered = sorted(attachments, key=sat_module.attachment_priority)
    return [a for a in ordered
            if os.path.splitext(str(a.get("name") or ""))[1].lower() in supported][:3]


def _realism_scan() -> dict:
    data = json.loads(PROOF.read_text())
    supported = {".pdf", ".docx", ".txt", ".csv", ".md"}
    per_notice = []
    displaced_notices = 0
    slots_lost_total = 0
    for entry in data:
        atts = entry.get("attachments") or []
        if not atts:
            continue
        top3 = _selection_rule(cand_sat, atts)
        gate = [(a["name"], cand_sat._public_file(a)) for a in top3]
        rejected = [(n, r) for n, (ok, r) in gate if not ok]
        top_ids = {a["resource_id"] for a in top3}
        fetchable_outside = [
            a["name"] for a in sorted(atts, key=cand_sat.attachment_priority)
            if a["resource_id"] not in top_ids
            and os.path.splitext(str(a.get("name") or ""))[1].lower() in supported
            and cand_sat._public_file(a)[0]]
        displaced = bool(rejected) and bool(fetchable_outside)
        if displaced:
            displaced_notices += 1
            slots_lost_total += min(len(rejected), len(fetchable_outside))
        per_notice.append({
            "notice_id": entry.get("notice_id"), "inventory_count": len(atts),
            "top3": [a["name"] for a in top3],
            "top3_gate_rejected": rejected,
            "fetchable_supported_outside_top3": fetchable_outside,
            "displacement": displaced,
        })
    return {"real_inventories_with_files": len(per_notice),
            "notices_with_displaced_fetchable_file": displaced_notices,
            "fetchable_files_lost_total": slots_lost_total,
            "detail": [n for n in per_notice if n["top3_gate_rejected"]]}


def main() -> int:
    out: dict = {"finding": "F-11", "candidate_sha": "67f644b (code 6b51f00)",
                 "base_sha": "2d522f0"}
    cand = _drive(cand_rs, cand_sat, SCENARIO)
    cand_ctl = _drive(cand_rs, cand_sat, CONTROL)
    base = _drive(base_rs, base_sat, SCENARIO)
    base_ctl = _drive(base_rs, base_sat, CONTROL)
    out["candidate_scenario"] = cand
    out["candidate_control"] = cand_ctl
    out["base_scenario"] = base
    out["base_control"] = base_ctl
    out["realism_scan_real_inventories"] = _realism_scan()

    gate_is_pure = "_download_bytes" not in _src(cand_sat, "_public_file")
    out["gate_pure_no_network_in_candidate"] = gate_is_pure
    out["gate_identical_at_base"] = (
        _src(cand_sat, "_public_file") == _src(base_sat, "_public_file"))

    defect_shown = (not cand["amendment_attempted"]
                    and cand["record_status"] == "TEXT_UNAVAILABLE"
                    and cand["attempted_download_resource_ids"] == [])
    control_ok = cand_ctl["amendment_attempted"] and \
        cand_ctl["record_status"] == "DISCOVERY_TEXT_CAPTURED"
    base_same = (base["amendment_attempted"] == cand["amendment_attempted"]
                 and base["record_status"] == cand["record_status"]
                 and base_ctl["amendment_attempted"] == cand_ctl["amendment_attempted"])
    out["checks"] = {"candidate_defect_reproduced": defect_shown,
                     "control_proves_download_seam_live": control_ok,
                     "base_behaviour_identical": base_same}
    out["status"] = "FAIL" if (defect_shown and control_ok) else "PASS"
    out["classification_evidence"] = (
        "pre_existing" if base_same else "new_defect")
    print(json.dumps(out, indent=1, sort_keys=True, default=str))
    return 0


def _src(mod, name: str) -> str:
    import inspect
    return inspect.getsource(getattr(mod, name))


if __name__ == "__main__":
    try:
        rc = main()
    finally:
        shutil.rmtree(TMP, ignore_errors=True)
    sys.exit(rc)
