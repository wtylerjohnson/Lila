"""F-19 independent reproduction: does replay_ihs_portable.py synthesize request_started_at
from the previous clock reading while retrieved_at stays exact?

Checks (all offline, review clone untouched):
  A  static: driver mutates replay_clock only inside the _download_bytes mock; the product stamps
     request_started_at BEFORE calling _download_bytes.
  B  packaged receipt: native-ihs-replay-002/RECEIPT.json per-file request_started_at vs
     source-proof ihs-files-001/RESULTS.json started_at; retrieved_at exactness; unfetched file stamp.
  C  live rerun of the driver into a probe-local output dir; same comparison on the fresh receipt.
  D  synthetic: replicate the driver clock, call extract_public_attachment_text in reversed
     acquisition order, look for request_started_at AFTER its own retrieved_at.
  E  product consumers of request_started_at (grep over tracked .py files, excluding the stamp).
"""
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/Users/wtjohnson/lila-step7-052')
PKG = Path('/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052')
HERE = PKG / 'probes/verify/F-19/reproduce'
SRC = PKG / 'extracted/source-proof'
DRIVER = ROOT / 'docs/verification/step7-052/replay_ihs_portable.py'
NOTICE = '0caab6e53d8b47d7850692b7684610bf'
observed = {}
fails = []


def iso(s):
    return datetime.fromisoformat(s)


# ---------- A static ----------
drv = DRIVER.read_text()
mut_lines = [i + 1 for i, l in enumerate(drv.splitlines()) if "replay_clock['now'] =" in l]
saved_start = next(i + 1 for i, l in enumerate(drv.splitlines()) if 'def saved_bytes' in l)
saved_end = next(i + 1 for i, l in enumerate(drv.splitlines()) if 'class Source' in l)
init_line = next(i + 1 for i, l in enumerate(drv.splitlines()) if "replay_clock = {'now'" in l)
observed['A'] = {
    'docstring_claim': 'freezes file acquisition clocks at their original observed values' in drv,
    'clock_policy_claim': 'Original per-file observed acquisition times' in drv,
    'clock_init_line': init_line,
    'clock_mutation_lines': mut_lines,
    'saved_bytes_span': [saved_start, saved_end],
    'all_mutations_inside_saved_bytes': all(saved_start < m < saved_end for m in mut_lines),
    'saved_bytes_sets_now_to_retrieved_at': "replay_clock['now'] = datetime.fromisoformat(receipt['retrieved_at'])" in drv,
    'started_at_used_anywhere': "started_at'" in drv and "receipt['started_at']" in drv,
}
sat_src = (ROOT / 'tools/api/sam_attachment_text.py').read_text().splitlines()
stamp_line = next(i + 1 for i, l in enumerate(sat_src) if '"request_started_at": datetime.now' in l)
dl_line = next(i + 1 for i, l in enumerate(sat_src) if 'payload = _download_bytes(' in l)
observed['A']['product_stamp_line'] = stamp_line
observed['A']['product_download_call_line'] = dl_line
observed['A']['stamp_precedes_download'] = stamp_line < dl_line
if not (observed['A']['all_mutations_inside_saved_bytes'] and observed['A']['stamp_precedes_download']):
    fails.append('A: mechanism does not match finding')

# ---------- B packaged receipt ----------
results = {r['attachment']['resource_id']: r for r in json.loads((SRC / 'ihs-files-001/RESULTS.json').read_text())}
inv_completed = json.loads((SRC / 'public-inventory-001' / f'{NOTICE}.json').read_text())['completed_at']


def compare_receipt(receipt_path):
    rec = json.loads(Path(receipt_path).read_text())
    files = rec['attachment_record_receipts'][NOTICE]['files']
    rows = []
    prev_clock = inv_completed
    any_synth = False
    for f in files:
        rid = f['resource_id']
        entry = {'resource_id': rid, 'collection_status': f.get('collection_status'),
                 'replay_request_started_at': f.get('request_started_at'),
                 'replay_retrieved_at': f.get('retrieved_at')}
        if rid in results:
            entry['original_started_at'] = results[rid]['started_at']
            entry['original_retrieved_at'] = results[rid]['retrieved_at']
            entry['retrieved_at_exact'] = f.get('retrieved_at') == results[rid]['retrieved_at']
            entry['request_started_at_exact'] = f.get('request_started_at') == results[rid]['started_at']
            entry['request_started_at_equals_previous_clock'] = f.get('request_started_at') == prev_clock
            if not entry['request_started_at_exact']:
                any_synth = True
            if f.get('retrieved_at'):
                prev_clock = f['retrieved_at']
        elif f.get('request_started_at'):
            entry['unfetched_stamp_equals_previous_clock'] = f['request_started_at'] == prev_clock
            entry['note'] = 'never acquired originally; any stamp here is synthesized'
            any_synth = True
        rows.append(entry)
    return {'inventory_completed_at': inv_completed, 'files': rows, 'any_request_started_at_synthesized': any_synth,
            'all_retrieved_at_exact': all(r.get('retrieved_at_exact', True) for r in rows)}


observed['B'] = compare_receipt(PKG / 'extracted/producer-proof/native-ihs-replay-002/RECEIPT.json')
if not observed['B']['any_request_started_at_synthesized']:
    fails.append('B: packaged receipt request_started_at values are exact (finding refuted)')
if not observed['B']['all_retrieved_at_exact']:
    fails.append('B: retrieved_at NOT exact (finding overstated the exactness)')

# ---------- C live rerun of the driver ----------
out = HERE / 'rerun-output'
if out.exists():
    import shutil
    shutil.rmtree(out)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           LILA_NOTICE_CACHE_DIR=str(HERE / 'rerun-notice-cache'))
proc = subprocess.run([str(ROOT / '.venv/bin/python'), str(DRIVER), '--repo-root', str(ROOT),
                       '--source-root', str(SRC), '--output-dir', str(out)],
                      cwd=str(ROOT), env=env, capture_output=True, text=True, timeout=600)
observed['C'] = {'driver_exit': proc.returncode, 'stderr_tail': proc.stderr[-800:]}
if proc.returncode == 0 and (out / 'RECEIPT.json').exists():
    observed['C']['receipt'] = compare_receipt(out / 'RECEIPT.json')
    observed['C']['result_clock_policy'] = json.loads((out / 'RESULT.json').read_text()).get('clock_policy')
    pk = observed['B']['files']
    fr = observed['C']['receipt']['files']
    observed['C']['rerun_matches_packaged_clocks'] = [
        (a['resource_id'], a.get('replay_request_started_at') == b.get('replay_request_started_at'),
         a.get('replay_retrieved_at') == b.get('replay_retrieved_at')) for a, b in zip(pk, fr)]
    if not observed['C']['receipt']['any_request_started_at_synthesized']:
        fails.append('C: rerun produced exact request_started_at (finding refuted)')
else:
    fails.append('C: driver rerun did not complete')

# ---------- D synthetic reversed order ----------
sys.path.insert(0, str(ROOT))
from tools.api import sam_attachment_text as sat  # noqa: E402

inv_body = json.loads((SRC / 'public-inventory-001' / f'{NOTICE}.body').read_bytes())
from tools.api import sam_notice_detail as detail  # noqa: E402
attachments, recognized = detail._attachment_inventory(inv_body, NOTICE)
by_rid = {a['resource_id']: a for a in attachments}
order = ['b38d5c05511a4ff7bb8c54baf9361acb', '9170a0e92059434a808821358dabe89f']  # reversed vs acquisition
clock = {'now': iso(inv_completed)}


class ReplayClock(datetime):
    @classmethod
    def now(cls, tz=None):
        return clock['now'].astimezone(tz) if tz else clock['now'].replace(tzinfo=None)


def saved_bytes(rid, **kwargs):
    r = results[rid]
    clock['now'] = iso(r['retrieved_at'])
    return (SRC / 'ihs-files-001' / f'{rid}.pdf').read_bytes()


def deny(*a, **k):
    raise AssertionError('network blocked')


d_rows = []
with tempfile.TemporaryDirectory(dir=str(HERE)) as td, \
        patch.dict(os.environ, {'LILA_SAM_ATTACHMENT_TEXT_DIR': td}), \
        patch.object(sat, 'datetime', ReplayClock), patch.object(sat, '_download_bytes', saved_bytes), \
        patch.object(socket.socket, 'connect', deny), patch.object(socket, 'create_connection', deny):
    for rid in order:
        res = sat.extract_public_attachment_text(dict(by_rid[rid]))
        d_rows.append({'resource_id': rid, 'collection_status': res['collection_status'],
                       'request_started_at': res['request_started_at'], 'retrieved_at': res.get('retrieved_at'),
                       'original_started_at': results[rid]['started_at'],
                       'request_started_at_after_own_retrieved_at':
                           iso(res['request_started_at']) > iso(res['retrieved_at']) if res.get('retrieved_at') else None})
observed['D'] = {'order': order, 'files': d_rows,
                 'inversion_demonstrated': any(r['request_started_at_after_own_retrieved_at'] for r in d_rows)}
if not observed['D']['inversion_demonstrated']:
    fails.append('D: no request_started_at > retrieved_at inversion under reversed order')

# ---------- E consumers ----------
tracked = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '*.py'], text=True).split()
hits = []
for rel in tracked:
    for i, l in enumerate((ROOT / rel).read_text(errors='replace').splitlines()):
        if 'request_started_at' in l:
            hits.append(f'{rel}:{i + 1}')
observed['E'] = {'tracked_py_hits': hits,
                 'only_hit_is_the_stamp': hits == ['tools/api/sam_attachment_text.py:%d' % stamp_line]}
if not observed['E']['only_hit_is_the_stamp']:
    fails.append('E: request_started_at has a product consumer; finding understates reach')

status = 'FAIL' if not fails else 'INFO'
# FAIL here means: the finding reproduces (defect/overstatement demonstrated). If any check refuted it, list it.
print(json.dumps({'status': 'FAIL' if not fails else 'PASS_OR_MIXED', 'refutations': fails, 'observed': observed},
                 indent=2, default=str))
