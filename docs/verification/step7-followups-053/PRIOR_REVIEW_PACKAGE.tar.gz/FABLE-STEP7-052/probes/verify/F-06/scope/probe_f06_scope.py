"""F-06 SCOPE/CLASSIFICATION refuter probe.

Question: is the stale-inventory fallback that skips _resource_capture_valid a
new_defect (introduced or left open by Step7), pre_existing (same behaviour at
base 2d522f0), disclosed_residual, doc_overstatement, or harness?

Method: run identical cache seeds + identical mocked HTTP against the candidate
modules and against base copies (git show 2d522f0:<file>, written into this
probe dir with the em-dash character replaced by ' - ' to honour the hard rule;
no logic changed). Then check the run_searches receipt surface and the doc
sentences the finding leans on. No network (sockets blocked), no LLM.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
BASE_DIR = HERE / "base"
TMP = HERE / "tmp"
BASE_SHA = "2d522f0"
EMDASH = "\u2014"

sys.path.insert(0, str(REPO))
os.chdir(REPO)

# ---- hard network block -----------------------------------------------------
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand_detail  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import run_searches as cand_searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

_http.time.sleep = lambda *_a, **_k: None  # no backoff waits
sam_quota.calls_today = lambda: 0

observed: dict = {}
checks: dict[str, bool] = {}


def note(name: str, ok: bool, **details):
    checks[name] = bool(ok)
    observed[name] = {"ok": bool(ok), **details}


# ---- base copies -------------------------------------------------------------
def write_base(rel: str, out: Path) -> Path:
    src = subprocess.run(["git", "-C", str(REPO), "show", f"{BASE_SHA}:{rel}"],
                         check=True, capture_output=True, text=True).stdout
    src = src.replace(EMDASH, " - ")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(src)
    return out


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


if BASE_DIR.exists():
    shutil.rmtree(BASE_DIR)
base_detail_path = write_base("tools/api/sam_notice_detail.py", BASE_DIR / "base_sam_notice_detail.py")
base_searches_path = write_base("run_searches.py", BASE_DIR / "base_run_searches.py")
base_detail = load_module("base_sam_notice_detail", base_detail_path)
base_searches_err = None
try:
    base_searches = load_module("base_run_searches", base_searches_path)
except Exception as exc:  # noqa: BLE001
    base_searches = None
    base_searches_err = repr(exc)
observed["base_copies"] = {
    "detail_has_capture_valid": hasattr(base_detail, "_resource_capture_valid"),
    "detail_has_identity_check": hasattr(base_detail, "_resource_identity_matches"),
    "run_searches_loaded": base_searches is not None,
    "run_searches_load_error": base_searches_err,
}

# ---- helpers -----------------------------------------------------------------
NID_A = "a" * 32
NID_B = "b" * 32
RID_A = "c" * 32
RID_B = "d" * 32
RID_INV = "e" * 32
http_calls: list[str] = []


def mock_http(status: int, body: bytes):
    def handler(request):
        http_calls.append(f"{status}:{request.url}")
        return httpx.Response(status, content=body)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def fresh_cache(tag: str) -> Path:
    d = TMP / tag
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(d)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(d / "text")
    return d


def iso_ago(seconds: float, aware: bool = True) -> str:
    dt = datetime.now(timezone.utc) - timedelta(seconds=seconds)
    if not aware:
        dt = dt.replace(tzinfo=None)
    return dt.isoformat()


def sam_row(name: str, rid: str) -> dict:
    return {"name": name, "resourceId": rid, "mimeType": "text/plain", "size": 40,
            "accessLevel": "public"}


BODY_A = json.dumps({"attachments": [sam_row("Pricing A.txt", RID_A)]}).encode()
BODY_B_NAMED = json.dumps({"opportunityId": NID_B,
                           "attachments": [sam_row("B notice SOW.txt", RID_B)]}).encode()


def seed_candidate_capture(cache: Path, body: bytes) -> dict:
    """Produce a genuine candidate cache entry for NID_A from `body`."""
    mock_http(200, body)
    first = cand_detail.fetch_notice_resources(NID_A)
    assert first["from_cache"] is False and first["resources_checked"] is True
    return json.loads((cache / f"{NID_A}.resources.json").read_text())


def invented_row() -> dict:
    return {"name": "INVENTED SOW.txt", "type": "text/plain", "resource_id": RID_INV,
            "source_url": cand_detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID_INV),
            "size": 40, "access_level": "public", "access_status": "public",
            "export_controlled": "0", "explicit_access": "0"}


def tamper(entry: dict, age_seconds: float, aware: bool = True) -> dict:
    e = json.loads(json.dumps(entry))
    e["attachments"] = [invented_row()] + list(e.get("attachments") or [])
    e["attachment_inventory_count"] = len(e["attachments"])
    e["attachment_inventory_hash"] = cand_detail._manifest_hash(e["attachments"])
    e["retrieved_at"] = iso_ago(age_seconds, aware)
    if isinstance(e.get("raw_capture"), dict):
        e["raw_capture"]["received_at"] = iso_ago(age_seconds, aware)
    return e


def write_entry(cache: Path, entry: dict):
    (cache / f"{NID_A}.resources.json").write_text(json.dumps(entry))


def summary(r: dict) -> dict:
    return {
        "from_cache": r.get("from_cache"), "stale_cache": r.get("stale_cache"),
        "collection_status": r.get("collection_status"),
        "resources_checked": r.get("resources_checked"),
        "names": [a.get("name") for a in (r.get("attachments") or [])],
        "hash": r.get("attachment_inventory_hash"),
        "id": r.get("id"),
        "refresh_attempt_status": (r.get("refresh_attempt") or {}).get("collection_status"),
    }


def run_pair(tag: str, entry_for: callable, status: int, body: bytes) -> dict:
    """Same seed + same HTTP against candidate and base; return both summaries."""
    out = {}
    for label, mod in (("candidate", cand_detail), ("base", base_detail)):
        cache = fresh_cache(f"{tag}_{label}")
        write_entry(cache, entry_for(cache))
        http_calls.clear()
        mock_http(status, body)
        r = mod.fetch_notice_resources(NID_A)
        out[label] = {**summary(r), "http_calls": len(http_calls)}
        if label == "candidate":
            out["candidate"]["capture_valid_on_disk_entry"] = cand_detail._resource_capture_valid(
                json.loads((cache / f"{NID_A}.resources.json").read_text()))
    return out


# Genuine capture template (made once, copied into each scenario's cache dir).
template_cache = fresh_cache("template")
GENUINE = seed_candidate_capture(template_cache, BODY_A)
GENUINE_OBJ = template_cache / GENUINE["raw_capture"]["path"]
TAMPERED_HASH = cand_detail._manifest_hash([invented_row()] + GENUINE["attachments"])


def with_objects(cache: Path, entry: dict) -> dict:
    (cache / "objects").mkdir(exist_ok=True)
    shutil.copy(GENUINE_OBJ, cache / entry["raw_capture"]["path"])
    return entry


# ---- S1: tampered projection, past TTL (7h), refresh 503 ---------------------
s1 = run_pair("s1_tampered_7h_503",
              lambda cache: with_objects(cache, tamper(GENUINE, 7 * 3600)), 503, b"busy")
observed["S1_tampered_past_ttl_refresh_fails"] = s1
note("S1_candidate_serves_tampered_as_stale",
     s1["candidate"]["stale_cache"] is True and "INVENTED SOW.txt" in s1["candidate"]["names"]
     and s1["candidate"]["collection_status"] == "stale_inventory"
     and s1["candidate"]["capture_valid_on_disk_entry"] is False)
note("S1_base_identical_stale_service",
     s1["base"]["stale_cache"] is True and "INVENTED SOW.txt" in s1["base"]["names"]
     and s1["base"]["names"] == s1["candidate"]["names"]
     and s1["base"]["hash"] == s1["candidate"]["hash"] == TAMPERED_HASH)

# ---- S2: tampered projection, inside TTL (1h), refresh 503 -------------------
s2 = run_pair("s2_tampered_1h_503",
              lambda cache: with_objects(cache, tamper(GENUINE, 3600)), 503, b"busy")
observed["S2_tampered_inside_ttl_refresh_fails"] = s2
note("S2_candidate_refuses_fresh_then_serves_stale",
     s2["candidate"]["http_calls"] == 1 and s2["candidate"]["stale_cache"] is True
     and s2["candidate"]["collection_status"] == "stale_inventory")
note("S2_base_served_tampered_FRESH_zero_http",
     s2["base"]["http_calls"] == 0 and s2["base"]["from_cache"] is True
     and s2["base"]["stale_cache"] is False and "INVENTED SOW.txt" in s2["base"]["names"])

# ---- S3: legacy wrong-notice cache (rows of B under id A), refresh names B ---
def legacy_wrong_notice(age: float) -> dict:
    rows = [{"name": "B notice SOW.txt", "type": "text/plain", "resource_id": RID_B,
             "source_url": cand_detail.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=RID_B),
             "size": 40, "access_level": "public", "access_status": "public",
             "export_controlled": "0", "explicit_access": "0"}]
    return {"id": NID_A, "attachments": rows, "retrieved_at": iso_ago(age),
            "resources_checked": True, "resources_schema": "recognized_v1", "errors": [],
            "attachment_inventory_count": 1,
            "attachment_inventory_hash": cand_detail._manifest_hash(rows)}

s3 = run_pair("s3_legacy_wrong_7h_identityB", lambda cache: legacy_wrong_notice(7 * 3600), 200, BODY_B_NAMED)
observed["S3_legacy_wrong_notice_refresh_names_B"] = s3
note("S3_candidate_stale_with_identity_mismatch_receipt",
     s3["candidate"]["collection_status"] == "stale_inventory"
     and s3["candidate"]["refresh_attempt_status"] == "identity_mismatch"
     and s3["candidate"]["names"] == ["B notice SOW.txt"] and s3["candidate"]["id"] == NID_A)
note("S3_base_ACCEPTS_B_body_as_fresh_A_inventory",
     s3["base"]["from_cache"] is False and s3["base"]["stale_cache"] is False
     and s3["base"]["resources_checked"] is True and s3["base"]["names"] == ["B notice SOW.txt"])

s3b = run_pair("s3b_legacy_wrong_8d_identityB", lambda cache: legacy_wrong_notice(8 * 86400), 200, BODY_B_NAMED)
observed["S3b_legacy_wrong_notice_8_days"] = s3b
note("S3b_candidate_drops_after_7d_identity_mismatch",
     s3b["candidate"]["collection_status"] == "identity_mismatch"
     and s3b["candidate"]["resources_checked"] is False and s3b["candidate"]["names"] == [])
note("S3b_base_still_accepts_B_body",
     s3b["base"]["resources_checked"] is True and s3b["base"]["names"] == ["B notice SOW.txt"])

# ---- S4: naive clocks on an otherwise genuine capture, 1h, refresh 503 -------
def naive_entry(cache: Path) -> dict:
    e = json.loads(json.dumps(GENUINE))
    e["retrieved_at"] = iso_ago(3600, aware=False)
    e["raw_capture"]["received_at"] = iso_ago(3600, aware=False)
    return with_objects(cache, e)

s4 = run_pair("s4_naive_1h_503", naive_entry, 503, b"busy")
observed["S4_naive_clock_refresh_fails"] = s4
note("S4_candidate_refuses_fresh_serves_stale_naive",
     s4["candidate"]["http_calls"] == 1 and s4["candidate"]["stale_cache"] is True
     and s4["candidate"]["capture_valid_on_disk_entry"] is False)
note("S4_base_serves_naive_as_FRESH",
     s4["base"]["http_calls"] == 0 and s4["base"]["from_cache"] is True and s4["base"]["stale_cache"] is False)

# ---- S5: stale-path condition text identical base vs candidate ---------------
def stale_condition(src: str) -> str:
    m = re.search(r"except Exception as exc:.*?return cached", src, re.S)
    body = m.group(0) if m else ""
    # drop the two candidate-added receipt lines to compare the CONDITION only
    body = "\n".join(l for l in body.splitlines()
                     if "collection_status" not in l and "refresh_attempt" not in l)
    return re.sub(r"\s+", " ", body)

cand_src = (REPO / "tools/api/sam_notice_detail.py").read_text()
base_src = base_detail_path.read_text()
note("S5_stale_fallback_condition_byte_identical_to_base",
     stale_condition(cand_src) == stale_condition(base_src),
     candidate_condition=stale_condition(cand_src)[:400])
diff_stale = subprocess.run(
    ["git", "-C", str(REPO), "diff", f"{BASE_SHA}..6b51f00", "--", "tools/api/sam_notice_detail.py"],
    check=True, capture_output=True, text=True).stdout
added_in_except = [l for l in diff_stale.splitlines()
                   if l.startswith("+") and ("stale_inventory" in l or "refresh_attempt" in l)]
observed["S5_lines_added_to_stale_branch"] = added_in_except

# ---- S6: run_searches receipt surface, candidate vs base ---------------------
def run_enrich(mod, detail_mod, tag: str) -> tuple[list, dict]:
    cache = fresh_cache(tag)
    write_entry(cache, with_objects(cache, tamper(GENUINE, 7 * 3600)))
    import tools.api.sam_notice_detail as live_detail
    saved = live_detail.fetch_notice_resources
    live_detail.fetch_notice_resources = detail_mod.fetch_notice_resources
    try:
        candidate = RawOpportunity(source="sam.gov", source_id=NID_A, title="Requirement",
                                   agency="NASA", raw_payload={"type": "Solicitation"})
        class Source:
            last_attachment_census = {"selected": 1}
            def attachment_candidates(self, *a, **k):
                return [candidate]
        tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                 core=[TaxonomyTerm(term="network visibility")])
        http_calls.clear()
        mock_http(503, b"busy")
        return mod._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
    finally:
        live_detail.fetch_notice_resources = saved

rows_c, stats_c = run_enrich(cand_searches, cand_detail, "s6_candidate")
rc = stats_c["attachment_record_receipts"][NID_A]
inv = rc.get("inventory_receipt") or {}
observed["S6_candidate_receipt"] = {
    "rows_added": len(rows_c), "status": rc.get("status"), "errors": rc.get("errors"),
    "inventory_receipt_keys": sorted(inv.keys()),
    "inventory_receipt_collection_status": inv.get("collection_status"),
    "inventory_receipt_hash": inv.get("attachment_inventory_hash"),
    "hash_is_tampered_value": inv.get("attachment_inventory_hash") == TAMPERED_HASH,
    "raw_capture_sha_is_original": (inv.get("raw_capture") or {}).get("sha256") == GENUINE["raw_capture"]["sha256"],
    "refresh_attempt_status": (inv.get("refresh_attempt") or {}).get("collection_status"),
    "refresh_attempt_errors": (inv.get("refresh_attempt") or {}).get("errors"),
    "discovery_evidence_present": "discovery_evidence" in rc,
    "files_key_present": "files" in rc,
}
note("S6_candidate_excludes_stale_from_relevance_no_row",
     rc.get("status") == "STALE_INVENTORY" and len(rows_c) == 0 and "discovery_evidence" not in rc)
note("S6_candidate_receipt_carries_tampered_hash_but_labelled_stale",
     inv.get("attachment_inventory_hash") == TAMPERED_HASH and inv.get("collection_status") == "stale_inventory"
     and any("stale inventory" in str(e) for e in (rc.get("errors") or [])))
# the tampered hash is contradicted by the receipt's own raw_capture: re-derive
raw_bytes = (TMP / "s6_candidate" / inv["raw_capture"]["path"]).read_bytes()
items, recognized = cand_detail._attachment_inventory(json.loads(raw_bytes), NID_A)
note("S6_receipt_hash_disagrees_with_its_own_raw_capture",
     recognized and cand_detail._manifest_hash(items) != inv.get("attachment_inventory_hash"),
     hash_from_raw_capture=cand_detail._manifest_hash(items), hash_in_receipt=inv.get("attachment_inventory_hash"))

if base_searches is not None:
    rows_b, stats_b = run_enrich(base_searches, base_detail, "s6_base")
    rb = stats_b["attachment_record_receipts"][NID_A]
    observed["S6_base_receipt"] = {"rows_added": len(rows_b), "status": rb.get("status"),
                                   "keys": sorted(rb.keys()), "errors": rb.get("errors")}
    note("S6_base_also_STALE_INVENTORY_excluded_no_inventory_receipt_surface",
         rb.get("status") == "STALE_INVENTORY" and len(rows_b) == 0 and "inventory_receipt" not in rb)

# ---- S7: who consumes inventory_receipt / IDENTITY_MISMATCH reachability ----
consumers = []
for p in REPO.rglob("*.py"):
    s = str(p)
    if "/.venv/" in s or "/tests/" in s or "/docs/" in s:
        continue
    txt = p.read_text(errors="ignore")
    if "inventory_receipt" in txt:
        consumers.append(str(p.relative_to(REPO)))
observed["S7_inventory_receipt_readers_outside_tests"] = consumers
note("S7_only_writer_no_reader", consumers == ["run_searches.py"])
note("S7_run_searches_IDENTITY_MISMATCH_unreachable_id_always_requested",
     s3["candidate"]["id"] == NID_A and s3b["candidate"]["id"] == NID_A and s1["candidate"]["id"] == NID_A)

# ---- S8: doc sentences -------------------------------------------------------
conv = (REPO / "docs/CONVENTIONS.md").read_text()
contract = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
lv = (REPO / "docs/verification/step7-052/LOCAL_VERIFICATION.json").read_text()
review = (REPO / "docs/verification/step7-052/REVIEW.md").read_text()
docs_all = conv + contract + lv + review + (REPO / "docs/verification/step7-052/PRIOR_FOLLOWUPS.json").read_text()
sent = {
    "contract_current_reuse": "Current cache reuse rebinds the original response and projected inventory.",
    "conv_failed_refresh": "failed\nrefresh cannot return their text as freshly collected.",
    "conv_successful_caches": "Successful caches\nbind the original resource metadata, raw bytes, text bytes and aware acquisition\nclock.",
    "conv_identity_refuse": "Explicit response notice-ID conflicts refuse the inventory, including depth\nreconciliation.",
    "lv_stale_excluded": "Stale inventory remains excluded from native relevance.",
}
def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s)
present = {k: (_norm(v) in _norm(contract) or _norm(v) in _norm(conv) or _norm(v) in _norm(lv))
           for k, v in sent.items()}
observed["S8_doc_sentences_present"] = present
observed["S8_stale_inventory_token_in_docs_count"] = docs_all.count("stale_inventory")
# a disclosure must talk about the stale INVENTORY custody, not any other 'stale' input
stale_inv_hits = [m.group(0) for m in re.finditer(
    r"stale[^.\n]{0,40}inventor[^.\n]{0,80}(unvalidated|unbound|not rebound|without rebind|custody)"
    r"|inventor[^.\n]{0,40}stale[^.\n]{0,80}(unvalidated|unbound|not rebound|without rebind|custody)",
    _norm(docs_all), re.I)]
observed["S8_stale_inventory_custody_disclosures"] = stale_inv_hits
observed["S8_docs_mention_stale_unvalidated"] = bool(stale_inv_hits)
note("S8_current_reuse_claim_is_scoped_and_true", present["contract_current_reuse"] and s2["candidate"]["http_calls"] == 1)
note("S8_not_returned_as_freshly_collected",
     s1["candidate"]["from_cache"] is True and s1["candidate"]["stale_cache"] is True
     and s1["candidate"]["collection_status"] == "stale_inventory")
note("S8_no_doc_discloses_stale_path_is_unvalidated",
     not observed["S8_docs_mention_stale_unvalidated"] and observed["S8_stale_inventory_token_in_docs_count"] == 0)

# ---- verdict -----------------------------------------------------------------
serving_identical_at_base = checks["S1_base_identical_stale_service"] and checks["S5_stale_fallback_condition_byte_identical_to_base"]
base_worse = checks["S2_base_served_tampered_FRESH_zero_http"] and checks["S3_base_ACCEPTS_B_body_as_fresh_A_inventory"] and checks["S4_base_serves_naive_as_FRESH"]
receipt_surface_new = checks["S6_candidate_receipt_carries_tampered_hash_but_labelled_stale"] and checks.get("S6_base_also_STALE_INVENTORY_excluded_no_inventory_receipt_surface", False)
result = {
    "status": "INFO" if (serving_identical_at_base and base_worse) else "FAIL",
    "probe": "F-06 scope/classification",
    "classification": "pre_existing" if serving_identical_at_base else "new_defect",
    "reasoning_flags": {
        "stale_serving_identical_at_base": serving_identical_at_base,
        "base_strictly_worse_on_fresh_path": base_worse,
        "receipt_hash_surface_new_but_stale_labelled_and_unread": receipt_surface_new and checks["S7_only_writer_no_reader"],
        "no_evidence_reaches_assess_candidate": checks["S6_candidate_excludes_stale_from_relevance_no_row"],
        "docs_scoped_and_accurate_but_silent_on_stale_custody": checks["S8_current_reuse_claim_is_scoped_and_true"] and checks["S8_no_doc_discloses_stale_path_is_unvalidated"],
    },
    "checks": checks,
    "observed": observed,
}
print(json.dumps(result, indent=1, default=str))
shutil.rmtree(TMP, ignore_errors=True)
