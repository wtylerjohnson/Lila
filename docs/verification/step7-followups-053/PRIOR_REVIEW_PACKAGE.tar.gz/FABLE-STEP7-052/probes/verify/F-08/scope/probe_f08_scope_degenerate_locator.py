"""F-08 independent refutation probe: zero-budget third file locator.

Runs the native enrichment with a raised per-file text cap so the first
files fill the 150000-character combined bundle, then feeds the row to
the dossier research context. Repeats the identical inputs against BASE
copies (git show 2d522f0:<file>) of run_searches, sam_attachment_text and
dossier placed under ./base to classify new_defect vs pre_existing.

No network (sockets blocked), no LLM, no sam.gov. Writes only under this
probe directory. Prints one JSON object with status PASS/FAIL/INFO.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

# --- network isolation --------------------------------------------------------
def _blocked(*a, **k):
    raise RuntimeError("socket connect blocked by probe")
socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]

TMP_ROOT = Path(tempfile.mkdtemp(prefix="f08_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP_ROOT / "notice_cache")

import run_searches as cand_searches  # noqa: E402
from agents.decisions import dossier as cand_dossier  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as cand_sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


base_sat = _load("base_sam_attachment_text", HERE / "base" / "base_sam_attachment_text.py")
base_dossier = _load("base_dossier", HERE / "base" / "base_dossier.py")
base_searches = _load("base_run_searches", HERE / "base" / "base_run_searches.py")

NOTICE = "a" * 32
TERM = "network visibility"
TAXONOMY = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


def _public(rid: str, name: str) -> dict:
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def run_scenario(label: str, *, per_file_cap: int, n_files: int, chars_per_file: int,
                 searches_mod, sat_mod, dossier_mods: dict) -> dict:
    """Run enrichment once with the given cap and return measured facts."""
    cache_dir = TMP_ROOT / label
    cache_dir.mkdir(parents=True)
    files = [_public(letter * 32, f"SOW {i}.txt") for i, letter in enumerate("bcd"[:n_files])]
    prefix = f"{TERM} requirement. "
    content = {f["resource_id"]: (prefix + "x" * chars_per_file)[:chars_per_file] for f in files}
    inventory = detail._manifest_hash(files)
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    env = {"LILA_SAM_ATTACHMENT_TEXT_DIR": str(cache_dir),
           "LILA_SAM_ATTACHMENT_TEXT_CHARS": str(per_file_cap)}
    # The cap is read at module import; patch the module constant to honour
    # the env seam faithfully for both base and candidate copies.
    with mock.patch.dict(os.environ, env), \
            mock.patch.object(sat_mod, "MAX_ATTACHMENT_TEXT_CHARS", per_file_cap), \
            mock.patch("tools.api.sam_quota.calls_today", return_value=0), \
            mock.patch.object(detail, "fetch_notice_resources", return_value={
                "id": NOTICE, "resources_checked": True, "attachments": files,
                "attachment_inventory_hash": inventory}), \
            mock.patch.object(sat_mod, "_download_bytes",
                              lambda rid, **k: content[rid].encode()), \
            mock.patch.dict(sys.modules, {"tools.api.sam_attachment_text": sat_mod}):
        rows, stats = searches_mod._enrich_sam_public_attachments(
            [], Source(), object(), TAXONOMY, None, limit=8)

    out: dict = {"per_file_cap": per_file_cap, "n_files": n_files,
                 "chars_per_file": chars_per_file, "rows": len(rows)}
    if not rows:
        out["record_receipt"] = stats["attachment_record_receipts"].get(NOTICE)
        return out
    raw = rows[0]["raw_payload"]
    text = raw["text"]
    out["combined_len"] = len(text)
    out["combined_ends_with_separator"] = text.endswith("\n\n")
    out["record_status"] = stats["attachment_record_receipts"][NOTICE]["status"]
    evidence = raw["attachment_evidence"]
    out["evidence_files"] = len(evidence)
    out["locators"] = [
        [e.get("combined_text_locator", {}).get("start"), e.get("combined_text_locator", {}).get("end")]
        for e in evidence]
    out["file_text_truncated"] = [e.get("file_text_truncated") for e in evidence]
    out["degenerate_locators"] = [
        e["resource_id"][:4] for e in evidence
        if isinstance(e.get("combined_text_locator"), dict)
        and e["combined_text_locator"]["start"] >= e["combined_text_locator"]["end"]]
    out["locator_beyond_text"] = [
        e["resource_id"][:4] for e in evidence
        if isinstance(e.get("combined_text_locator"), dict)
        and e["combined_text_locator"]["end"] > len(text)]
    receipts = stats["attachment_record_receipts"][NOTICE].get("files")
    if receipts:
        out["file_receipts"] = [{"rid": r["resource_id"][:4], "status": r["status"],
                                 "reason": r.get("reason")} for r in receipts]
    out["has_collection_v1"] = "attachment_collection_v1" in raw
    if out["has_collection_v1"]:
        out["collection_lists_files"] = len(raw["attachment_collection_v1"]["files"])
    depth = {"id": NOTICE, "resources_checked": True, "attachment_inventory_hash": inventory}
    out["dossier"] = {}
    for dname, dmod in dossier_mods.items():
        ctx = dmod._attachment_research_context(rows[0], depth)
        entry = {"status": ctx.get("status"), "reason": ctx.get("reason")}
        if ctx.get("status") == "discovery_only":
            entry["included_characters"] = ctx.get("included_characters")
            entry["passages"] = len(ctx.get("file_passages", [])) if "file_passages" in ctx else None
        out["dossier"][dname] = entry
    return out


observed: dict = {"tmp_root": str(TMP_ROOT)}
cand = dict(searches_mod=cand_searches, sat_mod=cand_sat,
            dossier_mods={"candidate": cand_dossier})
base = dict(searches_mod=base_searches, sat_mod=base_sat,
            dossier_mods={"base": base_dossier, "candidate": cand_dossier})

try:
    observed["cand_default_50000_3files"] = run_scenario(
        "c50000", per_file_cap=50000, n_files=3, chars_per_file=60000, **cand)
    observed["cand_74997_3files"] = run_scenario(
        "c74997", per_file_cap=74997, n_files=3, chars_per_file=90000, **cand)
    observed["cand_74998_3files"] = run_scenario(
        "c74998", per_file_cap=74998, n_files=3, chars_per_file=90000, **cand)
    observed["cand_100000_3files"] = run_scenario(
        "c100000", per_file_cap=100000, n_files=3, chars_per_file=120000, **cand)
    observed["cand_149998_2files"] = run_scenario(
        "c149998", per_file_cap=149998, n_files=2, chars_per_file=160000, **cand)
    observed["base_100000_3files"] = run_scenario(
        "b100000", per_file_cap=100000, n_files=3, chars_per_file=120000, **base)
    observed["base_74998_3files"] = run_scenario(
        "b74998", per_file_cap=74998, n_files=3, chars_per_file=90000, **base)
    observed["base_default_50000_3files"] = run_scenario(
        "b50000", per_file_cap=50000, n_files=3, chars_per_file=60000, **base)
finally:
    shutil.rmtree(TMP_ROOT, ignore_errors=True)

c100 = observed["cand_100000_3files"]
b100 = observed["base_100000_3files"]
c74998 = observed["cand_74998_3files"]
c74997 = observed["cand_74997_3files"]
cdef = observed["cand_default_50000_3files"]

checks = {
    "default_candidate_readable": cdef["dossier"]["candidate"]["status"] == "discovery_only",
    "boundary_74997_readable": c74997["dossier"]["candidate"]["status"] == "discovery_only",
    "boundary_74998_degenerate": bool(c74998["degenerate_locators"]),
    "boundary_74998_dropped": c74998["dossier"]["candidate"]["status"] == "unavailable",
    "cap_100000_third_locator_beyond_text": bool(c100["locator_beyond_text"]),
    "cap_100000_third_receipt_captured": any(
        r["rid"] == "dddd" and r["status"] == "captured_discovery_only"
        for r in c100.get("file_receipts", [])),
    "cap_100000_candidate_dossier_unavailable": c100["dossier"]["candidate"]["status"] == "unavailable",
    "cap_100000_base_dossier_on_base_row_readable": b100["dossier"]["base"]["status"] == "discovery_only",
    "cap_100000_candidate_dossier_on_base_row_readable": b100["dossier"]["candidate"]["status"] == "discovery_only",
    "base_row_has_no_collection_v1": b100["has_collection_v1"] is False,
    "two_file_149998_dangling_separator": observed["cand_149998_2files"]["combined_ends_with_separator"],
    "two_file_149998_dropped": observed["cand_149998_2files"]["dossier"]["candidate"]["status"] == "unavailable",
}
regression = (checks["cap_100000_candidate_dossier_unavailable"]
              and checks["cap_100000_base_dossier_on_base_row_readable"]
              and checks["default_candidate_readable"])
status = "FAIL" if regression else ("PASS" if checks["default_candidate_readable"] else "INFO")
print(json.dumps({"probe": "F-08 scope/classification refutation",
                  "status": status,
                  "classification": "new_defect" if regression else "not_reproduced",
                  "checks": checks, "observed": observed}, indent=1, sort_keys=True))
