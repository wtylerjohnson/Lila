"""F-08 independent reproduction: zero-budget third file / degenerate locator.

Driver spawns one worker per configuration with the real env seam
LILA_SAM_ATTACHMENT_TEXT_CHARS set (module constant is read at import time),
sockets blocked, notice inventory and downloads mocked in-process.
Worker runs candidate enrichment + candidate dossier, then base enrichment
(base run_searches + base extractor copies in this dir) + base/candidate
dossier on the base-shaped row. Prints one JSON object.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
PY = REPO / ".venv" / "bin" / "python"
NOTICE = "a" * 32
TERM = "network visibility"
RIDS = ["b" * 32, "c" * 32, "d" * 32]


def _block_sockets() -> None:
    def deny(*a, **k):
        raise RuntimeError("network blocked by probe")
    socket.socket.connect = deny  # type: ignore[assignment]
    socket.socket.connect_ex = deny  # type: ignore[assignment]
    socket.create_connection = deny  # type: ignore[assignment]


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _source_text(index: int, chars: int) -> str:
    # Longer than any cap so the extractor cuts it to exactly MAX chars.
    unit = f"File{index} buyer requires {TERM} deliverables. "
    return (unit * (chars // len(unit) + 2))[: chars + 5000]


def _worker(chars: int, nfiles: int) -> dict:
    _block_sockets()
    os.chdir(REPO)
    if str(REPO) not in sys.path:
        sys.path.insert(0, str(REPO))
    cand_cache = tempfile.mkdtemp(prefix="f08_cand_", dir=str(HERE))
    base_cache = tempfile.mkdtemp(prefix="f08_base_", dir=str(HERE))
    notice_cache = tempfile.mkdtemp(prefix="f08_notice_", dir=str(HERE))
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = cand_cache
    os.environ["LILA_NOTICE_CACHE_DIR"] = notice_cache
    out: dict = {"chars_env": chars, "nfiles": nfiles}
    try:
        import run_searches as searches
        from agents.decisions import dossier as cand_dossier
        from agents.schemas import RawOpportunity
        from tools.api import sam_attachment_text as sat
        from tools.api import sam_notice_detail as detail
        from tools.api import sam_quota
        from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

        out["module_cap_seen"] = sat.MAX_ATTACHMENT_TEXT_CHARS
        files = [{"resource_id": rid, "name": f"SOW {i + 1}.txt",
                  "access_level": "public", "access_status": "public",
                  "export_controlled": "0", "explicit_access": "0"}
                 for i, rid in enumerate(RIDS[:nfiles])]
        inventory = detail._manifest_hash(files)
        texts = {rid: _source_text(i, chars) for i, rid in enumerate(RIDS[:nfiles])}

        sam_quota.calls_today = lambda: 0
        detail.fetch_notice_resources = lambda *a, **k: {
            "id": NOTICE, "resources_checked": True, "attachments": files,
            "attachment_inventory_hash": inventory}
        sat._download_bytes = lambda rid, **k: texts[rid].encode()

        taxonomy = CapabilityTaxonomy(client_name="Testco", version=1,
                                      updated="2026-07-21",
                                      core=[TaxonomyTerm(term=TERM)])
        candidate = RawOpportunity(source="sam.gov", source_id=NOTICE,
                                   title="Requirement", agency="NASA",
                                   raw_payload={"type": "Solicitation"})

        class Source:
            last_attachment_census = {"selected": 1}

            def attachment_candidates(self, *a, **k):
                return [candidate]

        depth = {"id": NOTICE, "resources_checked": True,
                 "attachment_inventory_hash": inventory}

        # ---- candidate ----
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(), taxonomy, None, limit=8)
        out["candidate_rows"] = len(rows)
        if rows:
            raw = rows[0]["raw_payload"]
            ev = raw["attachment_evidence"]
            receipt = stats["attachment_record_receipts"][NOTICE]
            text = raw["text"]
            out["candidate"] = {
                "record_status": receipt["status"],
                "text_len": len(text),
                "text_ends_with_separator": text.endswith("\n\n"),
                "evidence_count": len(ev),
                "locators": [[e["combined_text_locator"]["start"],
                              e["combined_text_locator"]["end"]] for e in ev],
                "file_text_locators": [[e["file_text_locator"]["start"],
                                        e["file_text_locator"]["end"]] for e in ev],
                "file_text_truncated": [e["file_text_truncated"] for e in ev],
                "last_text_sha_is_empty_sha": ev[-1]["text_sha256"]
                == hashlib.sha256(b"").hexdigest(),
                "file_receipts": [{"name": r["name"], "status": r["status"],
                                   "reason": r["reason"]}
                                  for r in receipt["files"]],
                "collection_files_in_fingerprint": [
                    f["resource_id"][:4] for f in
                    raw["attachment_collection_v1"]["files"]],
                "degenerate": [e["combined_text_locator"]["start"]
                               >= e["combined_text_locator"]["end"] for e in ev],
                "last_start_beyond_text": ev[-1]["combined_text_locator"]["start"]
                > len(text),
            }
            ctx = cand_dossier._attachment_research_context(rows[0], depth)
            out["candidate_dossier"] = {
                "status": ctx.get("status"), "reason": ctx.get("reason"),
                "passages": len(ctx.get("file_passages") or []),
                "included_characters": ctx.get("included_characters"),
            }
        else:
            out["candidate"] = {"record_status": stats["attachment_record_receipts"][NOTICE]["status"],
                                "errors": stats["attachment_errors"]}

        # ---- base (run_searches + extractor at 2d522f0, copies in this dir) ----
        os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = base_cache
        base_sat = _load("base_sam_attachment_text", HERE / "base_sam_attachment_text.py")
        out["base_module_cap_seen"] = base_sat.MAX_ATTACHMENT_TEXT_CHARS
        base_sat._download_bytes = lambda rid, **k: texts[rid].encode()
        saved = sys.modules["tools.api.sam_attachment_text"]
        sys.modules["tools.api.sam_attachment_text"] = base_sat
        try:
            base_searches = _load("base_run_searches", HERE / "base_run_searches.py")
            brows, bstats = base_searches._enrich_sam_public_attachments(
                [], Source(), object(), taxonomy, None, limit=8)
        finally:
            sys.modules["tools.api.sam_attachment_text"] = saved
        base_dossier = _load("base_dossier", HERE / "base_dossier.py")
        out["base_rows"] = len(brows)
        if brows:
            braw = brows[0]["raw_payload"]
            bctx_base = base_dossier._attachment_research_context(brows[0], depth)
            bctx_cand = cand_dossier._attachment_research_context(brows[0], depth)
            out["base"] = {
                "record_status": bstats["attachment_record_receipts"][NOTICE]["status"],
                "text_len": len(braw["text"]),
                "evidence_count": len(braw["attachment_evidence"]),
                "has_collection_v1": "attachment_collection_v1" in braw,
                "base_dossier_on_base_row": {"status": bctx_base.get("status"),
                                             "reason": bctx_base.get("reason"),
                                             "included_characters": bctx_base.get("included_characters")},
                "candidate_dossier_on_base_row": {"status": bctx_cand.get("status"),
                                                  "reason": bctx_cand.get("reason"),
                                                  "included_characters": bctx_cand.get("included_characters")},
            }
    finally:
        for d in (cand_cache, base_cache, notice_cache):
            shutil.rmtree(d, ignore_errors=True)
    return out


def _driver() -> dict:
    configs = [
        # (chars, nfiles, expect_degenerate)
        (50000, 3, False),   # default: 3 x 50000 + 4 = 150004
        (74997, 3, False),   # boundary below (claimed working)
        (74998, 3, True),    # claimed first failing value
        (80000, 3, True),    # ELD-05 value
        (100000, 3, True),   # UO-1 / YU-3 value
        (149997, 2, False),  # two-file boundary below
        (149998, 2, True),   # UO-1 two-file variant
    ]
    results = []
    checks = []
    for chars, nfiles, expect in configs:
        env = dict(os.environ)
        env.update({"LILA_SAM_ATTACHMENT_TEXT_CHARS": str(chars),
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "LILA_SAM_ATTACHMENT_STAGE_SECONDS": "120"})
        proc = subprocess.run(
            [str(PY), str(Path(__file__).resolve()), "--worker", str(chars), str(nfiles)],
            cwd=str(REPO), env=env, capture_output=True, text=True, timeout=600)
        if proc.returncode != 0:
            results.append({"chars_env": chars, "nfiles": nfiles, "error": proc.stderr[-3000:]})
            checks.append({"config": [chars, nfiles], "ok": False, "why": "worker crashed"})
            continue
        r = json.loads(proc.stdout.strip().splitlines()[-1])
        results.append(r)
        c = r.get("candidate", {})
        cd = r.get("candidate_dossier", {})
        b = r.get("base", {})
        if expect:
            ok = (r.get("module_cap_seen") == chars
                  and c.get("evidence_count") == nfiles
                  and c.get("degenerate", [None])[-1] is True
                  and c.get("file_receipts", [{}])[nfiles - 1].get("status") == "captured_discovery_only"
                  and c.get("record_status") == "DISCOVERY_TEXT_CAPTURED"
                  and cd.get("status") == "unavailable"
                  and cd.get("reason") == "Attachment file locator does not match retained text"
                  and cd.get("passages") == 0
                  and b.get("base_dossier_on_base_row", {}).get("status") == "discovery_only"
                  and b.get("candidate_dossier_on_base_row", {}).get("status") == "discovery_only")
        else:
            ok = (r.get("module_cap_seen") == chars
                  and c.get("evidence_count") == nfiles
                  and not any(c.get("degenerate", [True]))
                  and cd.get("status") == "discovery_only"
                  and cd.get("passages") == nfiles
                  and b.get("candidate_dossier_on_base_row", {}).get("status") == "discovery_only")
        checks.append({"config": [chars, nfiles], "expected_degenerate": expect, "ok": ok,
                       "locators": c.get("locators"), "dossier": cd.get("status"),
                       "reason": cd.get("reason"), "third_receipt": (c.get("file_receipts") or [{}])[-1]})
    status = "FAIL" if all(ch["ok"] for ch in checks) else "INFO"
    return {"status": status,
            "meaning": ("FAIL = defect reproduced exactly as described (degenerate locator "
                        "recorded captured_discovery_only, whole research context dropped, "
                        "base row still readable); INFO = some part did not reproduce"),
            "checks": checks, "observed": results}


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "--worker":
        print(json.dumps(_worker(int(sys.argv[2]), int(sys.argv[3])), sort_keys=True))
    else:
        print(json.dumps(_driver(), indent=1, sort_keys=True))
