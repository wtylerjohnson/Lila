"""F-09 refuter probe: is confirmed_empty reachable from real SAM zero-file shapes?

Runs the candidate and the base (2d522f0) inventory classifier over the 21 real
captured bodies and over synthetic shapes, then drives the candidate full path
(fetch_notice_resources) through httpx.MockTransport with sockets blocked.
Prints one JSON object. No network, no LLM, no writes outside the probe dir.
"""
import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path(__file__).resolve().parent
BODIES = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

# Block any real socket connect.
def _deny(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _deny  # type: ignore[assignment]
socket.socket.connect_ex = _deny  # type: ignore[assignment]

cache_dir = Path(tempfile.mkdtemp(prefix="f09_cache_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(cache_dir)

import httpx  # noqa: E402
from tools.api import _http, sam_notice_detail as cand  # noqa: E402

spec = importlib.util.spec_from_file_location("sam_notice_detail_base", HERE / "base" / "sam_notice_detail_base.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

observed = {}
status = "PASS"

def cand_state(payload, nid):
    if not cand._resource_identity_matches(payload, nid):
        return "identity_mismatch"
    items, recognized = cand._attachment_inventory(payload, nid)
    if not recognized:
        return "unrecognized_inventory"
    return "inventory_captured" if items else "confirmed_empty"

def base_state(payload, nid):
    items, recognized = base._attachment_inventory(payload)
    if not recognized:
        return "unrecognized_inventory"
    return "inventory_captured" if items else "confirmed_empty"

# 1. The 21 real bodies.
real = {}
census_c, census_b = {}, {}
shape_census = {}
links_self_names_notice = {}
for body in sorted(BODIES.glob("*.body")):
    nid = body.stem
    payload = json.loads(body.read_bytes())
    top = tuple(sorted(payload.keys())) if isinstance(payload, dict) else ("LIST",)
    emb = payload.get("_embedded") if isinstance(payload, dict) else None
    shape = f"top={top} embedded={tuple(sorted(emb.keys())) if isinstance(emb, dict) else None}"
    shape_census[shape] = shape_census.get(shape, 0) + 1
    c = cand_state(payload, nid); b = base_state(payload, nid)
    census_c[c] = census_c.get(c, 0) + 1; census_b[b] = census_b.get(b, 0) + 1
    real[nid] = {"candidate": c, "base": b, "bytes": len(body.read_bytes()), "shape": shape}
    if "_embedded" not in payload:
        href = payload.get("_links", {}).get("self", {}).get("href", "")
        links_self_names_notice[nid] = bool(re.search(rf"/opportunities/{nid}/resources", href))
observed["real_bodies"] = {
    "count": len(real), "shape_census": shape_census,
    "candidate_census": census_c, "base_census": census_b,
    "candidate_equals_base_every_body": all(v["candidate"] == v["base"] for v in real.values()),
    "confirmed_empty_count_candidate": census_c.get("confirmed_empty", 0),
    "confirmed_empty_count_base": census_b.get("confirmed_empty", 0),
    "links_only_bodies_self_href_names_requested_notice": links_self_names_notice,
    "ground_truth_that_links_only_notices_have_zero_files": "NOT IN PACKAGE (RESULTS.json response_notice_ids=[]; no attachment census for these four notices exists offline)",
}

# 2. Synthetic zero-file shapes.
NID = "a" * 32
links_only = {"_links": {"self": {"href": f"https://sam.gov/api/prod/opps/v3/opportunities/{NID}/resources"}}}
synthetic = {
    "links_only_self_names_notice": links_only,
    "wrapper_row_attachments_empty": {"_embedded": {"opportunityAttachmentList": [{"opportunityId": NID, "attachments": []}]}, "_links": links_only["_links"]},
    "wrapper_list_no_rows": {"_embedded": {"opportunityAttachmentList": []}, "_links": links_only["_links"]},
    "embedded_empty_dict": {"_embedded": {}, "_links": links_only["_links"]},
    "top_level_attachments_empty": {"attachments": []},
    "top_level_resources_empty": {"resources": []},
    "bare_empty_list": [],
    "bare_empty_dict": {},
}
syn = {}
for name, payload in synthetic.items():
    syn[name] = {"candidate": cand_state(payload, NID), "base": base_state(payload, NID)}
observed["synthetic_shapes"] = syn
observed["synthetic_confirmed_empty_reachable"] = sorted(k for k, v in syn.items() if v["candidate"] == "confirmed_empty")
observed["synthetic_candidate_equals_base"] = all(v["candidate"] == v["base"] for v in syn.values())

# 3. Candidate full path via MockTransport for the two contested shapes.
_NATIVE = _http._request
def full_path(payload_bytes, nid):
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=payload_bytes, headers={"content-type": "application/hal+json"})
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    _http._request = _NATIVE
    res = cand.fetch_notice_resources(nid)
    cache_file = cache_dir / f"{nid}.resources.json"
    return {"collection_status": res.get("collection_status"), "resources_checked": res.get("resources_checked"),
            "attachments": res.get("attachments"), "errors": res.get("errors"),
            "cache_written": cache_file.exists(), "raw_retained": bool(res.get("raw_capture", {}).get("sha256")),
            "run_searches_receipt_would_be": ("INVENTORY_UNAVAILABLE" if res.get("resources_checked") is not True or res.get("attachments") is None
                                             else ("VERIFIED_EMPTY_INVENTORY" if not res.get("attachments") else "INVENTORY_CHECKED")),
            "calls": len(calls)}
real_links_only = next(b for b in sorted(BODIES.glob("*.body")) if b"_embedded" not in b.read_bytes())
observed["full_path"] = {
    "real_links_only_body_" + real_links_only.stem: full_path(real_links_only.read_bytes(), real_links_only.stem),
    "wrapper_row_attachments_empty": full_path(json.dumps(synthetic["wrapper_row_attachments_empty"]).encode(), NID),
    "top_level_attachments_empty": full_path(json.dumps(synthetic["top_level_attachments_empty"]).encode(), "c" * 32),
}

# 4. Disclosure sentences.
conv = (REPO / "docs/CONVENTIONS.md").read_text()
prepatch = (REPO / "docs/verification/step7-052/PRE_PATCH_REPORT.md").read_text()
handoff = (REPO / "docs/verification/step7-052/FABLE_HANDOFF.md").read_text()
disp = (REPO / "docs/verification/step7-052/FAMILY_COLLECTION_DISPOSITIONS.json").read_text()
proto = json.loads((REPO / "docs/verification/step7-052/COLLECTION_PROTOCOL.v1.json").read_text())
observed["disclosures"] = {
    "CONVENTIONS_unknown_shapes_remain_unknown": "Unknown JSON shapes remain unknown, not zero files." in conv,
    "CONVENTIONS_zero_must_be_proved_by_recognized_schema": "zero attachments must be\n  proved by a recognized SAM resources schema" in conv or "proved by a recognized SAM resources schema" in conv,
    "PRE_PATCH_four_unfamiliar_none_called_empty": "The latter remain unknown; none is called confirmed empty." in prepatch,
    "HANDOFF_four_unrecognized_not_empty": "four were unrecognized, not empty" in handoff,
    "DISPOSITIONS_no_inference_of_empty_files": "No inference of empty files" in disp,
    "PROTOCOL_states_list_contains_confirmed_empty": "confirmed_empty" in proto.get("states", []),
    "fetch_notice_resources_docstring_unknown_schema_not_cached": "an error or unknown schema is not" in (cand.fetch_notice_resources.__doc__ or ""),
    "any_doc_claims_confirmed_empty_reached_on_live_SAM": False,
}

# Verdict logic for the refuter: the finding is TRUE as a measurement (0 confirmed_empty on real bodies, both
# base and candidate) but its production-unreachability claim rests on an inferred SAM shape, and the direction
# is the documented conservative one.
observed["assessment"] = {
    "measured_identical_at_base": observed["real_bodies"]["candidate_equals_base_every_body"] and observed["synthetic_candidate_equals_base"],
    "wrapper_empty_shape_witnessed_in_any_real_body": any("attachments\": []" in b.read_text() for b in BODIES.glob("*.body")),
    "conservative_direction": True,
}
status = "INFO"
print(json.dumps({"status": status, "observed": observed}, indent=1, sort_keys=True))
