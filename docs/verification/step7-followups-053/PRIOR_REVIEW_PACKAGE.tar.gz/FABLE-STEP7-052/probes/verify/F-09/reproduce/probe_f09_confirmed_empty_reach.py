"""F-09 independent reproduction: is confirmed_empty reachable from real SAM shapes?

Written from the merged finding text only (member scripts not consulted first).
Checks, against the candidate checkout and a sanitized copy of the base file:
  A. 21 real captured inventory bodies -> candidate _attachment_inventory census
     and fetch_notice_resources collection_status via MockTransport (no network).
  B. Synthetic wrapper-with-empty-attachments shape
     {_embedded:{opportunityAttachmentList:[{opportunityId:<this>, attachments:[]}]}}
  C. Synthetic shapes SAM is not observed to emit (top-level / _embedded empty list)
     -> do they reach confirmed_empty?
  D. Base (2d522f0) _attachment_inventory on every shape; equality with candidate.
  E. run_searches receipt state for a real _links-only body (expect
     INVENTORY_UNAVAILABLE) and for a synthetic empty list (VERIFIED_EMPTY_INVENTORY).
  F. Doc disclosure checks (PRE_PATCH_REPORT / FABLE_HANDOFF / protocol states).
Prints one JSON object with status and observed.
"""
import glob
import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
HERE = REVIEW / "probes" / "verify" / "F-09" / "reproduce"
BODIES = REVIEW / "extracted" / "source-proof" / "public-inventory-001"
sys.path.insert(0, str(REPO))

# Block any real socket connect.
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

tmp_root = Path(tempfile.mkdtemp(prefix="f09_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp_root / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp_root / "text")

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

observed: dict = {}
problems: list[str] = []


def serve(body: bytes, status: int = 200):
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=body,
                              headers={"content-type": "application/hal+json"})
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def fetch_fresh(notice_id: str, body: bytes) -> dict:
    cache = detail._cache_dir() / f"{notice_id}.resources.json"
    if cache.exists():
        cache.unlink()
    serve(body)
    return detail.fetch_notice_resources(notice_id)


# ---------- A. real bodies ----------
real = {}
for path in sorted(glob.glob(str(BODIES / "*.body"))):
    nid = Path(path).stem
    raw = Path(path).read_bytes()
    payload = json.loads(raw)
    items, recognized = detail._attachment_inventory(payload, nid)
    b_items, b_recognized = base._attachment_inventory(payload)
    res = fetch_fresh(nid, raw)
    keys = sorted(payload.keys()) if isinstance(payload, dict) else ["<list>"]
    links_self = ((payload.get("_links") or {}).get("self") or {}).get("href", "") \
        if isinstance(payload, dict) else ""
    real[nid] = {
        "bytes": len(raw),
        "top_keys": keys,
        "cand_recognized": recognized,
        "cand_count": None if items is None else len(items),
        "base_recognized": b_recognized,
        "base_count": None if b_items is None else len(b_items),
        "fetch_status": res.get("collection_status"),
        "self_href_names_notice": nid in links_self,
        "has_embedded": isinstance(payload, dict) and "_embedded" in payload,
    }
census = {}
for v in real.values():
    census[v["fetch_status"]] = census.get(v["fetch_status"], 0) + 1
links_only = [k for k, v in real.items() if v["top_keys"] == ["_links"]]
observed["A_real_bodies"] = {
    "count": len(real),
    "fetch_status_census": census,
    "links_only_ids": links_only,
    "links_only_all_self_href_name_notice": all(real[k]["self_href_names_notice"] for k in links_only),
    "links_only_bytes": sorted({real[k]["bytes"] for k in links_only}),
    "confirmed_empty_count": census.get("confirmed_empty", 0),
    "base_equals_candidate_all": all(
        (v["cand_recognized"], v["cand_count"]) == (v["base_recognized"], v["base_count"])
        for v in real.values()),
    "shape_census": sorted({",".join(v["top_keys"]) for v in real.values()}),
}
if len(real) != 21:
    problems.append(f"expected 21 real bodies, found {len(real)}")
if len(links_only) != 4:
    problems.append(f"expected 4 links-only bodies, found {len(links_only)}")
if census.get("confirmed_empty", 0) != 0:
    problems.append("a real body reached confirmed_empty")
if census.get("unrecognized_inventory", 0) != 4 or census.get("inventory_captured", 0) != 17:
    problems.append(f"census differs from 17/4 claim: {census}")

# ---------- B/C. synthetic shapes ----------
NID = "0" * 31 + "1"
def links(nid):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{nid}/resources?withScanResult=false&excludeDeleted=false")
    return {"self": {"href": href}, "opportunity:publish:latest": {"href": href}}

shapes = {
    "wrapper_row_empty_attachments_real_style": {
        "_embedded": {"opportunityAttachmentList": [{"opportunityId": NID, "attachments": []}]},
        "_links": links(NID)},
    "wrapper_list_no_rows": {
        "_embedded": {"opportunityAttachmentList": []}, "_links": links(NID)},
    "top_level_attachments_empty": {"attachments": []},
    "top_level_resources_empty": {"resources": []},
    "embedded_as_empty_list": {"_embedded": [], "_links": links(NID)},
    "links_only_synthetic": {"_links": links(NID)},
    "empty_object": {},
    "top_level_empty_list": [],
}
syn = {}
for name, payload in shapes.items():
    body = json.dumps(payload).encode()
    c_items, c_rec = detail._attachment_inventory(payload, NID)
    b_items, b_rec = base._attachment_inventory(payload)
    res = fetch_fresh(NID, body)
    syn[name] = {
        "cand": [c_rec, None if c_items is None else len(c_items)],
        "base": [b_rec, None if b_items is None else len(b_items)],
        "fetch_status": res.get("collection_status"),
        "same_as_base": (c_rec, c_items) == (b_rec, b_items),
    }
observed["B_C_synthetic_shapes"] = syn
if syn["wrapper_row_empty_attachments_real_style"]["fetch_status"] != "unrecognized_inventory":
    problems.append("wrapper row with attachments:[] did not classify unrecognized_inventory")
if syn["wrapper_list_no_rows"]["fetch_status"] != "confirmed_empty":
    problems.append("wrapper list with zero rows did not classify confirmed_empty")
if syn["links_only_synthetic"]["fetch_status"] != "unrecognized_inventory":
    problems.append("links-only did not classify unrecognized_inventory")
if not all(v["same_as_base"] for v in syn.values()):
    problems.append("base and candidate differ on a synthetic shape")

# Does any recognized real body use one of the "confirmed_empty-capable" containers
# in a way that could be empty in real life? Record which container the real
# 17 use: they are _embedded.opportunityAttachmentList with wrapper rows.
def wrapper_rows(payload):
    emb = payload.get("_embedded") if isinstance(payload, dict) else None
    lst = (emb or {}).get("opportunityAttachmentList") if isinstance(emb, dict) else None
    return lst
real_container = {}
for path in sorted(glob.glob(str(BODIES / "*.body"))):
    payload = json.loads(Path(path).read_bytes())
    rows = wrapper_rows(payload)
    if rows is None:
        real_container["none"] = real_container.get("none", 0) + 1
    else:
        key = f"wrapper_rows={len(rows)}"
        real_container[key] = real_container.get(key, 0) + 1
observed["A2_real_recognized_container_shape"] = real_container

# ---------- E. run_searches receipt mapping ----------
def sweep_receipt(nid: str, body: bytes):
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    from tools.api import sam_quota
    sam_quota.calls_today = lambda: 0
    cache = detail._cache_dir() / f"{nid}.resources.json"
    if cache.exists():
        cache.unlink()
    serve(body)
    candidate = RawOpportunity(source="sam.gov", source_id=nid, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})
    class Source:
        last_attachment_census = {"selected": 1}
        def attachment_candidates(self, *a, **k):
            return [candidate]
    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term="network visibility")])
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=8)
    receipts = stats.get("attachment_record_receipts") or {}
    rec = receipts.get(nid) if isinstance(receipts, dict) else None
    return {
        "status": (rec or {}).get("status"),
        "inventory_collection_status": ((rec or {}).get("inventory_receipt") or {}).get("collection_status"),
        "errors": (rec or {}).get("errors"),
        "stats_keys": sorted(stats.keys()),
    }

real_links_id = links_only[0] if links_only else None
E = {}
if real_links_id:
    E["real_links_only_body"] = sweep_receipt(real_links_id, (BODIES / f"{real_links_id}.body").read_bytes())
E["synthetic_top_level_empty"] = sweep_receipt(NID, b'{"attachments": []}')
E["wrapper_row_empty_attachments"] = sweep_receipt(
    NID, json.dumps(shapes["wrapper_row_empty_attachments_real_style"]).encode())
observed["E_run_searches_receipts"] = E
if real_links_id and E["real_links_only_body"]["status"] != "INVENTORY_UNAVAILABLE":
    problems.append("real links-only body did not yield INVENTORY_UNAVAILABLE receipt")
if E["synthetic_top_level_empty"]["status"] != "VERIFIED_EMPTY_INVENTORY":
    problems.append("synthetic empty list did not yield VERIFIED_EMPTY_INVENTORY")

# ---------- G. Assess attachment_gap closing (ledger._attachment_state) ----------
try:
    from agents.assess.ledger import _attachment_state
    G = {}
    if real_links_id:
        depth_links = fetch_fresh(real_links_id, (BODIES / f"{real_links_id}.body").read_bytes())
        G["real_links_only"] = list(_attachment_state(depth_links))
    depth_empty = fetch_fresh(NID, b'{"attachments": []}')
    G["synthetic_empty_list"] = list(_attachment_state(depth_empty))
    depth_wrapper = fetch_fresh(
        NID, json.dumps(shapes["wrapper_row_empty_attachments_real_style"]).encode())
    G["wrapper_row_empty_attachments"] = list(_attachment_state(depth_wrapper))
    observed["G_assess_attachment_state"] = G
    if G["synthetic_empty_list"] != [True, None]:
        problems.append("synthetic confirmed_empty did not close attachment_gap in Assess")
    if real_links_id and G["real_links_only"][0] is not False:
        problems.append("real links-only body closed attachment_gap in Assess")
except Exception as exc:  # noqa: BLE001
    observed["G_assess_attachment_state"] = {"error": repr(exc)}

# ---------- F. doc disclosures ----------
docs = {}
pre = (REPO / "docs/verification/step7-052/PRE_PATCH_REPORT.md").read_text()
handoff = (REPO / "docs/verification/step7-052/FABLE_HANDOFF.md").read_text()
proto = json.loads((REPO / "docs/verification/step7-052/COLLECTION_PROTOCOL.v1.json").read_text())
conv = (REPO / "docs/CONVENTIONS.md").read_text()
contract = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
docs["prepatch_discloses_four_not_called_empty"] = bool(
    re.search(r"four unfamiliar\s+schemas.*?none is called confirmed empty", pre, re.S))
docs["handoff_says_four_unrecognized_not_empty"] = "four were unrecognized, not empty" in handoff
docs["protocol_states_list_includes_confirmed_empty"] = "confirmed_empty" in (proto.get("states") or [])
alltext = pre + handoff + conv + contract + json.dumps(proto)
docs["any_doc_mentions_links_only_shape"] = ("_links" in alltext)
docs["any_doc_mentions_wrapper_empty_attachments_limit"] = bool(
    re.search(r"attachments\W*\[\s*\]|empty wrapper|wrapper row", alltext, re.I))
docs["any_doc_says_confirmed_empty_unreachable_live"] = bool(
    re.search(r"confirmed.empty.{0,80}(unreachable|not reachable|never)", alltext, re.I | re.S))
docs["conventions_receipt_vocab_mentions_checked_empty"] = "checked empty" in conv
observed["F_docs"] = docs

# ---------- verdict ----------
status = "FAIL" if not problems else "INFO"
# FAIL here means the finding's defect/limit reproduced (candidate leaves every real
# zero-file shape unverified); INFO would mean a material part did not reproduce.
observed["problems_with_claim"] = problems
print(json.dumps({"status": status, "observed": observed}, indent=1, sort_keys=True))

# cleanup temp caches
import shutil
shutil.rmtree(tmp_root, ignore_errors=True)
