"""F-09 impact refutation probe: where does an unreachable confirmed_empty actually flow?

Legs:
 A. replay the 21 real bodies through candidate and BASE _attachment_inventory
 B. synthetic zero-file shapes (links-only, wrapper-with-empty-attachments, wrapper-no-rows, top-level empty)
 C. fetch_notice_resources via MockTransport per shape -> collection_status / cache written
 D. run_searches._enrich_sam_public_attachments receipt status per shape
 E. deterministic_prefilter screen_state/verdict and decision coverage per receipt status
 F. strict Assess build: unverified inventory vs confirmed-empty inventory -> classification / attachments_checked / attachment_gap
No network (socket.connect blocked), no LLM, writes only under the probe dir.
"""
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
HERE = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/verify/F-09/impact")
BODIES = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tests"))

def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

TMP = Path(tempfile.mkdtemp(prefix="f09_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ.setdefault("LILA_SUITE_OFFLINE", "0")

import httpx  # noqa: E402
from tools.api import _http, sam_notice_detail as detail, sam_quota  # noqa: E402

def load_by_path(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

base = load_by_path("sam_notice_detail_base", HERE / "base" / "sam_notice_detail_base.py")

observed = {}
fails = []

# ---------- Leg A: 21 real bodies ----------
census_c, census_b, unrec_ids, links_only_ids = {}, {}, [], []
for body in sorted(BODIES.glob("*.body")):
    nid = body.stem
    payload = json.loads(body.read_bytes())
    items_c, rec_c = detail._attachment_inventory(payload, nid)
    items_b, rec_b = base._attachment_inventory(payload)
    st_c = ("inventory_captured" if items_c else "confirmed_empty") if rec_c else "unrecognized_inventory"
    st_b = ("inventory_captured" if items_b else "confirmed_empty") if rec_b else "unrecognized_inventory"
    census_c[st_c] = census_c.get(st_c, 0) + 1
    census_b[st_b] = census_b.get(st_b, 0) + 1
    if st_c != st_b:
        fails.append(f"base/candidate differ on {nid}: {st_b} vs {st_c}")
    if not rec_c:
        unrec_ids.append(nid)
    if set(payload) == {"_links"}:
        links_only_ids.append(nid)
        self_href = payload["_links"]["self"]["href"]
        if f"/opportunities/{nid}/resources" not in self_href:
            fails.append(f"links-only body {nid} self href names another route")
observed["A_real_bodies"] = {
    "candidate_census": census_c, "base_census": census_b,
    "unrecognized_ids": unrec_ids, "links_only_ids": links_only_ids,
    "links_only_equals_unrecognized": sorted(unrec_ids) == sorted(links_only_ids),
    "confirmed_empty_count_candidate": census_c.get("confirmed_empty", 0),
}

# ---------- Leg B: synthetic zero-file shapes ----------
NID = "a" * 32
LINKS = {"_links": {"self": {"href": f"https://x/opps/v3/opportunities/{NID}/resources"},
                    "opportunity:publish:latest": {"href": f"https://x/opps/v3/opportunities/{NID}/resources"}}}
shapes = {
    "links_only_real_shape": dict(LINKS),
    "wrapper_row_empty_attachments": {"_embedded": {"opportunityAttachmentList": [{"opportunityId": NID, "attachments": []}]}, **LINKS},
    "wrapper_list_no_rows": {"_embedded": {"opportunityAttachmentList": []}, **LINKS},
    "top_level_attachments_empty": {"attachments": []},
    "wrapper_row_all_deleted": {"_embedded": {"opportunityAttachmentList": [{"opportunityId": NID, "attachments": [
        {"resourceId": "b" * 32, "name": "old.pdf", "deletedFlag": "1", "mimeType": "application/pdf"}]}]}, **LINKS},
}
legB = {}
for name, payload in shapes.items():
    items_c, rec_c = detail._attachment_inventory(payload, NID)
    items_b, rec_b = base._attachment_inventory(payload)
    legB[name] = {
        "candidate": ("inventory_captured" if items_c else "confirmed_empty") if rec_c else "unrecognized_inventory",
        "base": ("inventory_captured" if items_b else "confirmed_empty") if rec_b else "unrecognized_inventory",
    }
    legB[name]["same_as_base"] = legB[name]["candidate"] == legB[name]["base"]
observed["B_synthetic_shapes"] = legB

# ---------- Leg C: fetch_notice_resources over MockTransport ----------
_NATIVE_REQUEST = _http._request
def mock_http(payload_bytes, status=200):
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=payload_bytes)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    _http._request = _NATIVE_REQUEST
    return calls

legC = {}
resources_by_shape = {}
for name, payload in shapes.items():
    cache_dir = TMP / "notice" / name
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(cache_dir)
    calls = mock_http(json.dumps(payload).encode())
    res = detail.fetch_notice_resources(NID)
    resources_by_shape[name] = res
    legC[name] = {
        "collection_status": res.get("collection_status"),
        "resources_checked": res.get("resources_checked"),
        "attachments": res.get("attachments"),
        "errors": res.get("errors"),
        "inventory_cache_written": (cache_dir / f"{NID}.resources.json").exists(),
        "raw_blob_retained": bool(list((cache_dir / "objects").glob("*.bin"))) if (cache_dir / "objects").exists() else False,
        "http_calls": len(calls),
    }
observed["C_fetch_notice_resources"] = legC

# ---------- Leg D: run_searches receipt per shape ----------
import run_searches as rs  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text  # noqa: E402
from tools.relevance.taxonomy import load_taxonomy  # noqa: E402

def _tax():
    try:
        return load_taxonomy("apexanalytix")
    except Exception as exc:  # noqa: BLE001
        observed.setdefault("notes", []).append(f"load_taxonomy failed: {exc!r}")
        return None

tax = _tax()
sam_quota.calls_today = lambda: 0
def forbidden_extract(*a, **k):
    raise AssertionError("empty/unverified inventory reached extraction")
sam_attachment_text.extract_public_attachment_text = forbidden_extract

legD, receipts_by_shape = {}, {}
if tax is not None:
    for name, res in resources_by_shape.items():
        cand = RawOpportunity(source="sam.gov", source_id=NID, title="Platform requirement",
                              raw_payload={"type": "Solicitation"})
        class Source:
            last_attachment_census = {}
            def attachment_candidates(self, *a, **k):
                return [cand]
        detail.fetch_notice_resources = (lambda r: (lambda *a, **k: dict(r)))(res)
        rows, stats = rs._enrich_sam_public_attachments(
            [json.loads(cand.model_dump_json())], Source(), object(), tax, None, limit=1)
        receipt = stats["attachment_record_receipts"][NID]
        receipts_by_shape[name] = receipt
        legD[name] = {"receipt_status": receipt["status"],
                      "inventory_receipt_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
                      "errors": receipt.get("errors")}
observed["D_run_searches_receipts"] = legD

# ---------- Leg E: prefilter screen_state / verdict / coverage ----------
legE = {}
if tax is not None:
    from agents.decisions.triage import deterministic_prefilter  # noqa: E402
    def notice(desc):
        return {"source": "sam.gov", "source_id": NID, "title": "Janitorial support services",
                "description": desc, "raw_payload": {"type": "Solicitation", "notice_id": NID},
                "response_deadline": "2099-01-01"}
    for text_case, desc in (("title_only", ""), ("narrative_no_match", "Provide custodial services for the building.")):
        for name, receipt in receipts_by_shape.items():
            row = notice(desc)
            cands, ruled, pre = deterministic_prefilter([row], tax, attachment_receipts={NID: receipt})
            cov = rs._decision_coverage_receipt([row], ruled, prefilter_receipt=pre)
            legE[f"{text_case}/{name}"] = {
                "receipt_status": receipt["status"],
                "screen_state": ruled[NID]["screen_state"], "verdict": ruled[NID]["verdict"],
                "candidate": bool(cands), "decision_coverage_complete": cov["complete"],
                "invalid_or_unscreened_count": cov["invalid_or_unscreened_count"],
            }
observed["E_prefilter_and_coverage"] = legE

# ---------- Leg F: strict Assess build ----------
legF = {}
try:
    tal = load_by_path("t_assess_ledger", REPO / "tests" / "test_assess_ledger.py")
    from agents.assess.contracts import LiveClassification  # noqa: E402
    for label, depth_kwargs in (("unverified_inventory_models_unrecognized", dict(resources_checked=False)),
                                ("confirmed_empty_models_recognized_empty", dict(resources_checked=True, attachments=[]))):
        searches = tal._sweep()
        depth = tal._depth_record(**depth_kwargs)
        if not depth_kwargs.get("resources_checked"):
            depth["source_depth"]["errors"] = ["unrecognized resources schema (non-fatal)"]
            depth["source_depth"]["attachments"] = None
        searches["results"]["dossiers"] = {"records": [depth]}
        run, _, _ = tal._build_with_requirement_review(searches)
        rec = next(r for r in run.live.records if r.notice_id == "N1")
        legF[label] = {"classification": str(rec.classification), "recommendation": str(rec.recommendation),
                       "attachments_checked": rec.attachments_checked, "attachment_gap": rec.attachment_gap,
                       "attachment_inventory_valid": rec.attachment_inventory_valid}
    legF["confirmed_empty_is_the_only_inventory_state_that_clears_attachment_gate"] = (
        legF["confirmed_empty_models_recognized_empty"]["attachments_checked"] is True
        and legF["unverified_inventory_models_unrecognized"]["attachments_checked"] is False)
except Exception as exc:  # noqa: BLE001
    legF["error"] = repr(exc)
observed["F_assess_strict_build"] = legF

# ---------- Leg G: the four real links-only notices are Presolicitation / Special Notice ----------
# Does the inventory state change the Assess outcome for those notice types at all?
legG = {}
try:
    for ntype in ("Presolicitation", "Special Notice"):
        for label, depth_kwargs in (("unverified", dict(resources_checked=False)),
                                    ("confirmed_empty", dict(resources_checked=True, attachments=[]))):
            searches = tal._sweep()
            searches["results"]["sam.gov"][0] = tal._notice("N1", "Packet capture platform", notice_type=ntype)
            depth = tal._depth_record(**depth_kwargs)
            if not depth_kwargs.get("resources_checked"):
                depth["source_depth"]["errors"] = ["unrecognized resources schema (non-fatal)"]
                depth["source_depth"]["attachments"] = None
            searches["results"]["dossiers"] = {"records": [depth]}
            run, _, _ = tal._build(searches)
            rec = next(r for r in run.live.records if r.notice_id == "N1")
            legG[f"{ntype}/{label}"] = {"classification": str(rec.classification),
                                        "recommendation": str(rec.recommendation),
                                        "attachments_checked": rec.attachments_checked,
                                        "attachment_gap": rec.attachment_gap}
    legG["classification_and_recommendation_identical_for_real_notice_types"] = all(
        legG[f"{t}/unverified"]["classification"] == legG[f"{t}/confirmed_empty"]["classification"]
        and legG[f"{t}/unverified"]["recommendation"] == legG[f"{t}/confirmed_empty"]["recommendation"]
        for t in ("Presolicitation", "Special Notice"))
except Exception as exc:  # noqa: BLE001
    legG["error"] = repr(exc)
observed["G_real_notice_types_in_assess"] = legG

# ---------- verdict ----------
# The finding claims confirmed_empty is unreachable from real shapes: PASS-shaped facts confirm the measurement,
# the impact question is what that unreachability costs and whether it can mis-attribute or approve anything.
checks = {
    "real_bodies_no_confirmed_empty": observed["A_real_bodies"]["confirmed_empty_count_candidate"] == 0,
    "links_only_unrecognized": legB["links_only_real_shape"]["candidate"] == "unrecognized_inventory",
    "wrapper_empty_unrecognized": legB["wrapper_row_empty_attachments"]["candidate"] == "unrecognized_inventory",
    "synthetic_top_level_confirmed_empty": legB["top_level_attachments_empty"]["candidate"] == "confirmed_empty",
    "identical_at_base": all(v["same_as_base"] for v in legB.values()) and not fails,
    "unrecognized_never_writes_inventory_cache": legC["links_only_real_shape"]["inventory_cache_written"] is False,
    "unrecognized_receipt_is_INVENTORY_UNAVAILABLE": legD.get("links_only_real_shape", {}).get("receipt_status") == "INVENTORY_UNAVAILABLE",
    "empty_receipt_is_VERIFIED_EMPTY": legD.get("top_level_attachments_empty", {}).get("receipt_status") == "VERIFIED_EMPTY_INVENTORY",
}
observed["checks"] = checks
observed["fails"] = fails
status = "INFO" if all(checks.values()) else "FAIL"
shutil.rmtree(TMP, ignore_errors=True)
print(json.dumps({"status": status, "observed": observed}, indent=1, default=str))
