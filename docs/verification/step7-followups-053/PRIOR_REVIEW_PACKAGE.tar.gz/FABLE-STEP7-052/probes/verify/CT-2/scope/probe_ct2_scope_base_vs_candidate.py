"""CT-2 scope/classification probe: is the coherent text-cache rewrite NEW to the Step7 delta?

Runs the same tamper cases against the BASE (2d522f0) extractor and the CANDIDATE
(6b51f00) extractor, then replays the base run_searches enrichment and base dossier
research context with a text-only cache edit to show the propagation path also
predates the delta. Network is blocked; every cache dir is probe-local.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402,F401


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base_sat = load("base_sat", HERE / "base" / "base_sam_attachment_text.py")
from tools.api import sam_attachment_text as cand_sat  # noqa: E402

RID = "b" * 32
ORIGINAL = b"Original requirement: network visibility appliance."
INVENTED = "Invented requirement: the buyer needs Testco Widget Pro immediately."
NEW_RAW = b"%PDF-1.4 completely different bytes"


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def fresh(name: str) -> Path:
    root = HERE / "tmp" / name
    if root.exists():
        shutil.rmtree(root)
    (root / "notice").mkdir(parents=True)
    (root / "text").mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(root / "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(root / "text")
    return root / "text"


def public_file(resource_id=RID, name="SOW.txt"):
    return {"resource_id": resource_id, "name": name, "type": "text/plain",
            "source_url": None, "size": 20, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def place_object(directory: Path, payload: bytes) -> dict:
    digest = sha(payload)
    (directory / "objects").mkdir(parents=True, exist_ok=True)
    (directory / "objects" / f"{digest}.bin").write_bytes(payload)
    return {"path": f"objects/{digest}.bin", "sha256": digest, "bytes": len(payload)}


def set_download(module, payload: bytes | None):
    def dl(resource_id, **k):
        if payload is None:
            raise RuntimeError("source unavailable (probe)")
        return payload
    module._download_bytes = dl


def summarize(r: dict) -> dict:
    return {"from_cache": r.get("from_cache"), "text": (r.get("text") or "")[:70],
            "sha256": r.get("sha256"), "collection_status": r.get("collection_status"),
            "error": (r.get("error") or "")[:60]}


def run_cases(label: str, module) -> dict:
    out = {}

    def capture(name: str):
        text_dir = fresh(f"{label}_{name}")
        set_download(module, ORIGINAL)
        first = module.extract_public_attachment_text(public_file())
        assert first.get("text") == ORIGINAL.decode(), first
        cache = text_dir / f"{RID}.json"
        return text_dir, cache, json.loads(cache.read_text())

    # A. positive control
    text_dir, cache, saved = capture("pos")
    set_download(module, None)
    r = module.extract_public_attachment_text(public_file())
    out["A_untampered_reuse"] = {**summarize(r), "served_from_cache": r.get("from_cache") is True}

    # B. text-only edit (the producer's own tamper test variant)
    text_dir, cache, saved = capture("textonly")
    saved["text"] = INVENTED
    cache.write_text(json.dumps(saved))
    set_download(module, None)
    r = module.extract_public_attachment_text(public_file())
    out["B_text_only_edit"] = {**summarize(r), "invented_served": r.get("from_cache") is True and r.get("text") == INVENTED,
                               "fields_edited": 1}

    # C. coherent text rewrite (finder H1): text + text_sha256 + text_capture object + locator
    text_dir, cache, saved = capture("coherent")
    saved["text"] = INVENTED
    saved["text_sha256"] = sha(INVENTED.encode())
    saved["text_capture"] = place_object(text_dir, INVENTED.encode())
    saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                             "start": 0, "end": len(INVENTED)}
    cache.write_text(json.dumps(saved))
    set_download(module, None)
    r = module.extract_public_attachment_text(public_file())
    raw_path = (saved.get("raw_capture") or {}).get("path") if isinstance(saved.get("raw_capture"), dict) else None
    out["C_coherent_text_rewrite"] = {**summarize(r), "invented_served": r.get("from_cache") is True and r.get("text") == INVENTED,
                                      "raw_object_still_original": bool(raw_path) and (text_dir / raw_path).read_bytes() == ORIGINAL,
                                      "fields_edited": 4, "new_object_dropped": True}

    # D. raw hash rewrite with text unchanged
    text_dir, cache, saved = capture("rawsha")
    saved["sha256"] = sha(NEW_RAW)
    if isinstance(saved.get("raw_capture"), dict):
        saved["raw_capture"] = place_object(text_dir, NEW_RAW)
    cache.write_text(json.dumps(saved))
    set_download(module, None)
    r = module.extract_public_attachment_text(public_file())
    out["D_raw_sha_rewrite_text_unchanged"] = {**summarize(r), "foreign_sha_served": r.get("from_cache") is True and r.get("sha256") == sha(NEW_RAW)}

    # E. does the module hold any cache validator at all
    out["E_validator_present"] = hasattr(module, "_text_capture_valid")
    return out


results = {"base_2d522f0": run_cases("base", base_sat), "candidate_6b51f00": run_cases("cand", cand_sat)}

# ---- base propagation: base run_searches + base dossier with a TEXT-ONLY cache edit ----
prop = {}
try:
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    from tools.api import sam_notice_detail as detail
    import tools.api.sam_quota as sam_quota

    base_rs = load("base_run_searches", HERE / "base" / "base_run_searches.py")
    base_dossier = load("base_dossier", HERE / "base" / "base_dossier.py")
    sam_quota.calls_today = lambda: 0
    NID = "a" * 32
    TERM = "network visibility"
    files = [public_file(RID, "SOW 1.txt")]
    inventory = sha(json.dumps(files, sort_keys=True).encode())
    detail.fetch_notice_resources = lambda *a, **k: {"id": NID, "resources_checked": True, "attachments": files,
                                                     "attachment_inventory_hash": inventory}

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [RawOpportunity(source="sam.gov", source_id=NID, title="Requirement", agency="NASA",
                                   raw_payload={"type": "Solicitation"})]

    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21", core=[TaxonomyTerm(term=TERM)])

    def base_enrich():
        saved_mod = sys.modules.get("tools.api.sam_attachment_text")
        sys.modules["tools.api.sam_attachment_text"] = base_sat
        try:
            return base_rs._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
        finally:
            sys.modules["tools.api.sam_attachment_text"] = saved_mod

    text_dir = fresh("base_prop")
    set_download(base_sat, b"Nothing relevant here at all.")
    rows0, stats0 = base_enrich()
    cache = text_dir / f"{RID}.json"
    saved = json.loads(cache.read_text())
    invented = f"Buyer requires {TERM} and has selected Testco."
    saved["text"] = invented
    cache.write_text(json.dumps(saved))
    set_download(base_sat, None)
    rows1, stats1 = base_enrich()
    ctx = base_dossier._attachment_research_context(
        rows1[0], {"id": NID, "resources_checked": True, "attachment_inventory_hash": inventory}) if rows1 else None
    prop = {"rows_before": len(rows0), "rows_after": len(rows1),
            "relevant_after": stats1.get("attachment_relevant"),
            "fields_edited": 1,
            "dossier_status": ctx.get("status") if ctx else None,
            "dossier_text_contains_invented": bool(ctx and invented in (ctx.get("text") or "")),
            "receipt_sha_still_neutral": bool(rows1) and rows1[0]["raw_payload"]["attachment_evidence"][0]["sha256"] == sha(b"Nothing relevant here at all.")}
except Exception as exc:  # noqa: BLE001
    prop = {"error": f"{type(exc).__name__}: {exc}"[:300]}
results["base_propagation_text_only_edit"] = prop

b, c = results["base_2d522f0"], results["candidate_6b51f00"]
pre_existing = (b["B_text_only_edit"]["invented_served"] and b["C_coherent_text_rewrite"]["invented_served"]
                and b["D_raw_sha_rewrite_text_unchanged"]["foreign_sha_served"])
narrowed = (not c["B_text_only_edit"]["invented_served"]) and c["C_coherent_text_rewrite"]["invented_served"]
verdict = ("PRE_EXISTING: base served ANY local cache edit (1 field) with no validator; the delta refuses the "
           "1-field edit and still serves the 4-field coherent rewrite, so the condition predates Step7 and was narrowed, not introduced"
           if pre_existing and narrowed else "UNEXPECTED: see cases")
print(json.dumps({"probe": "ct2_scope_base_vs_candidate",
                  "status": "INFO" if pre_existing and narrowed else "FAIL",
                  "observed": {"pre_existing_at_base": pre_existing, "delta_narrowed": narrowed,
                               "verdict": verdict, **results}},
                 indent=1, sort_keys=True, default=str))
