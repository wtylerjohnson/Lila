"""Independent reproduction of CT-2 (H1 coherent text-cache rewrite).

Written from the finding text only, without reading the finder's script.
Three legs:
  A. coherent text rewrite (text + text_sha256 + text_capture + locator.end
     + new objects/<sha>.bin) with raw untouched -> is it served from cache?
  B. coherent raw rewrite (new raw object + sha256) with text unchanged.
  C. propagation through run_searches._enrich_sam_public_attachments and
     agents.decisions.dossier._attachment_research_context.
Also: control legs (text-only rewrite rejected; base-version behaviour).
No network: socket connect is blocked, _download_bytes is patched.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import socket
import sys
import tempfile
from pathlib import Path

ROOT = Path("/Users/wtjohnson/lila-step7-052")
PROBE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

# hard network block
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

WORK = Path(tempfile.mkdtemp(prefix="ct2_", dir=str(PROBE_DIR)))
observed: dict = {"work_dir": str(WORK)}
failures: list[str] = []

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402


def public_file(resource_id="b" * 32, name="SOW.txt"):
    return {"resource_id": resource_id, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


def raise_unavailable(*a, **k):
    raise RuntimeError("source unavailable (probe)")


def fresh_text_dir(tag: str) -> Path:
    path = WORK / tag
    path.mkdir(parents=True)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(path)
    return path


def seed(text_dir: Path, original: bytes, attachment: dict) -> dict:
    sat._download_bytes = lambda *a, **k: original
    first = sat.extract_public_attachment_text(attachment)
    assert first["collection_status"] == "captured_discovery_only", first
    assert first["from_cache"] is False
    return first


def coherent_text_rewrite(text_dir: Path, resource_id: str, new_text: str) -> dict:
    cache = text_dir / f"{resource_id}.json"
    saved = json.loads(cache.read_text())
    new_bytes = new_text.encode("utf-8")
    saved["text"] = new_text
    saved["text_sha256"] = hashlib.sha256(new_bytes).hexdigest()
    saved["text_capture"] = retain_bytes(text_dir, new_bytes)
    saved["text_locator"]["end"] = len(new_text)
    cache.write_text(json.dumps(saved))
    return saved


# ---------------------------------------------------------------- Leg A
ORIGINAL = b"Buyer requires ergonomic office chairs for the regional office."
INVENTED = "Buyer requires network visibility and packet capture tooling."
attachment = public_file()
text_dir = fresh_text_dir("legA")
first = seed(text_dir, ORIGINAL, attachment)
saved = coherent_text_rewrite(text_dir, "b" * 32, INVENTED)
sat._download_bytes = raise_unavailable
second = sat.extract_public_attachment_text(attachment)
observed["A_coherent_text_rewrite"] = {
    "from_cache": second.get("from_cache"),
    "collection_status": second.get("collection_status"),
    "text_is_invented": second.get("text") == INVENTED,
    "sha256_still_original_raw": second.get("sha256") == hashlib.sha256(ORIGINAL).hexdigest(),
    "raw_capture_unchanged": second.get("raw_capture") == first["raw_capture"],
    "text_sha256_is_invented": second.get("text_sha256") == hashlib.sha256(INVENTED.encode()).hexdigest(),
    "network_attempted": False,
}
A_ok = (second.get("from_cache") is True
        and second.get("collection_status") == "captured_discovery_only"
        and second.get("text") == INVENTED
        and second.get("sha256") == hashlib.sha256(ORIGINAL).hexdigest())
if not A_ok:
    failures.append("legA: coherent text rewrite was NOT served from cache")

# Control A1: text-only rewrite (the producer's tamper variant) must be rejected.
text_dir = fresh_text_dir("legA_control")
seed(text_dir, ORIGINAL, attachment)
cache = text_dir / ("b" * 32 + ".json")
s = json.loads(cache.read_text()); s["text"] = INVENTED; cache.write_text(json.dumps(s))
sat._download_bytes = raise_unavailable
ctrl = sat.extract_public_attachment_text(attachment)
observed["A1_control_text_only_rewrite"] = {
    "from_cache": ctrl.get("from_cache"),
    "collection_status": ctrl.get("collection_status"),
    "text_empty": not ctrl.get("text"),
}
if not (ctrl.get("from_cache") is False and ctrl.get("collection_status") == "lookup_failed"):
    failures.append("legA control: text-only rewrite unexpectedly accepted")

# Control A2: does validation ever read the raw object to re-derive text?
# Instrument _text_from_bytes; validation must not call it.
text_dir = fresh_text_dir("legA_rederive")
seed(text_dir, ORIGINAL, attachment)
coherent_text_rewrite(text_dir, "b" * 32, INVENTED)
calls = []
_orig_tfb = sat._text_from_bytes
sat._text_from_bytes = lambda *a, **k: (calls.append(1), _orig_tfb(*a, **k))[1]
sat._download_bytes = raise_unavailable
res = sat.extract_public_attachment_text(attachment)
sat._text_from_bytes = _orig_tfb
observed["A2_validation_rederives_text_from_raw"] = {
    "text_from_bytes_calls_during_cache_hit": len(calls),
    "from_cache": res.get("from_cache"),
}

# ---------------------------------------------------------------- Leg B
text_dir = fresh_text_dir("legB")
first = seed(text_dir, ORIGINAL, attachment)
cache = text_dir / ("b" * 32 + ".json")
saved = json.loads(cache.read_text())
FOREIGN_RAW = b"%PDF-1.4 completely unrelated bytes from another document"
saved["raw_capture"] = retain_bytes(text_dir, FOREIGN_RAW)
saved["sha256"] = hashlib.sha256(FOREIGN_RAW).hexdigest()
cache.write_text(json.dumps(saved))
sat._download_bytes = raise_unavailable
res_b = sat.extract_public_attachment_text(attachment)
observed["B_coherent_raw_rewrite_text_unchanged"] = {
    "from_cache": res_b.get("from_cache"),
    "collection_status": res_b.get("collection_status"),
    "text_still_original": res_b.get("text") == first["text"],
    "sha256_is_foreign": res_b.get("sha256") == hashlib.sha256(FOREIGN_RAW).hexdigest(),
}
B_ok = res_b.get("from_cache") is True and res_b.get("sha256") == hashlib.sha256(FOREIGN_RAW).hexdigest()
if not B_ok:
    failures.append("legB: coherent raw rewrite was NOT served from cache")

# ---------------------------------------------------------------- Leg C
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

sam_quota.calls_today = lambda: 0
TERM = "network visibility"
NOTICE = "a" * 32
files = [public_file("b" * 32, "SOW 1.txt")]
inventory = detail._manifest_hash(files)
detail.fetch_notice_resources = lambda *a, **k: {
    "id": NOTICE, "resources_checked": True, "attachments": files,
    "attachment_inventory_hash": inventory}
searches.fetch_notice_resources = detail.fetch_notice_resources  # in case of direct import
taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})]


def run_enrich():
    return searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=8)


text_dir = fresh_text_dir("legC")
sat._download_bytes = lambda rid, **k: ORIGINAL
rows_before, stats_before = run_enrich()
receipt_before = stats_before["attachment_record_receipts"][NOTICE]
# coherent rewrite of the file cache
coherent_text_rewrite(text_dir, "b" * 32, INVENTED)
sat._download_bytes = raise_unavailable
rows_after, stats_after = run_enrich()
receipt_after = stats_after["attachment_record_receipts"][NOTICE]
legC = {
    "rows_before": len(rows_before),
    "status_before": receipt_before.get("status"),
    "relevant_before": receipt_before.get("discovery_evidence", {}).get("retained_in_candidate"),
    "rows_after": len(rows_after),
    "status_after": receipt_after.get("status"),
    "file_status_after": [f.get("status") for f in receipt_after.get("files", [])],
    "file_from_cache_after": [f.get("from_cache") for f in receipt_after.get("files", [])],
    "network_attempted_after": False,
}
if rows_after:
    row = rows_after[0]
    raw = row["raw_payload"]
    legC["row_text_is_invented"] = raw.get("text") == INVENTED
    legC["evidence_sha256_still_original_raw"] = (
        raw["attachment_evidence"][0]["sha256"] == hashlib.sha256(ORIGINAL).hexdigest())
    ctx = _attachment_research_context(
        row, {"id": NOTICE, "resources_checked": True,
              "attachment_inventory_hash": inventory})
    legC["dossier_status"] = ctx.get("status")
    legC["dossier_text_contains_invented"] = any(
        INVENTED in (p.get("text") or "") for p in ctx.get("file_passages", []))
    legC["dossier_passage_authority"] = [p.get("authority") for p in ctx.get("file_passages", [])]
    legC["source_depth_in_raw"] = "source_depth" in raw
    legC["full_description_in_raw"] = "full_description" in raw
observed["C_run_searches_propagation"] = legC
C_ok = (len(rows_before) == 0 and len(rows_after) == 1
        and legC.get("row_text_is_invented") is True
        and legC.get("dossier_status") == "discovery_only"
        and legC.get("dossier_text_contains_invented") is True
        and legC.get("evidence_sha256_still_original_raw") is True)
if not C_ok:
    failures.append("legC: propagation did not reproduce as described")

# ---------------------------------------------------------------- Base comparison
# At base 2d522f0 the text cache had no validation at all; a plain text-only
# rewrite was served. So the local-writer class is pre-existing; the delta
# narrowed it (text-only rewrite now rejected) but not to zero.
base_src = os.popen(
    "git -C /Users/wtjohnson/lila-step7-052 show 2d522f0:tools/api/sam_attachment_text.py").read()
observed["base_2d522f0_cache_path"] = {
    "has_text_capture_valid": "_text_capture_valid" in base_src,
    "cache_served_without_validation": 'result["from_cache"] = True' in base_src
    and "_text_capture_valid" not in base_src,
}

# ---------------------------------------------------------------- Doc wording
conv = (ROOT / "docs/CONVENTIONS.md").read_text()
observed["conventions_sentence_present"] = (
    "bind the original resource metadata, raw bytes, text bytes and aware acquisition" in conv)
lv = json.loads((ROOT / "docs/verification/step7-052/LOCAL_VERIFICATION.json").read_text())
observed["producer_residual_byte_custody_not_truth"] = any(
    "byte custody, not truth" in r for r in lv.get("residuals", []))

reproduced = A_ok and B_ok and C_ok
# PASS = candidate behaved as the producer claims (tampering rejected);
# FAIL = coherent rewrite accepted exactly as the finding describes.
status = "FAIL" if reproduced else "PASS"
print(json.dumps({"status": status, "finding": "CT-2", "reproduced": reproduced,
                  "failures": failures, "observed": observed}, indent=2))
shutil.rmtree(WORK, ignore_errors=True)
