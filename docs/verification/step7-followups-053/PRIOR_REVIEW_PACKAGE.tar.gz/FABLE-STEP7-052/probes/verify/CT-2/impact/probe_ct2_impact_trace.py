"""CT-2 impact trace: where does a coherent text-cache rewrite actually flow?

Reproduces H1 (coherent rewrite of text + text_sha256 + objects/<sha>.bin), then
follows the invented text through run_searches (saved sweep row, receipts,
attachment_relevance_excerpt as projected to triage), the dossier research
context, and a strict Assess build. Also runs the BASE (2d522f0) collector from a
saved copy to show whether a local cache writer already had this power before
the Step7 delta. Network is blocked; no LLM is called.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe harness")


socket.socket.connect = _blocked  # type: ignore[assignment]
socket.socket.connect_ex = _blocked  # type: ignore[assignment]
socket.create_connection = _blocked  # type: ignore[assignment]

from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

sam_quota.calls_today = lambda: 0

NID = "N1"
R1, R2 = "b" * 32, "c" * 32
TERM = "packet capture"
INVENTED = f"Buyer requires {TERM} and has selected Testco as the only acceptable source."
NEUTRAL = {R1: b"Nothing relevant here at all.", R2: b"Also nothing relevant."}
observed: dict = {}


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def fresh(name: str) -> tuple[Path, Path]:
    root = HERE / "tmp" / name
    if root.exists():
        shutil.rmtree(root)
    notice, text = root / "notice", root / "text"
    notice.mkdir(parents=True)
    text.mkdir(parents=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(notice)
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(text)
    return notice, text


def public_file(resource_id, name):
    return {"resource_id": resource_id, "name": name, "type": "text/plain",
            "source_url": None, "size": 20, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def files():
    return [public_file(R1, "SOW 1.txt"), public_file(R2, "SOW 2.txt")]


def mock_download(mapping):
    calls = []

    def dl(resource_id, **k):
        calls.append(resource_id)
        return mapping[resource_id]

    sat._download_bytes = dl
    return calls


def run_enrich():
    inventory_files = files()
    inventory = detail._manifest_hash(inventory_files)
    detail.fetch_notice_resources = lambda *a, **k: {
        "id": NID, "resources_checked": True, "attachments": inventory_files,
        "attachment_inventory_hash": inventory, "collection_status": "inventory_captured"}
    searches.fetch_notice_resources = detail.fetch_notice_resources
    candidate = RawOpportunity(source="sam.gov", source_id=NID, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                             core=[TaxonomyTerm(term=TERM)])
    rows, stats = searches._enrich_sam_public_attachments([], Source(), object(), tax, None, limit=8)
    return rows, stats, inventory


def coherent_rewrite(text_dir: Path, resource_id: str, invented: str) -> dict:
    cache = text_dir / f"{resource_id}.json"
    saved = json.loads(cache.read_text())
    payload = invented.encode()
    (text_dir / "objects").mkdir(exist_ok=True)
    (text_dir / "objects" / f"{sha(payload)}.bin").write_bytes(payload)
    saved["text"] = invented
    saved["text_sha256"] = sha(payload)
    saved["text_capture"] = {"path": f"objects/{sha(payload)}.bin", "sha256": sha(payload), "bytes": len(payload)}
    saved["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters", "start": 0, "end": len(invented)}
    cache.write_text(json.dumps(saved))
    return saved


# ---------------------------------------------------------------- 1. candidate H1 through run_searches
notice_dir, text_dir = fresh("candidate_h1")
calls = mock_download(NEUTRAL)
rows0, stats0, inventory = run_enrich()
downloads_first_pass = list(calls)
coherent_rewrite(text_dir, R1, INVENTED)
calls = mock_download(NEUTRAL)  # source IS reachable this time; does the cache still win?
rows, stats, inventory = run_enrich()
rec = stats["attachment_record_receipts"][NID]
row = rows[0] if rows else None
raw = (row or {}).get("raw_payload") or {}
ctx = _attachment_research_context(row, {"id": NID, "resources_checked": True,
                                         "attachment_inventory_hash": inventory}) if row else None
f1 = next(f for f in rec["files"] if f["resource_id"] == R1)
# triage.py:691 projection, computed without a model call
triage_official_excerpt = (str(raw.get("attachment_relevance_excerpt") or "")[:1200]
                           if raw.get("attachment_evidence") else None)
observed["candidate_run_searches"] = {
    "rows_before": len(rows0), "rows_after": len(rows),
    "downloads_first_pass": len(downloads_first_pass),
    "downloads_second_pass_with_source_reachable": len(calls),
    "file1_from_cache": f1.get("from_cache"), "file1_status": f1["status"],
    "file1_sha256_is_neutral_raw": f1.get("sha256") == sha(NEUTRAL[R1]),
    "file1_text_sha256_is_invented": f1.get("text_sha256") == sha(INVENTED.encode()),
    "raw_text_contains_invented": INVENTED in str(raw.get("text") or ""),
    "attachment_relevance_relevant": (raw.get("attachment_relevance") or {}).get("relevant"),
    "attachment_relevance_excerpt_contains_invented": INVENTED[:40] in str(raw.get("attachment_relevance_excerpt") or ""),
    "triage_official_attachment_excerpt_contains_invented": bool(triage_official_excerpt and INVENTED[:40] in triage_official_excerpt),
    "record_receipt_status": rec["status"],
    "discovery_evidence_disposition": (rec.get("discovery_evidence") or {}).get("disposition"),
    "dossier_status": ctx["status"] if ctx else None,
    "dossier_text_contains_invented": bool(ctx and INVENTED in ctx.get("text", "")),
    "dossier_passage_authority": sorted({p["authority"] for p in (ctx or {}).get("file_passages", [])}),
    "source_depth_in_raw": "source_depth" in raw, "full_description_in_raw": "full_description" in raw,
}

# ---------------------------------------------------------------- 2. strict Assess build on the tampered row
from tests.test_assess_ledger import _sweep, _build  # noqa: E402
from agents.assess.contracts import LiveClassification  # noqa: E402

sweep = _sweep()
original = sweep["results"]["sam.gov"][0]
original["source_id"] = row["source_id"]
original["raw_payload"].update(row["raw_payload"])
run, diagnostics, index = _build(sweep)
parent = next(r for r in run.live.records if r.notice_id == row["source_id"])
run_json = run.model_dump_json() if hasattr(run, "model_dump_json") else json.dumps(run, default=str)
parent_json = parent.model_dump_json() if hasattr(parent, "model_dump_json") else json.dumps(parent, default=str)
observed["assess_ledger"] = {
    "classification": str(parent.classification),
    "is_bid_now": parent.classification == LiveClassification.BID_NOW,
    "requirement_reviewed_at": parent.requirement_reviewed_at,
    "requirement_excerpt": parent.requirement_excerpt,
    "requirement_excerpt_from_invented": bool(parent.requirement_excerpt and parent.requirement_excerpt in INVENTED),
    "attachment_gap": parent.attachment_gap,
    "attachments_checked": parent.attachments_checked,
    "invented_sentence_in_parent_record_json": INVENTED[:40] in parent_json,
    "invented_sentence_in_whole_run_json": INVENTED[:40] in run_json,
    "authoritative_evidence_count": len(parent.authoritative_evidence),
    "authoritative_evidence_excerpts_contain_invented": any(
        INVENTED[:40] in (getattr(e, "excerpt", "") or "") for e in parent.authoritative_evidence),
}

# ---------------------------------------------------------------- 3. BASE collector (2d522f0) from saved copy: was the cache ever bound?
spec = importlib.util.spec_from_file_location("sat_base", HERE / "base" / "sam_attachment_text_base.py")
sat_base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sat_base)  # type: ignore[union-attr]
notice_dir, text_dir = fresh("base_plain_edit")
sat_base._download_bytes = lambda rid, **k: NEUTRAL[R1]
first = sat_base.extract_public_attachment_text(public_file(R1, "SOW 1.txt"))
base_cache = text_dir / f"{R1}.json"
saved = json.loads(base_cache.read_text())
saved["text"] = INVENTED  # one-field edit, no hash, no object
base_cache.write_text(json.dumps(saved))
sat_base._download_bytes = _blocked
second = sat_base.extract_public_attachment_text(public_file(R1, "SOW 1.txt"))
observed["base_2d522f0"] = {
    "base_cache_keys": sorted(saved.keys()),
    "base_has_any_hash_binding": any(k in saved for k in ("text_sha256", "text_capture", "raw_capture", "attachment_binding_sha256")),
    "plain_text_edit_served_from_cache": second.get("from_cache") is True and second.get("text") == INVENTED,
    "note": "at base a single unhashed field edit is enough; the Step7 delta forces the writer to also mint a matching objects/<sha>.bin and text_sha256",
}

# ---------------------------------------------------------------- 4. candidate: what the writer must control, and what the same writer can already write
observed["trust_boundary"] = {
    "default_text_cache_dir": str(sat._DEFAULT_CACHE),
    "default_dir_is_repo_local_gitignored_data_cache": str(sat._DEFAULT_CACHE).endswith("data/cache/sam_attachment_text"),
    "writer_needs": ["write access to the text cache directory", "ability to place objects/<sha256>.bin"],
    "same_writer_can_also": ["edit the saved sweep JSON that Assess reads directly",
                             "edit the repository code that performs validation"],
    "doc_claims_read": {
        "CONVENTIONS": "Successful caches bind the original resource metadata, raw bytes, text bytes and aware acquisition clock.",
        "CONVENTIONS_limit": "New sidecar hashes are internal custody, not general entailment or source authentication.",
        "REVIEW.md_limit": "no continuous filesystem or government-source authentication",
    },
}

# ---------------------------------------------------------------- verdict
c = observed["candidate_run_searches"]
a = observed["assess_ledger"]
h1_reproduced = c["rows_before"] == 0 and c["rows_after"] == 1 and c["file1_from_cache"] is True and c["dossier_text_contains_invented"]
reaches_trusted = a["is_bid_now"] or a["requirement_reviewed_at"] is not None or a["requirement_excerpt_from_invented"] \
    or a["authoritative_evidence_excerpts_contain_invented"] or c["source_depth_in_raw"] or c["full_description_in_raw"]
observed["summary"] = {
    "h1_reproduced_through_run_searches": h1_reproduced,
    "invented_text_reaches_trusted_assess_surface": reaches_trusted,
    "invented_text_reaches_discovery_surfaces": {
        "saved_sweep_row_text": c["raw_text_contains_invented"],
        "triage_prompt_official_attachment_excerpt": c["triage_official_attachment_excerpt_contains_invented"],
        "dossier_research_context": c["dossier_text_contains_invented"],
        "assess_record_json_anywhere": a["invented_sentence_in_parent_record_json"],
    },
    "pre_existing_at_base_with_weaker_tamper": observed["base_2d522f0"]["plain_text_edit_served_from_cache"],
}
status = "INFO" if h1_reproduced and not reaches_trusted else ("FAIL" if reaches_trusted else "PASS")
print(json.dumps({"probe": "ct2_impact_trace", "status": status, "observed": observed},
                 indent=1, sort_keys=True, default=str))
