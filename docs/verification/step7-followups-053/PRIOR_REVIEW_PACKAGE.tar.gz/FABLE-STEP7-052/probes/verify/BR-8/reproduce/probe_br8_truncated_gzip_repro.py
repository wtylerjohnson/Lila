"""BR-8 independent reproduction: truncated gzip body flagged complete=true.

Written without reading the original probe. Four measurements:
  A. MockTransport, gzip body cut at half wire length -> what does raw_capture say?
  B. MockTransport, full gzip body (positive control) -> inventory_captured?
  C. HTTPTransport code path (httpcore HTTP/1.1 + h11) fed an in-process byte
     buffer with a short Content-Length body -> does h11 raise before flush?
  D. Same path with a truncated chunked body.
No socket is opened: socket.socket.connect is blocked and the HTTPTransport
pool is given httpcore's MockBackend byte buffer.
"""
from __future__ import annotations

import gzip
import json
import os
import socket
import sys
import tempfile
import zlib
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp(prefix="br8-", dir=str(PROBE_DIR)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")

def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

sys.path.insert(0, "/Users/wtjohnson/lila-step7-052")
import httpx  # noqa: E402
import httpcore  # noqa: E402
from httpcore._backends.mock import MockBackend  # noqa: E402
import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as snd  # noqa: E402

NOTICE = "0123456789abcdef0123456789abcdef"
BODY = json.dumps({
    "opportunityId": NOTICE,
    "_embedded": {"opportunityAttachmentList": [{
        "attachments": [{
            "resourceId": "r1", "name": "solicitation.pdf",
            "mimeType": "application/pdf", "accessLevel": "public", "size": 1234,
        }],
    }]},
    "_links": {"self": {"href": f"/opportunities/{NOTICE}/resources"}},
}).encode()
GZ = gzip.compress(BODY)
HALF = GZ[: len(GZ) // 2]

observed: dict = {"body_bytes": len(BODY), "gzip_wire_bytes": len(GZ),
                  "half_wire_bytes": len(HALF)}

# Step 0: does zlib/httpx GZipDecoder flush validate the trailer on a cut stream?
d = zlib.decompressobj(zlib.MAX_WBITS | 16)
partial = d.decompress(HALF)
try:
    partial += d.flush()
    observed["zlib_flush_on_half_stream"] = {"raised": False, "decoded": len(partial),
                                             "eof": d.eof}
except zlib.error as exc:
    observed["zlib_flush_on_half_stream"] = {"raised": True, "error": str(exc)}


def run_case(name: str, client_factory) -> dict:
    cache_dir = TMP / "notice_cache"
    if cache_dir.exists():
        for p in sorted(cache_dir.rglob("*"), reverse=True):
            p.unlink() if p.is_file() else p.rmdir()
    _http._client = client_factory
    res = snd.fetch_notice_resources(NOTICE, timeout_seconds=5.0)
    cap = res.get("raw_capture") or {}
    retained = None
    if cap.get("sha256"):
        try:
            from tools.api.sam_capture import read_retained
            retained = read_retained(cache_dir, cap)
        except Exception as exc:  # noqa: BLE001
            retained = f"read_retained error: {exc}"
    return {
        "collection_status": res.get("collection_status"),
        "from_cache": res.get("from_cache"),
        "cache_file_written": (cache_dir / f"{NOTICE}.resources.json").exists(),
        "raw_capture_present": bool(cap),
        "complete": cap.get("complete"),
        "http_status": cap.get("http_status"),
        "captured_bytes": cap.get("size") if "size" in cap else cap.get("bytes"),
        "capture_keys": sorted(cap.keys()),
        "retained_equals_decoded_json": (retained == BODY) if isinstance(retained, bytes) else None,
        "retained_len": len(retained) if isinstance(retained, bytes) else retained,
        "errors": res.get("errors"),
    }


# A + B: MockTransport
def mock_factory(content: bytes):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, headers={"content-encoding": "gzip",
                                            "content-type": "application/hal+json"},
                              content=content)
    return lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

observed["A_mock_truncated_gzip"] = run_case("A", mock_factory(HALF))
observed["B_mock_full_gzip"] = run_case("B", mock_factory(GZ))


# C + D: real HTTPTransport class, httpcore pool over an in-process byte buffer
def h1_factory(wire: list[bytes]):
    def factory(timeout):
        transport = httpx.HTTPTransport(retries=0)
        transport._pool = httpcore.ConnectionPool(network_backend=MockBackend(wire))
        return httpx.Client(timeout=timeout, transport=transport)
    return factory

short_cl = [
    b"HTTP/1.1 200 OK\r\nContent-Type: application/hal+json\r\n"
    b"Content-Encoding: gzip\r\nContent-Length: " + str(len(GZ)).encode() + b"\r\n\r\n",
    HALF,
    b"",  # peer closes early
]
observed["C_h1_short_content_length"] = run_case("C", h1_factory(short_cl))

chunked = [
    b"HTTP/1.1 200 OK\r\nContent-Type: application/hal+json\r\n"
    b"Content-Encoding: gzip\r\nTransfer-Encoding: chunked\r\n\r\n",
    f"{len(HALF):x}\r\n".encode() + HALF + b"\r\n",
    b"",  # no terminating 0-chunk
]
observed["D_h1_truncated_chunked"] = run_case("D", h1_factory(chunked))

# Sanity: the h1 path with a full body must still produce inventory_captured
full_cl = [
    b"HTTP/1.1 200 OK\r\nContent-Type: application/hal+json\r\n"
    b"Content-Encoding: gzip\r\nContent-Length: " + str(len(GZ)).encode() + b"\r\n\r\n",
    GZ,
]
observed["E_h1_full_body_control"] = run_case("E", h1_factory(full_cl))

A = observed["A_mock_truncated_gzip"]
B = observed["B_mock_full_gzip"]
C = observed["C_h1_short_content_length"]
D = observed["D_h1_truncated_chunked"]
E = observed["E_h1_full_body_control"]

claim_holds = (
    A["complete"] is True and A["collection_status"] == "lookup_failed"
    and A["from_cache"] is False and A["cache_file_written"] is False
    and B["collection_status"] == "inventory_captured" and B["complete"] is True
    and B["retained_equals_decoded_json"] is True
    and C["complete"] is False and C["collection_status"] == "lookup_failed"
    and D["complete"] is False and D["collection_status"] == "lookup_failed"
    and E["collection_status"] == "inventory_captured"
)
# INFO: the finding is a harness/transport-layer observation with no wrong
# evidence reaching a cache or a row; the mismatch is only reachable under a
# transport that does not enforce body length.
print(json.dumps({"status": "INFO" if claim_holds else "FAIL",
                  "claim_reproduced": claim_holds,
                  "observed": observed}, indent=2, default=str))
