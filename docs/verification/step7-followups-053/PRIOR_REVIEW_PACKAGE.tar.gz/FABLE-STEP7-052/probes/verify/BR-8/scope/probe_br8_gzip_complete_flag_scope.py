"""BR-8 refutation/scope probe: truncated gzip flagged complete=true under MockTransport.

Stance: try to refute or re-classify. Measures
  A. the producer sentences that bound what `complete` means (docs/CONVENTIONS.md Step7);
  B. base 2d522f0 has no capture path at all (no complete flag exists to mislabel);
  C. finder's exact MockTransport case reproduced in-process (no foreign writes);
  D. the SAME candidate code run through the REAL httpx.HTTPTransport whose network
     backend is httpcore.MockBackend (h11 framing enforced, zero sockets) under six
     wire framings of the gzip body:
       cl_full_short      Content-Length = full length, body cut in half (peer close)
       chunked_short      chunked, chunk cut in half (peer close)
       close_delimited    no length, no chunking, Connection: close, body cut in half
       cl_honest_corrupt  Content-Length = truncated length (server-side corrupt gzip)
       trailer_only_cut   gzip trailer (8 bytes) dropped, honest Content-Length
       full_control       intact body with Content-Length
  E. production consequence through fetch_notice_resources for the framings that survive
     h11 with complete=true: does anything wrong ever reach the inventory cache?
Writes only under this probe directory. No network (socket connect blocked). No LLM calls.
"""
from __future__ import annotations

import gzip
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))


def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda seconds: None

import httpx  # noqa: E402
import httpcore  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

observed: dict = {}
checks: dict = {}

NOTICE = "a" * 32
plain = json.dumps({"_embedded": {"opportunityAttachmentList": [
    {"name": "SOW.pdf", "resourceId": "b" * 32, "mimeType": "application/pdf",
     "accessLevel": "public"}]}, "opportunityId": NOTICE}).encode()
gz = gzip.compress(plain)
half = gz[: len(gz) // 2]
trailer_cut = gz[:-8]

# A. Producer sentences bounding the meaning of `complete`.
conv = (REPO / "docs/CONVENTIONS.md").read_text()
sentence_partial = ("Public inventories use one attempt, a 2MiB response cap,\n"
                    "and retain partial/error bodies separately from complete recognized responses.")
sentence_custody = "this is observed custody, not independent source truth."
observed["A_doc"] = {
    "partial_vs_complete_recognized_sentence_present": sentence_partial in conv,
    "observed_custody_sentence_present": sentence_custody in conv,
    "doc_claims_complete_detects_truncation": any(
        s in conv for s in ("detects truncation", "truncation detection", "validates the gzip", "gzip trailer")),
}
checks["A_doc_binds_complete_to_recognized_not_to_integrity"] = (
    observed["A_doc"]["partial_vs_complete_recognized_sentence_present"]
    and not observed["A_doc"]["doc_claims_complete_detects_truncation"])

# B. Base has no capture path.
base_src = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:tools/api/_http.py"],
                          check=True, capture_output=True, text=True).stdout
observed["B_base"] = {"has_response_observer": "response_observer" in base_src,
                      "has_max_response_bytes": "max_response_bytes" in base_src,
                      "has_complete_flag": "complete" in base_src,
                      "candidate_has_all": all(t in (REPO / "tools/api/_http.py").read_text()
                                               for t in ("response_observer", "max_response_bytes", "complete = True"))}
checks["B_complete_flag_is_step7_new_not_pre_existing"] = (
    not observed["B_base"]["has_complete_flag"] and observed["B_base"]["candidate_has_all"])

# Cache dir plumbing.
root = Path(tempfile.mkdtemp(prefix="br8-", dir=PROBE_DIR))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(root / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(root / "text")
cache_dir = root / "notice"
cache_file = cache_dir / f"{NOTICE}.resources.json"


def reset_cache():
    shutil.rmtree(cache_dir, ignore_errors=True)


def run_production():
    res = detail.fetch_notice_resources(NOTICE)
    rc = res.get("raw_capture") or {}
    retained = None
    try:
        retained = read_retained(cache_dir, rc) if rc else None
    except Exception as exc:  # noqa: BLE001
        retained = f"read_retained error: {exc!r}"
    return {"collection_status": res.get("collection_status"), "errors": res.get("errors"),
            "from_cache": res.get("from_cache"), "complete": rc.get("complete"),
            "bytes": rc.get("bytes"), "http_status": rc.get("http_status"),
            "cache_file_written": cache_file.exists(),
            "retained_equals_full_plain": retained == plain,
            "retained_is_prefix_of_plain": isinstance(retained, bytes) and plain.startswith(retained),
            "attachments_resource_ids": [a.get("resource_id") for a in (res.get("attachments") or [])]}


# C. Finder's exact MockTransport case (streaming half gzip, no length header).
def mock_transport_client(handler):
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)


reset_cache()
mock_transport_client(lambda request: httpx.Response(
    200, stream=httpx.ByteStream(half), headers={"content-encoding": "gzip"}))
observed["C_mocktransport_half_gzip"] = run_production()
c = observed["C_mocktransport_half_gzip"]
checks["C_finder_repro_complete_true_lookup_failed_no_cache"] = (
    c["complete"] is True and c["collection_status"] == "lookup_failed"
    and c["cache_file_written"] is False and c["bytes"] == 37)


# D. Real HTTPTransport with h11 framing, network backend mocked (no sockets).
def wire(headers: list[str], body: bytes, chunked: bool = False) -> list[bytes]:
    head = "HTTP/1.1 200 OK\r\n" + "".join(h + "\r\n" for h in headers) + "\r\n"
    if chunked:
        body = f"{len(gz):x}\r\n".encode() + body
    return [head.encode(), body]


def real_transport_client(buffer: list[bytes]):
    def make(timeout):
        transport = httpx.HTTPTransport(retries=0, local_address="0.0.0.0")
        transport._pool._network_backend = httpcore.MockBackend(buffer)
        return httpx.Client(timeout=timeout, transport=transport, follow_redirects=True)
    _http._client = make


FRAMINGS = {
    "cl_full_short": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                           f"Content-Length: {len(gz)}"], half),
    "chunked_short": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                           "Transfer-Encoding: chunked"], half, chunked=True),
    "close_delimited": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                             "Connection: close"], half),
    "cl_honest_corrupt": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                               f"Content-Length: {len(half)}"], half),
    "trailer_only_cut": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                              f"Content-Length: {len(trailer_cut)}"], trailer_cut),
    "full_control": wire(["Content-Type: application/hal+json", "Content-Encoding: gzip",
                          f"Content-Length: {len(gz)}"], gz),
}

observed["D_real_transport_helper"] = {}
for name, buffer in FRAMINGS.items():
    seen: dict = {}
    real_transport_client(buffer)
    try:
        payload = _http.get_json("http://sam.invalid/x", retries=1, max_response_bytes=1 << 20,
                                 response_observer=lambda r, raw, comp: seen.update(
                                     status=r.status_code, raw=len(raw), complete=comp))
        outcome = {"error": None, "parsed_notice_id": payload.get("opportunityId") if isinstance(payload, dict) else None}
    except Exception as exc:  # noqa: BLE001
        outcome = {"error": f"{type(exc).__name__}: {exc}", "parsed_notice_id": None}
    outcome["observer"] = seen
    observed["D_real_transport_helper"][name] = outcome

D = observed["D_real_transport_helper"]
checks["D_cl_short_real_transport_complete_false"] = (
    D["cl_full_short"]["observer"].get("complete") is False
    and "RemoteProtocolError" in (D["cl_full_short"]["error"] or ""))
checks["D_chunked_short_real_transport_complete_false"] = (
    D["chunked_short"]["observer"].get("complete") is False
    and "RemoteProtocolError" in (D["chunked_short"]["error"] or ""))
checks["D_full_control_complete_true_parses"] = (
    D["full_control"]["observer"].get("complete") is True and D["full_control"]["parsed_notice_id"] == NOTICE)
# These two are the residual the finder did not name: real transport, complete=true, truncated.
observed["D_residual_close_delimited_complete_true"] = D["close_delimited"]["observer"].get("complete")
observed["D_residual_cl_honest_corrupt_complete_true"] = D["cl_honest_corrupt"]["observer"].get("complete")
checks["D_residual_neither_survives_json_parse"] = (
    D["close_delimited"]["parsed_notice_id"] is None and D["cl_honest_corrupt"]["parsed_notice_id"] is None)
# Trailer-only cut: decoder emits full plaintext without trailer validation.
observed["D_trailer_only_cut_decoded_full"] = D["trailer_only_cut"]["observer"].get("raw") == len(plain)
checks["D_trailer_only_cut_yields_correct_inventory_anyway"] = D["trailer_only_cut"]["parsed_notice_id"] == NOTICE

# E. Production consequence for the complete=true survivors.
observed["E_production_real_transport"] = {}
for name in ("cl_full_short", "close_delimited", "cl_honest_corrupt", "trailer_only_cut", "full_control"):
    reset_cache()
    real_transport_client(FRAMINGS[name])
    observed["E_production_real_transport"][name] = run_production()

E = observed["E_production_real_transport"]
checks["E_cl_short_production_complete_false_lookup_failed"] = (
    E["cl_full_short"]["complete"] is False and E["cl_full_short"]["collection_status"] == "lookup_failed"
    and E["cl_full_short"]["cache_file_written"] is False)
checks["E_close_delimited_truncated_never_cached"] = (
    E["close_delimited"]["complete"] is True and E["close_delimited"]["collection_status"] == "lookup_failed"
    and E["close_delimited"]["cache_file_written"] is False and E["close_delimited"]["from_cache"] is False)
checks["E_cl_honest_corrupt_truncated_never_cached"] = (
    E["cl_honest_corrupt"]["collection_status"] == "lookup_failed" and E["cl_honest_corrupt"]["cache_file_written"] is False)
checks["E_trailer_cut_cached_inventory_equals_control"] = (
    E["trailer_only_cut"]["collection_status"] == "inventory_captured"
    and E["trailer_only_cut"]["attachments_resource_ids"] == E["full_control"]["attachments_resource_ids"] == ["b" * 32]
    and E["trailer_only_cut"]["retained_equals_full_plain"] is True)

# A JSON prefix of an object is never itself a complete object except for trailing
# whitespace loss, so a deflate-stream cut cannot produce a different recognized inventory.
prefix_parses = []
for cut in range(1, len(plain)):
    try:
        json.loads(plain[:cut])
        prefix_parses.append(cut)
    except ValueError:
        pass
observed["E_plain_prefixes_that_parse_as_json"] = prefix_parses
checks["E_no_strict_prefix_of_inventory_parses"] = prefix_parses == []

shutil.rmtree(root, ignore_errors=True)
status = "PASS" if all(checks.values()) else "FAIL"
print(json.dumps({"probe": "br8_gzip_complete_flag_scope", "status": status,
                  "checks": checks, "observed": observed}, indent=2, sort_keys=True, default=str))
