"""Independent reproduction probe for merged finding F-07 (per-file stop reasons).

Written from the finding text only, before consulting any member probe.
Claims tested against the candidate run_searches._enrich_sam_public_attachments
and tools.api.sam_attachment_text.extract_public_attachment_text:

  C1  after stage-budget exhaustion mid-loop, the file at which the loop breaks
      gets 'stage time budget exhausted' while later ELIGIBLE (selected) files keep
      the pre-filled 'outside file/type budget' (false for them).
  C2  a stage deadline that fires between a successful download and parsing is
      labelled collection_status 'unreadable' (raw bytes retained, parser never ran).
  C3  type-filtered files (.xlsx) and cap-overflow files (rank 4+) share one
      indistinguishable receipt (not_fetched / 'outside file/type budget').
  C4  mitigations named by the merged summary: record-level errors list names the
      true budget stop; nothing failed is cached in the text cache dir.
  C5  deadline before the first file: file 1 'stage time budget exhausted',
      files 2..3 default reason, record TEXT_UNAVAILABLE.

No network (socket.connect blocked), no LLM, probe-local temp dirs only.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
import time
from pathlib import Path

ROOT = "/Users/wtjohnson/lila-step7-052"
sys.path.insert(0, ROOT)
os.chdir(ROOT)

PROBE_DIR = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp(prefix="f07_", dir=str(PROBE_DIR)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "10"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

import run_searches as searches  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.relevance import engine as rel_engine  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402

NOTICE = "a" * 32


class FakeClock:
    def __init__(self, start: float = 1000.0):
        self.now = start

    def __call__(self) -> float:
        return self.now


clock = FakeClock()
_real_monotonic = time.monotonic
time.monotonic = clock  # both run_searches and sam_attachment_text read time.monotonic

sam_quota.calls_today = lambda: 0


def public_file(rid: str, name: str) -> dict:
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0",
            "explicit_access": "0"}


class Verdict:
    relevant = False
    score = 0.0
    core_terms: list = []
    adjacent_terms: list = []
    excluded_by_code = False
    scope_basis = "probe"
    spans: list = []


rel_engine.score_record = lambda *a, **k: Verdict()


class Source:
    last_attachment_census = {"selected": 1}

    def __init__(self, candidate):
        self._candidate = candidate

    def attachment_candidates(self, *a, **k):
        return [self._candidate]


def make_inventory(files: list[dict]) -> dict:
    return {"id": NOTICE, "resources_checked": True, "attachments": files,
            "attachment_inventory_hash": detail._manifest_hash(files)}


def run(files: list[dict], download_stub, *, before_loop_advance: float = 0.0,
        after_extract_advance: dict | None = None):
    """Run the candidate enrichment with a controllable clock.

    download_stub(rid) -> bytes; may move clock.now.
    before_loop_advance: seconds added while fetch_notice_resources runs.
    after_extract_advance: {resource_id: seconds} added after the real extractor
      returns for that file (so the file itself completes normally).
    """
    inventory = make_inventory(files)

    def fetch(*a, **k):
        clock.now += before_loop_advance
        return inventory

    detail.fetch_notice_resources = fetch
    sat._download_bytes = lambda rid, **k: download_stub(rid)
    real_extract = sat.extract_public_attachment_text
    advance = after_extract_advance or {}

    def wrapped_extract(attachment, **k):
        out = real_extract(attachment, **k)
        clock.now += float(advance.get(attachment.get("resource_id"), 0.0))
        return out

    sat.extract_public_attachment_text = wrapped_extract
    try:
        candidate = RawOpportunity(source="sam.gov", source_id=NOTICE,
                                   title="Requirement", agency="NASA",
                                   raw_payload={"type": "Solicitation"})
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(candidate), object(), object(), None, limit=8)
    finally:
        sat.extract_public_attachment_text = real_extract
    receipt = stats["attachment_record_receipts"][NOTICE]
    files_by_name = {r["name"]: r for r in receipt.get("files", [])}
    return receipt, files_by_name, stats


def slim(r: dict) -> dict:
    return {k: r.get(k) for k in ("status", "reason", "error",
                                  "collection_status") if k in r}


observed: dict = {}
checks: dict[str, bool] = {}

# ---------------------------------------------------------------- C1 + C3
# Five listed files: three eligible .txt selected, one .txt overflow (rank 4),
# one .xlsx filtered by type.  File 1 succeeds; the clock jumps past the
# deadline right after file 1's extractor returns, so file 2 is where the
# loop breaks and file 3 is eligible but never attempted.
clock.now = 1000.0
files_c1 = [public_file("b" * 32, "SOW 1.txt"), public_file("c" * 32, "PWS 2.txt"),
            public_file("d" * 32, "Specification 3.txt"),
            public_file("e" * 32, "Solicitation 4.txt"),
            public_file("f" * 32, "Pricing.xlsx")]
attempted: list[str] = []


def stub_c1(rid: str) -> bytes:
    attempted.append(rid)
    return b"Buyer requires network visibility for the enterprise."


receipt, fb, stats = run(files_c1, stub_c1, after_extract_advance={"b" * 32: 11.0})
observed["C1_C3_mid_loop"] = {
    "record_status": receipt["status"],
    "record_errors": receipt.get("errors"),
    "stats_errors": stats["attachment_errors"],
    "downloads_attempted": [a[0] * 4 for a in attempted],
    "files": {n: slim(r) for n, r in fb.items()},
}
checks["C1_file1_captured"] = fb["SOW 1.txt"]["status"] == "captured_discovery_only"
checks["C1_file2_break_marked_exhausted"] = (
    fb["PWS 2.txt"]["status"] == "not_fetched"
    and fb["PWS 2.txt"]["reason"] == "stage time budget exhausted")
checks["C1_file3_eligible_unattempted_keeps_default"] = (
    fb["Specification 3.txt"]["status"] == "not_fetched"
    and fb["Specification 3.txt"]["reason"] == "outside file/type budget"
    and "d" * 32 not in attempted)
checks["C1_budget_stop_in_stats_errors"] = any(
    "hard budget" in e for e in stats["attachment_errors"])
checks["C1_budget_stop_in_record_errors"] = any(
    "hard budget" in e for e in (receipt.get("errors") or []))
checks["C3_overflow_and_type_filter_identical"] = (
    slim(fb["Solicitation 4.txt"]) == slim(fb["Pricing.xlsx"])
    == {"status": "not_fetched", "reason": "outside file/type budget"})

# ---------------------------------------------------------------- C2 + C4
# Fresh temp dir state: deadline fires AFTER a successful download of a .pdf
# whose parser we instrument to prove it never ran.
clock.now = 2000.0
parser_calls: list[str] = []
_real_pdf_text = sat._pdf_text


def counting_pdf_text(payload, **k):
    parser_calls.append("pdf")
    return _real_pdf_text(payload, **k)


sat._pdf_text = counting_pdf_text
files_c2 = [public_file("1" * 32, "SOW A.pdf"), public_file("2" * 32, "PWS B.txt"),
            public_file("3" * 32, "Spec C.txt")]


def stub_c2(rid: str) -> bytes:
    payload = b"%PDF-1.4 probe bytes"
    clock.now += 11.0  # deadline passes while/after the bytes arrive
    return payload


receipt2, fb2, stats2 = run(files_c2, stub_c2)
sat._pdf_text = _real_pdf_text
text_cache_dir = Path(os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"])
cached_json = sorted(p.name for p in text_cache_dir.glob("*.json")) if text_cache_dir.exists() else []
raw_obj = fb2["SOW A.pdf"].get("raw_capture") or {}
raw_obj_path = None
if isinstance(raw_obj, dict):
    rel = raw_obj.get("path") or raw_obj.get("object") or ""
    sha = raw_obj.get("sha256") or ""
    cand = text_cache_dir / "objects" / f"{sha}.bin"
    raw_obj_path = str(cand) if cand.exists() else None
observed["C2_C4_deadline_after_download"] = {
    "record_status": receipt2["status"],
    "record_errors": receipt2.get("errors"),
    "stats_errors": stats2["attachment_errors"],
    "parser_calls": parser_calls,
    "files": {n: slim(r) for n, r in fb2.items()},
    "file1_has_raw_capture": bool(raw_obj),
    "file1_raw_object_exists": raw_obj_path is not None,
    "file1_retrieved_at_present": bool(fb2["SOW A.pdf"].get("retrieved_at")),
    "text_cache_json_files": cached_json,
}
checks["C2_deadline_after_download_labelled_unreadable"] = (
    fb2["SOW A.pdf"]["status"] == "unreadable"
    and fb2["SOW A.pdf"].get("collection_status") == "unreadable"
    and fb2["SOW A.pdf"]["reason"] == "SAM attachment stage deadline reached")
checks["C2_parser_never_ran"] = parser_calls == []
checks["C2_raw_bytes_retained"] = bool(raw_obj) and raw_obj_path is not None
checks["C2_later_eligible_files_keep_default"] = (
    fb2["PWS B.txt"]["reason"] == "stage time budget exhausted"
    and fb2["Spec C.txt"]["reason"] == "outside file/type budget")
checks["C4_nothing_failed_cached"] = cached_json == [f"{'b' * 32}.json"]  # only C1's success
checks["C4_record_errors_name_true_stop"] = any(
    "deadline" in e for e in (receipt2.get("errors") or [])) and any(
    "hard budget" in e for e in stats2["attachment_errors"])

# ---------------------------------------------------------------- C5
clock.now = 3000.0
files_c5 = [public_file("7" * 32, "SOW X.txt"), public_file("8" * 32, "PWS Y.txt"),
            public_file("9" * 32, "Spec Z.txt")]
attempted5: list[str] = []


def stub_c5(rid: str) -> bytes:
    attempted5.append(rid)
    return b"never"


receipt5, fb5, stats5 = run(files_c5, stub_c5, before_loop_advance=11.0)
observed["C5_deadline_before_first_file"] = {
    "record_status": receipt5["status"],
    "downloads_attempted": attempted5,
    "files": {n: slim(r) for n, r in fb5.items()},
    "stats_errors": stats5["attachment_errors"],
}
checks["C5_file1_exhausted_files23_default_record_text_unavailable"] = (
    attempted5 == []
    and fb5["SOW X.txt"]["reason"] == "stage time budget exhausted"
    and fb5["PWS Y.txt"]["reason"] == "outside file/type budget"
    and fb5["Spec Z.txt"]["reason"] == "outside file/type budget"
    and receipt5["status"] == "TEXT_UNAVAILABLE")

# ---------------------------------------------------------------- doc claim
conv = Path(ROOT, "docs/CONVENTIONS.md").read_text()
doc_claim = ("retains every listed file's status\nand stop reason" in conv
             or "retains every listed file's status and stop reason" in conv)
checks["DOC_conventions_claims_every_file_stop_reason"] = doc_claim

time.monotonic = _real_monotonic
all_defect_claims = [
    checks["C1_file1_captured"], checks["C1_file2_break_marked_exhausted"],
    checks["C1_file3_eligible_unattempted_keeps_default"],
    checks["C2_deadline_after_download_labelled_unreadable"], checks["C2_parser_never_ran"],
    checks["C3_overflow_and_type_filter_identical"],
    checks["C5_file1_exhausted_files23_default_record_text_unavailable"],
    checks["DOC_conventions_claims_every_file_stop_reason"],
]
status = "FAIL" if all(all_defect_claims) else ("INFO" if any(all_defect_claims) else "PASS")
print(json.dumps({"status": status, "finding": "F-07",
                  "meaning": "FAIL = the misreported stop reasons reproduce as described",
                  "checks": checks, "observed": observed,
                  "tmp_dir": str(TMP)}, indent=2, default=str))
