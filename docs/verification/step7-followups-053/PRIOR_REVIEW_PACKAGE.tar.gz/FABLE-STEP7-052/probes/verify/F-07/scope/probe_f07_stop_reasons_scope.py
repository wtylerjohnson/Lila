"""F-07 refuter probe: per-file receipt stop reasons under stage-budget stops.

Scenarios (candidate run_searches + candidate extractor, offline, clock-controlled):
  A  deadline fires after file 1 download completes (inside extractor): file 1 label
  B  deadline already gone at the loop check for file 2: file 2 and file 3 labels
  C  deadline already gone before file 1: labels of all three selected files
  D  type-filtered vs cap-overflow files: same or distinct reason
Base comparison: base run_searches (git show 2d522f0) compiled in memory; base
extractor compiled in memory; same scenarios; presence of per-file receipts and of
any collection_status label.
Consumer check: does any non-test module read the per-file `reason`/`status`?
Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import types

REPO = "/Users/wtjohnson/lila-step7-052"
BASE_SHA = "2d522f0"
os.chdir(REPO)
sys.path.insert(0, REPO)

# No live network anywhere.
def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _blocked  # type: ignore[assignment]

tmp_root = tempfile.mkdtemp(prefix="f07_", dir=os.path.dirname(os.path.abspath(__file__)))
os.environ["LILA_NOTICE_CACHE_DIR"] = os.path.join(tmp_root, "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(tmp_root, "text")
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "100"

# Controllable monotonic clock shared by run_searches and sam_attachment_text.
_REAL_MONOTONIC = time.monotonic
CLOCK = {"offset": 0.0}
def fake_monotonic() -> float:
    return _REAL_MONOTONIC() + CLOCK["offset"]
time.monotonic = fake_monotonic  # type: ignore[assignment]

import run_searches as searches  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.api import sam_attachment_text as sat, sam_notice_detail as detail, sam_quota  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

sam_quota.calls_today = lambda: 0

NOTICE = "a" * 32
TERM = "network visibility"


def public_file(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


FILES = [public_file("b" * 32, "SOW 1.txt"),
         public_file("c" * 32, "PWS 2.txt"),
         public_file("d" * 32, "Spec 3.txt"),
         public_file("e" * 32, "Amendment 4.txt"),
         public_file("f" * 32, "Pricing.xlsx")]
TEXTS = {rid: f"Buyer requires {TERM} in file {rid[:2]}." for rid in
         ("b" * 32, "c" * 32, "d" * 32, "e" * 32)}


def reset_caches():
    import shutil
    for sub in ("notice", "text"):
        shutil.rmtree(os.path.join(tmp_root, sub), ignore_errors=True)


def run_enrich(module, download_stub):
    """Run one enrichment with the given run_searches module and download stub."""
    reset_caches()
    CLOCK["offset"] = 0.0
    inventory = detail._manifest_hash(FILES)
    module_detail = sys.modules["tools.api.sam_notice_detail"]
    saved_fetch = module_detail.fetch_notice_resources
    saved_download = sat._download_bytes
    module_detail.fetch_notice_resources = lambda *a, **k: {
        "id": NOTICE, "resources_checked": True, "attachments": FILES,
        "attachment_inventory_hash": inventory}
    sat._download_bytes = download_stub
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class Source:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                             core=[TaxonomyTerm(term=TERM)])
    try:
        rows, stats = module._enrich_sam_public_attachments(
            [], Source(), object(), tax, None, limit=8)
    finally:
        module_detail.fetch_notice_resources = saved_fetch
        sat._download_bytes = saved_download
    return rows, stats


def receipt_view(stats):
    rec = stats["attachment_record_receipts"][NOTICE]
    files = rec.get("files")
    view = {"record_status": rec.get("status"),
            "record_errors": rec.get("errors"),
            "stage_errors": [e for e in stats.get("attachment_errors", []) if "budget" in e],
            "has_per_file_receipts": files is not None}
    if files:
        view["files"] = [{"name": f["name"], "status": f.get("status"),
                          "reason": f.get("reason"),
                          "has_raw_capture": bool(f.get("raw_capture"))} for f in files]
    return view


# ---- download stubs ----------------------------------------------------------
attempted: list[str] = []


def stub_jump_after_first(rid, **k):
    attempted.append(rid[:2])
    payload = TEXTS[rid].encode()
    if len(attempted) == 1:
        CLOCK["offset"] += 10_000.0  # deadline passes after bytes are acquired
    return payload


def stub_plain(rid, **k):
    attempted.append(rid[:2])
    return TEXTS[rid].encode()


observed: dict = {}

# Scenario A/B (one run): file 1 downloads, deadline passes inside the extractor
# before parse (A); loop check for file 2 sees the deadline (B); file 3 unattempted.
attempted.clear()
rows, stats = run_enrich(searches, stub_jump_after_first)
observed["cand_A_B_deadline_after_first_download"] = {
    **receipt_view(stats), "attempted_downloads": list(attempted)}

# Scenario C: deadline gone before the first file.
attempted.clear()
reset_caches()
CLOCK["offset"] = 0.0
_saved_stop = None
# Force the deadline to have passed by the time the per-file loop is reached:
# fetch_notice_resources stub bumps the clock.
inventory = detail._manifest_hash(FILES)
module_detail = sys.modules["tools.api.sam_notice_detail"]
saved_fetch = module_detail.fetch_notice_resources
saved_download = sat._download_bytes


def fetch_and_jump(*a, **k):
    CLOCK["offset"] += 10_000.0
    return {"id": NOTICE, "resources_checked": True, "attachments": FILES,
            "attachment_inventory_hash": inventory}


module_detail.fetch_notice_resources = fetch_and_jump
sat._download_bytes = stub_plain
try:
    candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})

    class SourceC:
        last_attachment_census = {"selected": 1}

        def attachment_candidates(self, *a, **k):
            return [candidate]

    tax = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                             core=[TaxonomyTerm(term=TERM)])
    rows_c, stats_c = searches._enrich_sam_public_attachments(
        [], SourceC(), object(), tax, None, limit=8)
finally:
    module_detail.fetch_notice_resources = saved_fetch
    sat._download_bytes = saved_download
observed["cand_C_deadline_before_first_file"] = {
    **receipt_view(stats_c), "attempted_downloads": list(attempted)}

# Scenario D: happy path, type-filtered vs cap-overflow reasons.
attempted.clear()
rows_d, stats_d = run_enrich(searches, stub_plain)
observed["cand_D_type_filter_vs_cap_overflow"] = {
    **receipt_view(stats_d), "attempted_downloads": list(attempted)}

# Direct extractor: deadline passes between download and parse.
reset_caches()
CLOCK["offset"] = 0.0
saved_download = sat._download_bytes


def stub_direct(rid, **k):
    CLOCK["offset"] += 10_000.0
    return TEXTS[rid].encode()


sat._download_bytes = stub_direct
try:
    deadline = time.monotonic() + 100.0
    direct = sat.extract_public_attachment_text(FILES[0], deadline_monotonic=deadline)
finally:
    sat._download_bytes = saved_download
observed["cand_extractor_deadline_between_download_and_parse"] = {
    "collection_status": direct.get("collection_status"), "error": direct.get("error"),
    "has_raw_capture": bool(direct.get("raw_capture")), "has_retrieved_at": bool(direct.get("retrieved_at")),
    "cache_written": os.path.exists(os.path.join(tmp_root, "text", "b" * 32 + ".json"))}

# ---- base comparison ----------------------------------------------------------
def git_show(path: str) -> str:
    return subprocess.run(["git", "-C", REPO, "show", f"{BASE_SHA}:{path}"],
                          check=True, capture_output=True, text=True).stdout


base_rs_src = git_show("run_searches.py")
base_rs = types.ModuleType("run_searches_base")
base_rs.__file__ = os.path.join(REPO, "run_searches.py")
exec(compile(base_rs_src, base_rs.__file__, "exec"), base_rs.__dict__)

base_sat_src = git_show("tools/api/sam_attachment_text.py")
base_sat = types.ModuleType("sam_attachment_text_base")
base_sat.__file__ = os.path.join(REPO, "tools/api/sam_attachment_text.py")
exec(compile(base_sat_src, base_sat.__file__, "exec"), base_sat.__dict__)

# Base run_searches imports the (candidate) extractor lazily; the receipt question
# (does base emit per-file receipts at all) is independent of the extractor.
attempted.clear()
rows_b, stats_b = run_enrich(base_rs, stub_jump_after_first)
observed["base_A_B_deadline_after_first_download"] = {
    **receipt_view(stats_b), "attempted_downloads": list(attempted),
    "record_receipt_keys": sorted(stats_b["attachment_record_receipts"][NOTICE].keys())}

# Base extractor: deadline between download and parse.
reset_caches()
CLOCK["offset"] = 0.0
base_sat._download_bytes = stub_direct
deadline = time.monotonic() + 100.0
base_direct = base_sat.extract_public_attachment_text(FILES[0], deadline_monotonic=deadline)
observed["base_extractor_deadline_between_download_and_parse"] = {
    "keys": sorted(base_direct.keys()), "error": base_direct.get("error"),
    "has_collection_status": "collection_status" in base_direct}

# ---- consumers of per-file reason/status ---------------------------------------
grep = subprocess.run(
    ["grep", "-rln", "-e", "attachment_record_receipts", "-e", "attachment_receipts",
     "--include=*.py", "agents", "tools", "run_searches.py"],
    cwd=REPO, capture_output=True, text=True).stdout.split()
observed["non_test_modules_naming_record_receipts"] = grep
screening_src = open(os.path.join(REPO, "tools/relevance/screening.py")).read()
triage_src = open(os.path.join(REPO, "agents/decisions/triage.py")).read()
observed["per_file_reason_read_by_screening_or_triage"] = any(
    tok in screening_src or tok in triage_src
    for tok in ('["files"]', "['files']", '.get("files")', ".get('files')"))

# ---- doc sentences ----------------------------------------------------------------
conv = open(os.path.join(REPO, "docs/CONVENTIONS.md"), encoding="utf-8").read().splitlines()
observed["conventions_sentences"] = [
    line.strip() for line in conv
    if "retains every listed file" in line or "collection_status` distinguishes" in line
    or "unreadable, inaccessible, invalid identity and not fetched" in line]

# ---- evaluation --------------------------------------------------------------------
ab = observed["cand_A_B_deadline_after_first_download"]["files"]
by_name = {f["name"]: f for f in ab}
# Selection order as run_searches computes it: priority sort, supported types, [:3].
ordered = sorted(FILES, key=sat.attachment_priority)
supported_sel = [f["name"] for f in ordered
                 if os.path.splitext(f["name"])[1].lower() in {".pdf", ".docx", ".txt", ".csv", ".md"}]
sel1, sel2, sel3 = supported_sel[:3]
cap_overflow = supported_sel[3]
observed["selection_order"] = {"selected": [sel1, sel2, sel3], "cap_overflow": cap_overflow,
                               "type_filtered": "Pricing.xlsx"}
c_files = {f["name"]: f for f in observed["cand_C_deadline_before_first_file"]["files"]}
d_files = {f["name"]: f for f in observed["cand_D_type_filter_vs_cap_overflow"]["files"]}

checks = {
    "A_file1_deadline_after_download_labelled_unreadable":
        by_name["SOW 1.txt"]["status"] == "unreadable"
        and by_name["SOW 1.txt"]["reason"] == "SAM attachment stage deadline reached"
        and by_name["SOW 1.txt"]["has_raw_capture"],
    "B_file2_break_point_labelled_budget":
        by_name["PWS 2.txt"]["reason"] == "stage time budget exhausted",
    "B_file3_eligible_unattempted_keeps_default":
        by_name[sel3]["status"] == "not_fetched"
        and by_name[sel3]["reason"] == "outside file/type budget",
    "B_record_errors_name_true_budget_stop":
        any("hard budget" in e for e in observed["cand_A_B_deadline_after_first_download"]["stage_errors"]),
    "C_file1_budget_files2_3_default":
        c_files[sel1]["reason"] == "stage time budget exhausted"
        and c_files[sel2]["reason"] == "outside file/type budget"
        and c_files[sel3]["reason"] == "outside file/type budget"
        and observed["cand_C_deadline_before_first_file"]["attempted_downloads"] == [],
    "D_type_filter_and_cap_overflow_share_reason":
        d_files[cap_overflow]["reason"] == d_files["Pricing.xlsx"]["reason"] == "outside file/type budget"
        and d_files[cap_overflow]["status"] == d_files["Pricing.xlsx"]["status"] == "not_fetched",
    "C_record_level_errors_empty_only_stage_list_names_budget":
        observed["cand_C_deadline_before_first_file"]["record_errors"] == []
        and any("hard budget" in e for e in observed["cand_C_deadline_before_first_file"]["stage_errors"]),
    "base_has_no_per_file_receipts":
        observed["base_A_B_deadline_after_first_download"]["has_per_file_receipts"] is False,
    "base_extractor_has_no_collection_status":
        observed["base_extractor_deadline_between_download_and_parse"]["has_collection_status"] is False,
    "no_pipeline_consumer_reads_per_file_reason":
        observed["per_file_reason_read_by_screening_or_triage"] is False,
}
observed["checks"] = checks
defect_shown = (checks["A_file1_deadline_after_download_labelled_unreadable"]
                and checks["B_file3_eligible_unattempted_keeps_default"]
                and checks["C_file1_budget_files2_3_default"])
status = "FAIL" if defect_shown else "PASS"
print(json.dumps({"probe": "probe_f07_stop_reasons_scope", "status": status,
                  "meaning": ("FAIL = per-file receipts carry a false or undifferentiated stop "
                              "reason under the candidate; receipts absent at base"),
                  "observed": observed}, indent=1, default=str))
import shutil
shutil.rmtree(tmp_root, ignore_errors=True)
