"""F-07 IMPACT lens: per-file receipt stop reasons after stage-budget stops.

Reproduces the three mechanisms independently (deterministic fake clock, no
network, no LLM) and then traces where the defective per-file values can flow:
record-level status/errors, screening_evidence, deterministic_prefilter,
saved sweep JSON (results.sam_census), strict Assess build (tests helper
_sweep/_build), dossier research context, text cache, and a static reader
census of the repository.

Run: cd /Users/wtjohnson/lila-step7-052 && PYTHONDONTWRITEBYTECODE=1 \
  .venv/bin/python <this file> > <log> 2>&1
"""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

# ---- isolation ---------------------------------------------------------------
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

TMP = Path(tempfile.mkdtemp(prefix="f07_impact_"))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_SAM_ATTACHMENT_STAGE_SECONDS"] = "10"
os.environ["LILA_SUITE_OFFLINE"] = "1"

import run_searches as searches  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402
from tools.relevance.engine import score_record  # noqa: E402
from tools.relevance.screening import screening_evidence, no_match_state  # noqa: E402
from agents.decisions.triage import deterministic_prefilter  # noqa: E402
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

sam_quota.calls_today = lambda: 0

class FakeClock:
    def __init__(self):
        self.now = 1000.0
    def __call__(self):
        return self.now
    def advance(self, seconds):
        self.now += seconds

CLOCK = FakeClock()
time.monotonic = CLOCK  # both run_searches and sam_attachment_text read time.monotonic

TERM = "network visibility"
NOTICE = "a" * 32
TAX = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                         core=[TaxonomyTerm(term=TERM)])

def pub(rid, name):
    return {"resource_id": rid, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}

FILES = [pub("b" * 32, "SOW 1.txt"), pub("c" * 32, "PWS 2.txt"), pub("d" * 32, "Spec 3.txt"),
         pub("e" * 32, "Solicitation 4.txt"), pub("f" * 32, "Pricing.xlsx")]
TEXTS = {"b" * 32: f"Buyer requires {TERM} tooling.", "c" * 32: f"More {TERM}.",
         "d" * 32: f"Third {TERM}.", "e" * 32: f"Fourth {TERM}."}
INVENTORY = detail._manifest_hash(FILES)

detail.fetch_notice_resources = lambda *a, **k: {
    "id": NOTICE, "resources_checked": True, "attachments": FILES,
    "attachment_inventory_hash": INVENTORY}

class Source:
    last_attachment_census = {"selected": 1}
    def attachment_candidates(self, *a, **k):
        return [RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                               agency="NASA", raw_payload={"type": "Solicitation"})]

REAL_EXTRACT = sat.extract_public_attachment_text
REAL_DOWNLOAD = sat._download_bytes

def run(download_hook=None, after_file_hook=None, after_fetch_advance=0.0):
    """Run the real enrichment with controllable clock side effects."""
    for p in (TMP / "text", TMP / "notice"):
        if p.exists():
            for f in sorted(p.rglob("*"), reverse=True):
                if f.is_file():
                    f.unlink()
    CLOCK.now = 1000.0
    attempted = []
    def fake_download(rid, **k):
        attempted.append(rid)
        payload = TEXTS[rid].encode()
        if download_hook:
            download_hook(rid)
        return payload
    sat._download_bytes = fake_download
    def wrapped_extract(attachment, **k):
        out = REAL_EXTRACT(attachment, **k)
        if after_file_hook:
            after_file_hook(attachment)
        return out
    sat.extract_public_attachment_text = wrapped_extract
    def fake_fetch(*a, **k):
        CLOCK.advance(after_fetch_advance)  # after stop_at was computed, before file 1
        return {"id": NOTICE, "resources_checked": True, "attachments": FILES,
                "attachment_inventory_hash": INVENTORY}
    detail.fetch_notice_resources = fake_fetch
    try:
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(), TAX, None, limit=8)
    finally:
        sat._download_bytes = REAL_DOWNLOAD
        sat.extract_public_attachment_text = REAL_EXTRACT
    return rows, stats, attempted

def receipts(stats):
    rec = stats["attachment_record_receipts"][NOTICE]
    return rec, {f["name"]: (f["status"], f["reason"]) for f in rec["files"]}

observed: dict = {}
checks: dict[str, bool] = {}

# ---- Scenario A: H6, budget exhausted after file 1 fully processed ----------
rows_a, stats_a, att_a = run(after_file_hook=lambda a: CLOCK.advance(11.0))
rec_a, files_a = receipts(stats_a)
observed["A_h6_mid_loop"] = {
    "attempted": att_a, "record_status": rec_a["status"], "files": files_a,
    "record_errors": rec_a["errors"], "stage_errors": stats_a["attachment_errors"]}
checks["A_file1_captured"] = files_a["SOW 1.txt"][0] == "captured_discovery_only"
checks["A_file2_budget_reason"] = files_a["PWS 2.txt"] == ("not_fetched", "stage time budget exhausted")
checks["A_file3_false_reason"] = files_a["Spec 3.txt"] == ("not_fetched", "outside file/type budget")
checks["A_stage_error_names_budget"] = any("hard budget" in e for e in stats_a["attachment_errors"])
checks["A_record_errors_empty_for_budget"] = rec_a["errors"] == []

# ---- Scenario B: deadline fires between download and parse -----------------
rows_b, stats_b, att_b = run(download_hook=lambda rid: CLOCK.advance(11.0))
rec_b, files_b = receipts(stats_b)
f1_b = next(f for f in rec_b["files"] if f["name"] == "SOW 1.txt")
raw_obj = None
if f1_b.get("raw_capture"):
    from tools.api.sam_capture import read_retained
    try:
        raw_obj = read_retained(TMP / "text", f1_b["raw_capture"]).decode()
    except Exception as exc:  # noqa: BLE001
        raw_obj = f"read failed: {exc}"
observed["B_deadline_after_download"] = {
    "attempted": att_b, "record_status": rec_b["status"], "files": files_b,
    "file1_error": f1_b.get("error"), "file1_has_raw_capture": bool(f1_b.get("raw_capture")),
    "file1_raw_bytes_readable": raw_obj == TEXTS["b" * 32],
    "record_errors": rec_b["errors"],
    "text_cache_json_files": sorted(p.name for p in (TMP / "text").glob("*.json")),
    "objects_retained": len(list((TMP / "text" / "objects").glob("*.bin"))) if (TMP / "text" / "objects").exists() else 0}
checks["B_file1_labelled_unreadable"] = files_b["SOW 1.txt"] == ("unreadable", "SAM attachment stage deadline reached")
checks["B_file1_raw_retained"] = raw_obj == TEXTS["b" * 32]
checks["B_no_failed_cache_entry"] = observed["B_deadline_after_download"]["text_cache_json_files"] == []
checks["B_record_error_carries_true_cause"] = rec_b["errors"] == ["SAM attachment stage deadline reached"]
checks["B_record_status_text_unavailable"] = rec_b["status"] == "TEXT_UNAVAILABLE"

# ---- Scenario C: type filter vs cap overflow share one reason ---------------
rows_c, stats_c, att_c = run()
rec_c, files_c = receipts(stats_c)
observed["C_type_vs_cap"] = {"attempted": att_c, "files": files_c, "record_status": rec_c["status"]}
# attachment_priority ranks 'Solicitation 4.txt' third; 'Spec 3.txt' is the cap-overflow file
checks["C_xlsx_and_overflow_txt_same_reason"] = (
    files_c["Pricing.xlsx"] == files_c["Spec 3.txt"] == ("not_fetched", "outside file/type budget")
    and "d" * 32 not in att_c and len(att_c) == 3)

# ---- Scenario D: deadline gone before first file (RUF-9 shape) -------------
rows_d, stats_d, att_d = run(after_fetch_advance=11.0)
rec_d, files_d = receipts(stats_d)
observed["D_deadline_before_first"] = {"attempted": att_d, "record_status": rec_d["status"], "files": files_d,
                                       "stage_errors": stats_d["attachment_errors"]}
checks["D_zero_attempts_text_unavailable"] = att_d == [] and rec_d["status"] == "TEXT_UNAVAILABLE"
checks["D_file1_budget_reason"] = files_d["SOW 1.txt"] == ("not_fetched", "stage time budget exhausted")
checks["D_files_2_3_false_reason"] = (files_d["PWS 2.txt"] == files_d["Solicitation 4.txt"]
                                      == ("not_fetched", "outside file/type budget"))

# ---- IMPACT 1: screening / prefilter read record-level only ----------------
def corrected(stats):
    fixed = copy.deepcopy(stats)
    for f in fixed["attachment_record_receipts"][NOTICE]["files"]:
        if f["reason"] == "outside file/type budget" and f["name"].endswith(".txt"):
            f["reason"] = "stage time budget exhausted (corrected by probe)"
        if f["status"] == "unreadable" and "deadline" in str(f.get("reason")):
            f["status"] = "not_parsed_time_budget (corrected by probe)"
    return fixed

impact = {}
for label, (rows, stats) in {"A": (rows_a, stats_a), "B": (rows_b, stats_b), "D": (rows_d, stats_d)}.items():
    notice_row = rows[0] if rows else json.loads(Source().attachment_candidates()[0].model_dump_json())
    verdict = score_record(notice_row, TAX, engagement_scope=None)
    ev_defective = screening_evidence(notice_row, verdict, stats["attachment_record_receipts"][NOTICE])
    ev_fixed = screening_evidence(notice_row, verdict, corrected(stats)["attachment_record_receipts"][NOTICE])
    _, ruled_def, rcpt_def = deterministic_prefilter([notice_row], TAX, attachment_receipts=stats["attachment_record_receipts"])
    _, ruled_fix, rcpt_fix = deterministic_prefilter([notice_row], TAX, attachment_receipts=corrected(stats)["attachment_record_receipts"])
    ev_str = json.dumps(ev_defective, sort_keys=True, default=str)
    impact[label] = {
        "screening_attachment_status": ev_defective["attachment_status"],
        "screening_attachment_errors": ev_defective["attachment_errors"],
        "screening_evidence_identical_after_receipt_correction": ev_defective == ev_fixed,
        "screening_evidence_mentions_file_reason": "outside file/type budget" in ev_str or "unreadable" in ev_str,
        "prefilter_ruled_identical": ruled_def == ruled_fix,
        "prefilter_verdict": {k: v.get("verdict") for k, v in ruled_def.items()},
        "no_match_state": no_match_state(ev_defective)[0] if ev_defective["attachment_status"] != "DISCOVERY_TEXT_CAPTURED" else "n/a",
    }
observed["impact_screening_prefilter"] = impact
checks["IMPACT_screening_never_reads_file_reason"] = all(
    v["screening_evidence_identical_after_receipt_correction"] and not v["screening_evidence_mentions_file_reason"]
    for v in impact.values())
checks["IMPACT_prefilter_unchanged"] = all(v["prefilter_ruled_identical"] for v in impact.values())

# ---- IMPACT 2: saved sweep JSON carries the defective reasons -------------
census_box = {"matched": 1, "active_screened": 3, "complete": True, "source": "sam_extract"}
census_box.update(stats_a)
saved = json.loads(json.dumps({"results": {"sam_census": dict(census_box)}}, default=str))
saved_files = saved["results"]["sam_census"]["attachment_record_receipts"][NOTICE]["files"]
observed["impact_saved_sweep"] = {
    "path": "results.sam_census.attachment_record_receipts.<notice>.files[*].reason",
    "persisted_reasons": {f["name"]: f["reason"] for f in saved_files}}
checks["IMPACT_saved_sweep_persists_false_reason"] = any(
    f["name"] == "Spec 3.txt" and f["reason"] == "outside file/type budget" for f in saved_files)

# ---- IMPACT 3: strict Assess build ignores per-file receipts ---------------
assess = {}
try:
    spec = importlib.util.spec_from_file_location("t_assess", REPO / "tests" / "test_assess_ledger.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    sweep_def = mod._sweep()
    sweep_def["results"]["sam_census"]["attachment_record_receipts"] = json.loads(
        json.dumps(stats_a["attachment_record_receipts"], default=str))
    sweep_fix = copy.deepcopy(sweep_def)
    sweep_fix["results"]["sam_census"]["attachment_record_receipts"] = json.loads(
        json.dumps(corrected(stats_a)["attachment_record_receipts"], default=str))
    sweep_none = mod._sweep()
    def dump(built):
        proposed = built[0]
        try:
            d = proposed.model_dump(mode="json")
        except Exception:  # noqa: BLE001
            d = json.loads(json.dumps(proposed, default=str))
        return json.dumps(d, sort_keys=True, default=str)
    d_def, d_fix, d_none = dump(mod._build(sweep_def)), dump(mod._build(sweep_fix)), dump(mod._build(sweep_none))
    proposed = mod._build(sweep_def)[0]
    live = [(r.notice_id, str(getattr(r, "classification", "")), getattr(r, "requirement_reviewed_at", None))
            for r in proposed.live.records]
    assess = {
        "assess_identical_defective_vs_corrected": d_def == d_fix,
        "assess_identical_vs_no_receipts": d_def == d_none,
        "assess_dump_mentions_file_reason": "outside file/type budget" in d_def or "stage time budget" in d_def,
        "live_records": live,
        "any_bid_now": any("BID_NOW" in c for _, c, _ in live),
        "any_requirement_reviewed": any(t for _, _, t in live),
    }
except Exception as exc:  # noqa: BLE001
    assess = {"error": f"{type(exc).__name__}: {exc}"}
observed["impact_assess"] = assess
checks["IMPACT_assess_unaffected"] = bool(assess.get("assess_identical_defective_vs_corrected")) and bool(
    assess.get("assess_identical_vs_no_receipts")) and not assess.get("assess_dump_mentions_file_reason", True)

# ---- IMPACT 4: dossier research context reads collection_v1, not receipts --
ctx = _attachment_research_context(rows_a[0], {"id": NOTICE, "resources_checked": True,
                                                "attachment_inventory_hash": INVENTORY})
ctx_str = json.dumps(ctx, default=str)
observed["impact_dossier"] = {"status": ctx.get("status"), "passages": len(ctx.get("file_passages") or []),
                              "mentions_file_reason": "outside file/type budget" in ctx_str or "stage time budget" in ctx_str,
                              "authority": ctx.get("authority")}
checks["IMPACT_dossier_unaffected"] = ctx.get("status") == "discovery_only" and observed["impact_dossier"]["passages"] == 1 \
    and not observed["impact_dossier"]["mentions_file_reason"]

# ---- IMPACT 5: static reader census -----------------------------------------
def grep(pattern):
    out = subprocess.run(["grep", "-rIl", "--exclude-dir=.venv", "--exclude-dir=.git", pattern, "."],
                         capture_output=True, text=True, cwd=REPO).stdout.split()
    return sorted(p for p in out if not p.startswith("./tests/") and not p.startswith("./docs/"))
observed["static_readers"] = {
    "attachment_record_receipts": grep("attachment_record_receipts"),
    "outside file/type budget": grep("outside file/type budget"),
    "stage time budget exhausted": grep("stage time budget exhausted"),
}
checks["STATIC_only_producer_names_receipt_keys"] = all(v == ["./run_searches.py"] for v in observed["static_readers"].values())

# ---- Base comparison: per-file receipts new in the delta -------------------
base_src = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:run_searches.py"],
                          capture_output=True, text=True).stdout
observed["base"] = {"base_has_file_receipts": "file_receipt" in base_src,
                    "base_has_outside_budget_reason": "outside file/type budget" in base_src,
                    "base_has_record_receipts": "attachment_record_receipts" in base_src}
checks["BASE_receipts_new_in_delta"] = not observed["base"]["base_has_file_receipts"]

mechanism_confirmed = all(checks[k] for k in checks if k.startswith(("A_", "B_", "C_", "D_")))
confined = all(checks[k] for k in checks if k.startswith(("IMPACT_", "STATIC_")))
print(json.dumps({
    "status": "FAIL" if mechanism_confirmed else "PASS",
    "verdict_note": ("mechanism reproduced; defective per-file reasons are confined to the saved sweep "
                     "receipt (results.sam_census.attachment_record_receipts) and never reach screening, "
                     "prefilter, Assess, dossier or LeadRow" if mechanism_confirmed and confined else
                     "see checks"),
    "checks": checks, "observed": observed, "tmp": str(TMP)}, indent=1, default=str))
