"""WNI-1 IMPACT lens: where does raw_capture.source_url (requested URL, not served
URL) actually flow after a redirect, and does anything trusted read it?

Scenario: notice A's resources URL answers 302 to an off-host URL that serves an
id-less inventory body listing one public .txt resource C. The real candidate
fetch_notice_resources runs over MockTransport (no socket), then the REAL
run_searches._enrich_sam_public_attachments stage consumes it with
_download_bytes mocked, then the dossier research context, the triage
deterministic prefilter and a strict Assess build are run on the produced row.

Surfaces checked for the misrecorded URL and for wrong-notice attribution:
  S1 fetch_notice_resources return + on-disk <A>.resources.json cache
  S2 run_searches record receipt (attachment_record_receipts[A].inventory_receipt)
  S3 candidate row raw_payload / attachment_collection_v1 (the row the sweep saves)
  S4 dossier _attachment_research_context (model-facing research context)
  S5 triage deterministic_prefilter receipt (screening evidence)
  S6 strict Assess build (LiveClassification, requirement_reviewed_at, attachment_gap)
Base 2d522f0 fetch_notice_resources runs the same scenario for kind attribution.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni1-impact-", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
import tools.api.sam_quota as sam_quota  # noqa: E402
import tools.api.sam_notice_detail as detail  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import run_searches as rs  # noqa: E402
from agents.schemas import RawOpportunity  # noqa: E402
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm  # noqa: E402

A = "a" * 32
C = "c" * 32
TERM = "packet capture"
URL_A = detail.RESOURCES_URL_TPL.format(id=A)
OFF_HOST = "https://attachments.example.net/opps/v3/opportunities/" + "b" * 32 + "/resources"
BODY = {"attachments": [{"resourceId": C, "name": "Other notice SOW.txt",
                         "mimeType": ".txt", "size": 40, "accessLevel": "public",
                         "accessStatus": "public", "exportControlled": "0",
                         "explicitAccess": "0"}]}
FILE_TEXT = f"The buyer requires an enterprise {TERM} platform for the other notice."

calls: list[dict] = []


def handler(request):
    calls.append({"url": str(request.url)})
    if str(request.url) == URL_A:
        return httpx.Response(302, headers={"Location": OFF_HOST})
    if str(request.url) == OFF_HOST:
        return httpx.Response(200, content=json.dumps(BODY).encode())
    return httpx.Response(404, content=b"unexpected")


_http._client = lambda timeout: httpx.Client(
    transport=httpx.MockTransport(handler), follow_redirects=True)
sam_quota.calls_today = lambda: 0
downloads: list[str] = []


def fake_download(resource_id, **kw):
    downloads.append(resource_id)
    return FILE_TEXT.encode()


sat._download_bytes = fake_download


def contains(obj, needle: str) -> bool:
    return needle in json.dumps(obj, default=str, sort_keys=True)


observed: dict = {"scenario": {"requested": URL_A, "served_from": OFF_HOST,
                               "body_has_notice_id_key": False}}

# ---- S1: adapter return and on-disk cache -------------------------------------------------
inv = detail.fetch_notice_resources(A)
cap = inv.get("raw_capture") or {}
cache_file = Path(os.environ["LILA_NOTICE_CACHE_DIR"]) / f"{A}.resources.json"
on_disk = json.loads(cache_file.read_text()) if cache_file.exists() else None
second = detail.fetch_notice_resources(A)
observed["S1_adapter"] = {
    "hops": [c["url"] for c in calls],
    "collection_status": inv.get("collection_status"),
    "resources_checked": inv.get("resources_checked"),
    "attachment_count": inv.get("attachment_inventory_count"),
    "raw_capture_source_url": cap.get("source_url"),
    "raw_capture_records_served_url": cap.get("source_url") == OFF_HOST,
    "raw_capture_has_any_redirect_field": any(
        k for k in cap if "redirect" in k or "history" in k or "final" in k),
    "cache_written": on_disk is not None,
    "cache_source_url": (on_disk or {}).get("raw_capture", {}).get("source_url"),
    "second_call_from_cache_without_network": second.get("from_cache") is True
    and len(calls) == 2,
    "capture_valid_passes_on_reuse": detail._resource_capture_valid(on_disk or {}),
}

# ---- S2/S3: real run_searches stage -----------------------------------------------------
candidate = RawOpportunity(source="sam.gov", source_id=A, title="Requirement",
                           agency="DHS", raw_payload={"type": "Solicitation"})


class Source:
    last_attachment_census = {"selected": 1}

    def attachment_candidates(self, *a, **k):
        return [candidate]


taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                              core=[TaxonomyTerm(term=TERM)])
rows, stats = rs._enrich_sam_public_attachments([], Source(), object(), taxonomy, None, limit=8)
receipt = (stats.get("attachment_record_receipts") or {}).get(A, {})
inv_receipt = receipt.get("inventory_receipt") or {}
observed["S2_sweep_record_receipt"] = {
    "status": receipt.get("status"),
    "identity_guard_fired": receipt.get("status") == "IDENTITY_MISMATCH",
    "inventory_receipt_collection_status": inv_receipt.get("collection_status"),
    "inventory_receipt_raw_capture_source_url": (inv_receipt.get("raw_capture") or {}).get("source_url"),
    "receipt_mentions_served_host": contains(receipt, "attachments.example.net"),
    "receipt_errors": receipt.get("errors"),
    "files_downloaded_by_resource_id": downloads,
    "download_side_enforces_final_host": "_ALLOWED_FINAL_HOSTS" in Path(
        REPO / "tools/api/sam_attachment_text.py").read_text(),
}
row = rows[0] if rows else None
raw = (row or {}).get("raw_payload") or {}
coll = raw.get("attachment_collection_v1") or {}
observed["S3_candidate_row"] = {
    "row_produced_for_A": bool(row) and row.get("source_id") == A,
    "collection_notice_id": coll.get("notice_id"),
    "collection_files": [f.get("name") for f in coll.get("files", [])],
    "file_source_urls": [f.get("source_url") for f in coll.get("files", [])],
    "row_mentions_inventory_receipt_url": contains(row, URL_A),
    "row_mentions_served_host": contains(row, "attachments.example.net"),
    "row_carries_inventory_raw_capture": contains(row, "decoded_http_entity_bytes"),
    "wrong_notice_text_attributed_to_A": FILE_TEXT[:30] in (raw.get("text") or ""),
    "authority": coll.get("authority"),
}

# ---- S4: dossier research context -----------------------------------------------------
from agents.decisions.dossier import _attachment_research_context  # noqa: E402

depth = {"id": A, "resources_checked": True,
         "attachment_inventory_hash": inv.get("attachment_inventory_hash")}
ctx = _attachment_research_context(row, depth) if row else {"status": "no_row"}
observed["S4_dossier_context"] = {
    "status": ctx.get("status"),
    "inventory_binding": ctx.get("inventory_binding"),
    "passages": [p.get("name") for p in ctx.get("file_passages", [])],
    "context_mentions_inventory_url_or_served_host": contains(ctx, URL_A)
    or contains(ctx, "attachments.example.net"),
    "context_text_is_other_notice_text": FILE_TEXT[:30] in (ctx.get("text") or ""),
}

# ---- S5: triage deterministic prefilter -------------------------------------------------
from agents.decisions.triage import deterministic_prefilter  # noqa: E402

cands, ruled, pre = deterministic_prefilter([row], taxonomy,
                                            attachment_receipts=stats["attachment_record_receipts"])
observed["S5_triage_prefilter"] = {
    "candidate_count": len(cands),
    "screen_state": (pre.get("screening") or pre.get("records") or {}).get(A, {}).get("screen_state")
    if isinstance(pre, dict) else None,
    "prefilter_keys": sorted(pre)[:12] if isinstance(pre, dict) else str(type(pre)),
    "prefilter_mentions_inventory_url": contains(pre, URL_A),
    "prefilter_mentions_served_host": contains(pre, "attachments.example.net"),
    "prefilter_mentions_raw_capture": contains(pre, "decoded_http_entity_bytes"),
}

# ---- S6: strict Assess build ---------------------------------------------------------
from agents.assess.contracts import LiveClassification  # noqa: E402
from tests.test_assess_ledger import _sweep, _build  # noqa: E402

sweep = _sweep()
original = sweep["results"]["sam.gov"][0]
original["source_id"] = A
original["raw_payload"]["notice_id"] = A
original["api_url"] = f"https://sam.gov/opp/{A}/view"
original["raw_payload"].update(raw)
sweep["results"]["triage"][A] = sweep["results"]["triage"].pop("N1")
sweep["results"]["sam_census"]["attachment_record_receipts"] = stats["attachment_record_receipts"]
try:
    run, diagnostics, index = _build(sweep)
    parent = next(r for r in run.live.records if r.notice_id == A)
    dumped = run.model_dump(mode="json") if hasattr(run, "model_dump") else str(run)
    observed["S6_assess"] = {
        "classification": str(parent.classification),
        "is_bid_now": parent.classification == LiveClassification.BID_NOW,
        "requirement_reviewed_at": parent.requirement_reviewed_at,
        "attachment_gap": parent.attachment_gap,
        "attachments_checked": getattr(parent, "attachments_checked", None),
        "assess_run_mentions_inventory_url": contains(dumped, URL_A),
        "assess_run_mentions_served_host": contains(dumped, "attachments.example.net"),
        "assess_run_mentions_other_notice_text": FILE_TEXT[:30] in json.dumps(dumped, default=str),
    }
except Exception as exc:  # noqa: BLE001
    observed["S6_assess"] = {"error": f"{type(exc).__name__}: {str(exc)[:300]}"}

# ---- base 2d522f0 comparison -----------------------------------------------------------
spec = importlib.util.spec_from_file_location("base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "base_cache")
calls.clear()
binv = base.fetch_notice_resources(A)
observed["base_2d522f0"] = {
    "hops": [c["url"] for c in calls],
    "accepted_redirected_body": binv.get("resources_checked") is True,
    "attachment_count": binv.get("attachment_inventory_count"),
    "has_raw_capture": "raw_capture" in binv,
    "has_collection_status": "collection_status" in binv,
}

# ---- persistence path (static) -----------------------------------------------------------
src = (REPO / "run_searches.py").read_text()
observed["persistence_static"] = {
    "stats_merged_into_sam_census_box": "sam_census_box.update(c)" in src and "c.update(attachment_stats)" in src,
    "sam_census_saved_in_sweep": 'out["results"]["sam_census"] = dict(sam_census_box)' in src,
    "inventory_receipt_readers_outside_run_searches": [],
}
for path in (REPO / "agents").rglob("*.py"):
    if "inventory_receipt" in path.read_text():
        observed["persistence_static"]["inventory_receipt_readers_outside_run_searches"].append(str(path.relative_to(REPO)))
for path in (REPO / "tools").rglob("*.py"):
    if "inventory_receipt" in path.read_text():
        observed["persistence_static"]["inventory_receipt_readers_outside_run_searches"].append(str(path.relative_to(REPO)))
for path in (REPO / "ui").rglob("*.py"):
    if "inventory_receipt" in path.read_text():
        observed["persistence_static"]["inventory_receipt_readers_outside_run_searches"].append(str(path.relative_to(REPO)))

# ---- verdict --------------------------------------------------------------------------------
receipt_misrecorded = (observed["S1_adapter"]["raw_capture_source_url"] == URL_A
                       and not observed["S1_adapter"]["raw_capture_records_served_url"])
reaches_trusted = (observed["S6_assess"].get("is_bid_now") is True
                   or observed["S6_assess"].get("requirement_reviewed_at") is not None
                   or observed["S6_assess"].get("assess_run_mentions_inventory_url") is True)
misrecord_reaches_beyond_receipt = (observed["S3_candidate_row"]["row_mentions_inventory_receipt_url"]
                                    or observed["S4_dossier_context"]["context_mentions_inventory_url_or_served_host"]
                                    or observed["S5_triage_prefilter"]["prefilter_mentions_inventory_url"])
status = "FAIL" if receipt_misrecorded else "PASS"
print(json.dumps({
    "probe": "WNI-1 impact",
    "status": status,
    "meaning": ("FAIL = finder's mechanism reproduced (receipt names requested URL after redirect); "
                "the impact keys below say how far it travels"),
    "impact_summary": {
        "receipt_misrecorded": receipt_misrecorded,
        "misrecorded_url_reaches_row_dossier_or_triage": misrecord_reaches_beyond_receipt,
        "reaches_assess_approval": reaches_trusted,
        "wrong_notice_attribution_in_research": observed["S4_dossier_context"]["context_text_is_other_notice_text"],
        "wrong_notice_attribution_present_at_base": observed["base_2d522f0"]["accepted_redirected_body"],
        "confined_to": ["fetch_notice_resources return", "<id>.resources.json local cache",
                        "saved sweep results.sam_census.attachment_record_receipts[id].inventory_receipt"],
    },
    "observed": observed,
    "tmp_dir": str(TMP),
}, indent=2, sort_keys=True, default=str))
