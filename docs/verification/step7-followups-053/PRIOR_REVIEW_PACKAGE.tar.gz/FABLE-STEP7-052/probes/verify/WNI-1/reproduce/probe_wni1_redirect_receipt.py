"""Independent reproduction probe for WNI-1.

Claim under test: fetch_notice_resources records raw_capture.source_url from the
request template, never from response.url, and performs no final-host or
final-path check after redirects. A 302 from notice A's resources URL to a
different notice or a non-sam.gov host is followed and the id-less body is
captured as A's inventory with a receipt naming A's sam.gov URL.

No network: _client is replaced with a MockTransport client and socket.connect
is blocked. Cache dir is a probe-local temp dir.
"""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

REPO = "/Users/wtjohnson/lila-step7-052"
sys.path.insert(0, REPO)
HERE = Path(__file__).resolve().parent

TMP = tempfile.mkdtemp(prefix="wni1_", dir=str(HERE))
os.environ["LILA_NOTICE_CACHE_DIR"] = TMP

import httpx  # noqa: E402

import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as snd  # noqa: E402


def _blocked_connect(*_a, **_k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _blocked_connect  # type: ignore[assignment]

A = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
B = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
RES_ID = "cccccccccccccccccccccccccccccccc"
A_URL = snd.RESOURCES_URL_TPL.format(id=A)
B_SAME_HOST_URL = snd.RESOURCES_URL_TPL.format(id=B)
B_OFF_HOST_URL = f"https://attachments.example.net/opps/v3/opportunities/{B}/resources"

# Inventory body that names NO notice id in any checked key. Only the HAL
# self link names notice B, which the identity check does not read.
ID_LESS_BODY = {
    "_embedded": {
        "opportunityAttachmentList": [
            {
                "attachments": [
                    {
                        "name": "wrong_notice_sow.pdf",
                        "resourceId": RES_ID,
                        "mimeType": "application/pdf",
                        "accessLevel": "public",
                        "size": 1234,
                    }
                ]
            }
        ]
    },
    "_links": {"self": {"href": f"/opps/v3/opportunities/{B}/resources"}},
}


def make_handler(target: str, hops: list[str]):
    def handler(request: httpx.Request) -> httpx.Response:
        hops.append(str(request.url))
        if str(request.url) == A_URL:
            return httpx.Response(302, headers={"Location": target})
        if str(request.url) == target:
            return httpx.Response(
                200, json=ID_LESS_BODY,
                headers={"Content-Type": "application/hal+json"})
        return httpx.Response(404, json={"error": "unexpected url"})
    return handler


def install(handler):
    def _mock_client(timeout: float) -> httpx.Client:
        return httpx.Client(timeout=timeout,
                            transport=httpx.MockTransport(handler),
                            follow_redirects=True)
    _http._client = _mock_client


def observe_final_url(handler) -> dict:
    """What the response_observer could have seen: response.url and history."""
    install(handler)
    seen: dict = {}

    def obs(response, raw, complete):
        seen["final_url"] = str(response.url)
        seen["history"] = [f"{r.status_code} {r.url}" for r in getattr(response, "history", [])]
        seen["complete"] = complete
    _http.get_json(A_URL, timeout=5.0, headers=snd.RESOURCES_HEADERS, retries=1,
                   response_observer=obs, max_response_bytes=2 * 1024 * 1024)
    return seen


def run_case(name: str, target: str) -> dict:
    for p in Path(TMP).glob(f"{A}*"):
        p.unlink()
    hops: list[str] = []
    install(make_handler(target, hops))
    out = snd.fetch_notice_resources(A, timeout_seconds=5.0)
    cache_path = Path(TMP) / f"{A}.resources.json"
    rc = out.get("raw_capture") or {}
    seen = observe_final_url(make_handler(target, []))
    return {
        "case": name,
        "redirect_target": target,
        "hops": hops,
        "collection_status": out.get("collection_status"),
        "resources_checked": out.get("resources_checked"),
        "attachment_inventory_count": out.get("attachment_inventory_count"),
        "attachments": out.get("attachments"),
        "errors": out.get("errors"),
        "cache_written": cache_path.exists(),
        "raw_capture_source_url": rc.get("source_url"),
        "raw_capture_http_status": rc.get("http_status"),
        "raw_capture_complete": rc.get("complete"),
        "raw_capture_keys": sorted(rc.keys()),
        "observer_could_see_final_url": seen.get("final_url"),
        "observer_could_see_history": seen.get("history"),
        "receipt_source_url_equals_final_url": rc.get("source_url") == seen.get("final_url"),
        "receipt_names_requested_url": rc.get("source_url") == A_URL,
    }


def run_base(target: str) -> dict:
    """Base 2d522f0 behavior for the same redirect (no receipt existed then)."""
    for p in Path(TMP).glob(f"{A}*"):
        p.unlink()
    spec = importlib.util.spec_from_file_location(
        "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    hops: list[str] = []
    install(make_handler(target, hops))
    out = base.fetch_notice_resources(A, timeout_seconds=5.0)
    return {
        "hops": hops,
        "resources_checked": out.get("resources_checked"),
        "attachment_inventory_count": out.get("attachment_inventory_count"),
        "has_raw_capture": "raw_capture" in out,
        "has_collection_status": "collection_status" in out,
        "errors": out.get("errors"),
    }


def main() -> None:
    src = Path(REPO, "tools/api/sam_notice_detail.py").read_text()
    closure_start = src.index("def capture(response, raw, complete):")
    closure = src[closure_start: src.index("try:", closure_start)]
    static = {
        "closure_uses_response_url": "response.url" in closure,
        "closure_uses_template": "RESOURCES_URL_TPL.format(id=notice_id)" in closure,
        "module_mentions_response_url": "response.url" in src,
        "module_mentions_history": ".history" in src,
        "module_has_allowed_final_hosts": "_ALLOWED_FINAL_HOSTS" in src,
    }
    off_host = run_case("off_host_no_id_body", B_OFF_HOST_URL)
    same_host = run_case("same_host_other_notice_no_id_body", B_SAME_HOST_URL)
    base_off = run_base(B_OFF_HOST_URL)

    defect = (
        static["closure_uses_template"] and not static["closure_uses_response_url"]
        and off_host["collection_status"] == "inventory_captured"
        and off_host["receipt_names_requested_url"]
        and not off_host["receipt_source_url_equals_final_url"]
        and off_host["observer_could_see_final_url"] == B_OFF_HOST_URL
    )
    print(json.dumps({
        "probe": "WNI-1 independent reproduction",
        "status": "FAIL" if defect else "PASS",
        "meaning": ("FAIL = defect reproduced: redirected id-less body accepted "
                    "as A's inventory and receipt names the requested URL, not "
                    "the served URL" if defect else
                    "PASS = candidate refused or recorded the true origin"),
        "observed": {
            "static": static,
            "candidate": {"off_host": off_host, "same_host": same_host},
            "base_2d522f0_off_host": base_off,
            "download_bytes_has_final_host_check": "_ALLOWED_FINAL_HOSTS" in Path(
                REPO, "tools/api/sam_attachment_text.py").read_text(),
        },
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
