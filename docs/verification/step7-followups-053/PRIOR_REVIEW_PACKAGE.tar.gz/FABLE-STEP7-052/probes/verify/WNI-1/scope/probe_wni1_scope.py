"""WNI-1 scope/classification probe (independent refuter).

Question: is "raw_capture.source_url records the requested URL; no final-host
check after a redirect on the inventory lane" a NEW defect introduced by the
Step7 delta, or a pre-existing base (2d522f0) behavior that Step7 merely made
visible by adding a receipt field?

Checks (all offline, MockTransport, sockets blocked, probe-local cache dirs):
  1. Production redirect policy is identical at base and candidate
     (`_http._client` has follow_redirects=True in both).
  2. Same redirect scenarios against BASE and CANDIDATE fetch_notice_resources:
     id-less body (finder's accepted case), real HAL body naming B, real
     links-only body naming B, each reached via 302 from A (same host and off host).
  3. Field semantics: `_resource_capture_valid` binds `source_url` to the
     templated request URL for the cached id; a receipt written with the
     finder's recommended value (response.url) is rejected on cache reuse.
     The producer proof JSONs use the same convention (source_url = request
     URL, response identities carried separately).
  4. File lane `_download_bytes` final-host check exists at BASE and CANDIDATE
     (pre-existing), so redirected inventory rows still download by resource
     id from an approved host only.
  5. Where the inventory `raw_capture` travels (sweep inventory_receipt only;
     dossier consumes file-lane source_url, not inventory source_url).
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni1-", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "notice_cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text_cache")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "sam_calls.json")
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("probe attempted a real socket connect")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402

from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402
from tools.api import sam_attachment_text as cand_text  # noqa: E402

spec = importlib.util.spec_from_file_location("base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)

A, B = "a" * 32, "b" * 32
URL_A = cand.RESOURCES_URL_TPL.format(id=A)
URL_B = cand.RESOURCES_URL_TPL.format(id=B)
OFF_HOST_B = "https://attachments.example.net/opps/v3/opportunities/" + B + "/resources"


def row(resource_id=B, name="SOW.txt"):
    return {"resourceId": resource_id, "name": name, "mimeType": ".txt", "size": 10,
            "accessLevel": "public", "accessStatus": "public",
            "exportControlled": "0", "explicitAccess": "0"}


def hal_body(notice_id, rows):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_embedded": {"opportunityAttachmentList": [{"opportunityId": notice_id, "attachments": rows}]},
            "_links": {"self": {"href": href}}}


def links_only(notice_id):
    href = ("https://86samdotgovopportunitiesmodern.prod.apps-internal.prod-iae.bsp.gsa.gov"
            f"/opps/v3/opportunities/{notice_id}/resources?withScanResult=false&excludeDeleted=false")
    return {"_links": {"self": {"href": href}}}


def install(handler, follow):
    calls = []

    def logged(request):
        calls.append(str(request.url))
        return handler(request)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(logged), follow_redirects=follow)
    return calls


def redirect_handler(target, body):
    payload = json.dumps(body).encode()

    def handler(request):
        if str(request.url) == URL_A:
            return httpx.Response(302, headers={"Location": target})
        if str(request.url) == target:
            return httpx.Response(200, content=payload)
        return httpx.Response(404, content=b"unexpected")
    return handler


def fresh(label):
    p = TMP / f"cache_{label}"
    p.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p)
    return p


observed: dict = {}

# 1. production redirect policy at base vs candidate
base_http = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:tools/api/_http.py"],
                           capture_output=True, text=True, check=True).stdout
cand_http = (REPO / "tools/api/_http.py").read_text()
observed["redirect_policy"] = {
    "base_client_follow_redirects_true": "follow_redirects=True" in base_http,
    "candidate_client_follow_redirects_true": "follow_redirects=True" in cand_http,
    "base_inventory_lane_has_final_host_check": ("response.url" in
        subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_notice_detail.py"],
                       capture_output=True, text=True, check=True).stdout),
    "candidate_inventory_lane_has_final_host_check": "response.url" in (REPO / "tools/api/sam_notice_detail.py").read_text(),
}

# 2. redirect scenarios: base vs candidate
scenarios = {
    "idless_body_redirect_same_host": (URL_B, {"attachments": [row()]}),
    "idless_body_redirect_off_host": (OFF_HOST_B, {"attachments": [row(name="Offhost SOW.pdf")]}),
    "real_hal_body_B_redirect_same_host": (URL_B, hal_body(B, [row()])),
    "real_hal_body_B_redirect_off_host": (OFF_HOST_B, hal_body(B, [row()])),
    "real_links_only_B_redirect_same_host": (URL_B, links_only(B)),
}
observed["scenarios"] = {}
for name, (target, body) in scenarios.items():
    fresh("c_" + name)
    ccalls = install(redirect_handler(target, body), True)
    c = cand.fetch_notice_resources(A)
    cap = c.get("raw_capture") or {}
    fresh("b_" + name)
    bcalls = install(redirect_handler(target, body), True)
    b = base.fetch_notice_resources(A)
    observed["scenarios"][name] = {
        "final_url": ccalls[-1] if ccalls else None,
        "candidate": {"accepted": bool(c.get("resources_checked") and c.get("attachments")),
                      "collection_status": c.get("collection_status"),
                      "raw_capture_source_url": cap.get("source_url"),
                      "source_url_is_requested_url": cap.get("source_url") == URL_A},
        "base": {"accepted": bool(b.get("resources_checked") and b.get("attachments")),
                 "attachment_count": b.get("attachment_inventory_count"),
                 "hops": len(bcalls),
                 "has_raw_capture_field": "raw_capture" in b},
    }

# 3. field semantics: source_url is the templated request-URL binding key
fresh("semantics")
install(redirect_handler(URL_B, {"attachments": [row()]}), True)
c = cand.fetch_notice_resources(A)
cache_path = Path(os.environ["LILA_NOTICE_CACHE_DIR"]) / f"{A}.resources.json"
saved = json.loads(cache_path.read_text())
valid_as_written = cand._resource_capture_valid(json.loads(json.dumps(saved)))
alt = json.loads(json.dumps(saved))
alt["raw_capture"]["source_url"] = URL_B  # finder's recommended value (response.url)
valid_with_final_url = cand._resource_capture_valid(alt)
src = (REPO / "tools/api/sam_notice_detail.py").read_text()
proof_dir = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001")
proof_convention = []
for pj in sorted(proof_dir.glob("*.json"))[:21]:
    d = json.loads(pj.read_text())
    if not isinstance(d, dict) or "notice_id" not in d:
        continue
    proof_convention.append({
        "source_url_is_requested_template": d.get("source_url") == cand.RESOURCES_URL_TPL.format(id=d.get("notice_id")),
        "carries_response_notice_ids": "response_notice_ids" in d,
    })
observed["field_semantics"] = {
    "validator_binds_source_url_to_requested_template":
        'capture.get("source_url") != RESOURCES_URL_TPL.format(id=cached["id"])' in src,
    "cache_valid_as_written": valid_as_written,
    "cache_valid_if_source_url_were_final_url": valid_with_final_url,
    "producer_proof_bodies": len(proof_convention),
    "producer_proof_all_source_url_requested_template": all(p["source_url_is_requested_template"] for p in proof_convention),
    "producer_proof_all_carry_response_notice_ids": all(p["carries_response_notice_ids"] for p in proof_convention),
    "file_lane_source_url_also_templated_at_base": "RESOURCE_DOWNLOAD_URL_TPL.format(" in subprocess.run(
        ["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_attachment_text.py"],
        capture_output=True, text=True, check=True).stdout,
}

# 4. file lane final-host check at base and candidate (pre-existing)
base_text_src = subprocess.run(["git", "-C", str(REPO), "show", "2d522f0:tools/api/sam_attachment_text.py"],
                               capture_output=True, text=True, check=True).stdout
file_url = cand_text.RESOURCE_DOWNLOAD_URL_TPL.format(resource_id=B)
off_file = "https://attachments.example.net/files/" + B + "/download"


def file_handler(request):
    if str(request.url) == file_url:
        return httpx.Response(302, headers={"Location": off_file})
    if str(request.url) == off_file:
        return httpx.Response(200, content=b"hello", headers={"content-length": "5"})
    return httpx.Response(404)


real_client = httpx.Client


class PatchedClient(real_client):
    def __init__(self, *a, **k):
        k.pop("transport", None)
        super().__init__(*a, transport=httpx.MockTransport(file_handler), **k)


cand_text.httpx.Client = PatchedClient
try:
    cand_text._download_bytes(B)
    file_lane_refused = False
    file_lane_error = None
except Exception as exc:  # noqa: BLE001
    file_lane_refused = True
    file_lane_error = str(exc)[:120]
finally:
    cand_text.httpx.Client = real_client
observed["file_lane_final_host_check"] = {
    "base_has_ALLOWED_FINAL_HOSTS_and_response_url_check": ("_ALLOWED_FINAL_HOSTS" in base_text_src and "response.url" in base_text_src),
    "candidate_download_off_host_redirect_refused": file_lane_refused,
    "candidate_error": file_lane_error,
}

# 5. where inventory raw_capture travels
rs = (REPO / "run_searches.py").read_text()
dossier = (REPO / "agents/decisions/dossier.py").read_text()
observed["receipt_reach"] = {
    "run_searches_inventory_receipt_carries_raw_capture": bool(re.search(r'"inventory_receipt".*?"raw_capture"', rs, re.S)),
    "dossier_reads_inventory_raw_capture": "raw_capture" in dossier,
    "dossier_file_source_url_host_gate": 'host == "sam.gov" or host.endswith(".sam.gov")' in dossier,
}

# 6. disclosure search
docs = REPO / "docs/verification/step7-052"
hits = []
for p in list(docs.glob("*.md")) + list(docs.glob("*.json")) + [REPO / "docs/CONVENTIONS.md", REPO / "docs/CONTRACT_SURFACES.md"]:
    txt = p.read_text(errors="replace")
    for m in re.finditer(r"(?i)redirect|response\.url|final host|source_url", txt):
        hits.append({"file": p.name, "match": txt[max(0, m.start() - 60): m.end() + 60].replace("\n", " ")})
observed["disclosure_hits"] = hits[:10]

sc = observed["scenarios"]
pre_existing = (sc["idless_body_redirect_same_host"]["base"]["accepted"]
                and sc["idless_body_redirect_off_host"]["base"]["accepted"]
                and sc["idless_body_redirect_same_host"]["candidate"]["accepted"]
                and sc["idless_body_redirect_off_host"]["candidate"]["accepted"])
candidate_narrows = (sc["real_hal_body_B_redirect_same_host"]["base"]["accepted"]
                     and not sc["real_hal_body_B_redirect_same_host"]["candidate"]["accepted"]
                     and sc["real_hal_body_B_redirect_off_host"]["base"]["accepted"]
                     and not sc["real_hal_body_B_redirect_off_host"]["candidate"]["accepted"])
status = "PASS" if (pre_existing and candidate_narrows and observed["field_semantics"]["cache_valid_as_written"]
                    and not observed["field_semantics"]["cache_valid_if_source_url_were_final_url"]) else "FAIL"
print(json.dumps({
    "probe": "wni1_scope",
    "status": status,
    "verdict_support": {
        "idless_redirect_acceptance_pre_existing_at_base": pre_existing,
        "candidate_refuses_real_shape_redirects_base_accepted": candidate_narrows,
        "no_final_host_check_on_inventory_lane_pre_existing": (
            not observed["redirect_policy"]["base_inventory_lane_has_final_host_check"]
            and not observed["redirect_policy"]["candidate_inventory_lane_has_final_host_check"]),
        "source_url_is_request_locator_binding_key_by_design": (
            observed["field_semantics"]["validator_binds_source_url_to_requested_template"]
            and observed["field_semantics"]["producer_proof_all_source_url_requested_template"]),
        "redirect_not_disclosed_in_docs": not any("redirect" in h["match"].lower() for h in hits),
    },
    "observed": observed,
    "tmp_dir": str(TMP),
}, indent=2, sort_keys=True, default=str))
