"""BR-6 independent reproduction: failure-path objects without on-disk receipt, no GC.

Re-implemented from the finding text only (original probe not read first).
Offline: socket.connect blocked, _http._client mocked, _download_bytes patched.
Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
from pathlib import Path

PROBE_ROOT = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/verify/BR-6/reproduce")
WORK = Path(tempfile.mkdtemp(prefix="br6_", dir=str(PROBE_ROOT)))
NOTICE_DIR = WORK / "notice_cache"
TEXT_DIR = WORK / "text_cache"
os.environ["LILA_NOTICE_CACHE_DIR"] = str(NOTICE_DIR)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR)
sys.path.insert(0, "/Users/wtjohnson/lila-step7-052")


def _no_connect(*args, **kwargs):
    raise AssertionError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]
socket.socket.connect_ex = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402

import tools.api._http as http_mod  # noqa: E402
import tools.api.sam_attachment_text as sat  # noqa: E402
import tools.api.sam_notice_detail as snd  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402

N_BAD_JSON = "a" * 32
N_500 = "b" * 32
N_OVER_1 = "c" * 32
N_OVER_2 = "d" * 32
N_GOOD = "e" * 32
OVERSIZE_CAP = 2 * 1024 * 1024
CALLS: list[str] = []


def handler(request: httpx.Request) -> httpx.Response:
    CALLS.append(str(request.url))
    url = str(request.url)
    if N_BAD_JSON in url:
        return httpx.Response(200, content=b"<html>not json at all</html>")
    if N_500 in url:
        return httpx.Response(500, content=b'{"error":"server exploded"}')
    if N_OVER_1 in url:
        return httpx.Response(200, content=b"1" * (OVERSIZE_CAP + 4096))
    if N_OVER_2 in url:
        return httpx.Response(200, content=b"2" * (OVERSIZE_CAP + 4096))
    if N_GOOD in url:
        body = {"_embedded": {"opportunityAttachmentList": [
            {"attachments": [{"resourceId": "f" * 32, "name": "sow.pdf",
                              "mimeType": "application/pdf", "size": 10,
                              "accessLevel": "public"}]}]}}
        return httpx.Response(200, json=body)
    return httpx.Response(404, content=b"{}")


http_mod._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def objects_in(directory: Path) -> dict[str, int]:
    obj = directory / "objects"
    if not obj.exists():
        return {}
    return {p.name: p.stat().st_size for p in obj.iterdir() if p.is_file()}


def referenced_shas(directory: Path) -> set[str]:
    """Every sha256 named by any on-disk JSON receipt under the cache dir (recursive)."""
    found: set[str] = set()

    def walk(node):
        if isinstance(node, dict):
            sha = node.get("sha256")
            if isinstance(sha, str) and len(sha) == 64 and node.get("path", "").startswith("objects/"):
                found.add(sha)
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    for p in directory.rglob("*.json"):
        try:
            walk(json.loads(p.read_text()))
        except (ValueError, OSError):
            pass
    return found


observed: dict = {}

# 1. Inventory failure paths -------------------------------------------------
inv: dict[str, dict] = {}
for nid in (N_BAD_JSON, N_500, N_OVER_1, N_OVER_1, N_OVER_2, N_GOOD):
    out = snd.fetch_notice_resources(nid)
    inv.setdefault(nid, []).append({
        "collection_status": out.get("collection_status"),
        "raw_capture": {k: out.get("raw_capture", {}).get(k) for k in ("sha256", "bytes", "complete", "http_status")}
        if out.get("raw_capture") else None,
        "error": (out.get("errors") or [""])[0][:120],
        "cache_file_on_disk": (NOTICE_DIR / f"{nid}.resources.json").exists(),
    })
observed["inventory_attempts"] = inv
observed["http_calls_made"] = len(CALLS)

notice_objects = objects_in(NOTICE_DIR)
notice_refs = referenced_shas(NOTICE_DIR)
notice_orphans = sorted(name for name in notice_objects if name[:-4] not in notice_refs)
observed["notice_objects"] = notice_objects
observed["notice_disk_receipts"] = sorted(p.name for p in NOTICE_DIR.glob("*.json"))
observed["notice_orphan_objects_without_disk_receipt"] = notice_orphans
observed["notice_orphan_count"] = len(notice_orphans)
observed["notice_object_count"] = len(notice_objects)
observed["oversize_object_sizes"] = sorted(v for v in notice_objects.values() if v >= OVERSIZE_CAP)
observed["oversize_identical_body_deduped"] = (
    sum(1 for v in notice_objects.values() if v == OVERSIZE_CAP) == 2)

# 2. File path: unreadable after successful download ----------------------------
RID = "9" * 32
sat._download_bytes = lambda resource_id, *, deadline_monotonic=None: b"   \n\t  "  # whitespace only text
attachment = {"resource_id": RID, "name": "blank.txt", "type": "text/plain",
              "size": 7, "access_level": "public", "access_status": "public",
              "export_controlled": "0", "explicit_access": "0",
              "source_url": None}
file_out = sat.extract_public_attachment_text(attachment)
text_objects = objects_in(TEXT_DIR)
text_refs = referenced_shas(TEXT_DIR)
observed["file_attempt"] = {
    "collection_status": file_out.get("collection_status"),
    "error": file_out.get("error"),
    "raw_capture_sha": (file_out.get("raw_capture") or {}).get("sha256"),
    "cache_file_on_disk": (TEXT_DIR / f"{RID}.json").exists(),
    "text_dir_objects": text_objects,
    "text_dir_disk_receipts": sorted(p.name for p in TEXT_DIR.glob("*.json")),
    "orphan": sorted(n for n in text_objects if n[:-4] not in text_refs),
}

# 3. Temp litter from a killed process + absence of any reaper --------------------
obj_dir = NOTICE_DIR / "objects"
stray = obj_dir / "tmpkilled_process_leftover"
stray.write_bytes(b"partial write from a killed process")
retain_bytes(NOTICE_DIR, b"fresh payload after litter")
snd.fetch_notice_resources(N_GOOD)  # a cache hit path; should it sweep? measure
observed["temp_litter"] = {
    "stray_still_present_after_retain_and_fetch": stray.exists(),
    "objects_dir_listing": sorted(p.name for p in obj_dir.iterdir()),
}

# 4. Static check: no deletion of objects anywhere in the collection modules -------
import re  # noqa: E402

repo = Path("/Users/wtjohnson/lila-step7-052")
deleters = {}
for rel in ("tools/api/sam_capture.py", "tools/api/sam_notice_detail.py",
            "tools/api/sam_attachment_text.py", "run_searches.py", "tools/artifacts.py"):
    src = (repo / rel).read_text()
    hits = [ln.strip() for ln in src.splitlines()
            if re.search(r"unlink|rmtree|os\.remove|\.remove\(", ln)]
    deleters[rel] = hits
observed["deletion_sites"] = deleters
observed["only_deletions_are_own_temp_files"] = all(
    ("temporary.unlink" in h or "tmp.unlink" in h) for hs in deleters.values() for h in hs)

# Verdict ------------------------------------------------------------------------
reproduced = (
    observed["notice_orphan_count"] >= 3  # bad json, 500, oversize bodies
    and observed["file_attempt"]["collection_status"] == "unreadable"
    and observed["file_attempt"]["cache_file_on_disk"] is False
    and len(observed["file_attempt"]["orphan"]) == 1
    and observed["temp_litter"]["stray_still_present_after_retain_and_fetch"] is True
    and observed["only_deletions_are_own_temp_files"] is True
    and observed["oversize_object_sizes"] and all(s == OVERSIZE_CAP for s in observed["oversize_object_sizes"])
)
observed["reproduced_as_described"] = reproduced
observed["nuance"] = (
    "identical oversize bodies dedupe to one object (content-addressed); distinct bodies keep 2 MiB each"
)
print(json.dumps({"status": "INFO" if reproduced else "FAIL",
                  "finding": "BR-6",
                  "work_dir": str(WORK),
                  "observed": observed}, indent=2, sort_keys=True))
