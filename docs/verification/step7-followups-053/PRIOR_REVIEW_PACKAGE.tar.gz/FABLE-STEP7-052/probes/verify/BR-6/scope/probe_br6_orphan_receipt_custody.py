"""BR-6 refutation probe: failure-path objects, receipts, custody and GC.

Questions measured (no network, no LLM, probe-local temp dirs only):
  Q1  Candidate: do failed inventory attempts and unreadable files publish
      objects under objects/ that no cache file references?  (finder claim)
  Q2  Does the receipt for those objects reach the sweep-level receipts that
      run_searches writes to disk in the sweep artifact?  (title claim test)
  Q3  Base 2d522f0: what did the same failures leave on disk?  (pre_existing test)
  Q4  Is there any deletion / reaper of objects or tmp files in the delta?
  Q5  Is repeated identical failure content-addressed (no duplication) and is
      daily growth bounded by the stage caps?
  Q6  Do the producer docs disclose absent GC / orphan objects in so many words?
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import sys
import tempfile
import time
from pathlib import Path

SCOPE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

# Hard network block.
def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_quota  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402

observed: dict = {}
checks: dict = {}
root = Path(tempfile.mkdtemp(prefix="br6-", dir=SCOPE))
cand_notice = root / "cand_notice"
cand_text = root / "cand_text"
base_notice = root / "base_notice"
os.environ["LILA_NOTICE_CACHE_DIR"] = str(cand_notice)
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(cand_text)


def bind(handler):
    calls = []
    def wrapped(req):
        calls.append(str(req.url))
        return handler(req)
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(wrapped), follow_redirects=True)
    return calls


def listing(path: Path) -> list[str]:
    if not path.exists():
        return []
    return sorted(str(p.relative_to(path)) for p in path.rglob("*") if p.is_file())


def referenced_hashes(cache_dir: Path) -> set[str]:
    out = set()
    for p in cache_dir.glob("*.json"):
        try:
            data = json.loads(p.read_text())
        except Exception:  # noqa: BLE001
            continue
        for key in ("raw_capture", "text_capture"):
            cap = data.get(key)
            if isinstance(cap, dict) and cap.get("sha256"):
                out.add(cap["sha256"] + ".bin")
    return out


NOTICE = "a" * 32
RID = "b" * 32

# ---------------------------------------------------------------- Q1 candidate
bad_body = b'{"attachments": [ not json'
bind(lambda r: httpx.Response(200, content=bad_body))
inv_fail = detail.fetch_notice_resources(NOTICE)
big = b"x" * (3 * 1024 * 1024)
bind(lambda r: httpx.Response(200, content=big))
inv_big = detail.fetch_notice_resources(NOTICE)
sat._download_bytes = lambda resource_id, **k: b"%PDF-1.4 broken bytes"
sat._text_from_bytes = lambda *a, **k: (_ for _ in ()).throw(ValueError("unreadable pdf"))
attachment = {"resource_id": RID, "name": "sow.pdf", "type": "file",
              "source_url": "https://sam.gov/api/prod/opps/v3/opportunities/resources/files/" + RID + "/download",
              "size": 100, "access_level": "public", "access_status": "public"}
file_fail = sat.extract_public_attachment_text(attachment)

objs_notice = listing(cand_notice)
objs_text = listing(cand_text)
observed["q1_candidate"] = {
    "inventory_invalid_json": {"collection_status": inv_fail["collection_status"],
                                "raw_capture": inv_fail.get("raw_capture")},
    "inventory_oversize": {"collection_status": inv_big["collection_status"],
                            "raw_capture": inv_big.get("raw_capture"),
                            "errors": inv_big.get("errors")},
    "file_unreadable": {"collection_status": file_fail["collection_status"],
                         "raw_capture": file_fail.get("raw_capture"),
                         "error": file_fail.get("error")},
    "notice_dir_files": objs_notice, "text_dir_files": objs_text,
    "notice_cache_files": [f for f in objs_notice if f.endswith(".resources.json")],
    "text_cache_files": [f for f in objs_text if f.endswith(".json")],
}
orphans_notice = sorted(set(Path(f).name for f in objs_notice if f.startswith("objects/"))
                        - referenced_hashes(cand_notice))
orphans_text = sorted(set(Path(f).name for f in objs_text if f.startswith("objects/"))
                      - referenced_hashes(cand_text))
observed["q1_candidate"]["objects_unreferenced_by_any_cache_file"] = {
    "notice": orphans_notice, "text": orphans_text}
checks["q1_failure_objects_published_without_cache_reference"] = (
    len(orphans_notice) == 2 and len(orphans_text) == 1)
checks["q1_oversize_object_is_exactly_2MiB_and_marked_incomplete"] = (
    (inv_big.get("raw_capture") or {}).get("bytes") == 2 * 1024 * 1024
    and (inv_big.get("raw_capture") or {}).get("complete") is False)
checks["q1_no_cache_file_written_on_failure"] = (
    not observed["q1_candidate"]["notice_cache_files"]
    and not observed["q1_candidate"]["text_cache_files"])

# ---------------------------------------------------------------- Q2 sweep receipts
# Drive the production sweep enrichment with a stub source; the inventory fails
# with invalid JSON.  Does the object hash land in the stats the sweep persists?
import run_searches  # noqa: E402

class _Cand:
    def __init__(self, sid):
        self.source_id = sid
    def model_dump_json(self):
        return json.dumps({"source_id": self.source_id, "raw_payload": {}})

class _Source:
    last_attachment_census = {"stub": True}
    def attachment_candidates(self, query, taxonomy, engagement_scope, *, limit):
        return [_Cand(NOTICE)]

sam_quota.calls_today = lambda: 0
bind(lambda r: httpx.Response(200, content=bad_body))
rows, stats = run_searches._enrich_sam_public_attachments(
    [], _Source(), "q", None, None, limit=1)
receipt = stats["attachment_record_receipts"][NOTICE]
observed["q2_sweep_receipt_for_failed_inventory"] = receipt
inv_receipt = receipt.get("inventory_receipt") or {}
rc = inv_receipt.get("raw_capture") or {}
checks["q2_failed_inventory_object_referenced_by_sweep_receipt"] = (
    receipt.get("status") == "INVENTORY_UNAVAILABLE"
    and rc.get("sha256") == hashlib.sha256(bad_body).hexdigest()
    and rc.get("path") == f"objects/{rc.get('sha256')}.bin"
    and rc.get("sha256") + ".bin" in orphans_notice)

# Static confirmation that these stats reach the sweep artifact on disk.
src = (REPO / "run_searches.py").read_text()
persist_chain = {
    "c.update(attachment_stats)": "c.update(attachment_stats)" in src,
    "sam_census_box.update(c)": "sam_census_box.update(c)" in src,
    "atomic_write_json(path, out)": "atomic_write_json(path, out)" in src,
}
m = re.search(r'out\["results"\]\[["\']([a-z_]+)["\']\]\s*=\s*(?:dict\()?sam_census_box', src)
persist_chain["out_results_key_for_sam_census_box"] = m.group(1) if m else None
observed["q2_persistence_chain_in_run_searches"] = persist_chain
checks["q2_receipts_reach_sweep_artifact_on_disk"] = all(
    v for k, v in persist_chain.items() if k != "out_results_key_for_sam_census_box"
) and persist_chain["out_results_key_for_sam_census_box"] is not None

# ---------------------------------------------------------------- Q3 base 2d522f0
spec = importlib.util.spec_from_file_location("base_detail", SCOPE / "base_sam_notice_detail.py")
base_detail = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_detail)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(base_notice)
bind(lambda r: httpx.Response(200, content=bad_body))
try:
    base_res = base_detail.fetch_notice_resources(NOTICE)
    base_summary = {k: base_res.get(k) for k in ("resources_checked", "errors", "from_cache")}
except Exception as exc:  # noqa: BLE001
    base_summary = {"raised": repr(exc)}
bind(lambda r: httpx.Response(200, content=big))
try:
    base_big = base_detail.fetch_notice_resources(NOTICE)
    base_summary["oversize"] = {k: base_big.get(k) for k in ("resources_checked", "errors")}
except Exception as exc:  # noqa: BLE001
    base_summary["oversize"] = {"raised": repr(exc)}
observed["q3_base"] = {"result": base_summary, "files_on_disk": listing(base_notice),
                       "has_objects_dir": (base_notice / "objects").exists(),
                       "has_retain_bytes": hasattr(base_detail, "retain_bytes")
                       or "retain_bytes" in (SCOPE / "base_sam_notice_detail.py").read_text()}
checks["q3_base_left_nothing_on_disk_no_object_store"] = (
    observed["q3_base"]["files_on_disk"] == [] and not observed["q3_base"]["has_objects_dir"])
os.environ["LILA_NOTICE_CACHE_DIR"] = str(cand_notice)

# ---------------------------------------------------------------- Q4 deletion / reaper
deleters = {}
for rel in ("tools/api/sam_capture.py", "tools/api/sam_notice_detail.py",
            "tools/api/sam_attachment_text.py", "run_searches.py"):
    text = (REPO / rel).read_text()
    hits = [ln.strip() for ln in text.splitlines()
            if re.search(r"\b(unlink|os\.remove|rmtree|rmdir|reap|prune|garbage)\b", ln)]
    deleters[rel] = hits
observed["q4_deletion_sites"] = deleters
only_temp_unlink = (deleters["tools/api/sam_capture.py"] == ["temporary.unlink(missing_ok=True)"]
                    and all(not v for k, v in deleters.items() if k != "tools/api/sam_capture.py"
                            and "sam_capture" not in k))
checks["q4_no_reaper_only_own_temp_unlink"] = only_temp_unlink

# Stray temp from a killed writer stays in place across later retentions.
stray = cand_notice / "objects" / "tmpkilledwriter"
stray.write_bytes(b"half")
retain_bytes(cand_notice, b"another payload")
observed["q4_stray_temp_survives"] = stray.exists()
checks["q4_stray_temp_left_in_place"] = stray.exists()

# ---------------------------------------------------------------- Q5 dedupe + growth bound
before = len(listing(cand_notice / "objects"))
bind(lambda r: httpx.Response(200, content=bad_body))
for _ in range(5):
    detail.fetch_notice_resources(NOTICE)
bind(lambda r: httpx.Response(200, content=big))
for _ in range(5):
    detail.fetch_notice_resources(NOTICE)
after = len(listing(cand_notice / "objects"))
observed["q5_repeat_identical_failures"] = {"objects_before": before, "objects_after": after}
checks["q5_identical_failures_deduplicated"] = before == after
caps = {}
for name in ("_SAM_ATTACHMENT_CALL_HARD_CAP", "_SAM_ATTACHMENT_STAGE_HARD_SECONDS",
             "_SAM_ATTACHMENT_CANDIDATE_HARD_CAP"):
    caps[name] = getattr(run_searches, name, None)
caps["inventory_max_response_bytes"] = 2 * 1024 * 1024
caps["file_max_bytes_default"] = sat.MAX_ATTACHMENT_BYTES if hasattr(sat, "MAX_ATTACHMENT_BYTES") else None
observed["q5_growth_bounds"] = caps

# ---------------------------------------------------------------- Q6 disclosure wording
doc_hits = {}
pat = re.compile(r"garbage|reaper|orphan|unreferenced|delet|prune|tmp|temporary", re.I)
for p in sorted((REPO / "docs/verification/step7-052").glob("*.md")) + \
         sorted((REPO / "docs/verification/step7-052").glob("*.json")) + \
         [REPO / "docs/CONVENTIONS.md", REPO / "docs/CONTRACT_SURFACES.md"]:
    text = p.read_text(errors="replace")
    if p.name in ("CONVENTIONS.md", "CONTRACT_SURFACES.md"):
        idx = text.find("Step7")
        text = text[idx:] if idx >= 0 else ""
        # only the Step7 sections matter
        text = text[text.rfind("## Step7"):] if "## Step7" in text else text
    hits = [ln.strip()[:200] for ln in text.splitlines() if pat.search(ln)]
    if hits:
        doc_hits[str(p.relative_to(REPO))] = hits
observed["q6_doc_lines_mentioning_gc_or_orphans"] = doc_hits
conv = (REPO / "docs/CONVENTIONS.md").read_text()
observed["q6_closest_disclosure_sentences"] = [
    s.strip() for s in re.findall(
        r"[^.]*retain partial/error bodies separately[^.]*\.", conv)] + [
    s.strip() for s in re.findall(r"[^.]*internal custody[^.]*\.", conv)]
checks["q6_no_exact_sentence_discloses_absent_gc_or_orphan_objects"] = not any(
    re.search(r"garbage|reaper|orphan|unreferenced", " ".join(v), re.I)
    for v in doc_hits.values())

status = "PASS" if all(checks.values()) else "FAIL"
print(json.dumps({"probe": "br6_orphan_receipt_custody", "status": status,
                  "checks": checks, "observed": observed}, indent=2, sort_keys=True, default=str))
shutil.rmtree(root, ignore_errors=True)
