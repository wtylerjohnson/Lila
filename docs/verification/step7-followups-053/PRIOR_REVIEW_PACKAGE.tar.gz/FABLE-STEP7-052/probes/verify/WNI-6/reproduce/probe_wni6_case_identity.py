"""WNI-6 independent reproduction: uppercase requested notice id vs lowercase SAM body.

Claim under test: _PUBLIC_NOTICE_ID admits any case, but the identity comparison
is exact string equality, so an uppercase request against its own (lowercase)
body yields identity_mismatch. Also measures whether the behaviour exists at the
Step6 base (2d522f0), which had no identity check at all.

No network: socket.connect is blocked and tools.api._http._client is replaced by a
MockTransport that serves the 21 real captured bodies by the id in the URL path.
"""
from __future__ import annotations

import collections
import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
BODIES = REVIEW / "extracted/source-proof/public-inventory-001"
HERE = REVIEW / "probes/verify/WNI-6/reproduce"
REPO = Path("/Users/wtjohnson/lila-step7-052")

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
TMP = Path(tempfile.mkdtemp(prefix="wni6_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "cand")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
sys.path.insert(0, str(REPO))


def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

import httpx  # noqa: E402
import tools.api._http as _http  # noqa: E402
import tools.api.sam_notice_detail as detail  # noqa: E402

# Real bodies, keyed by lowercase id.
bodies: dict[str, bytes] = {}
for body in sorted(BODIES.glob("*.body")):
    bodies[body.stem.lower()] = body.read_bytes()

# Synthetic bodies (matrix) keyed by their requested URL id, exact case.
LOWER_ID = "abcdef0123456789abcdef0123456789"
UPPER_ID = LOWER_ID.upper()


def _synthetic(opp_id: str) -> bytes:
    return json.dumps({
        "_embedded": {"opportunityAttachmentList": [{
            "opportunityId": opp_id,
            "attachments": [{
                "resourceId": "r1", "name": "sow.pdf", "mimeType": "application/pdf",
                "accessLevel": "public", "size": 10,
            }],
        }]},
    }).encode()


synthetic: dict[str, bytes] = {}
ID_RE = re.compile(r"/opportunities/([0-9A-Za-z]{32})/resources")


def handler(request: httpx.Request) -> httpx.Response:
    m = ID_RE.search(str(request.url))
    rid = m.group(1) if m else ""
    if rid in synthetic:
        return httpx.Response(200, content=synthetic[rid],
                              headers={"content-type": "application/hal+json"})
    if rid.lower() in bodies:
        # SAM would serve the same notice regardless of the id case in the URL.
        return httpx.Response(200, content=bodies[rid.lower()],
                              headers={"content-type": "application/hal+json"})
    return httpx.Response(404, content=b"{}")


_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

observed: dict = {"body_count": len(bodies)}

# 1. Regex admission.
observed["regex_admits_upper"] = bool(detail._PUBLIC_NOTICE_ID.fullmatch(UPPER_ID))
observed["regex_flags_ignorecase"] = bool(detail._PUBLIC_NOTICE_ID.flags & re.IGNORECASE)

# 2. Are all real body ids and their embedded ids lowercase?
embedded_ids: set[str] = set()
for raw in bodies.values():
    stack = [json.loads(raw)]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            for key in ("opportunityId", "noticeId", "notice_id"):
                if isinstance(cur.get(key), str):
                    embedded_ids.add(cur[key])
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)
observed["all_body_file_ids_lowercase"] = all(k == k.lower() for k in bodies)
observed["embedded_id_count"] = len(embedded_ids)
observed["all_embedded_ids_lowercase"] = all(v == v.lower() for v in embedded_ids)

# 3. Real bodies: lowercase vs uppercase request on candidate.
tally_lower: collections.Counter = collections.Counter()
tally_upper: collections.Counter = collections.Counter()
per_notice = {}
for nid in sorted(bodies):
    lo = detail.fetch_notice_resources(nid)
    up = detail.fetch_notice_resources(nid.upper())
    tally_lower[lo["collection_status"]] += 1
    tally_upper[up["collection_status"]] += 1
    per_notice[nid] = {"lower": lo["collection_status"], "upper": up["collection_status"],
                       "lower_checked": lo["resources_checked"],
                       "upper_checked": up["resources_checked"]}
observed["tally_lower"] = dict(tally_lower)
observed["tally_upper"] = dict(tally_upper)
observed["per_notice"] = per_notice

# 4. Synthetic identity matrix on candidate.
matrix = {}
synthetic[UPPER_ID] = _synthetic(LOWER_ID)      # body lower, request upper
r = detail.fetch_notice_resources(UPPER_ID)
matrix["body_lower_request_upper"] = r["collection_status"]
synthetic.clear()
synthetic[LOWER_ID] = _synthetic(UPPER_ID)      # body upper, request lower
r = detail.fetch_notice_resources(LOWER_ID)
matrix["body_upper_request_lower"] = r["collection_status"]
synthetic.clear()
synthetic[LOWER_ID] = _synthetic(LOWER_ID)      # both lower (control)
r = detail.fetch_notice_resources(LOWER_ID)
matrix["body_lower_request_lower"] = r["collection_status"]
observed["candidate_matrix"] = matrix
observed["candidate_direct_identity_fn"] = {
    "lower_vs_upper": detail._resource_identity_matches({"opportunityId": LOWER_ID}, UPPER_ID),
    "lower_vs_lower": detail._resource_identity_matches({"opportunityId": LOWER_ID}, LOWER_ID),
}

# 5. Base (2d522f0) comparison: load the base file as a separate module.
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "base")
spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(base)
observed["base_has_identity_fn"] = hasattr(base, "_resource_identity_matches")
synthetic.clear()
synthetic[UPPER_ID] = _synthetic(LOWER_ID)
b = base.fetch_notice_resources(UPPER_ID)
observed["base_body_lower_request_upper"] = {
    "resources_checked": b.get("resources_checked"),
    "attachment_count": b.get("attachment_inventory_count"),
    "collection_status_key_present": "collection_status" in b,
    "errors": b.get("errors"),
}
synthetic.clear()
base_upper_checked = collections.Counter()
for nid in sorted(bodies):
    bu = base.fetch_notice_resources(nid.upper())
    base_upper_checked[bool(bu.get("resources_checked"))] += 1
observed["base_real_bodies_upper_resources_checked"] = {
    str(k): v for k, v in base_upper_checked.items()}
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "cand")

# Verdict logic.
claim_repro = (
    observed["regex_admits_upper"]
    and matrix["body_lower_request_upper"] == "identity_mismatch"
    and matrix["body_upper_request_lower"] == "identity_mismatch"
    and matrix["body_lower_request_lower"] == "inventory_captured"
    and tally_upper.get("identity_mismatch", 0) == tally_lower.get("inventory_captured", 0)
    + tally_lower.get("confirmed_empty", 0)
)
base_accepts_upper = (
    observed["base_body_lower_request_upper"]["resources_checked"] is True
    and not observed["base_has_identity_fn"]
)
observed["claim_reproduced"] = claim_repro
observed["base_accepts_upper_request"] = base_accepts_upper
observed["kind_measured"] = (
    "new_defect (identity check and identity_mismatch state do not exist at base; "
    "only the IGNORECASE regex is pre-existing)" if base_accepts_upper else "pre_existing")
status = "FAIL" if claim_repro else "PASS"
print(json.dumps({"status": status, "observed": observed}, indent=1, sort_keys=True))
