"""WNI-6 scope/classification probe.

Question: is the "uppercase requested id -> identity_mismatch" behaviour
pre_existing at base 2d522f0, or introduced by the Step7 delta?

Method: run the identical scenario (lowercase SAM HAL body, requested id in
UPPERCASE) through the BASE copy of sam_notice_detail (git show 2d522f0:...)
and through the candidate module. No network (sockets blocked, MockTransport).
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
TMP = Path(tempfile.mkdtemp(prefix="wni6-", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(TMP / "cache")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TMP / "text")
os.environ["LILA_SAM_LEDGER"] = str(TMP / "ledger.json")
os.environ.pop("SAM_GOV_API_KEY", None)
sys.path.insert(0, str(REPO))


def _refuse(*a, **k):
    raise RuntimeError("real socket connect attempted")


socket.socket.connect = _refuse  # type: ignore[assignment]
socket.socket.connect_ex = _refuse  # type: ignore[assignment]
socket.create_connection = _refuse  # type: ignore[assignment]

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as cand  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "base_sam_notice_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec)
sys.modules["base_sam_notice_detail"] = base
spec.loader.exec_module(base)

LOWER = "0caab6e53d8b47d7850692b7684610bf"
UPPER = LOWER.upper()
BODY = {
    "_embedded": {"opportunityAttachmentList": [{
        "opportunityId": LOWER,
        "attachments": [{"resourceId": "b" * 32, "name": "SOW.pdf",
                         "mimeType": "application/pdf", "size": 10,
                         "accessLevel": "public"}]}]},
    "_links": {"self": {"href": f"https://sam.gov/opps/v3/opportunities/{LOWER}/resources"}},
}
RAW = json.dumps(BODY).encode()

calls: list[str] = []


def mock():
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=RAW)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def fresh(label: str) -> Path:
    p = TMP / label
    p.mkdir(parents=True, exist_ok=True)
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(p)
    return p


def summarize(out: dict) -> dict:
    return {"collection_status": out.get("collection_status"),
            "resources_checked": out.get("resources_checked"),
            "attachment_inventory_count": out.get("attachment_inventory_count"),
            "from_cache": out.get("from_cache"),
            "returned_id": out.get("id"),
            "errors": out.get("errors")}


observed: dict = {}

# 1. Regex identical at base and candidate (the IGNORECASE admission is pre-existing).
observed["regex_base"] = {"pattern": base._PUBLIC_NOTICE_ID.pattern,
                          "ignorecase": bool(base._PUBLIC_NOTICE_ID.flags & re.IGNORECASE)}
observed["regex_candidate"] = {"pattern": cand._PUBLIC_NOTICE_ID.pattern,
                               "ignorecase": bool(cand._PUBLIC_NOTICE_ID.flags & re.IGNORECASE)}
observed["base_has_identity_check"] = hasattr(base, "_resource_identity_matches")
observed["candidate_has_identity_check"] = hasattr(cand, "_resource_identity_matches")

# 2. Uppercase request against a lowercase body, fresh cache, base vs candidate.
mock()
fresh("base_upper")
observed["base_upper_request"] = summarize(base.fetch_notice_resources(UPPER))
fresh("cand_upper")
observed["candidate_upper_request"] = summarize(cand.fetch_notice_resources(UPPER))
fresh("cand_lower")
observed["candidate_lower_request"] = summarize(cand.fetch_notice_resources(LOWER))

# 3. Base behaviour on a case-insensitive filesystem: after an uppercase request
#    writes a cache file, does a lowercase request read it back? (base only wrote
#    cache on success; candidate never writes for the uppercase path.)
p = fresh("base_case_fs")
base.fetch_notice_resources(UPPER)
files_after_upper = sorted(x.name for x in p.iterdir())
lower_hit = base.fetch_notice_resources(LOWER)
observed["base_cache_after_upper_then_lower"] = {
    "files": files_after_upper,
    "lower_request": summarize(lower_hit),
    "fs_case_insensitive": (p / f"{LOWER}.resources.json").exists()
    and (p / f"{UPPER}.resources.json").exists() and len(files_after_upper) == 1,
}
p = fresh("cand_case_fs")
cand.fetch_notice_resources(LOWER)
files_after_lower = sorted(x.name for x in p.iterdir())
upper_hit = cand.fetch_notice_resources(UPPER)
observed["candidate_cache_after_lower_then_upper"] = {
    "files": files_after_lower,
    "upper_request": summarize(upper_hit),
    "cache_file_rewritten_by_upper": sorted(x.name for x in p.iterdir()) != files_after_lower,
}

# 4. Exposure: the only production caller passes candidate.source_id, which
#    sam_gov.py builds from SAM's noticeId (or solicitationNumber) unchanged.
src = (REPO / "run_searches.py").read_text()
gov = (REPO / "tools/api/sam_gov.py").read_text()
observed["caller_passes_source_id"] = "fetch_notice_resources(\n                candidate.source_id" in src
observed["source_id_from_noticeId_unnormalized"] = (
    "source_id=notice.get(\"noticeId\")" in gov and ".lower()" not in gov.split("source_id=notice.get(\"noticeId\")")[0][-200:])
real_bodies = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001")
ids = [x.stem for x in real_bodies.glob("*.body")]
observed["real_body_ids"] = {"count": len(ids), "non_lowercase": [i for i in ids if i != i.lower()]}
observed["mock_calls"] = len(calls)

# Verdict logic
base_admits_upper_with_yield = (observed["base_upper_request"]["resources_checked"] is True
                                and observed["base_upper_request"]["attachment_inventory_count"] == 1)
cand_refuses_upper = observed["candidate_upper_request"]["collection_status"] == "identity_mismatch"
regex_preexisting = observed["regex_base"] == observed["regex_candidate"]

status = "FAIL" if (base_admits_upper_with_yield and cand_refuses_upper) else "INFO"
print(json.dumps({
    "probe": "wni6_scope",
    "status": status,
    "meaning": ("FAIL here means the finding's kind label is wrong: the identity_mismatch "
                "refusal of uppercase ids does NOT exist at base 2d522f0 (base returned a "
                "full inventory for the same request); the refusal is introduced by the "
                "Step7 delta. Only the IGNORECASE regex admission is pre-existing."),
    "base_admits_upper_with_yield": base_admits_upper_with_yield,
    "candidate_refuses_upper": cand_refuses_upper,
    "regex_preexisting_and_identical": regex_preexisting,
    "observed": observed,
    "tmp_dir": str(TMP),
}, indent=2, sort_keys=True, default=str))
