"""CT-4 independent reproduction: are inventory receipt fields rebound on cache hit?

Builds a legitimate two-file inventory cache through a MockTransport, forges the
receipt fields (collection_status, authority, resources_schema, errors) while
leaving raw bytes, projection, count and hash intact, then asks
fetch_notice_resources again. Also drives run_searches._enrich_sam_public_attachments
against the forged cache and checks what lands in inventory_receipt. Finally
repeats the resources_schema/errors forge against the BASE (2d522f0) module to
classify new vs pre-existing. No network: socket.connect is blocked.
"""
import importlib.util
import json
import os
import socket
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOTICE = "a" * 32
observed = {}
failures = []

def block_connect(*a, **k):
    raise AssertionError("network blocked")
socket.socket.connect = block_connect  # type: ignore[assignment]

tmp = Path(tempfile.mkdtemp(prefix="ct4_", dir=str(HERE)))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp / "inv")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp / "txt")

import httpx
from tools.api import _http
from tools.api import sam_notice_detail as detail

BODY = json.dumps({"_embedded": {"opportunityAttachmentList": [
    {"attachments": [
        {"name": "SOW.txt", "resourceId": "b" * 32, "accessLevel": "public", "mimeType": "text/plain"},
        {"name": "PWS.txt", "resourceId": "c" * 32, "accessLevel": "public", "mimeType": "text/plain"},
    ]}]}}).encode()

calls = []
def handler(request):
    calls.append(str(request.url))
    return httpx.Response(200, content=BODY, headers={"content-type": "application/hal+json"})
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

cache_path = tmp / "inv" / f"{NOTICE}.resources.json"

# A. legitimate capture
first = detail.fetch_notice_resources(NOTICE)
observed["first"] = {k: first.get(k) for k in ("from_cache", "collection_status", "authority",
                                                 "resources_schema", "errors", "attachment_inventory_count")}
if not (first["from_cache"] is False and first["collection_status"] == "inventory_captured"
        and first["attachment_inventory_count"] == 2 and len(calls) == 1):
    failures.append("legitimate capture did not behave as expected")

second = detail.fetch_notice_resources(NOTICE)
observed["second_from_cache"] = second.get("from_cache")
observed["http_calls_after_second"] = len(calls)
if not (second["from_cache"] is True and len(calls) == 1):
    failures.append("second call did not serve from cache")

pristine = json.loads(cache_path.read_text())

def forge(**fields):
    doc = json.loads(json.dumps(pristine))
    doc.update(fields)
    cache_path.write_text(json.dumps(doc))
    before = len(calls)
    res = detail.fetch_notice_resources(NOTICE)
    return {
        "from_cache": res.get("from_cache"),
        "stale_cache": res.get("stale_cache"),
        "http_calls_made": len(calls) - before,
        "returned": {k: res.get(k) for k in fields},
        "attachment_inventory_count": res.get("attachment_inventory_count"),
        "capture_valid": detail._resource_capture_valid(json.loads(cache_path.read_text())),
    }

cases = {
    "collection_status_confirmed_empty": {"collection_status": "confirmed_empty"},
    "collection_status_arbitrary": {"collection_status": "trusted_inventory"},
    "authority_trusted": {"authority": "trusted"},
    "resources_schema_forged": {"resources_schema": "recognized_v9"},
    "errors_injected": {"errors": ["injected: refresh failed; inventory unverified"]},
    "all_at_once": {"collection_status": "confirmed_empty", "authority": "trusted",
                    "resources_schema": "recognized_v9", "errors": ["injected"]},
}
served_forged = []
rejected = []
for name, fields in cases.items():
    res = forge(**fields)
    observed[f"case_{name}"] = res
    if res["from_cache"] is True and res["http_calls_made"] == 0 and res["returned"] == fields:
        served_forged.append(name)
    else:
        rejected.append(name)
observed["served_fresh_from_cache_with_forged_values"] = served_forged
observed["rejected_or_refetched"] = rejected

# Control: forging a BOUND field (attachments) must be rejected and refetched.
ctrl = forge(attachments=[{"name": "Invented"}])
observed["control_bound_field_attachments"] = ctrl
if ctrl["from_cache"] is not False or ctrl["http_calls_made"] != 1:
    failures.append("control: bound field tamper was not refetched")

# F. run_searches receipt propagation against the fully forged cache (real fetch_notice_resources)
doc = json.loads(json.dumps(pristine))
doc.update(cases["all_at_once"])
cache_path.write_text(json.dumps(doc))
import run_searches as searches
from tools.api import sam_quota, sam_attachment_text as sat
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
sam_quota.calls_today = lambda: 0
term = "network visibility"
texts = {"b" * 32: f"Buyer requires {term}.", "c" * 32: f"More {term} deliverables."}
sat._download_bytes = lambda rid, **k: texts[rid].encode()
candidate = RawOpportunity(source="sam.gov", source_id=NOTICE, title="Requirement",
                           agency="NASA", raw_payload={"type": "Solicitation"})
class Source:
    last_attachment_census = {"selected": 1}
    def attachment_candidates(self, *a, **k):
        return [candidate]
before = len(calls)
rows, stats = searches._enrich_sam_public_attachments(
    [], Source(), object(),
    CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                       core=[TaxonomyTerm(term=term)]), None, limit=8)
receipt = stats["attachment_record_receipts"][NOTICE]
observed["run_searches"] = {
    "http_calls_made": len(calls) - before,
    "record_status": receipt.get("status"),
    "inventory_count": receipt.get("inventory_count"),
    "inventory_receipt_collection_status": (receipt.get("inventory_receipt") or {}).get("collection_status"),
    "inventory_receipt_resources_schema": (receipt.get("inventory_receipt") or {}).get("resources_schema"),
    "record_errors": receipt.get("errors"),
    "file_statuses": {f.get("resource_id"): f.get("status") for f in receipt.get("files") or []},
    "rows_enriched": len(rows),
}
rs = observed["run_searches"]
if rs["inventory_receipt_collection_status"] != "confirmed_empty" or rs["inventory_receipt_resources_schema"] != "recognized_v9":
    failures.append("run_searches did not propagate the forged receipt fields (finding overstated)")
if rs["record_status"] != "INVENTORY_CHECKED" or rs["inventory_count"] != 2:
    failures.append("relevance path changed under forged receipt (finding understated)")

# G. BASE comparison: load 2d522f0 module and forge resources_schema/errors (base has no collection_status/authority)
spec = importlib.util.spec_from_file_location("base_detail", HERE / "base_sam_notice_detail.py")
base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp / "base_inv")
bcalls_before = len(calls)
b_first = base.fetch_notice_resources(NOTICE)
bpath = tmp / "base_inv" / f"{NOTICE}.resources.json"
bdoc = json.loads(bpath.read_text())
bdoc.update({"resources_schema": "recognized_v9", "errors": ["injected"], "collection_status": "confirmed_empty", "authority": "trusted"})
bpath.write_text(json.dumps(bdoc))
b_second = base.fetch_notice_resources(NOTICE)
observed["base_2d522f0"] = {
    "first_from_cache": b_first.get("from_cache"), "http_calls_total": len(calls) - bcalls_before,
    "forged_served_from_cache": b_second.get("from_cache"),
    "returned": {k: b_second.get(k) for k in ("resources_schema", "errors", "collection_status", "authority")},
    "has_capture_validator": hasattr(base, "_resource_capture_valid"),
    "base_emits_collection_status_or_authority": any(k in b_first for k in ("collection_status", "authority")),
}
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp / "inv")

status = "FAIL" if not failures and len(served_forged) == len(cases) else ("INFO" if not failures else "FAIL")
# FAIL here means: defect demonstrated (forged receipt fields served as fresh cache).
observed["probe_internal_inconsistencies"] = failures
print(json.dumps({"status": status, "meaning": "FAIL = forged receipt fields served from_cache without refetch",
                  "observed": observed}, indent=2, default=str))
