"""F-02 refuter probe (SCOPE and CLASSIFICATION lens).

Question: is the coherent text-cache rewrite / unauthenticated clock behaviour a
new defect, a pre-existing behaviour, a disclosed residual, or a doc overstatement?

Method: run the same tamper matrix against the candidate modules (review clone,
HEAD 67f644b, code 6b51f00) and against verbatim base copies (git show 2d522f0)
placed in ./base/. No network (socket.connect blocked, downloads monkeypatched,
HTTP via httpx.MockTransport). Writes only under this probe dir.
Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import socket
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))

# ---- hard network block -----------------------------------------------------
def _no_connect(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _no_connect  # type: ignore[assignment]

TEXT_DIR = Path(tempfile.mkdtemp(prefix="f02_text_", dir=str(HERE)))
INV_DIR = Path(tempfile.mkdtemp(prefix="f02_inv_", dir=str(HERE)))
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR / "cand")
os.environ["LILA_NOTICE_CACHE_DIR"] = str(INV_DIR / "cand")

from tools.api import _http  # noqa: E402
from tools.api import sam_attachment_text as sat  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import retain_bytes  # noqa: E402


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

base_sat = _load("base_sam_attachment_text", HERE / "base" / "sam_attachment_text_base.py")
base_detail = _load("base_sam_notice_detail", HERE / "base" / "sam_notice_detail_base.py")

RID = "b" * 32
NID = "a" * 32
ORIGINAL = b"Baseline notice text about network visibility monitoring."
INVENTED = "Invented requirement: vendor X is mandatory for network visibility."
observed: dict = {}
downloads: list[str] = []


def public_file(resource_id=RID, name="SOW.txt"):
    return {"resource_id": resource_id, "name": name, "access_level": "public",
            "access_status": "public", "export_controlled": "0", "explicit_access": "0"}


def dl_ok(*a, **k):
    downloads.append("download")
    return ORIGINAL


def dl_sentinel(*a, **k):
    downloads.append("download")
    raise RuntimeError("source unavailable (probe sentinel)")


def summarize(r: dict) -> dict:
    return {"from_cache": r.get("from_cache"), "collection_status": r.get("collection_status"),
            "text": (r.get("text") or "")[:80], "sha256": (r.get("sha256") or "")[:16],
            "error": (r.get("error") or "")[:80]}


# ============================ TEXT CACHE: CANDIDATE ============================
def cand_text_cases():
    out = {}
    cache_dir = Path(os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"])
    cache = cache_dir / f"{RID}.json"
    sat._download_bytes = dl_ok
    first = sat.extract_public_attachment_text(public_file())
    out["t1_populate"] = summarize(first)
    pristine = json.loads(cache.read_text())

    def write(rec):
        cache.write_text(json.dumps(rec))

    def coherent(rec, text=INVENTED, clock=None):
        rec = json.loads(json.dumps(rec))
        blob = text.encode("utf-8")
        rec["text"] = text
        rec["text_capture"] = retain_bytes(cache_dir, blob)
        rec["text_sha256"] = hashlib.sha256(blob).hexdigest()
        rec["text_locator"] = {"surface": "extracted_text", "unit": "unicode_characters",
                               "start": 0, "end": len(text)}
        if clock is not None:
            rec["retrieved_at"] = clock
        return rec

    # t2 coherent rewrite: text + text_sha256 + new object + locator, raw untouched
    sat._download_bytes = dl_sentinel
    write(coherent(pristine))
    downloads.clear()
    r = sat.extract_public_attachment_text(public_file())
    out["t2_coherent_rewrite"] = {**summarize(r), "download_attempted": bool(downloads),
                                  "raw_sha_still_original": r.get("sha256") == hashlib.sha256(ORIGINAL).hexdigest(),
                                  "served_invented": r.get("text") == INVENTED}

    # t3 control: text-only tamper (producer test case) refused
    rec = json.loads(json.dumps(pristine)); rec["text"] = INVENTED; write(rec)
    downloads.clear()
    r = sat.extract_public_attachment_text(public_file())
    out["t3_text_only_tamper_control"] = {**summarize(r), "download_attempted": bool(downloads)}

    # t4..t6 clock handling on a coherent record
    for label, clock in (("t4_clock_1970_aware", "1970-01-01T00:00:00+00:00"),
                         ("t5_clock_naive", "2026-01-01T00:00:00"),
                         ("t6_clock_future_aware", (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()),
                         ("t7_clock_garbage", "not a clock")):
        write(coherent(pristine, clock=clock))
        downloads.clear()
        r = sat.extract_public_attachment_text(public_file())
        out[label] = {**summarize(r), "download_attempted": bool(downloads)}

    # t8 name / extraction_limits are not in the binding (CT-5 shape)
    rec = json.loads(json.dumps(pristine)); rec["name"] = "Renamed.txt"
    rec["extraction_limits"] = {"completeness": "full_document"}; write(rec)
    r = sat.extract_public_attachment_text(public_file())
    out["t8_cache_name_and_limits_rewrite"] = {**summarize(r), "name": r.get("name"),
                                              "limits": r.get("extraction_limits")}
    write(pristine)
    return out


# ============================== TEXT CACHE: BASE ==============================
def base_text_cases():
    out = {}
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR / "base")
    cache_dir = Path(os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"])
    cache = cache_dir / f"{RID}.json"
    base_sat._download_bytes = dl_ok
    first = base_sat.extract_public_attachment_text(public_file())
    out["b1_populate"] = summarize(first)
    pristine = json.loads(cache.read_text())
    out["b1_base_record_keys"] = sorted(pristine.keys())
    base_sat._download_bytes = dl_sentinel

    def run(label, mutate):
        rec = json.loads(json.dumps(pristine)); mutate(rec); cache.write_text(json.dumps(rec))
        downloads.clear()
        r = base_sat.extract_public_attachment_text(public_file())
        out[label] = {**summarize(r), "download_attempted": bool(downloads),
                      "served_invented": r.get("text") == INVENTED}

    run("b2_text_only_tamper", lambda rec: rec.__setitem__("text", INVENTED))
    run("b3_clock_garbage", lambda rec: (rec.__setitem__("text", INVENTED), rec.__setitem__("retrieved_at", "not a clock")))
    run("b4_clock_future", lambda rec: rec.__setitem__("retrieved_at", "2999-01-01T00:00:00+00:00"))
    run("b5_wrong_resource_id_in_record", lambda rec: rec.__setitem__("resource_id", "e" * 32))
    run("b6_name_rewrite", lambda rec: rec.__setitem__("name", "Renamed.txt"))
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(TEXT_DIR / "cand")
    return out


# ========================== INVENTORY CACHE (both) ============================
BODY = json.dumps({"attachments": [
    {"name": "SOW.txt", "resourceId": "c" * 32, "mimeType": "text/plain", "size": 10, "accessLevel": "public"},
    {"name": "QA.txt", "resourceId": "d" * 32, "mimeType": "text/plain", "size": 12, "accessLevel": "public"},
]}).encode()


def http(payload: bytes, status: int = 200):
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(status, content=payload)
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
    return calls


def inv_cases(mod, tag: str, env_dir: Path):
    out = {}
    os.environ["LILA_NOTICE_CACHE_DIR"] = str(env_dir)
    cache = env_dir / f"{NID}.resources.json"
    calls = http(BODY)
    first = mod.fetch_notice_resources(NID)
    out["i1_populate"] = {"from_cache": first.get("from_cache"), "collection_status": first.get("collection_status"),
                          "count": first.get("attachment_inventory_count"), "http_calls": len(calls)}
    pristine = json.loads(cache.read_text())
    out["i1_record_keys"] = sorted(pristine.keys())

    def served(label, mutate, status=500):
        rec = json.loads(json.dumps(pristine)); mutate(rec); cache.write_text(json.dumps(rec))
        calls = http(b"boom", status)
        r = mod.fetch_notice_resources(NID)
        out[label] = {"from_cache": r.get("from_cache"), "stale_cache": r.get("stale_cache"),
                      "collection_status": r.get("collection_status"), "authority": r.get("authority"),
                      "resources_schema": r.get("resources_schema"),
                      "attachment_names": [a.get("name") for a in (r.get("attachments") or [])],
                      "http_calls": len(calls)}

    # receipt field forgery (CT-4 shape); relevance keys on attachments, receipt copies status
    served("i2_forge_receipt_fields", lambda rec: rec.update(
        collection_status="confirmed_empty", authority="trusted", resources_schema="recognized_v9"))
    # projection forgery: candidate re-derives from raw; base does not
    served("i3_forge_attachments_projection", lambda rec: rec.__setitem__("attachments", [{"name": "Invented SOW"}]))

    # clock: age the record past the 7 day stale ceiling, refetch fails
    def age(rec, days):
        stamp = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        if isinstance(rec.get("raw_capture"), dict):
            rec["raw_capture"]["received_at"] = stamp
        rec["retrieved_at"] = stamp
    served("i4_aged_10d_refetch_fails", lambda rec: age(rec, 10))
    served("i5_clock_rewritten_to_now", lambda rec: age(rec, 0))
    served("i6_future_clock", lambda rec: age(rec, -30))
    cache.write_text(json.dumps(pristine))
    return out


# =============================== DOC CHECKS ===================================
def doc_checks():
    conv = (REPO / "docs/CONVENTIONS.md").read_text()
    cs = (REPO / "docs/CONTRACT_SURFACES.md").read_text()
    review = (REPO / "docs/verification/step7-052/REVIEW.md").read_text()
    lv = json.loads((REPO / "docs/verification/step7-052/LOCAL_VERIFICATION.json").read_text())
    pf = (REPO / "docs/verification/step7-052/PRIOR_FOLLOWUPS.json").read_text()
    handoff = (REPO / "docs/verification/step7-052/FABLE_HANDOFF.md").read_text()
    sentences = {
        "conv_claim": "Successful caches\nbind the original resource metadata, raw bytes, text bytes and aware acquisition\nclock.",
        "conv_disclosure_same_section": "read-time hashes bind those bytes;\nthis is observed custody, not independent source truth.",
        "conv_changed_entries": "Legacy/unbound/changed cache entries require a new bounded attempt",
        "conv_checksum_not_authenticity": "a checksum does not attest their freshness or authenticity.",
        "cs_inventory_rebinds": "Current cache reuse rebinds the\noriginal response and projected inventory.",
        "cs_text_adds_binding": "adds raw/text capture\nlocators, resource-metadata binding, aware collection clock, parse limits and\nseparate states.",
        "review_no_fs_auth": "no continuous filesystem or government-source authentication",
        "handoff_custody": "Hash custody is not government-source\nauthentication or semantic truth.",
        "pf_later_writes": "No cloud-filesystem parity; later writes remain possible",
        "pf_observed_read": "Observed-read integrity only; no continuous immutability or cloud-filesystem parity.",
    }
    where = {"conv_claim": conv, "conv_disclosure_same_section": conv, "conv_changed_entries": conv,
             "conv_checksum_not_authenticity": conv, "cs_inventory_rebinds": cs, "cs_text_adds_binding": cs,
             "review_no_fs_auth": review, "handoff_custody": handoff, "pf_later_writes": pf, "pf_observed_read": pf}
    found = {k: (v in where[k]) for k, v in sentences.items()}
    found["lv_residual_custody_not_truth"] = any("Hashes establish byte custody, not truth." in s for s in lv.get("residuals", []))
    # is the disclosure in the SAME CONVENTIONS section as the claim?
    sec_start = conv.index("## Step7 decision-changing collection (052)")
    sec_end = conv.find("\n## ", sec_start + 10)
    section = conv[sec_start: sec_end if sec_end > 0 else None]
    found["disclosure_and_claim_share_section"] = (
        "observed custody, not independent source truth" in section and "Successful caches" in section)
    found["default_text_cache_dir"] = str(sat._DEFAULT_CACHE)
    found["default_cache_inside_repo_tree"] = str(sat._DEFAULT_CACHE).startswith(str(REPO))
    return found


def main() -> int:
    try:
        observed["candidate_text"] = cand_text_cases()
        observed["base_text"] = base_text_cases()
        observed["candidate_inventory"] = inv_cases(detail, "cand", INV_DIR / "cand")
        observed["base_inventory"] = inv_cases(base_detail, "base", INV_DIR / "base")
        observed["docs"] = doc_checks()
    finally:
        shutil.rmtree(TEXT_DIR, ignore_errors=True)
        shutil.rmtree(INV_DIR, ignore_errors=True)

    ct = observed["candidate_text"]; bt = observed["base_text"]
    ci = observed["candidate_inventory"]; bi = observed["base_inventory"]
    d = observed["docs"]
    verdict = {
        "coherent_rewrite_served_by_candidate": ct["t2_coherent_rewrite"]["served_invented"] is True
            and ct["t2_coherent_rewrite"]["from_cache"] is True,
        "text_only_tamper_refused_by_candidate": ct["t3_text_only_tamper_control"]["from_cache"] is False,
        "base_served_text_only_tamper_blindly": bt["b2_text_only_tamper"]["served_invented"] is True,
        "base_served_garbage_clock": bt["b3_clock_garbage"]["from_cache"] is True,
        "candidate_refuses_naive_future_garbage_clock": all(
            ct[k]["from_cache"] is False for k in ("t5_clock_naive", "t6_clock_future_aware", "t7_clock_garbage")),
        "candidate_accepts_past_aware_clock": ct["t4_clock_1970_aware"]["from_cache"] is True,
        # forged projection must not be served FRESH; the disclosed stale path (stale_cache True,
        # collection_status stale_inventory, excluded from relevance) is allowed after a failed refetch
        "candidate_rederives_inventory_projection": (
            ci["i3_forge_attachments_projection"]["http_calls"] == 1
            and (ci["i3_forge_attachments_projection"]["from_cache"] is False
                 or ci["i3_forge_attachments_projection"]["stale_cache"] is True)),
        "base_served_forged_inventory_projection": bi["i3_forge_attachments_projection"]["from_cache"] is True,
        "inventory_clock_rewrite_revives_stale_in_both": (
            ci["i5_clock_rewritten_to_now"]["from_cache"] is True and bi["i5_clock_rewritten_to_now"]["from_cache"] is True),
        "candidate_serves_forged_receipt_fields": ci["i2_forge_receipt_fields"]["collection_status"] == "confirmed_empty",
        "all_disclosure_sentences_present": all(v is True for k, v in d.items() if k not in (
            "default_text_cache_dir", "default_cache_inside_repo_tree")),
    }
    candidate_tamper_surface_subset_of_base = (
        verdict["text_only_tamper_refused_by_candidate"] and verdict["base_served_text_only_tamper_blindly"]
        and verdict["candidate_refuses_naive_future_garbage_clock"] and verdict["base_served_garbage_clock"]
        and verdict["candidate_rederives_inventory_projection"] and verdict["base_served_forged_inventory_projection"])
    verdict["candidate_accepts_strict_subset_of_base_tampers"] = candidate_tamper_surface_subset_of_base
    status = "INFO" if (verdict["coherent_rewrite_served_by_candidate"]
                        and candidate_tamper_surface_subset_of_base
                        and verdict["all_disclosure_sentences_present"]) else "FAIL"
    print(json.dumps({"probe": "F-02 scope/classification", "status": status,
                      "verdict_support": verdict, "observed": observed}, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
