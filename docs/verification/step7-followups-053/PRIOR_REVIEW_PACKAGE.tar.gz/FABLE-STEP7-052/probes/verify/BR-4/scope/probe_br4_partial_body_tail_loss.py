"""BR-4 refutation probe: does a mid-body transport error lose the unflushed 64 KiB tail?

Stance: try to refute. Measures
  A. the exact doc sentence exists (CONVENTIONS.md);
  B. the streaming capture path is absent at base 2d522f0 (pre_existing check);
  C. production reproduction through fetch_notice_resources (34-byte and 70000-byte partials);
  D. library-level isolation: iter_bytes(65536) vs iter_bytes() on the same broken stream;
  E. counterfactual: the finder's recommended one-token fix applied to an in-memory copy of
     tools/api/_http.py, checked against the partial case AND the existing cap cases;
  F. gzip nuance for the recommendation (decoder-level buffering, not chunker-level);
  G. real captured inventory body sizes from the source proof (premise check);
  H. harness: the producer's partial test uses a Response with _content, which bypasses ByteChunker.
Writes only under this probe directory. No network (socket connect blocked). No LLM calls.
"""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import types
from pathlib import Path

PROBE_DIR = Path(__file__).resolve().parent
REPO = Path("/Users/wtjohnson/lila-step7-052")
REVIEW = Path("/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052")
sys.path.insert(0, str(REPO))

# Hard network block.
def _blocked(*a, **k):
    raise RuntimeError("network blocked by probe")
socket.socket.connect = _blocked
socket.socket.connect_ex = _blocked
socket.create_connection = _blocked
time.sleep = lambda s: None

import httpx  # noqa: E402
from tools.api import _http  # noqa: E402
from tools.api import sam_notice_detail as detail  # noqa: E402
from tools.api.sam_capture import read_retained  # noqa: E402

observed: dict = {}
checks: dict = {}

tmp_root = Path(tempfile.mkdtemp(prefix="br4-", dir=PROBE_DIR))
os.environ["LILA_NOTICE_CACHE_DIR"] = str(tmp_root / "notice")
os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = str(tmp_root / "text")
cache_dir = tmp_root / "notice"
NOTICE = "b" * 32

SMALL = b'{"attachments": [{"name": "partial'   # 34 bytes
assert len(SMALL) == 34
LARGE = b"y" * 70000


def broken_stream(payload: bytes):
    class Broken(httpx.SyncByteStream):
        def __iter__(self):
            yield payload
            raise httpx.ReadError("connection reset mid-body")
        def close(self):
            pass
    return Broken()


def bind(handler, module=_http):
    module._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)


# A. Doc sentence.
conv = (REPO / "docs/CONVENTIONS.md").read_text()
sentence = "retain partial/error bodies separately from complete recognized responses"
observed["doc_sentence_present"] = sentence in conv
checks["A_doc_sentence_present"] = sentence in conv
observed["doc_sentence_line"] = next(
    (i + 1 for i, line in enumerate(conv.splitlines()) if sentence in line), None)

# B. Base file lacks the streaming capture path.
base_http = subprocess.run(
    ["git", "-C", str(REPO), "show", "2d522f0:tools/api/_http.py"],
    check=True, capture_output=True, text=True).stdout
observed["base_has_max_response_bytes"] = "max_response_bytes" in base_http
observed["base_has_iter_bytes_65536"] = "iter_bytes(65536)" in base_http
checks["B_capture_path_is_step7_new"] = (
    "max_response_bytes" not in base_http and "iter_bytes(65536)" not in base_http)
cand_http = (REPO / "tools/api/_http.py").read_text()
checks["B_candidate_uses_iter_bytes_65536"] = "streamed.iter_bytes(65536)" in cand_http

# C. Production reproduction.
def prod(payload: bytes, label: str):
    bind(lambda request: httpx.Response(200, stream=broken_stream(payload)))
    res = detail.fetch_notice_resources(NOTICE)
    rc = res.get("raw_capture")
    observed[label] = {
        "collection_status": res["collection_status"],
        "errors": res["errors"],
        "received_before_reset": len(payload),
        "retained_bytes": rc["bytes"] if rc else None,
        "complete": rc["complete"] if rc else None,
        "retained_equals_received": (read_retained(cache_dir, rc) == payload) if rc else None,
        "cache_file_written": (cache_dir / f"{NOTICE}.resources.json").exists(),
    }
    return res, rc

res_s, rc_s = prod(SMALL, "C_prod_small_34")
checks["C_small_status_lookup_failed"] = res_s["collection_status"] == "lookup_failed"
checks["C_small_complete_false"] = rc_s is not None and rc_s["complete"] is False
checks["C_small_retains_received_bytes"] = rc_s is not None and rc_s["bytes"] == 34

res_l, rc_l = prod(LARGE, "C_prod_large_70000")
checks["C_large_retains_received_bytes"] = rc_l is not None and rc_l["bytes"] == 70000
observed["C_large_retained_is_whole_64k_multiple"] = (
    rc_l is not None and rc_l["bytes"] % 65536 == 0 and rc_l["bytes"] == 65536)

# D. Library isolation on the same stream, both chunk sizes.
def stream_capture(chunk_size, payload):
    client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, stream=broken_stream(payload))))
    got = bytearray()
    err = None
    with client.stream("GET", "https://sam.gov/x") as s:
        try:
            for chunk in (s.iter_bytes(chunk_size) if chunk_size else s.iter_bytes()):
                got.extend(chunk)
        except httpx.ReadError as exc:
            err = type(exc).__name__
    return {"captured": len(got), "error": err}

observed["D_iter_bytes_65536_small"] = stream_capture(65536, SMALL)
observed["D_iter_bytes_none_small"] = stream_capture(None, SMALL)
observed["D_iter_bytes_65536_large"] = stream_capture(65536, LARGE)
observed["D_iter_bytes_none_large"] = stream_capture(None, LARGE)
checks["D_chunker_buffers_small_tail"] = observed["D_iter_bytes_65536_small"]["captured"] == 0
checks["D_unbuffered_yields_small"] = observed["D_iter_bytes_none_small"]["captured"] == 34
checks["D_chunker_yields_only_64k_multiple"] = observed["D_iter_bytes_65536_large"]["captured"] == 65536
checks["D_unbuffered_yields_large"] = observed["D_iter_bytes_none_large"]["captured"] == 70000

# E. Counterfactual: apply the recommended fix to an in-memory copy and re-run partial + cap cases.
patched_src = cand_http.replace("streamed.iter_bytes(65536)", "streamed.iter_bytes()")
assert patched_src != cand_http
spec = importlib.util.spec_from_loader("_http_patched", loader=None)
patched = importlib.util.module_from_spec(spec)
patched.__file__ = "<in-memory patched copy of tools/api/_http.py>"
exec(compile(patched_src, patched.__file__, "exec"), patched.__dict__)

def run_module(module, handler, retries=1, cap=2 * 1024 * 1024):
    bind(handler, module)
    seen = []
    err = None
    payload = None
    try:
        payload = module.get_json("https://sam.gov/x", retries=retries, max_response_bytes=cap,
                                  response_observer=lambda r, raw, c: seen.append((r.status_code, len(raw), c, hashlib.sha256(raw).hexdigest()[:12])))
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    return {"observer": seen, "error": err, "payload_ok": payload is not None}

big = b"x" * (2 * 1024 * 1024 + 1)
exact = b'{"attachments": []}' + b" " * (2 * 1024 * 1024 - 19)
cases = {
    "small_partial": lambda request: httpx.Response(200, stream=broken_stream(SMALL)),
    "large_partial": lambda request: httpx.Response(200, stream=broken_stream(LARGE)),
    "oversize_streamed": lambda request: httpx.Response(200, stream=httpx.ByteStream(big)),
    "exact_cap_streamed": lambda request: httpx.Response(200, stream=httpx.ByteStream(exact)),
    "http_500": lambda request: httpx.Response(500, content=b"error body for 500"),
}
observed["E_candidate"] = {k: run_module(_http, h) for k, h in cases.items()}
observed["E_patched"] = {k: run_module(patched, h) for k, h in cases.items()}
E_c, E_p = observed["E_candidate"], observed["E_patched"]
checks["E_candidate_small_partial_retains_0"] = E_c["small_partial"]["observer"][0][1] == 0
checks["E_patched_small_partial_retains_34"] = E_p["small_partial"]["observer"][0][1] == 34 and E_p["small_partial"]["observer"][0][2] is False
checks["E_patched_large_partial_retains_70000"] = E_p["large_partial"]["observer"][0][1] == 70000
checks["E_patched_oversize_still_capped_2MiB_incomplete"] = (
    E_p["oversize_streamed"]["observer"][0][1] == 2 * 1024 * 1024
    and E_p["oversize_streamed"]["observer"][0][2] is False
    and "byte boundary" in (E_p["oversize_streamed"]["error"] or ""))
checks["E_patched_exact_cap_complete"] = (
    E_p["exact_cap_streamed"]["observer"][0][1] == 2 * 1024 * 1024
    and E_p["exact_cap_streamed"]["observer"][0][2] is True and E_p["exact_cap_streamed"]["payload_ok"])
checks["E_patched_matches_candidate_on_cap_and_error_cases"] = all(
    E_c[k] == E_p[k] for k in ("oversize_streamed", "exact_cap_streamed", "http_500"))

# F. gzip nuance: with Content-Encoding gzip, chunk_size None still depends on the zlib decoder.
gz = gzip.compress(SMALL)
def gz_partial_stream(cut: int):
    class GZBroken(httpx.SyncByteStream):
        def __iter__(self):
            yield gz[:cut]
            raise httpx.ReadError("reset inside gzip body")
        def close(self):
            pass
    return GZBroken()

def gz_capture(chunk_size, cut):
    client = httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, headers={"content-encoding": "gzip"}, stream=gz_partial_stream(cut))))
    got = bytearray()
    with client.stream("GET", "https://sam.gov/x") as s:
        try:
            for chunk in (s.iter_bytes(chunk_size) if chunk_size else s.iter_bytes()):
                got.extend(chunk)
        except httpx.ReadError:
            pass
    return len(got)

observed["F_gzip_total_compressed_bytes"] = len(gz)
observed["F_gzip_cut_before_trailer"] = {
    "iter_bytes_65536": gz_capture(65536, len(gz) - 8),
    "iter_bytes_none": gz_capture(None, len(gz) - 8)}
observed["F_gzip_cut_mid_deflate"] = {
    "iter_bytes_65536": gz_capture(65536, 20),
    "iter_bytes_none": gz_capture(None, 20)}

# G. Premise: real captured inventory body sizes (source proof, public-inventory-001).
inv_dir = REVIEW / "extracted/source-proof/public-inventory-001"
sizes = sorted(p.stat().st_size for p in inv_dir.glob("*.json")
               if p.name not in {"RESULTS.json", "ATTEMPT_PLAN.json"})
observed["G_inventory_body_sizes"] = {"count": len(sizes), "min": sizes[0] if sizes else None,
                                      "max": sizes[-1] if sizes else None,
                                      "all_under_65536": all(s < 65536 for s in sizes)}
checks["G_all_real_inventories_under_one_chunk"] = bool(sizes) and all(s < 65536 for s in sizes)

# H. Harness: producer test path bypasses ByteChunker because Response(content=...) sets _content.
r = httpx.Response(200, content=b"0123456789")
observed["H_producer_test_response_has_content_attr"] = hasattr(r, "_content")
observed["H_producer_test_iter_bytes_65536_chunks"] = [len(c) for c in r.iter_bytes(65536)]
test_src = (REPO / "tests/test_step7_evidence_collection.py").read_text()
observed["H_suite_has_ReadError_or_SyncByteStream"] = ("ReadError" in test_src) or ("SyncByteStream" in test_src)
checks["H_suite_never_exercises_streaming_chunker"] = (
    hasattr(r, "_content") and not observed["H_suite_has_ReadError_or_SyncByteStream"])

# Disclosure search in producer docs.
disclosure_hits = []
for p in (REPO / "docs/verification/step7-052").glob("*"):
    if p.suffix in {".md", ".json"}:
        text = p.read_text(errors="replace").lower()
        for needle in ("65536", "64 kib", "64kib", "chunk", "bytechunker", "unflushed", "transport error", "mid-body"):
            if needle in text:
                disclosure_hits.append(f"{p.name}:{needle}")
observed["disclosure_hits_in_producer_docs"] = disclosure_hits
checks["not_disclosed_by_producer"] = not disclosure_hits

# Verdict: FAIL means the finding's defect/overstatement is demonstrated.
# Expected-to-be-false checks under the finding: C_small_retains_received_bytes,
# C_large_retains_received_bytes, E_candidate would retain; those are the demonstration.
demonstrated = (
    not checks["C_small_retains_received_bytes"]
    and not checks["C_large_retains_received_bytes"]
    and checks["D_chunker_buffers_small_tail"]
    and checks["D_unbuffered_yields_small"]
    and checks["E_patched_small_partial_retains_34"]
    and checks["E_patched_matches_candidate_on_cap_and_error_cases"]
    and checks["B_capture_path_is_step7_new"]
    and checks["A_doc_sentence_present"])
status = "FAIL" if demonstrated else "PASS"
print(json.dumps({"probe": "br4_partial_body_tail_loss", "status": status,
                  "observed": observed, "checks": checks}, indent=2, sort_keys=True, default=str))
shutil.rmtree(tmp_root, ignore_errors=True)
