"""BR-4 independent reproduction: does a mid-body transport error lose the
unflushed iter_bytes(65536) tail in tools.api._http._request capture mode?

Probe design (written before reading the original probe script):
  * MockTransport returns a streaming 200 response whose byte stream yields
    N bytes and then raises httpx.ReadError (connection dropped mid-body).
  * Observe what response_observer receives (raw bytes, complete flag).
  * Cases: 34 bytes, 65535, 65536, 70000, 131072+10.
  * Counterfactual: same streams iterated with iter_bytes() (chunk_size None)
    to see whether the finder's recommended fix would retain the tail.
  * End to end: fetch_notice_resources with LILA_NOTICE_CACHE_DIR set to a
    temp dir; check collection_status and raw_capture bytes on disk.
No network (socket.connect blocked). No LLM calls.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/wtjohnson/lila-step7-052")
sys.path.insert(0, str(REPO))
os.chdir(REPO)

import httpx  # noqa: E402


def _no_connect(*a, **k):
    raise AssertionError("network blocked by probe")


socket.socket.connect = _no_connect  # type: ignore[assignment]

from tools.api import _http  # noqa: E402

observed: dict = {}
status = "PASS"
notes: list[str] = []


class DroppingStream(httpx.SyncByteStream):
    """Yield `body` in `piece` sized raw chunks, then raise ReadError."""

    def __init__(self, body: bytes, piece: int = 1024):
        self.body = body
        self.piece = piece

    def __iter__(self):
        for i in range(0, len(self.body), self.piece):
            yield self.body[i:i + self.piece]
        raise httpx.ReadError("connection dropped mid-body")

    def close(self):
        pass


def make_client_factory(body: bytes):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, headers={"content-type": "application/json"},
                              stream=DroppingStream(body), request=request)

    return lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))


def run_case(n: int) -> dict:
    body = (b"x" * n)
    _http._client = make_client_factory(body)
    seen: list = []

    def obs(response, raw, complete):
        seen.append({"retained": len(raw), "complete": complete,
                     "http_status": response.status_code})

    exc_name = None
    try:
        _http.get_json("https://sam.gov/probe", retries=1,
                       max_response_bytes=2 * 1024 * 1024, response_observer=obs)
    except Exception as exc:  # noqa: BLE001
        exc_name = type(exc).__name__
    return {"received_before_drop": n, "observer_calls": seen, "exception": exc_name}


def counterfactual(n: int) -> dict:
    """Iterate the same dropping stream with iter_bytes() (no chunk size)."""
    body = b"x" * n
    client = make_client_factory(body)(30.0)
    captured = bytearray()
    exc_name = None
    try:
        with client.stream("GET", "https://sam.gov/probe") as streamed:
            try:
                for chunk in streamed.iter_bytes():
                    captured.extend(chunk)
            except Exception as exc:  # noqa: BLE001
                exc_name = type(exc).__name__
    except Exception as exc:  # noqa: BLE001
        exc_name = exc_name or type(exc).__name__
    return {"received_before_drop": n, "retained_with_iter_bytes_none": len(captured),
            "exception": exc_name}


cases = [34, 65535, 65536, 70000, 131072 + 10]
observed["capture_mode_cases"] = [run_case(n) for n in cases]
observed["counterfactual_iter_bytes_none"] = [counterfactual(n) for n in cases]

# Expected under the finding: retained == (n // 65536) * 65536 for every case.
finding_holds = True
for c in observed["capture_mode_cases"]:
    n = c["received_before_drop"]
    calls = c["observer_calls"]
    if len(calls) != 1:
        finding_holds = False
        notes.append(f"case {n}: observer called {len(calls)} times, expected 1")
        continue
    got = calls[0]["retained"]
    exp = (n // 65536) * 65536
    if got != exp or calls[0]["complete"] is not False:
        finding_holds = False
        notes.append(f"case {n}: retained {got} complete {calls[0]['complete']}, expected {exp} / False")
observed["finding_prediction_matches_all_cases"] = finding_holds

cf_ok = all(c["retained_with_iter_bytes_none"] == c["received_before_drop"]
            for c in observed["counterfactual_iter_bytes_none"])
observed["counterfactual_retains_every_byte"] = cf_ok

# End to end through fetch_notice_resources with a probe-local cache dir.
tmp = tempfile.mkdtemp(prefix="br4_cache_", dir="/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/probes/verify/BR-4/reproduce")
os.environ["LILA_NOTICE_CACHE_DIR"] = tmp
from tools.api import sam_notice_detail as snd  # noqa: E402

e2e = {}
for n, nid in ((34, "a" * 32), (70000, "b" * 32)):
    # a real-looking prefix of an inventory body so the small case is realistic
    body = (b'{"_embedded":{"opportunityAttachmentList":[{"attachments":[' + b"x" * n)[:n]
    _http._client = make_client_factory(body)
    result = snd.fetch_notice_resources(nid, timeout_seconds=5.0)
    rc = result.get("raw_capture") or {}
    obj = Path(tmp) / rc.get("path", "missing") if rc else None
    e2e[f"n={n}"] = {
        "collection_status": result.get("collection_status"),
        "raw_capture_present": bool(rc),
        "raw_capture_bytes": rc.get("bytes"),
        "raw_capture_complete": rc.get("complete"),
        "object_on_disk_bytes": (obj.stat().st_size if obj and obj.exists() else None),
        "errors": result.get("errors"),
        "cache_file_written": (Path(tmp) / f"{nid}.resources.json").exists(),
    }
observed["end_to_end_fetch_notice_resources"] = e2e

# Doc claim under test
doc = (REPO / "docs/CONVENTIONS.md").read_text()
observed["doc_claim_present"] = "retain partial/error bodies separately from complete recognized responses" in doc

# Verdict logic: PASS = candidate behaved as claimed (partial bodies retained).
# FAIL = the tail is lost as the finding says (doc claim overstated).
if finding_holds and observed["doc_claim_present"]:
    status = "FAIL"
    notes.append("mid-body drop retains only whole 64 KiB multiples; 34-byte body retains 0 bytes; doc says partial bodies are retained")
elif not finding_holds:
    status = "PASS"
    notes.append("finding prediction did not match; candidate retained partial bytes")
else:
    status = "INFO"

print(json.dumps({"status": status, "observed": observed, "notes": notes,
                  "httpx_version": httpx.__version__}, indent=2, default=str))
