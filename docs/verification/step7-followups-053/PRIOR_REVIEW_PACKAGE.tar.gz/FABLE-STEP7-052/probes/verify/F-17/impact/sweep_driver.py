"""F-17 impact driver: one synthetic attachment sweep on the base or candidate stack.

Runs the real run_searches._enrich_sam_public_attachments with only the network
and quota seams replaced. The base variant loads the 2d522f0 copies of
run_searches, sam_notice_detail, sam_attachment_text and _http from base_stack/
under their production module names, so every other module (relevance engine,
schemas, quota) resolves from the review clone. Prints one JSON object.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import socket
import sys
import time

CLONE = "/Users/wtjohnson/lila-step7-052"
HERE = os.path.dirname(os.path.abspath(__file__))
BASE_STACK = os.path.join(HERE, "base_stack")
HEX = "0123456789abcdef"


def nid(n: int) -> str:
    return (HEX[n % 16] * 30 + f"{n:02d}")[:32]


def rid(n: int) -> str:
    return "e" * 29 + f"{n:03d}"


def body(notice_id: str, attachments: list[dict]) -> bytes:
    payload = {"_embedded": {"opportunityAttachmentList": [
        {"opportunityId": notice_id, "attachments": attachments}]},
        "_links": {"self": {"href": f"https://sam.gov/api/prod/opps/v3/opportunities/{notice_id}/resources"}}}
    return json.dumps(payload).encode()


def att(resource_id: str, name: str, size: int = 4321) -> dict:
    return {"attachmentId": "2" * 32, "resourceId": resource_id, "name": name,
            "type": "file", "accessLevel": "public", "exportControlled": "0",
            "explicitAccess": "0", "mimeType": os.path.splitext(name)[1],
            "size": size, "accessStatus": "public"}


RELEVANT = "The Government requires network visibility across all enclaves. Deliverables due monthly."
IRRELEVANT = "Janitorial services for the building lobby and grounds, five days a week."
LONG = ("Network visibility statement of work. " * 2000)  # about 78000 chars, capped to 50000


def scenario():
    """Six attachment candidates plus two description-matched census rows."""
    ids, inv, dl = [], {}, {}
    # C1: relevant only through two attachment files
    n = nid(1); ids.append(n)
    inv[n] = body(n, [att(rid(11), "SOW.txt"), att(rid(12), "PWS.txt")])
    dl[rid(11)] = RELEVANT.encode(); dl[rid(12)] = ("Part two. " + RELEVANT).encode()
    # C2: relevant through one long file (exercises the text cap)
    n = nid(2); ids.append(n)
    inv[n] = body(n, [att(rid(21), "requirements.md", size=80000)])
    dl[rid(21)] = LONG.encode()
    # C3: irrelevant attachment
    n = nid(3); ids.append(n)
    inv[n] = body(n, [att(rid(31), "SOW.txt")])
    dl[rid(31)] = IRRELEVANT.encode()
    # C4: confirmed empty inventory
    n = nid(4); ids.append(n)
    inv[n] = json.dumps({"_embedded": {"opportunityAttachmentList": []}}).encode()
    # C5: already description-matched census row AND relevant attachment
    n = nid(5); ids.append(n)
    inv[n] = body(n, [att(rid(51), "SOW.txt")])
    dl[rid(51)] = RELEVANT.encode()
    # C6: four public files, only three fetched, third relevant
    n = nid(6); ids.append(n)
    inv[n] = body(n, [att(rid(61), "a.txt"), att(rid(62), "b.txt"),
                      att(rid(63), "c.txt"), att(rid(64), "d.txt")])
    for k in (61, 62, 63, 64):
        dl[rid(k)] = (RELEVANT if k == 63 else IRRELEVANT).encode()
    return ids, inv, dl


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", choices=("base", "candidate"), required=True)
    ap.add_argument("--notice-cache", required=True)
    ap.add_argument("--text-cache", required=True)
    ap.add_argument("--network", choices=("ok", "fail", "inventory-only"), default="ok")
    ap.add_argument("--stage-seconds", default=None)
    ap.add_argument("--text-chars", default=None)
    ap.add_argument("--inv-delay", type=float, default=0.0)
    ap.add_argument("--dl-delay", type=float, default=0.0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    os.environ["LILA_NOTICE_CACHE_DIR"] = args.notice_cache
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = args.text_cache
    os.environ["LILA_SAM_LEDGER"] = os.path.join(HERE, "tmp", "sam_calls_ledger.json")
    for key, value in (("LILA_SAM_ATTACHMENT_STAGE_SECONDS", args.stage_seconds),
                       ("LILA_SAM_ATTACHMENT_TEXT_CHARS", args.text_chars)):
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = str(value)

    def no_connect(*a, **k):
        raise AssertionError("real socket connect attempted")
    socket.socket.connect = no_connect  # type: ignore[assignment]

    sys.path.insert(0, CLONE)
    os.chdir(CLONE)
    import tools.api  # noqa: F401  (clone package; base files are registered under it)

    if args.variant == "base":
        for dotted, rel in (("tools.api._http", "tools/api/_http.py"),
                            ("tools.api.sam_notice_detail", "tools/api/sam_notice_detail.py"),
                            ("tools.api.sam_attachment_text", "tools/api/sam_attachment_text.py"),
                            ("run_searches", "run_searches.py")):
            spec = importlib.util.spec_from_file_location(dotted, os.path.join(BASE_STACK, rel))
            module = importlib.util.module_from_spec(spec)
            sys.modules[dotted] = module
            spec.loader.exec_module(module)
            if dotted.startswith("tools.api."):
                setattr(sys.modules["tools.api"], dotted.rsplit(".", 1)[1], module)

    import httpx
    from tools.api import sam_quota
    import tools.api._http  # noqa: F401
    import tools.api.sam_attachment_text  # noqa: F401
    import tools.api.sam_notice_detail  # noqa: F401
    import run_searches as searches
    # Patch the modules the stack under test actually imports (sys.modules entries).
    _http = sys.modules["tools.api._http"]
    sat = sys.modules["tools.api.sam_attachment_text"]
    detail = sys.modules["tools.api.sam_notice_detail"]
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    ids, inventories, downloads = scenario()
    inv_calls: list[str] = []
    dl_calls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        inv_calls.append(url)
        if args.inv_delay:
            time.sleep(args.inv_delay)
        if args.network == "fail":
            raise httpx.ConnectError("network down", request=request)
        notice_id = url.rstrip("/").split("/")[-2]
        payload = inventories.get(notice_id)
        if payload is None:
            return httpx.Response(404, content=b"{}", request=request)
        return httpx.Response(200, content=payload, request=request)

    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))

    def fake_download(resource_id, *, deadline_monotonic=None):
        dl_calls.append(resource_id)
        if args.dl_delay:
            time.sleep(args.dl_delay)
        if args.network in ("fail", "inventory-only"):
            raise RuntimeError("download network down")
        payload = downloads.get(resource_id)
        if payload is None:
            raise RuntimeError("unknown resource")
        return payload
    sat._download_bytes = fake_download
    sam_quota.calls_today = lambda: 0

    def raw_row(n: str, title: str) -> dict:
        return {"type": "Solicitation", "active": "Yes", "agency": "DHS",
                "notice_id": n, "description_snippet": title}

    candidates = [RawOpportunity(source="sam.gov", source_id=n, title=f"Requirement {n[-2:]}",
                                 agency="Department of Homeland Security / CISA",
                                 raw_payload=raw_row(n, f"Requirement {n[-2:]}"))
                  for n in ids]
    # description-matched census rows: C5 (also a candidate) and X9 (not a candidate)
    census = [json.loads(c.model_dump_json()) for c in candidates if c.source_id == nid(5)]
    census.append(json.loads(RawOpportunity(
        source="sam.gov", source_id=nid(9), title="Packet capture platform",
        agency="Department of Homeland Security / CISA",
        raw_payload=raw_row(nid(9), "Packet capture platform")).model_dump_json()))

    class Source:
        last_attachment_census = {"selected": len(candidates)}

        def attachment_candidates(self, *a, **k):
            return list(candidates)

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1, updated="2026-07-21",
                                  core=[TaxonomyTerm(term="network visibility")])
    t0 = time.monotonic()
    rows, stats = searches._enrich_sam_public_attachments(
        list(census), Source(), object(), taxonomy, None, limit=12)
    wall = round(time.monotonic() - t0, 4)

    receipts = {}
    for cid, rec in (stats.get("attachment_record_receipts") or {}).items():
        view = {"status": rec.get("status"), "errors": rec.get("errors")}
        if "files" in rec:
            view["files"] = {f["resource_id"][-3:]: [f.get("status"), f.get("reason")] for f in rec["files"]}
        if "inventory_receipt" in rec:
            ir = rec["inventory_receipt"] or {}
            view["inventory_collection_status"] = ir.get("collection_status")
            view["refresh_attempt_status"] = (ir.get("refresh_attempt") or {}).get("collection_status")
        receipts[cid[-2:]] = view
    result = {
        "variant": args.variant, "network": args.network,
        "module_files": {"run_searches": searches.__file__, "detail": detail.__file__,
                         "sat": sat.__file__, "_http": _http.__file__},
        "rows": rows,
        "row_ids": sorted(r["source_id"][-2:] for r in rows),
        "attachment_relevant_ids": sorted(
            r["source_id"][-2:] for r in rows
            if ((r.get("raw_payload") or {}).get("attachment_relevance") or {}).get("relevant")),
        "census_ids": sorted(r["source_id"][-2:] for r in census),
        "stats": {k: v for k, v in stats.items() if k != "attachment_record_receipts"},
        "receipts": receipts,
        "inventory_calls": len(inv_calls),
        "download_calls": len(dl_calls),
        "wall_seconds": wall,
    }
    with open(args.out, "w") as handle:
        json.dump(result, handle, indent=1, sort_keys=True, default=str)
    print(json.dumps({"ok": True, "rows": len(rows), "wall": wall}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
