"""Independent reproduction probe for merged finding F-17 (members YU-1, YU-2, YU-5, YU-6).

Claims under test (from the finding text only; member scripts were not consulted
before this script was written):
  C1  Legacy caches written by the BASE stack (no raw_capture / no binding) are
      rejected by the CANDIDATE validators, so the first candidate sweep
      refetches every cached inventory and every cached file (storm), while
      the base rerun spends zero calls.
  C2  The storm is one-time: a second candidate sweep spends zero calls.
  C3  If the keyless inventory endpoint fails during that first sweep while
      the legacy inventories are inside the 6 h TTL, every candidate receipt is
      STALE_INVENTORY and the sweep yields zero attachment rows, where the base
      served every cached relevant row with zero calls.
  C4  If inventories come back but downloads fail, every legacy text cache is
      invalidated (TEXT_UNAVAILABLE) and the yield is zero rows.
  C5  A slow source plus a small stage budget turns the storm into
      NOT_ATTEMPTED candidates and a STALE_INVENTORY fallback whose error names
      the new 'capture time boundary'; the base serves the same caches in ms.
  C6  Lowering LILA_SAM_ATTACHMENT_TEXT_CHARS invalidates cached text longer
      than the new cap (second storm); raising it does not re-extract.
  C7  Cache-hit revalidation is more expensive than base but immaterial.

Every scenario runs in a child process (this file re-executes itself) so the
base and candidate stacks never share sys.modules. No network: socket.connect
is blocked, tools.api._http._client is a MockTransport, and
sam_attachment_text._download_bytes is an in-process stub.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

CLONE = "/Users/wtjohnson/lila-step7-052"
HERE = os.path.dirname(os.path.abspath(__file__))
BASE_STACK = os.path.join(HERE, "base_stack")
PY = os.path.join(CLONE, ".venv", "bin", "python")
TERM = "network visibility"
N_CANDIDATES = 6
RELEVANT = {4, 5, 6}


def nid(i: int) -> str:
    return hashlib.md5(f"notice-{i}".encode()).hexdigest()


def rid(i: int) -> str:
    return hashlib.md5(f"resource-{i}".encode()).hexdigest()


def file_text(i: int, long: bool) -> str:
    if i in RELEVANT:
        body = (f"Buyer requires {TERM}. The {TERM} platform must deliver "
                f"{TERM} across the enterprise network.")
    else:
        body = "Janitorial services for building 4. Floor wax and trash removal."
    if long and i in RELEVANT:
        # only the relevant files are padded (about 45k chars); the others
        # stay short so a cap decrease can be tested against both lengths
        body = body + " " + ("padding words " * 3300)
    return body


# ----------------------------------------------------------------------------
# child side
# ----------------------------------------------------------------------------

def _install_base_stack():
    import importlib.util
    import tools.api  # noqa: F401  candidate package object, submodules swapped

    def load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        parent, _, child = name.rpartition(".")
        if parent:
            setattr(sys.modules[parent], child, module)
        return module

    load("tools.api._http", os.path.join(BASE_STACK, "tools", "api", "_http.py"))
    load("tools.api.sam_notice_detail",
         os.path.join(BASE_STACK, "tools", "api", "sam_notice_detail.py"))
    load("tools.api.sam_attachment_text",
         os.path.join(BASE_STACK, "tools", "api", "sam_attachment_text.py"))
    load("run_searches", os.path.join(BASE_STACK, "run_searches.py"))


def child(stack: str, scenario: str, workdir: str, opts: dict) -> dict:
    import socket

    def _no_connect(*a, **k):
        raise RuntimeError("network blocked by probe")
    socket.socket.connect = _no_connect  # type: ignore[assignment]

    sys.path.insert(0, CLONE)
    os.chdir(CLONE)
    os.environ["LILA_NOTICE_CACHE_DIR"] = os.path.join(workdir, "notice")
    os.environ["LILA_SAM_ATTACHMENT_TEXT_DIR"] = os.path.join(workdir, "text")
    if stack == "base":
        _install_base_stack()
    import httpx
    import run_searches as searches
    from tools.api import _http
    from tools.api import sam_attachment_text as sat
    from tools.api import sam_notice_detail as detail
    from tools.api import sam_quota
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

    inv_mode = opts.get("inventory", "ok")      # ok | fail | slow
    dl_mode = opts.get("download", "ok")        # ok | fail | slow
    latency = float(opts.get("latency", 0.3))
    long_text = bool(opts.get("long_text", False))

    inventory_calls: list[str] = []
    download_calls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        inventory_calls.append(str(request.url))
        if inv_mode == "fail":
            return httpx.Response(503, content=b"upstream unavailable")
        if inv_mode == "slow":
            time.sleep(latency)
        notice_id = str(request.url).rsplit("/", 2)[-2]
        index = next(i for i in range(1, N_CANDIDATES + 1) if nid(i) == notice_id)
        payload = {"attachments": [{
            "name": f"SOW {index}.txt", "resourceId": rid(index),
            "accessLevel": "public", "size": 1000}]}
        return httpx.Response(200, content=json.dumps(payload).encode(),
                              headers={"content-type": "application/hal+json"})

    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), timeout=timeout)

    def download(resource_id, **kw):
        download_calls.append(resource_id)
        if dl_mode == "fail":
            raise RuntimeError("download source unavailable")
        if dl_mode == "slow":
            time.sleep(latency)
        index = next(i for i in range(1, N_CANDIDATES + 1) if rid(i) == resource_id)
        return file_text(index, long_text).encode("utf-8")

    sat._download_bytes = download
    sam_quota.calls_today = lambda: 0

    candidates = [RawOpportunity(source="sam.gov", source_id=nid(i),
                                 title=f"Requirement {i}", agency="NASA",
                                 raw_payload={"type": "Solicitation"})
                  for i in range(1, N_CANDIDATES + 1)]

    class Source:
        last_attachment_census = {"selected": N_CANDIDATES}

        def attachment_candidates(self, *a, **k):
            return list(candidates)

    taxonomy = CapabilityTaxonomy(client_name="Testco", version=1,
                                  updated="2026-07-21",
                                  core=[TaxonomyTerm(term=TERM)])
    pre: dict = {}
    # direct validator observations on the LEGACY cache files BEFORE the
    # candidate sweep rewrites them
    if stack == "cand" and opts.get("inspect_validators"):
        cache = detail._cache_dir() / f"{nid(1)}.resources.json"
        legacy = json.loads(cache.read_text())
        pre["legacy_inventory_keys"] = sorted(legacy.keys())
        pre["legacy_inventory_has_raw_capture"] = "raw_capture" in legacy
        pre["legacy_inventory_fresh"] = detail._resource_cache_fresh(legacy)
        pre["legacy_resource_capture_valid"] = detail._resource_capture_valid(legacy)
        tcache = sat._cache_dir() / f"{rid(1)}.json"
        tlegacy = json.loads(tcache.read_text())
        pre["legacy_text_keys"] = sorted(tlegacy.keys())
        pre["legacy_text_capture_valid"] = sat._text_capture_valid(
            tlegacy, rid(1), "any-binding")
    started = time.monotonic()
    rows, stats = searches._enrich_sam_public_attachments(
        [], Source(), object(), taxonomy, None, limit=8)
    wall = time.monotonic() - started
    receipts = stats.get("attachment_record_receipts", {})
    label = {nid(i): f"{i:02d}" for i in range(1, N_CANDIDATES + 1)}
    statuses = {label[k]: v.get("status") for k, v in receipts.items()}
    out = {
        "stack": stack, "scenario": scenario,
        "inventory_calls": len(inventory_calls),
        "download_calls": len(download_calls),
        "rows": sorted(label[str(r.get("source_id"))] for r in rows),
        "statuses": statuses,
        "errors": stats.get("attachment_errors", [])[:10],
        "wall_seconds": round(wall, 4),
        **pre,
    }
    if stack == "cand" and opts.get("inspect_validators"):
        upgraded = json.loads(
            (detail._cache_dir() / f"{nid(1)}.resources.json").read_text())
        out["upgraded_inventory_has_raw_capture"] = "raw_capture" in upgraded
        out["upgraded_resource_capture_valid"] = detail._resource_capture_valid(upgraded)
    if opts.get("report_text_len"):
        lens = {}
        for i in range(1, N_CANDIDATES + 1):
            tcache = sat._cache_dir() / f"{rid(i)}.json"
            if tcache.exists():
                lens[f"{i:02d}"] = len(json.loads(tcache.read_text()).get("text") or "")
        out["cached_text_lengths"] = lens
        out["module_text_cap"] = sat.MAX_ATTACHMENT_TEXT_CHARS
    return out


# ----------------------------------------------------------------------------
# parent side
# ----------------------------------------------------------------------------

def run_child(stack: str, scenario: str, workdir: str, opts: dict | None = None,
              env_extra: dict | None = None) -> dict:
    env = {k: v for k, v in os.environ.items()
           if not k.startswith("LILA_")}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.update(env_extra or {})
    proc = subprocess.run(
        [PY, os.path.abspath(__file__), "--child", stack, scenario, workdir,
         json.dumps(opts or {})],
        capture_output=True, text=True, env=env, cwd=CLONE, timeout=300)
    if proc.returncode != 0:
        return {"stack": stack, "scenario": scenario, "child_error": proc.stderr[-3000:]}
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except Exception:  # noqa: BLE001
        return {"stack": stack, "scenario": scenario,
                "child_error": proc.stdout[-2000:] + proc.stderr[-2000:]}


def fresh_legacy_workdir(root: str, name: str, long_text: bool = False) -> tuple[str, dict]:
    workdir = os.path.join(root, name)
    os.makedirs(workdir, exist_ok=True)
    seed = run_child("base", "seed_base", workdir, {"long_text": long_text})
    return workdir, seed


def main() -> int:
    root = tempfile.mkdtemp(prefix="f17_", dir=HERE)
    observed: dict = {"workroot": root}
    checks: dict = {}
    try:
        # C1 / C2 / C7 : storm on legacy caches, network OK
        wd, seed = fresh_legacy_workdir(root, "storm_ok")
        observed["seed_base"] = seed
        observed["base_rerun_ok"] = run_child("base", "base_rerun_ok", wd)
        observed["cand_first_ok"] = run_child(
            "cand", "cand_first_ok", wd, {"inspect_validators": True})
        observed["cand_second_ok"] = run_child("cand", "cand_second_ok", wd)
        b = observed["base_rerun_ok"]
        c1 = observed["cand_first_ok"]
        c2 = observed["cand_second_ok"]
        checks["C1_base_rerun_zero_calls"] = (
            b.get("inventory_calls") == 0 and b.get("download_calls") == 0)
        checks["C1_candidate_refetches_every_legacy_inventory"] = (
            c1.get("inventory_calls") == N_CANDIDATES)
        checks["C1_candidate_refetches_every_legacy_text"] = (
            c1.get("download_calls") == N_CANDIDATES)
        checks["C1_legacy_validators_reject"] = (
            c1.get("legacy_resource_capture_valid") is False
            and c1.get("legacy_text_capture_valid") is False
            and c1.get("legacy_inventory_has_raw_capture") is False)
        checks["C1_yield_equal_when_network_ok"] = (
            sorted(c1.get("rows", [])) == sorted(b.get("rows", [])) == ["04", "05", "06"])
        checks["C2_second_candidate_sweep_zero_calls"] = (
            c2.get("inventory_calls") == 0 and c2.get("download_calls") == 0
            and sorted(c2.get("rows", [])) == ["04", "05", "06"])
        checks["C7_all_hit_sweep_under_1s_both_stacks"] = (
            b.get("wall_seconds", 99) < 1.0 and c2.get("wall_seconds", 99) < 1.0)

        # C3 : inventory endpoint fails inside TTL on legacy caches
        wd, seed = fresh_legacy_workdir(root, "inv_fail")
        observed["base_inv_fail"] = run_child(
            "base", "base_inv_fail", wd, {"inventory": "fail", "download": "fail"})
        observed["cand_inv_fail"] = run_child(
            "cand", "cand_inv_fail", wd, {"inventory": "fail", "download": "fail"})
        bf = observed["base_inv_fail"]
        cf = observed["cand_inv_fail"]
        checks["C3_base_serves_cached_rows_with_zero_calls"] = (
            sorted(bf.get("rows", [])) == ["04", "05", "06"]
            and bf.get("inventory_calls") == 0)
        checks["C3_candidate_all_stale_inventory_zero_rows"] = (
            cf.get("rows") == [] and set(cf.get("statuses", {}).values()) == {"STALE_INVENTORY"})
        # heal after failure: next successful sweep
        observed["cand_after_fail_ok"] = run_child("cand", "cand_after_fail_ok", wd)
        checks["C3_heals_on_next_successful_sweep"] = (
            sorted(observed["cand_after_fail_ok"].get("rows", [])) == ["04", "05", "06"])

        # C4 : inventories OK, downloads fail on legacy text caches
        wd, seed = fresh_legacy_workdir(root, "dl_fail")
        observed["base_dl_fail"] = run_child(
            "base", "base_dl_fail", wd, {"download": "fail"})
        observed["cand_dl_fail"] = run_child(
            "cand", "cand_dl_fail", wd, {"download": "fail"})
        bd = observed["base_dl_fail"]
        cd = observed["cand_dl_fail"]
        checks["C4_base_serves_text_from_cache"] = (
            sorted(bd.get("rows", [])) == ["04", "05", "06"] and bd.get("download_calls") == 0)
        checks["C4_candidate_text_unavailable_zero_rows"] = (
            cd.get("rows") == [] and set(cd.get("statuses", {}).values()) == {"TEXT_UNAVAILABLE"}
            and cd.get("download_calls") == N_CANDIDATES)

        # C5 : slow source + 2 s stage budget
        wd, seed = fresh_legacy_workdir(root, "budget")
        observed["base_slow_budget2"] = run_child(
            "base", "base_slow_budget2", wd, {"inventory": "slow", "download": "slow"},
            {"LILA_SAM_ATTACHMENT_STAGE_SECONDS": "2"})
        observed["cand_slow_budget2"] = run_child(
            "cand", "cand_slow_budget2", wd, {"inventory": "slow", "download": "slow"},
            {"LILA_SAM_ATTACHMENT_STAGE_SECONDS": "2"})
        bs = observed["base_slow_budget2"]
        cs = observed["cand_slow_budget2"]
        cs_status = list(cs.get("statuses", {}).values())
        cs_errors = " | ".join(cs.get("errors", []))
        checks["C5_base_slow_all_rows_in_ms"] = (
            sorted(bs.get("rows", [])) == ["04", "05", "06"] and bs.get("wall_seconds", 9) < 0.5)
        checks["C5_candidate_not_attempted_present"] = "NOT_ATTEMPTED" in cs_status
        checks["C5_candidate_stale_via_capture_time_boundary"] = (
            "STALE_INVENTORY" in cs_status and "capture time boundary" in cs_errors)
        checks["C5_candidate_hard_budget_error"] = "hard budget" in cs_errors
        checks["C5_candidate_yield_below_base"] = len(cs.get("rows", [])) < 3
        # same storm under default budget completes
        wd2, seed2 = fresh_legacy_workdir(root, "budget_default")
        observed["cand_slow_default_budget"] = run_child(
            "cand", "cand_slow_default_budget", wd2,
            {"inventory": "slow", "download": "slow", "latency": 0.1})
        checks["C5_default_budget_storm_completes"] = (
            sorted(observed["cand_slow_default_budget"].get("rows", [])) == ["04", "05", "06"])

        # C6 : text cap lowering / raising on CANDIDATE caches
        wd = os.path.join(root, "cap")
        os.makedirs(wd, exist_ok=True)
        # seed: notices 04..06 long (about 45k chars), others short, cap 50000
        observed["cand_cap_seed_50000"] = run_child(
            "cand", "cand_cap_seed_50000", wd,
            {"long_text": True, "report_text_len": True},
            {"LILA_SAM_ATTACHMENT_TEXT_CHARS": "50000"})
        observed["cand_cap_lower_40000_dl_fail"] = run_child(
            "cand", "cand_cap_lower_40000_dl_fail", wd,
            {"long_text": True, "download": "fail", "report_text_len": True},
            {"LILA_SAM_ATTACHMENT_TEXT_CHARS": "40000"})
        observed["cand_cap_raise_60000_dl_fail"] = run_child(
            "cand", "cand_cap_raise_60000_dl_fail", wd,
            {"long_text": True, "download": "fail", "report_text_len": True},
            {"LILA_SAM_ATTACHMENT_TEXT_CHARS": "60000"})
        seed_lens = observed["cand_cap_seed_50000"].get("cached_text_lengths", {})
        lower = observed["cand_cap_lower_40000_dl_fail"]
        raise_ = observed["cand_cap_raise_60000_dl_fail"]
        long_ids = [k for k, v in seed_lens.items() if v > 40000]
        short_ids = [k for k, v in seed_lens.items() if v <= 40000]
        observed["cap_long_ids"] = long_ids
        observed["cap_short_ids"] = short_ids
        checks["C6_lower_cap_refetches_long_cached_files"] = (
            lower.get("download_calls") == len(long_ids) and lower.get("rows") == []
            and all(lower["statuses"].get(k) == "TEXT_UNAVAILABLE" for k in long_ids))
        checks["C6_lower_cap_does_NOT_refetch_short_cached_files"] = (
            len(short_ids) > 0 and all(
                lower["statuses"].get(k) == "DISCOVERY_TEXT_CAPTURED" for k in short_ids))
        checks["C6_raise_cap_serves_cache_no_reextract"] = (
            raise_.get("download_calls") == 0
            and sorted(raise_.get("rows", [])) == ["04", "05", "06"]
            and raise_.get("cached_text_lengths") == seed_lens)
    finally:
        shutil.rmtree(root, ignore_errors=True)

    failed = [k for k, v in checks.items() if not v]
    # Semantics: PASS = every claimed behavior reproduced (finding confirmed as
    # described); FAIL = some material claim did not reproduce.
    material = [k for k in failed if not k.startswith("C6_lower_cap_does_NOT")]
    status = "PASS" if not material else "FAIL"
    print(json.dumps({
        "status": status,
        "finding": "F-17",
        "checks": checks,
        "checks_failed": failed,
        "note": ("C6_lower_cap_does_NOT_refetch_short_cached_files is an "
                 "overstatement probe for YU-6 wording 'any cap decrease turns "
                 "every cached file into a fresh download'; True means the "
                 "wording is overstated (short files stay cache hits)."),
        "observed": observed,
    }, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--child":
        _, _, stack, scenario, workdir, opts_json = sys.argv
        try:
            result = child(stack, scenario, workdir, json.loads(opts_json))
        except Exception as exc:  # noqa: BLE001
            import traceback
            print(json.dumps({"stack": stack, "scenario": scenario,
                              "child_exception": repr(exc),
                              "trace": traceback.format_exc()[-3000:]}))
            raise SystemExit(0)
        print(json.dumps(result))
        raise SystemExit(0)
    raise SystemExit(main())
