"""F-17 IMPACT probe: where does the legacy-cache refetch storm and its yield hole flow?

Measures, with base (2d522f0) and candidate (6b51f00) stacks in separate processes:
  1. operator legacy cache census (READ-ONLY) and cache ages against the base TTLs;
  2. storm size on legacy caches versus a cold-start base sweep;
  3. yield with network failure on fresh legacy, aged legacy and upgraded caches;
  4. whether census (description-matched) rows survive, and what the receipts say;
  5. text-cap lowering after upgrade (second storm size);
  6. tight stage budget storm (YU-2) and the new capture time boundary;
  7. flow of the surviving/missing rows into the strict Assess ledger and dossier.
Prints one JSON object with status in {PASS, FAIL, INFO}.
"""
from __future__ import annotations

import copy
import datetime as dt
import glob
import json
import os
import shutil
import subprocess
import sys
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
CLONE = "/Users/wtjohnson/lila-step7-052"
PYTHON = os.path.join(CLONE, ".venv", "bin", "python")
TMP = os.path.join(HERE, "tmp")
OPERATOR_NOTICE = "/Users/wtjohnson/Lila/data/cache/sam_notice"
OPERATOR_TEXT = "/Users/wtjohnson/Lila/data/cache/sam_attachment_text"
TTL_H = 6.0
MAX_STALE_H = 7 * 24.0


def fresh(label: str) -> str:
    path = os.path.join(TMP, f"{label}-{uuid.uuid4().hex[:6]}")
    os.makedirs(path, exist_ok=True)
    return path


def clone_dir(src: str, label: str) -> str:
    dst = os.path.join(TMP, f"{label}-{uuid.uuid4().hex[:6]}")
    shutil.copytree(src, dst)
    return dst


def age_caches(notice_dir: str, hours: float) -> None:
    stamp = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=hours)).isoformat()
    for path in glob.glob(os.path.join(notice_dir, "*.resources.json")):
        with open(path) as handle:
            payload = json.load(handle)
        payload["retrieved_at"] = stamp
        with open(path, "w") as handle:
            json.dump(payload, handle)


def run(variant: str, notice: str, text: str, *, network: str = "ok", stage=None,
        text_chars=None, inv_delay=0.0, dl_delay=0.0) -> dict:
    out = os.path.join(TMP, f"run-{variant}-{uuid.uuid4().hex[:6]}.json")
    cmd = [PYTHON, os.path.join(HERE, "sweep_driver.py"), "--variant", variant,
           "--notice-cache", notice, "--text-cache", text, "--network", network,
           "--inv-delay", str(inv_delay), "--dl-delay", str(dl_delay), "--out", out]
    if stage is not None:
        cmd += ["--stage-seconds", str(stage)]
    if text_chars is not None:
        cmd += ["--text-chars", str(text_chars)]
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    done = subprocess.run(cmd, cwd=CLONE, env=env, capture_output=True, text=True, timeout=600)
    if done.returncode != 0:
        raise RuntimeError(f"{variant} failed rc={done.returncode}\n{done.stdout[-1500:]}\n{done.stderr[-4000:]}")
    with open(out) as handle:
        return json.load(handle)


def view(result: dict) -> dict:
    return {
        "row_ids": result["row_ids"],
        "attachment_relevant": result["attachment_relevant_ids"],
        "added_beyond_census": sorted(set(result["row_ids"]) - set(result["census_ids"])),
        "census_preserved": all(c in result["row_ids"] for c in result["census_ids"]),
        "statuses": {k: v["status"] for k, v in sorted(result["receipts"].items())},
        "inventory_calls": result["inventory_calls"],
        "download_calls": result["download_calls"],
        "wall_seconds": result["wall_seconds"],
    }


def census() -> dict:
    now = dt.datetime.now(dt.timezone.utc)
    out = {}
    for label, directory, pattern in (("inventory", OPERATOR_NOTICE, "*.resources.json"),
                                      ("text", OPERATOR_TEXT, "*.json")):
        rows = []
        for path in sorted(glob.glob(os.path.join(directory, pattern))):
            try:
                with open(path) as handle:
                    payload = json.load(handle)
            except (OSError, ValueError):
                rows.append({"file": os.path.basename(path)[:8], "unreadable": True})
                continue
            stamp = payload.get("retrieved_at")
            age = None
            try:
                parsed = dt.datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=dt.timezone.utc)
                age = round((now - parsed).total_seconds() / 3600, 1)
            except ValueError:
                pass
            rows.append({"file": os.path.basename(path)[:8], "legacy": "raw_capture" not in payload,
                         "age_hours": age, "text_chars": len(payload.get("text") or "")})
        out[label] = {
            "count": len(rows), "legacy_count": sum(1 for r in rows if r.get("legacy")),
            "within_base_ttl_6h": sum(1 for r in rows if r.get("age_hours") is not None and r["age_hours"] <= TTL_H),
            "within_base_max_stale_7d": sum(1 for r in rows if r.get("age_hours") is not None and r["age_hours"] <= MAX_STALE_H),
            "min_age_hours": min((r["age_hours"] for r in rows if r.get("age_hours") is not None), default=None),
            "max_age_hours": max((r["age_hours"] for r in rows if r.get("age_hours") is not None), default=None),
            "text_chars_at_50000_cap": sum(1 for r in rows if r.get("text_chars") == 50000),
            "rows": rows,
        }
    return out


def assess_flow(ok_rows: list[dict], fail_rows: list[dict]) -> dict:
    sys.path.insert(0, CLONE)
    os.chdir(CLONE)
    os.environ.setdefault("LILA_SUITE_OFFLINE", "1")
    from tests.test_assess_ledger import _sweep, _build
    from agents.assess.contracts import LiveClassification
    from agents.decisions.dossier import _attachment_research_context

    def build(rows: list[dict]) -> dict:
        sweep = _sweep()
        template = sweep["results"]["sam.gov"][0]
        for row in rows:
            notice = copy.deepcopy(template)
            notice["source_id"] = row["source_id"]
            notice["title"] = row["title"]
            notice["api_url"] = f"https://sam.gov/opp/{row['source_id']}/view"
            notice["raw_payload"] = {**notice["raw_payload"], **(row.get("raw_payload") or {})}
            sweep["results"]["sam.gov"].append(notice)
        sweep["results"]["sam_census"]["matched"] = len(sweep["results"]["sam.gov"])
        proposed, diagnostics, index = _build(sweep)
        records = {}
        for record in proposed.live.records:
            records[record.notice_id[-2:] if len(record.notice_id) == 32 else record.notice_id] = {
                "classification": str(record.classification),
                "requirement_reviewed_at": record.requirement_reviewed_at,
                "attachment_gap": (record.attachment_gap or "")[:100],
                "source_depth_present": bool(getattr(record, "source_depth", None)),
            }
        dossier = {}
        for row in rows:
            ctx = _attachment_research_context(row, {})
            dossier[row["source_id"][-2:]] = None if ctx is None else {
                "status": ctx.get("status"), "reason": ctx.get("reason"),
                "passages": len(ctx.get("file_passages") or [])}
        return {"live_record_count": len(proposed.live.records), "records": records,
                "diagnostics": [d[:120] for d in diagnostics][:8], "dossier": dossier}

    return {"network_ok_rows": build(ok_rows), "network_fail_rows": build(fail_rows)}


def main() -> int:
    if os.path.isdir(TMP):
        shutil.rmtree(TMP)
    os.makedirs(TMP)
    observed: dict = {"operator_census_read_only": census()}
    checks: dict = {}

    # base cold start builds legacy caches
    legacy_notice, legacy_text = fresh("legacy-notice"), fresh("legacy-text")
    r0 = run("base", legacy_notice, legacy_text)
    observed["base_cold_start"] = view(r0)
    legacy_files = [json.load(open(p)) for p in glob.glob(os.path.join(legacy_notice, "*.resources.json"))]
    observed["legacy_cache_shape"] = {
        "inventory_files": len(legacy_files),
        "text_files": len(glob.glob(os.path.join(legacy_text, "*.json"))),
        "has_raw_capture": any("raw_capture" in f for f in legacy_files),
        "module_files_base": r0["module_files"],
    }

    n1, t1 = clone_dir(legacy_notice, "n"), clone_dir(legacy_text, "t")
    r1 = run("base", n1, t1)
    observed["base_warm_legacy"] = view(r1)

    upgraded_notice, upgraded_text = clone_dir(legacy_notice, "up-n"), clone_dir(legacy_text, "up-t")
    r2 = run("candidate", upgraded_notice, upgraded_text)
    observed["candidate_first_sweep_on_legacy"] = view(r2)
    observed["candidate_module_files"] = r2["module_files"]
    checks["storm_equals_cold_start_cost"] = (
        r2["inventory_calls"] == r0["inventory_calls"] and r2["download_calls"] == r0["download_calls"])
    checks["storm_loses_no_rows_with_network_up"] = r2["row_ids"] == r0["row_ids"]

    n3, t3 = clone_dir(upgraded_notice, "n"), clone_dir(upgraded_text, "t")
    r3 = run("candidate", n3, t3)
    observed["candidate_second_sweep"] = view(r3)
    checks["second_sweep_zero_refetch"] = r3["inventory_calls"] == 0 and r3["download_calls"] == 0

    # network failure on FRESH legacy (inside base TTL)
    n4, t4 = clone_dir(legacy_notice, "n"), clone_dir(legacy_text, "t")
    r4 = run("base", n4, t4, network="fail")
    n5, t5 = clone_dir(legacy_notice, "n"), clone_dir(legacy_text, "t")
    r5 = run("candidate", n5, t5, network="fail")
    observed["base_fresh_legacy_network_fail"] = view(r4)
    observed["candidate_fresh_legacy_network_fail"] = view(r5)
    observed["candidate_fresh_legacy_network_fail_receipts"] = r5["receipts"]
    observed["candidate_fresh_legacy_network_fail_errors"] = r5["stats"].get("attachment_errors")
    checks["fresh_legacy_network_fail_candidate_loses_attachment_rows"] = (
        set(r4["row_ids"]) > set(r5["row_ids"]))
    checks["census_rows_preserved_on_failure"] = view(r5)["census_preserved"]
    checks["failure_receipts_are_explicit"] = all(
        v["status"] in ("STALE_INVENTORY", "INVENTORY_UNAVAILABLE", "TEXT_UNAVAILABLE", "NOT_ATTEMPTED")
        for v in r5["receipts"].values()) and any(r5["stats"].get("attachment_errors") or [])

    # network failure on AGED legacy (outside base TTL, inside max stale)
    aged_notice = clone_dir(legacy_notice, "aged-n")
    age_caches(aged_notice, 7.0)
    n6, t6 = clone_dir(aged_notice, "n"), clone_dir(legacy_text, "t")
    r6 = run("base", n6, t6, network="fail")
    n7, t7 = clone_dir(aged_notice, "n"), clone_dir(legacy_text, "t")
    r7 = run("candidate", n7, t7, network="fail")
    observed["base_aged_legacy_network_fail"] = view(r6)
    observed["candidate_aged_legacy_network_fail"] = view(r7)
    checks["aged_legacy_network_fail_base_equals_candidate"] = r6["row_ids"] == r7["row_ids"]

    # inventory endpoint up, downloads down, aged legacy caches
    n8, t8 = clone_dir(aged_notice, "n"), clone_dir(legacy_text, "t")
    r8 = run("base", n8, t8, network="inventory-only")
    n9, t9 = clone_dir(aged_notice, "n"), clone_dir(legacy_text, "t")
    r9 = run("candidate", n9, t9, network="inventory-only")
    observed["base_aged_legacy_inventory_only"] = view(r8)
    observed["candidate_aged_legacy_inventory_only"] = view(r9)
    observed["candidate_aged_legacy_inventory_only_receipts"] = r9["receipts"]
    checks["text_cache_regression_when_downloads_fail"] = (
        set(r8["row_ids"]) > set(r9["row_ids"]) and r9["download_calls"] > 0)

    # upgraded caches, network failure: heals
    n10, t10 = clone_dir(upgraded_notice, "n"), clone_dir(upgraded_text, "t")
    r10 = run("candidate", n10, t10, network="fail")
    observed["candidate_upgraded_network_fail"] = view(r10)
    checks["upgraded_cache_serves_through_network_failure"] = r10["row_ids"] == r0["row_ids"]

    # text cap lowered after upgrade
    n11, t11 = clone_dir(upgraded_notice, "n"), clone_dir(upgraded_text, "t")
    r11 = run("candidate", n11, t11, text_chars=40000)
    observed["candidate_upgraded_cap_40000_network_ok"] = view(r11)
    n12, t12 = clone_dir(upgraded_notice, "n"), clone_dir(upgraded_text, "t")
    r12 = run("candidate", n12, t12, text_chars=40000, network="inventory-only")
    observed["candidate_upgraded_cap_40000_inventory_only"] = view(r12)
    observed["candidate_upgraded_cap_40000_inventory_only_receipts"] = r12["receipts"]
    n13, t13 = clone_dir(upgraded_notice, "n"), clone_dir(upgraded_text, "t")
    r13 = run("candidate", n13, t13, text_chars=60000)
    observed["candidate_upgraded_cap_60000_network_ok"] = view(r13)
    checks["cap_decrease_refetches_only_texts_over_new_cap"] = r11["download_calls"] == 1
    checks["cap_increase_refetches_nothing"] = r13["download_calls"] == 0

    # tight stage budget storm (YU-2 shape)
    n14, t14 = clone_dir(legacy_notice, "n"), clone_dir(legacy_text, "t")
    r14 = run("base", n14, t14, stage=2, inv_delay=0.3, dl_delay=0.3)
    n15, t15 = clone_dir(legacy_notice, "n"), clone_dir(legacy_text, "t")
    r15 = run("candidate", n15, t15, stage=2, inv_delay=0.3, dl_delay=0.3)
    observed["base_legacy_slow_budget2s"] = view(r14)
    observed["candidate_legacy_slow_budget2s"] = view(r15)
    observed["candidate_legacy_slow_budget2s_errors"] = r15["stats"].get("attachment_errors")
    checks["tight_budget_storm_loses_attachment_relevance_vs_base"] = (
        set(r14["attachment_relevant_ids"]) > set(r15["attachment_relevant_ids"]))
    checks["tight_budget_storm_keeps_census_rows"] = view(r15)["census_preserved"]

    # flow into Assess and dossier
    added_ok = [r for r in r2["rows"] if r["source_id"][-2:] not in r2["census_ids"] or
                (r.get("raw_payload") or {}).get("attachment_collection_v1")]
    added_fail = [r for r in r5["rows"] if (r.get("raw_payload") or {}).get("attachment_collection_v1")]
    flow = assess_flow(added_ok, added_fail)
    observed["assess_flow"] = flow
    ok_records = flow["network_ok_rows"]["records"]
    attachment_ids = {r["source_id"][-2:] for r in added_ok}
    checks["attachment_rows_never_bid_now"] = all(
        "BID_NOW" not in rec["classification"] and rec["requirement_reviewed_at"] is None
        for key, rec in ok_records.items() if key in attachment_ids)
    checks["attachment_rows_reach_assess_as_records_when_present"] = any(
        key in ok_records for key in attachment_ids)
    checks["missing_rows_change_only_record_count"] = (
        flow["network_ok_rows"]["live_record_count"] > flow["network_fail_rows"]["live_record_count"])
    checks["dossier_discovery_only_when_present"] = all(
        (d or {}).get("status") == "discovery_only" for d in flow["network_ok_rows"]["dossier"].values()
        if d is not None)

    expected = {k: True for k in checks}
    failed = [k for k, v in checks.items() if v is not expected[k]]
    observed["checks"] = checks
    observed["failed_checks"] = failed
    observed["reading"] = (
        "The first candidate sweep on legacy caches costs exactly one cold-start sweep; with the "
        "network up no row is lost and the second sweep refetches nothing. With the network down "
        "the candidate loses attachment-added rows where the base served them from cache, but only "
        "while legacy inventories are inside the base 6 h TTL (aged legacy inventories lose the same "
        "rows on base) or while legacy text caches would have served through a download failure. "
        "Description-matched census rows always survive; every loss is an explicit receipt "
        "(STALE_INVENTORY / TEXT_UNAVAILABLE / NOT_ATTEMPTED with errors). In Assess the attachment "
        "rows only ever appear as non-BID_NOW records with an attachment gap, so their absence "
        "changes the record count, never an approval, identity or trusted depth.")
    status = "INFO" if not failed else "FAIL"
    print(json.dumps({"status": status, "observed": observed}, indent=1, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
