"""Assemble FINDINGS_AND_RESIDUALS.json from RESULTS.json votes plus the lead reviewer's final dispositions.

The lead dispositions live in dispositions.json (id -> {severity, kind, disposition, action}). Run after build_results.py.
"""
import json

R = '/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052'
results = json.load(open(R + '/RESULTS.json'))
merged = {m['id']: m for m in json.load(open(R + '/results/findings_merged.json'))['merged']}
disp = json.load(open(R + '/dispositions.json'))
prior = json.load(open('/Users/wtjohnson/lila-step7-052/docs/verification/step7-052/PRIOR_FOLLOWUPS.json'))

order = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3, 'Info': 4}
findings = []
for mid, m in merged.items():
    d = disp[mid]
    votes = next(x['votes'] for x in results['merged_findings'] if x['id'] == mid)
    findings.append({
        'id': mid, 'title': m['title'], 'summary': m['summary'],
        'severity': d['severity'], 'kind': d['kind'], 'disposition': d['disposition'], 'recommended_action': d['action'],
        'member_raw_findings': m['members'], 'member_titles': m['member_titles'],
        'refuter_votes': [{k: v[k] for k in ('finding_id', 'lens', 'verdict', 'severity_recommendation', 'kind_recommendation')} for v in votes],
        'vote_summary': d.get('vote_summary', ''),
        'evidence_scripts': [s for s in m.get('member_probe_scripts', []) if s.startswith('/')],
        'raw_finding_text': R + '/results/findings_raw_all.md',
    })
findings.sort(key=lambda f: (order[f['severity']], f['id']))

out = {
    'schema': 'lila.fable.findings_and_residuals.v2', 'work_id': 'FABLE-STEP7-052',
    'verdict': disp['_verdict'], 'verdict_basis': disp['_verdict_basis'],
    'exact_tested_sha': '67f644bc31bf19eadec628b738855e7b6c152a4e', 'tested_code_commit': '6b51f005c001d2d99a535e4a302370f9ad80c6ea',
    'accepted_base': '2d522f0362e656e029986344d47e2e06b86a58f8', 'branch': 'codex/step7-evidence-collection',
    'review_clone': '/Users/wtjohnson/lila-step7-052', 'package': R,
    'suite': {'focused': '201 passed', 'full': '5864 passed / 40 skipped / 0 failed / 0 errors / 26 subtests / 5930 junit cases; zero case-level differences from the producer junit',
              'fixtures': '31 ignored baseline fixtures staged byte-exact from producer-declared sources; without them 2 collection errors, 1 failure, 8 setup errors, 21 extra skips (results/fixture_dependency.json)',
              'cloud': 'not run; no cloud/local parity claimed'},
    'custody_checks': R + '/CUSTODY_CHECKS.json',
    'probe_counts': results['probe_counts'], 'probe_total': results['probe_total'], 'raw_findings_total': results['raw_findings_total'],
    'votes_total': results['votes_total'],
    'critic': results.get('critic'),
    'findings': findings,
    'required_before_operating_integration': disp['_required_before_integration'],
    'step7_policy_followups': disp['_policy_followups'],
    'informational_observations': disp['_observations'],
    'prior_residuals': {'register': 'docs/verification/step7-052/PRIOR_FOLLOWUPS.json', 'sha256': '30ba14ac52420314b9cf7e937c6927d7a990c806254af684248e3247ed9565da',
                        'retained_byte_for_byte': True, 'item_ids': [i['id'] for i in prior['items']],
                        'statement': 'All prior canonical residuals remain with their recorded status; no blanket closure is claimed.'},
    'non_claims': ['production merge', 'automatic Step7 acceptance', 'seller-ready lead', 'frozen rescore', 'NETSCOUT composite acceptance',
                   'live SAM acquisition', 'government-source authentication (hash custody only)', 'cloud/local suite parity',
                   'full-market recall or comparative relevance', 'independent trust upgrade for discovery text'],
}
json.dump(out, open(R + '/FINDINGS_AND_RESIDUALS.json', 'w'), indent=1)
print('verdict', out['verdict'])
for f in findings:
    print(f"{f['id']:5s} {f['severity']:7s} {f['kind']:18s} {f['disposition'][:60]}")
