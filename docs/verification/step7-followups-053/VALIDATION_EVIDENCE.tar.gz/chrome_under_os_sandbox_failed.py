#!/usr/bin/env python3
"""Test-only Chrome wrapper for the separately verified macOS network sandbox.

Chrome cannot initialize its own child sandbox inside sandbox-exec. The outer
OS network policy remains active; only Chrome's nested sandbox is disabled.
Always use a fresh temporary browser profile. Never configure this for production.
"""
import os
import subprocess
import sys
import tempfile

if os.environ.get('LILA_TEST_OS_NETWORK_SANDBOX') != '1':
    raise SystemExit('This test wrapper requires the verified outer OS network sandbox')
binary = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
with tempfile.TemporaryDirectory(prefix='lila053-chrome-') as profile:
    result = subprocess.run([binary, '--no-sandbox', '--disable-background-networking',
                             '--disable-component-update', f'--user-data-dir={profile}',
                             *sys.argv[1:]])
    raise SystemExit(result.returncode)
