#!/usr/bin/env python3
"""Test-only headless Chrome: private profile, blocked DNS and local closed proxy.

Chrome keeps its own sandbox. These flags are not an OS-wide network firewall.
The exec preserves the PDF exporter's process timeout ownership.
"""
import os
import sys
import tempfile

binary = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
profile = tempfile.mkdtemp(prefix='lila053-pdf-')
os.execv(binary, [binary, '--disable-background-networking', '--disable-component-update',
                 '--password-store=basic', '--use-mock-keychain', '--disable-search-engine-choice-screen',
                 '--disable-quic', '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost',
                 '--proxy-server=http://127.0.0.1:9', f'--user-data-dir={profile}', *sys.argv[1:]])
