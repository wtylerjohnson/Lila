import os,json,subprocess,tarfile,sys
from pathlib import Path
from run_guarded import guard,OUT,W
from tools.benchmark_v5 import synthetic as sy
from tools.benchmark_v5.io import read,digest
commands=[]
sha=guard();archive=OUT/'portable_code.tar';argv=['git','archive','--format=tar',sha,'tools/benchmark_v5']
p=subprocess.run(argv,cwd=W,capture_output=True);assert p.returncode==0;pout=p.stdout;archive.write_bytes(pout)
commands.append({'argv':argv,'cwd':str(W),'exit_code':p.returncode,'archive_sha256':digest(archive)})
export=OUT/'portable_export';export.mkdir()
with tarfile.open(archive) as t:t.extractall(export,filter='data')
env=os.environ.copy();env.pop('PYTHONPATH',None);env['PYTHONNOUSERSITE']='1'
def cli(name,args,expected_exit=0):
 guard();argv=[sys.executable,'-m','tools.benchmark_v5',*map(str,args)];p=subprocess.run(argv,cwd=export,env=env,capture_output=True,text=True)
 (OUT/(name+'.stdout.log')).write_text(p.stdout);(OUT/(name+'.stderr.log')).write_text(p.stderr)
 commands.append({'name':name,'argv':argv,'cwd':str(export),'PYTHONPATH':'removed','PYTHONNOUSERSITE':'1','exit_code':p.returncode,'stdout':name+'.stdout.log','stderr':name+'.stderr.log'})
 sy.put(OUT/'CLI_COMMANDS.json',commands);assert p.returncode==expected_exit,(name,p.stderr);guard();return p
cli('cli_help',['--help'])
root=OUT/'fixtures/portable_cli';sy.make_case(root,('positive','negative','insufficient'))
cli('cli_prepare',['prepare',root/'case',root/'packets','--input-trust',root/'trust/input.json','--anchor-output',root/'trust/prepared.json','--reviewer-one','synthetic-reviewer-1','--reviewer-two','synthetic-reviewer-2'])
sy.submit(root,('positive','negative','insufficient'))
args=['score',root/'case',root/'packets',root/'result.json','--anchor',root/'trust/prepared.json','--support-trust',root/'trust/support.json','--support-trust-sha256',digest(root/'trust/support.json'),'--support-dir',root/'support']
p=cli('cli_score',args);r=read(root/'result.json');assert json.loads(p.stdout)==r
prior=digest(root/'result.json');cli('cli_overwrite_refused',args,2);assert digest(root/'result.json')==prior
cli('cli_demo',['demo',OUT/'fixtures/portable_demo'])
ranks=r['agreed_counts_only']['LILA'];assert ranks['relevant_distinct_top20']==1 and ranks['unknown_relevance_slots_top20']==1 and ranks['confirmed_non_relevant_slots_top20']==1
summary={'portable_export_exact_sha':sha,'external_dependencies':False,'cli_prepare_score_help_demo':'PASS','exclusive_result_preserved':'PASS','counts':ranks,'result_sha256':prior,'source_files_exported':len(list((export/'tools/benchmark_v5').rglob('*.py')))}
sy.put(OUT/'CLI_RESULTS.json',summary);print(json.dumps(summary,indent=2));guard()
