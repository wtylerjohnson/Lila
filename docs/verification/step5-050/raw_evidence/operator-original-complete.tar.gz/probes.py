"""Bounded offline review probes. All authored fixture mutations stay under this folder.
The check-record mutation deliberately updates external admission to test structural
validation, not to claim the trusted checker can be cryptographically authenticated.
"""
import copy,json,sys,subprocess
from pathlib import Path
from run_guarded import guard,OUT,W
from tools.benchmark_v5 import synthetic as sy
from tools.benchmark_v5.io import read,object_hash,digest,encoded
from tools.benchmark_v5.scorer import score

RESULTS=[]
def fixture(name,kind='positive',override=None,pre=None,rows=None):
 guard();root=OUT/'fixtures'/name
 kinds=(kind,) if isinstance(kind,str) else kind
 sy.make_case(root,kinds,rows=rows)
 if pre:
  pre(root/'case');sy.put(root/'trust/input.json',sy.seal_case(root/'case'))
 sy.prepare_fixture(root);sy.submit(root,kinds,override)
 return root

def run_score(root):
 guard()
 r=sy.score_fixture(root)
 sy.put(root/'review_result.json',r)
 guard();return r

def first(r,n=1):return next(iter(r['validated_reviews'][f'reviewer_{n}'].values()))

def record(name,expected,actual,passed,**extra):
 r={'probe':name,'expected':expected,'actual':actual,'expectation_met':bool(passed),**extra};RESULTS.append(r)
 sy.put(OUT/'PROBE_RESULTS.json',RESULTS);print(json.dumps(r),flush=True)

def refused(name,work,expected='reject invalid binding'):
 try:
  r=work();record(name,expected,{'accepted':True},False)
 except (ValueError,TypeError,KeyError) as e:
  record(name,expected,{'exception':type(e).__name__,'message':str(e)},True)

# G5: checker declines unsupported claims; distinct raw proposals must not disappear.
for name,pred,values in [('unsupported_fit_opposition','fit',(False,True)),
                          ('unsupported_grade_opposition','grade',(0,3)),
                          ('unsupported_negative_vs_unknown','fit',(False,'unknown'))]:
 root=fixture(name,'insufficient',override=lambda n,c,cs,p=pred,v=values:[sy.make_claim(c,p,v[n-1])])
 r=run_score(root)
 actual={'raw_values':[first(r,n)['raw_judgment']['claims'][0]['value'] for n in (1,2)],
         'validated_classifications':[first(r,n)['classification'] for n in (1,2)],
         'disagreements':r['disagreements'],'initial_complete_decision_agreement':r['initial_complete_decision_agreement'],
         'raw_preserved':r['raw_reviews']['reviewer_1']!=r['raw_reviews']['reviewer_2']}
 record(name,'Preserve original proposal disagreement separately from validated-state agreement; no full initial agreement for opposing raw judgments',actual,bool(r['disagreements']) or bool(r.get('raw_proposal_disagreements')))

# Rebind an admitted receipt and its source-check record without changing its exact claim.
def replace_record(root,edit):
 rp=root/'trust/support.json';reg=read(rp);old=reg['accepted_receipts'][0]
 receipt=read(root/'support'/(old+'.json'))
 rec=read(root/'support'/receipt['assessment']['record_file']);edit(rec)
 new_record_sha=object_hash(rec);record_file='records/'+new_record_sha+'.json'
 sy.put(root/'support'/record_file,rec)
 receipt['assessment'].update(record_file=record_file,record_sha256=new_record_sha)
 new=object_hash(receipt);sy.put(root/'support'/(new+'.json'),receipt)
 reg['accepted_receipts']=[new if x==old else x for x in reg['accepted_receipts']];sy.put(rp,reg)
 for n in (1,2):
  p=root/f'packets/reviewer_{n}/review.json';review=read(p)
  for row in review['judgments']:
   for c in row['claims']:
    if c.get('support_receipt_sha256')==old:c['support_receipt_sha256']=new
  sy.put(p,review)
 return {'original_receipt_sha256':old,'replacement_receipt_sha256':new,'record_sha256':new_record_sha}

name='check_record_numeric_domain';root=fixture(name)
binds=replace_record(root,lambda rec:rec.update(synthetic=1))
try:
 r=run_score(root)
 record(name,'Reject check-record synthetic=1; require boolean domain before structural equality',{'accepted':True,'classification':first(r)['classification'],**binds},False)
except (ValueError,TypeError) as e:record(name,'Reject numeric synthetic domain',{'error':str(e),**binds},True)
name='check_record_string_domain_control';root=fixture(name);replace_record(root,lambda rec:rec.update(synthetic='true'))
refused(name,lambda:run_score(root),'Reject string synthetic domain')

# G1/G2 independently scoped supported negative preserves unknown/conflict, grade0 not decisive.
name='negative_with_evidence_gap';root=fixture(name,'negative',pre=lambda case:mutate_pool(case,lambda p:p['cards'][0]['evidence_gaps'].append('Unretrieved qualification annex'))) if False else None
def mutate_pool(case,edit):
 p=read(case/'pool.json');edit(p);sy.put(case/'pool.json',p)
root=fixture(name,'negative',pre=lambda case:mutate_pool(case,lambda p:p['cards'][0]['evidence_gaps'].append('Unretrieved qualification annex')))
r=run_score(root);row=first(r)
record(name,'not_relevant fit exclusion; preserve evidence gap and unknown clocks',{'classification':row['classification'],'gaps':row['evidence_gaps'],'states':row['states']},row['classification']=='not_relevant' and bool(row['evidence_gaps']) and row['states']['response_open']=='unknown')
name='supported_grade_zero_alone';root=fixture(name,'negative',override=lambda n,c,cs:[x for x in cs if x['predicate']=='grade']);r=run_score(root)
record(name,'unknown; grade0 cannot decide failure',{'classification':first(r)['classification'],'states':first(r)['states']},first(r)['classification']=='unknown')
name='fit_conflict_with_route_negative'
# This additional synthetic notice and audit oracle are declared before its proposals.
sy.TEXTS[name]='SYNTHETIC NOTICE. Clause A includes supplier control software; Clause B excludes it with no supersession. Both direct and partner routes for this offering and purchase are expressly barred.'
sy.AUDITED_FACTS[name]={'fit':[True,False],'route_eligible':[False]}
root=fixture(name,name,override=lambda n,c,cs:cs+[sy.make_claim(c,'fit',False,tag='-other-clause')]);r=run_score(root);row=first(r)
record(name,'fit conflicted, independent route false decides not_relevant',{'classification':row['classification'],'states':row['states'],'decisive':row['decisive_predicates']},row['classification']=='not_relevant' and row['states']['fit']=='conflicted' and row['decisive_predicates']==['route_eligible'])
name='conflict_reordering_and_revocation';root=fixture(name,'conflict',override=lambda n,c,cs:[sy.make_claim(c,'fit',True,tag='-yes'),sy.make_claim(c,'fit',False,tag='-no')]);before=run_score(root)
reg=read(root/'trust/support.json');reg['accepted_receipts'].reverse();sy.put(root/'trust/support.json',reg);reordered=run_score(root)
old_result=copy.deepcopy(before)
for sha in reg['accepted_receipts']:
 if read(root/'support'/(sha+'.json'))['context']['claim']['value'] is True:reg['revoked_receipts'][sha]='Explicit test correction: Clause A withdrawn by authorized checker'
reg['snapshot_id']='SYNTHETIC-explicit-correction';sy.put(root/'trust/support.json',reg);after=run_score(root)
record(name,'order stable; explicit revocation restores false; prior result retains conflict',{'before':first(before)['states']['fit'],'reordered':first(reordered)['states']['fit'],'after':first(after)['states']['fit'],'old_retained':before==old_result},first(before)['states']['fit']==first(reordered)['states']['fit']=='conflicted' and first(after)['states']['fit'] is False and before==old_result)

# G3: direct-only failure cannot stand for all permitted routes; bind continuation universe.
name='prime_only_negative_partner_unknown';sy.TEXTS[name]='SYNTHETIC NOTICE. Supplier risk control software purchase. The supplier is barred as a direct prime. Partner eligibility is unknown.';sy.AUDITED_FACTS[name]={'fit':[True]}
root=fixture(name,name,override=lambda n,c,cs:cs+[sy.make_claim(c,'route_eligible',False)])
r=run_score(root);row=first(r)
record(name,'unknown; direct exclusion is insufficient for route-universe false',{'classification':row['classification'],'route':row['states']['route_eligible'],'support':row['support_outcomes']},row['classification']=='unknown' and row['states']['route_eligible']=='unknown')
for field,value in [('continuation_universe','Every future buying action anywhere'),('allowed_routes',['direct']),('action_id','other-action'),('offering_id','other-offer')]:
 name='scope_'+field;root=fixture(name)
 p=root/'packets/reviewer_1/review.json';r=read(p);r['judgments'][0]['claims'][0]['scope'][field]=value;sy.put(p,r)
 refused(name,lambda root=root:run_score(root))

# G4 authority remains binding for both directions even after valid support receipt admission.
for authority in ['discovery_only','non_substantive']:
 for kind in ['positive','negative']:
  name=authority+'_'+kind
  root=fixture(name,kind,pre=lambda case,a=authority:mutate_pool(case,lambda p:p['cards'][0]['evidence'][0].update(authority=a)))
  r=run_score(root);record(name,'unknown; no positive or negative on non-substantive authority',{'classification':first(r)['classification']},first(r)['classification']=='unknown')
name='missing_dates';
def undate(case):
 mutate_pool(case,lambda p:(p['cards'][0]['evidence'][0].update(published_at_utc=None),p['cards'][0]['evidence_gaps'].append('Original publication date unknown')))
 p=case/'sources/source-0.json';s=read(p);s['published_at_utc']=None;sy.put(p,s)
root=fixture(name,'negative',pre=undate);r=run_score(root)
record(name,'unknown; undated support cannot prove exclusion',{'classification':first(r)['classification'],'support':first(r)['support_outcomes']},first(r)['classification']=='unknown')
name='original_subject_mismatch';
def foreign(case):
 p=case/'sources/source-0.json';s=read(p);s['notice_id']='OTHER';sy.put(p,s)
refused(name,lambda:fixture(name,pre=foreign),'Refuse original subject mismatch even after case manifest is resealed')
name='unicode_codepoint_span';
def unicode_pre(case):
 p=case/'sources/source-0.json';s=read(p);s['text']='😀 é '+s['text'];sy.put(p,s)
 mutate_pool(case,lambda p:p['cards'][0]['evidence'][0].update(span=[4,len(s['text'])]))
root=fixture(name,pre=unicode_pre);r=run_score(root)
record(name,'valid exact Unicode codepoint span accepted',{'classification':first(r)['classification']},first(r)['classification']=='relevant')
name='unicode_utf8_offset_refused';
def byte_pre(case):
 unicode_pre(case);mutate_pool(case,lambda p:p['cards'][0]['evidence'][0].update(span=[8,8+len(sy.TEXTS['positive'])]))
refused(name,lambda:fixture(name,pre=byte_pre),'UTF-8 byte indices are not accepted as codepoint span')
name='unfrozen_issuer';root=fixture(name);p=root/'trust/support.json';reg=read(p);reg['issuers']['unfrozen-checker']=reg['issuers']['synthetic-checker'];sy.put(p,reg)
refused(name,lambda:run_score(root),'Issuer entry alone cannot add a nonfrozen checker')
name='empty_registry';root=fixture(name);p=root/'trust/support.json';reg=read(p);reg.update(issuers={},accepted_receipts=[]);sy.put(p,reg);r=run_score(root)
record(name,'empty registry yields unknown',{'classification':first(r)['classification']},first(r)['classification']=='unknown')
name='duplicate_registry_json_key';root=fixture(name);p=root/'trust/support.json';raw=p.read_text();p.write_text(raw.replace('"snapshot_id":','"snapshot_id":"DUPLICATE", "snapshot_id":',1))
refused(name,lambda:run_score(root),'Strict duplicate JSON key refusal')

# Fixed20 includes known, duplicate, injected, unresolved provenance/identity; no rank21 backfill.
name='fixed20_mixed_21';rows=([*[(0,'retrieved_new_run')]*14,(1,'known_independently_retrieved'),(2,'injected_or_retained_only'),(3,'unresolved'),(4,'retrieved_new_run'),(5,'retrieved_new_run'),(6,'retrieved_new_run'),(7,'retrieved_new_run')],[(1,'known_independently_retrieved'),(6,'retrieved_new_run')])
root=fixture(name,('positive',)*6+('negative','positive'),rows=rows,pre=lambda c:mutate_pool(c,lambda p:p['cards'][4].update(family_id=None)))
r=run_score(root);counts=r['agreed_counts_only']['LILA'];expected={'relevant_distinct_top20':3,'duplicate_resolved_family_slots_top20':13,'unfilled_slots_top20':0,'injected_or_retained_only_slots_top20':1,'unresolved_provenance_slots_top20':1,'unresolved_identity_slots_top20':1,'confirmed_non_relevant_slots_top20':1}
record(name,expected,counts,all(counts[k]==v for k,v in expected.items()) and len(r['validated_reviews']['reviewer_1'])==7 and r['overall_winner'] is None)

# Original record metadata is a workflow blind-review boundary: observe, do not presume machine sanitization.
name='extra_original_metadata_blindness';
def metadata(case):
 p=case/'sources/source-0.json';s=read(p);s.update(product='LILA',native_rank=1);sy.put(p,s)
root=fixture(name,pre=metadata);packet=next((root/'packets/reviewer_1/sources').glob('*.json'));exposed=read(packet)
record(name,'Document whether raw original extra fields are mechanically scrubbed; custodian attestation is explicitly trusted',{'extra_product_visible':exposed.get('product'),'extra_rank_visible':exposed.get('native_rank')},True,disposition='TRUST_BOUNDARY_OBSERVATION: synthetic fixture asserted blind_content_reviewed=true despite injected private metadata; no claim this bypasses honest-custodian trust')

guard();print(json.dumps({'probes':len(RESULTS),'unmet_expectations':[r['probe'] for r in RESULTS if not r['expectation_met']]}))
