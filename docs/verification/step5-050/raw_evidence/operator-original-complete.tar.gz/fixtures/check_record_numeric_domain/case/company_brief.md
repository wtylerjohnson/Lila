SYNTHETIC COMPANY: supplier risk control software; direct or partner route.
