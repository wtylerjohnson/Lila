# Evidence-state review v5

Record each claim separately: fit, response_open, continuation_open,
route_eligible, evidence_sufficient, and grade. Use true/false/unknown for
predicates and integers 0-3 or unknown for grade. Give a specific rationale and
references to original passages. Grade2 permits a credible investigation with
an honest qualification question; grade3 denotes a specific current requirement
with evidenced fit and credible transaction path. Grade alone never establishes
rejection. Missing sources, discovery text and citation membership do not prove
positive or negative claims. Register no support yourself.

Work independently, disclose contamination, and finalize all cards including
unknowns. A separate predeclared checker owns source-support assessments; a
registered assessment establishes binding, not automatic language entailment.
No score authorizes a release, seller-ready lead, winner or novelty claim.
