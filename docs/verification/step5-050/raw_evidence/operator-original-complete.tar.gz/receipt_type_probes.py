import json
from run_guarded import guard,OUT
from tools.benchmark_v5 import synthetic as sy
from tools.benchmark_v5.io import read,object_hash
results=[]
for name,edit in [('receipt_context_float_span',lambda r:r['context']['evidence'][0].update(span=[float(x) for x in r['context']['evidence'][0]['span']])),('receipt_context_bool_span',lambda r:r['context']['evidence'][0]['span'].__setitem__(0,False)),('receipt_numeric_domain_control',lambda r:r.update(synthetic=1))]:
 guard();root=OUT/'fixtures'/name;sy.make_case(root);sy.prepare_fixture(root);sy.submit(root,('positive',))
 reg=read(root/'trust/support.json');old=reg['accepted_receipts'][0];receipt=read(root/'support'/(old+'.json'));edit(receipt)
 rec=read(root/'support'/receipt['assessment']['record_file']);rec['context_sha256']=object_hash(receipt['context'])
 record_sha=object_hash(rec);record_name='records/'+record_sha+'.json';sy.put(root/'support'/record_name,rec)
 receipt['assessment'].update(record_file=record_name,record_sha256=record_sha);new=object_hash(receipt);sy.put(root/'support'/(new+'.json'),receipt)
 reg['accepted_receipts']=[new if x==old else x for x in reg['accepted_receipts']];sy.put(root/'trust/support.json',reg)
 for n in (1,2):
  path=root/f'packets/reviewer_{n}/review.json';review=read(path)
  for row in review['judgments']:
   for c in row['claims']:
    if c.get('support_receipt_sha256')==old:c['support_receipt_sha256']=new
  sy.put(path,review)
 try:
  r=sy.score_fixture(root,root/'review_result.json');result={'accepted':True,'classification':next(iter(r['validated_reviews']['reviewer_1'].values()))['classification']};passed=False
 except (ValueError,TypeError) as e:result={'exception':type(e).__name__,'message':str(e)};passed=True
 result={'probe':name,'expected':'Reject noncanonical boolean/numeric receipt types even when admitted','actual':result,'expectation_met':passed,'receipt_sha256':new,'context_span':receipt['context']['evidence'][0]['span']}
 results.append(result);guard()
sy.put(OUT/'RECEIPT_TYPE_RESULTS.json',results);print(json.dumps(results,indent=2))
