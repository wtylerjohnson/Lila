import sys,os,json,hashlib,subprocess,datetime
from pathlib import Path
OUT=Path(__file__).resolve().parent
W=Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step2-capability-alignment')
PYTHON='/Users/wtjohnson/.local/share/uv/python/cpython-3.14.5-macos-aarch64-none/bin/python3.14'
snap=json.loads((OUT/'SNAPSHOT.json').read_text())
def guard():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
 assert head==snap['candidate_sha'], 'STOP: HEAD moved to '+head
 for rel,wanted in snap['working_files'].items():
  assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==wanted,'STOP: reviewed bytes changed: '+rel
 return head
if __name__=='__main__':
 name=sys.argv[1];argv=[PYTHON,*sys.argv[2:]];before=guard()
 env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(W),TMPDIR='/private/tmp')
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 proc=subprocess.run(argv,cwd=W,env=env,text=True,capture_output=True)
 (OUT/(name+'.stdout.log')).write_text(proc.stdout);(OUT/(name+'.stderr.log')).write_text(proc.stderr)
 after=guard()
 cmd={'name':name,'argv':argv,'cwd':str(W),'environment_overrides':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHONPATH','TMPDIR']},'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':proc.returncode,'head_before':before,'head_after':after,'stdout':name+'.stdout.log','stderr':name+'.stderr.log'}
 with (OUT/'COMMANDS.jsonl').open('a') as f:f.write(json.dumps(cmd)+'\n')
 print(json.dumps(cmd));print(proc.stdout[-3000:]);print(proc.stderr[-1500:])
 sys.exit(proc.returncode)
