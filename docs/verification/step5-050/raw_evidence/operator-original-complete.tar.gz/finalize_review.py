import json,hashlib,subprocess,datetime,ast
from pathlib import Path
from run_guarded import guard,OUT,W
B=Path('/Users/wtjohnson/Documents/Codex/LILA-Competitive-Benchmark');snap=json.loads((OUT/'SNAPSHOT.json').read_text());sha=guard()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=B/'operators/lila/STEP5-BASELINE-050'
base_after={str(p.relative_to(base)):h(p) for p in base.rglob('*') if p.is_file()}
assert base_after==snap['baseline_files']
plan=json.loads((W/'docs/verification/step5-050/ACCEPTANCE_PLAN.json').read_text())
log=(OUT/'focused_suite.stderr.log').read_text()
coverage={c['id']:'PASS' if ('test_'+c['id']+' (') in log and 'Ran 37 tests' in log and log.rstrip().endswith('OK') else 'UNVERIFIED' for c in plan['cases']}
assert set(coverage.values())=={'PASS'}
(OUT/'ACCEPTANCE_COVERAGE.json').write_text(json.dumps({'preserved_plan_sha256':h(W/'docs/verification/step5-050/ACCEPTANCE_PLAN.json'),'original_plan_modified':False,'coverage':coverage,'limitation':'Focused baseline tests pass; additional adversarial defects remain open.'},indent=2)+'\n')
changes=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',sha],cwd=W,text=True).splitlines()
assert all(p.startswith(('tools/benchmark_v5/','docs/verification/step5-050/')) or p in ['tests/test_benchmark_v5_states.py','docs/CONTRACT_SURFACES.md','docs/CONVENTIONS.md'] for p in changes)
root_import=json.loads((W/'docs/verification/step5-050/ROOT_P1_IMPORT.json').read_text())
assert root_import['after_sha']==snap['parent_sha']
reviewed={**snap['working_files'],**{p:h(W/p) for p in ['docs/CONVENTIONS.md','docs/CONTRACT_SURFACES.md']}}
# Manifests retain every authored source, proposal, trust record and result; no frozen cases enter this review.
fixture_manifest={str(p.relative_to(OUT)): {'sha256':h(p),'bytes':p.stat().st_size} for p in sorted((OUT/'fixtures').rglob('*')) if p.is_file()}
(OUT/'FIXTURE_MANIFEST.json').write_text(json.dumps(fixture_manifest,indent=2)+'\n')
artifact_manifest={str(p.relative_to(OUT)):{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['VERIFICATION.json','ARTIFACT_MANIFEST.json','finalize.stdout.log','finalize.stderr.log','COMMANDS.jsonl']}
# COMMANDS.jsonl is finalized by the outer guarded runner after this script returns.
(OUT/'ARTIFACT_MANIFEST.json').write_text(json.dumps(artifact_manifest,indent=2)+'\n')
probe=json.loads((OUT/'PROBE_RESULTS.json').read_text())+json.loads((OUT/'RECEIPT_TYPE_RESULTS.json').read_text())
v={'work_id':'REPAIR-STEP5-FIXED-REVIEW-050','status':'CHANGES_REQUIRED','completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_sha':sha,'parent_sha':snap['parent_sha'],'branch':snap['branch'],'head_remained_fixed':True,'reviewed_files_unchanged':True,'reviewed_file_sha256':reviewed,'tracked_status_after':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W,text=True),'focused_tests':{'passed':37,'failed':0,'runs':1,'python':'3.14.5'},'baseline_acceptance_cases_covered':32,'additional_probe_records':len(probe),'additional_behavior_checks':29,'expectations_met':23,'unmet_expectations':6,'trust_boundary_observations':1,'open_findings':[{'id':'S5-REVIEW-050-01','priority':'P2','guard':'G5','title':'Unsupported opposing proposals omitted from initial disagreement metrics','status':'OPEN'},{'id':'S5-REVIEW-050-02','priority':'P2','guard':'G4','title':'Coercive equality admits noncanonical receipt and checker-record field types','status':'OPEN'}],'report_sha256':h(OUT/'REPORT.md'),'artifact_manifest_sha256':h(OUT/'ARTIFACT_MANIFEST.json'),'fixture_manifest_sha256':h(OUT/'FIXTURE_MANIFEST.json'),'fixture_files':len(fixture_manifest),'commands_file':'COMMANDS.jsonl','cli_commands_file':'CLI_COMMANDS.json','portable_cli':json.loads((OUT/'CLI_RESULTS.json').read_text()),'baseline_preservation':{'file_count':len(base_after),'all_hashes_unchanged':True,'acceptance_plan_matches':True},'root_integration':{'parent_is_exact_import':True,'retained_producer_receipt_sha256':h(W/'docs/verification/S4-SOURCE-CLOCK-001/FINAL_VERIFICATION.json'),'step5_diff_paths':changes,'parent_product_implementation_unchanged':True,'root_p1':'OPEN pending combined review acceptance','duplicate_root_review_performed':False},'boundaries':{'product_code_edited':False,'full_suite_run':False,'live_calls':False,'model_calls':False,'frozen_case_reads_or_writes':False,'new_workers_or_worktrees':False,'push_or_fable_dispatch':False,'production_touched':False},'next_action':'Coordinator repair of both findings before combined exact-SHA handoff; operator checkpoint.','step6':'PENDING'}
assert not v['tracked_status_after'];(OUT/'VERIFICATION.json').write_text(json.dumps(v,indent=2)+'\n')
status={'work_id':v['work_id'],'status':'FIXED_REVIEW_COMPLETE_CHANGES_REQUIRED','updated_at_utc':v['completed_at_utc'],'candidate_sha':sha,'open_findings':[x['id'] for x in v['open_findings']],'verification':str(OUT/'VERIFICATION.json'),'report':str(OUT/'REPORT.md'),'focused_tests_passed':37,'root_p1':'OPEN pending combined review acceptance','step6':'PENDING','shepherd':'paused','next_action':v['next_action']}
(B/'operators/lila/status.json').write_text(json.dumps(status,indent=2)+'\n')
(B/'operators/lila/STATUS.md').write_text('# LILA operator checkpoint\n\nREPAIR-STEP5-FIXED-REVIEW-050: review complete, CHANGES_REQUIRED on `'+sha+'`.\n\n37 focused tests and clean-export CLI pass. Two open P2 findings: S5-REVIEW-050-01 (G5 original disagreement reporting) and S5-REVIEW-050-02 (G4 receipt type validation). Six adversarial repros substantiate these findings; no product patch performed.\n\nReport: '+str(OUT/'REPORT.md')+'\n\nVerification: '+str(OUT/'VERIFICATION.json')+'\n\nCoordinator owns repairs before combined exact-SHA handoff. Root P1 remains open pending combined acceptance; Step6 pending. Operator checkpointed; shepherd paused.\n')
print(json.dumps({'status':v['status'],'report_sha256':v['report_sha256'],'verification_sha256':h(OUT/'VERIFICATION.json'),'fixture_files':len(fixture_manifest),'baseline_preserved':len(base_after)},indent=2));guard()
