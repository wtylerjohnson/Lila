"""Narrow recheck of two required defects. New synthetic freezes only.
Original review fixtures are read solely for before/after source and scenario binding.
"""
import copy,json
from run_guarded import guard,OUT
from tools.benchmark_v5 import synthetic as sy
from tools.benchmark_v5.io import read,digest,object_hash,exact
from tools.benchmark_v5.support import DIMENSIONS
OLD=OUT.parent/'STEP5-FIXED-REVIEW-050'
RESULTS=[]
PREDICATES=(*DIMENSIONS,'grade')
def fixture(name,kind='positive',override=None):
 guard();root=OUT/'fixtures'/name;sy.make_case(root,(kind,));sy.prepare_fixture(root);sy.submit(root,(kind,),override);return root

def run_score(root):
 guard()
 r=sy.score_fixture(root,root/'result.json');guard();return r

def row(r,n=1):return next(iter(r['validated_reviews'][f'reviewer_{n}'].values()))

def original_binding(root,name):
 old=OLD/'fixtures'/name
 a=read(old/'case/sources/source-0.json');b=read(root/'case/sources/source-0.json')
 assert exact(a,b)
 return {'original_fixture':str(old),'original_source_sha256':digest(old/'case/sources/source-0.json'),'new_source_sha256':digest(root/'case/sources/source-0.json'),'same_original_source_bytes':digest(old/'case/sources/source-0.json')==digest(root/'case/sources/source-0.json')}

def record(name,expected,actual,passed,**extra):
 r={'probe':name,'expected':expected,'actual':actual,'pass':bool(passed),**extra};RESULTS.append(r)
 sy.put(OUT/'PROBE_RESULTS.json',RESULTS);print(json.dumps(r),flush=True)

def state(r):
 return {'original_disagreements':r['original_proposal_disagreements'],'validated_disagreements':r['validated_state_disagreements'],'union_disagreements':r['disagreements'],'initial_complete':r['initial_complete_decision_agreement'],'initial_semantic':r['initial_semantic_proposal_agreement'],'validated_agreement':r['validated_state_agreement'],'coverage':r['original_proposal_coverage'],'agreed_counts':r['agreed_counts_only']['LILA'],'classifications':[row(r,n)['classification'] for n in (1,2)]}

# Original three G5 repros: independently recreate unchanged claim/value scenarios.
for name,pred,values in [('unsupported_fit_opposition','fit',(False,True)),('unsupported_grade_opposition','grade',(0,3)),('unsupported_negative_vs_unknown','fit',(False,'unknown'))]:
 root=fixture(name,'insufficient',lambda n,c,cs,p=pred,v=values:[sy.make_claim(c,p,v[n-1])]);r=run_score(root);actual=state(r)
 old=read(OLD/'fixtures'/name/'review_result.json')
 raw_same=all(row(r,n)['raw_judgment']==row(old,n)['raw_judgment'] for n in (1,2))
 record(name,'Original disagreement retained; validated unknowns/counts unchanged; incomplete initial agreement=0',actual,len(r['original_proposal_disagreements'])==len(r['disagreements'])==1 and r['validated_state_disagreements']==[] and r['initial_complete_decision_agreement']==0 and r['initial_semantic_proposal_agreement']==0 and r['validated_state_agreement']==1 and r['agreed_counts_only']==old['agreed_counts_only'] and raw_same,original_defect='S5-REVIEW-050-01',original_repro=True,raw_judgments_match_original=raw_same,**original_binding(root,name))

# Missing and explicit unknown are distinct; six complete explicit-unknown proposals still yield zero credit.
for name,override,coverage,complete,disagreements in [
 ('missing_vs_explicit_unknown',lambda n,c,cs:[] if n==1 else [sy.make_claim(c,'fit','unknown')],(0,1),0,1),
 ('both_missing',lambda n,c,cs:[],(0,0),0,0),
 ('both_six_explicit_unknown',lambda n,c,cs:[sy.make_claim(c,p,'unknown') for p in PREDICATES],(6,6),1,0)]:
 root=fixture(name,'insufficient',override);r=run_score(root);actual=state(r)
 record(name,'Expected coverage '+str(coverage)+'; complete='+str(complete)+'; unknown counts retained',actual,tuple(r['original_proposal_coverage'][f'reviewer_{n}']['proposed_predicate_slots'] for n in (1,2))==coverage and r['initial_complete_decision_agreement']==complete and len(r['original_proposal_disagreements'])==disagreements and r['agreed_counts_only']['LILA']['unknown_relevance_slots_top20']==1 and r['agreed_counts_only']['LILA']['relevant_distinct_top20']==0)

# Every one of the six required slots controls completion, including the unused continuation branch.
for omitted in PREDICATES:
 name='five_slots_missing_'+omitted
 root=fixture(name,override=lambda n,c,cs,omit=omitted:[x for x in cs if x['predicate']!=omit]);r=run_score(root)
 record(name,'5/6 coverage; semantic agreement may be1 but complete initial agreement must be0',state(r),r['initial_complete_decision_agreement']==0 and r['initial_semantic_proposal_agreement']==1 and all(x['proposed_predicate_slots']==5 and x['possible_predicate_slots']==6 for x in r['original_proposal_coverage'].values()))
name='canonical_complete_positive';root=fixture(name);r=run_score(root)
record(name,'All six agree, relevant credit1, full initial agreement1',state(r),r['initial_complete_decision_agreement']==1 and r['agreed_counts_only']['LILA']['relevant_distinct_top20']==1)
name='raw_opposition_validated_positive_counts'
root=fixture(name,override=lambda n,c,cs:cs+([sy.make_claim(c,'fit',False,tag='-unsupported-opposition')] if n==1 else []));r=run_score(root)
record(name,'Retain original disagreement while explicitly validated-only agreed credit stays1; unsupported opposition cannot adjudicate',state(r),len(r['original_proposal_disagreements'])==1 and r['validated_state_disagreements']==[] and r['agreed_counts_only']['LILA']['relevant_distinct_top20']==1 and r['initial_complete_decision_agreement']==0 and r['adjudication']=='NOT_PERFORMED' and r['overall_winner'] is None)

# Mutate a received receipt representation; recompute exact checker/digest admission.
def replace(root,context_edit=None,record_edit=None,use='selected'):
 regpath=root/'trust/support.json';reg=read(regpath);old=reg['accepted_receipts'][0]
 receipt=read(root/'support'/(old+'.json'))
 if context_edit:context_edit(receipt['context'])
 rec=read(root/'support'/receipt['assessment']['record_file']);rec['context_sha256']=object_hash(receipt['context'])
 if record_edit:record_edit(rec)
 recsha=object_hash(rec);name='records/'+recsha+'.json';sy.put(root/'support'/name,rec)
 receipt['assessment'].update(record_file=name,record_sha256=recsha);new=object_hash(receipt);sy.put(root/'support'/(new+'.json'),receipt)
 reg['accepted_receipts']=[new if x==old else x for x in reg['accepted_receipts']]
 if use=='revoked_unused':reg['revoked_receipts'][new]='Synthetic explicit revocation; admitted bytes must still be schema-valid'
 sy.put(regpath,reg)
 for n in (1,2):
  p=root/f'packets/reviewer_{n}/review.json';review=read(p)
  if use!='selected':
   for rw in review['judgments']:rw['claims']=[]
  else:
   for rw in review['judgments']:
    for cl in rw['claims']:
     if cl.get('support_receipt_sha256')==old:cl['support_receipt_sha256']=new
  sy.put(p,review)
 return {'admitted_receipt_sha256':new,'checker_record_sha256':recsha,'received_span':receipt['context']['evidence'][0]['span'],'checker_domain':rec['synthetic'],'use':use}

mutations=[('check_record_numeric_domain',None,lambda x:x.update(synthetic=1),'Checker record domain must be boolean'),('receipt_context_float_span',lambda c:c['evidence'][0].update(span=[float(n) for n in c['evidence'][0]['span']]),None,'Receipt span needs canonical integer offsets'),('receipt_context_bool_span',lambda c:c['evidence'][0]['span'].__setitem__(0,False),None,'Receipt span needs canonical integer offsets')]
for base,ctx,rec,message in mutations:
 for use in ['selected','unused']:
  name=base if use=='selected' else base+'_unused';root=fixture(name);binding=replace(root,ctx,rec,use)
  try:r=run_score(root);actual={'accepted':True};passed=False
  except ValueError as e:actual={'exception':'ValueError','message':str(e),'score_file_created':(root/'result.json').exists()};passed=message in str(e) and not (root/'result.json').exists()
  extra={'original_defect':'S5-REVIEW-050-02','original_repro':use=='selected','mutation':binding}
  if use=='selected':extra.update(original_binding(root,base))
  record(name,'Refuse malformed admitted record/context even if unused; no score output',actual,passed,**extra)

# Nearby all-admitted controls: no claims select any receipt, including a revoked invalid record.
for name,ctx,rec,use in [('unused_extra_context_field',lambda c:c.update(extra=True),None,'unused'),('unused_numeric_predicate',lambda c:c['claim'].update(value=1),None,'unused'),('revoked_unused_numeric_record',None,lambda x:x.update(synthetic=1),'revoked_unused')]:
 root=fixture(name);binding=replace(root,ctx,rec,use)
 try:r=run_score(root);actual={'accepted':True};passed=False
 except ValueError as e:actual={'exception':'ValueError','message':str(e),'score_file_created':(root/'result.json').exists()};passed=not (root/'result.json').exists()
 record(name,'All admitted receipts validated before reviewer-use selection; no score output',actual,passed,mutation=binding)
for use in ['selected','unused']:
 name='canonical_readmitted_'+use;root=fixture(name);binding=replace(root,lambda c:c['evidence'][0].update(span=list(c['evidence'][0]['span'])),None,use);r=run_score(root)
 expected='relevant' if use=='selected' else 'unknown'
 record(name,'Canonical receipt accepted; '+use+' claims classify '+expected,{'classification':row(r)['classification'],'counts':r['agreed_counts_only']['LILA']},row(r)['classification']==expected,mutation=binding)

# Positive exact equality preserves object field order independence while keeping scalar JSON types distinct.
record('canonical_exact_type_controls','Object order irrelevant; boolean,integer,float distinct',{'object_order_equal':exact({'a':1,'b':2},{'b':2,'a':1}),'bool_integer_equal':exact(False,0),'integer_float_equal':exact(0,0.0)},exact({'a':1,'b':2},{'b':2,'a':1}) and not exact(False,0) and not exact(0,0.0))
guard();print(json.dumps({'probes':len(RESULTS),'passed':sum(x['pass'] for x in RESULTS),'original_repros':sum(x.get('original_repro',False) for x in RESULTS),'failures':[x['probe'] for x in RESULTS if not x['pass']]}))
