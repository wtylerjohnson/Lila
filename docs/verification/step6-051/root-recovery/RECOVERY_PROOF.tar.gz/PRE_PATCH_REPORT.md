# Step6 recovery pre-patch report

Work: ROOT-STEP6-RECOVERY-051. Canonical plan LILA-WEEKEND-2026-09-11-v1, SHA256 71a4c7c11ee575596357e5e0fcfb66a75d2c855b4761040042732c8cad26bfc5. Existing standing weekend authorization and ordered Fable handoffs apply. Salesforce/CRM, frozen benchmark cases, Step7 implementation and operating rollout remain outside this repair.

The existing coordinator stopped with a usage-limit compaction error. Root assumes temporary execution ownership of the unfinished Step6 repair, preserving the coordinator's complete committed and uncommitted work in an owned isolated recovery checkout. This execution receipt does not replace the canonical plan or claim that old coordinator status has advanced. The existing NETSCOUT task performed read-only recovery inspection and will not implement duplicate fixes.

Source checkout: /Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step2-capability-alignment, codex/step6-native-surfaces. Accepted base497b7f3; drafts23bfb920 and d767922b5f462308d2e62d2cff42c052e26f6a7e. Five unstaged files contain partial material-field and cross-post fixes; patch SHA256 097aef09d5ec8186d8f49e069c18c7b643cb8d00600214550960cb446ceaadcf. No staged changes. The source checkout must remain byte-for-byte untouched.

Recovery path: /Users/wtjohnson/Documents/Codex/2026-09-08/give-me-a-fun-recap-of/work/step6-root-recovery, branch codex/step6-root-recovery. Preserve the five-file patch before changing code. Root's accepted NETSCOUT composite d064f49 remains separately untouched until Step6/7 acceptance.

## Findings and bounded implementation

Extend the existing NoticeReadContext, native graph/external projection and structured-family contracts; no replacement pipeline. The operator's immutable STEP6-REVIEW-051 report demonstrated R1 stale/missing-source companion T1/T2 promotion, R2 constructor contacts/value acquiring published-source authority, and R3 loss of the current closed representative from the visible selected assessment. The coordinator also identified S6-LOCAL-002 cross-post collapse across independent solicitation IDs. Its existing five-file patch partially addresses R2 and S6-LOCAL-002 and has no subsequent verification.

1. Preserve and complete original-source material-field derivation across graph, targets and external fallback. Missing source values stay missing; guessed contact roles, amounts, buyer components and access claims cannot acquire authority from a constructor pack.
2. Require current source admission and current Assess provenance before a saved companion can create active priority or target authority. Retain stale/research assessment rows with explicit gaps and recheck context before returning.
3. Preserve selected row position and identity while exposing the actual current representative, closed/unknown family status and full member/suppression history. No backfill or re-ranking.
4. Verify the preserved full-solicitation cross-post repair with independent-call and true-amendment controls.

R1/R3 external projection ownership can be delegated together to avoid a same-file collision. Root owns R2/source-context and triage preservation; a read-only verifier may independently assess the final bounded result. All agents work only in the recovery checkout or this output directory and preserve independent worker files.

## Verification and release boundary

Run the original positive/negative review probes against the repaired code in new owned attempt directories, preserving originals. Run focused native notice/surface/triage checks first and required full offline strict regression on the final committed candidate. Bind exact commands, code and inputs/results; do not reuse the historical d767922 full02 result (5825 passed) as dirty/repaired-tree proof. Preserve prior residuals, source clocks, assessment history and all eight slots.

Only after verification: publish the exact candidate through the existing authorized route and obtain one CoS/Fable review before Step7 advancement. Reconcile canonical coordinator status with this durable recovery receipt when the concrete handoff is ready. No new paid review now, no operating changes, no accepted NETSCOUT suite repetition, no reset or deletion of other work.
