"""Offline, source-shaped review probes of immutable draft 23bfb920.

No product edits. Synthetic approvals model an input, not source authentication.
"""
import sys
sys.dont_write_bytecode = True
import os
import json
import hashlib
import traceback
from pathlib import Path
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
SRC = OUT / 'source'
RUN = OUT / sys.argv[1]
RUN.mkdir(exist_ok=False)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', LILA_SUITE_OFFLINE='1',
                  LILA_SUITE_OFFLINE_STRICT='1', TMPDIR=str(RUN))
blocked = []

def allowed(path):
    if isinstance(path, int):
        return True
    p = Path(os.fsdecode(path)).resolve()
    return p == Path('/dev/null') or p.is_relative_to(RUN)

def audit(event, args):
    if event == 'open':
        path, mode, flags = args
        writing = bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if writing and not allowed(path):
            blocked.append([event, str(path)])
            raise PermissionError('Probe write outside owned run: ' + str(path))
    if event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime'} and not allowed(args[0]):
        blocked.append([event, str(args[0])])
        raise PermissionError('Probe mutation outside owned run')
    if event in {'os.rename', 'os.link', 'os.symlink'} and not all(allowed(p) for p in args[:2]):
        blocked.append([event, str(args[:2])])
        raise PermissionError('Probe rename/link outside owned run')
    if event in {'socket.connect', 'socket.connect_ex', 'socket.bind', 'socket.getaddrinfo',
                 'subprocess.Popen', 'os.system', 'os.posix_spawn'}:
        blocked.append([event, 'blocked'])
        raise PermissionError('Offline probe forbids ' + event)

sys.addaudithook(audit)
sys.path.insert(0, str(SRC))
os.chdir(RUN)

def save(name, value):
    (RUN / name).write_text(json.dumps(value, indent=2, default=str) + '\n')

results = []
def case(name, fn):
    try:
        detail = fn()
        results.append(dict(case=name, execution='completed', **detail))
    except Exception:
        results.append(dict(case=name, execution='error', traceback=traceback.format_exc()))
    save('results.json', results)

try:
    from tests.test_native_notice_bridge import original_fixture, graph_fixture, write, NOW
    from agents.golden_press.retrieval import run_l1_from_sweep
    from agents.golden_press.notice_bridge import NoticeReadContext
    from agents.golden_press.evidence_pack_v2 import build_corrected_pack
    from agents.golden_press.market_map_projection import attach_v2_targets
    from agents.golden_press.external_product_projection import build_external_product_document

    def document(root, context, graph, leadgen=None):
        return build_external_product_document(market_map={}, graph_payload=graph,
            evidence_pack=json.loads((root / 'pack.json').read_text()), profile={},
            client_name='Testco', slug='testco', as_of=NOW.isoformat(),
            notice_context=context, leadgen=leadgen).to_dict()

    def slots(doc):
        return {s['slot_id']: s for s in doc['slots']}

    def control():
        root = RUN / 'positive_control'
        context, graph = graph_fixture(root)
        doc = document(root, context, graph)
        save('positive_control.document.json', doc)
        changed = deepcopy(graph)
        changed['qualified_opportunity_records'][0]['title'] = 'Invented saved graph title'
        no_context = document(root, None, graph)
        save('positive_control.no_context.json', no_context)
        return dict(context_gaps=context.gaps, qualified=graph['qualified_opportunities'],
            native_market_map_count=len(attach_v2_targets((), graph, notice_context=context)),
            changed_graph_market_map_count=len(attach_v2_targets((), changed, notice_context=context)),
            missing_context_priority_count=len(slots(no_context)['priority-pursuits']['records']),
            missing_context_raw_count=len(slots(no_context)['federal-opportunities']['records']))
    case('positive_and_saved_graph_controls', control)

    def display_injection():
        root = RUN / 'display_injection'
        sweep = original_fixture(root)
        records, _ = run_l1_from_sweep(sweep, ['packet capture'])
        pack = dict(client_name='Testco', generated_at=NOW.isoformat(),
                    records=[r.model_dump(mode='json') for r in records])
        save('display_injection.original_constructor.json', pack)
        changes = dict(contact_name='Synthetic Unsourced Official',
            contact_email='unsourced@example.invalid', contact_phone='555-0100',
            ceiling_dollars=990000000, sub_agency='Synthetic Unsourced Buyer')
        pack['records'][0].update(changes)
        write(root / 'pack.json', pack)
        context = NoticeReadContext(root, 'Testco', 'testco', NOW)
        _, graph = build_corrected_pack('testco', 'Testco', root=root,
            pressed_pack_path=root / 'pack.json', pack_dir=root / 'output', notice_context=context)
        mm = [asdict(r) for r in attach_v2_targets((), graph, notice_context=context)]
        save('display_injection.market_map.json', mm)
        doc = document(root, context, graph)
        save('display_injection.document.json', doc)
        serialized = json.dumps(dict(graph=graph, market_map=mm, doc=doc))
        return dict(changes_only_to_saved_pack=changes,
            originals_contain_unsourced_tokens='unsourced' in json.dumps(sweep).casefold(),
            context_gaps=context.gaps, qualified=graph['qualified_opportunities'],
            graph_admission=graph['records'][0]['notice_admission']['admitted'],
            published_value=[q.get('published_value') for q in graph['qualified_opportunity_records']],
            native_market_map_count=len(mm), unsourced_contact_survives='unsourced@example.invalid' in serialized,
            external_rows=slots(doc)['federal-opportunities']['records'])
    case('saved_pack_contact_value_injection', display_injection)

    def saved_leadgen():
        root = RUN / 'saved_leadgen'
        context, graph = graph_fixture(root)
        leadgen = dict(status='complete', receipt=dict(client_name='Testco',
            parents=[dict(assessment_id='synthetic-parent-N1', notice_id='N1',
                          live_classification='bid_now')],
            leads=[dict(parent_assessment_id='synthetic-parent-N1', lead_tier='LEAD_T1')]))
        save('saved_leadgen.input.json', leadgen)
        before = document(root, context, graph, leadgen)
        path = root / 'data/cleaned/searches_testco.json'
        value = json.loads(path.read_text())
        value['results']['sam.gov'][0]['raw_payload']['active'] = 'No'
        write(path, value)
        stale = document(root, context, graph, leadgen)
        missing = document(root, None, graph, leadgen)
        plain = document(root, context, graph)
        for name, doc in [('before', before), ('stale', stale), ('missing', missing), ('no_leadgen', plain)]:
            save('saved_leadgen.' + name + '.json', doc)
        return dict(leadgen_input='Synthetic saved companion projection; not a live persisted LeadGen run',
            original_source_now_inactive=True, graph_still_accepted=context.accepts_graph(graph),
            market_map_after_source_change=len(attach_v2_targets((), graph, notice_context=context)),
            priorities={name: slots(doc)['priority-pursuits']['records']
                for name, doc in [('before', before), ('stale', stale), ('missing', missing), ('no_leadgen', plain)]},
            stale_opportunity_rows=slots(stale)['federal-opportunities']['records'],
            stale_graph_receipt=stale['graph_receipt'])
    case('saved_leadgen_after_source_invalidation', saved_leadgen)

    def omitted_latest():
        root = RUN / 'omitted_latest'
        def mutate(sweep):
            first = sweep['results']['sam.gov'][0]
            first.update(agency='DHS', office='Office', solicitation='FULL-CALL-1')
            first['raw_payload'].update(agency='DHS', office='Office', solicitation='FULL-CALL-1')
            latest = deepcopy(first)
            latest.update(source_id='N2', title='Administrative cancellation', posted_date='2026-07-09')
            latest['raw_payload'].update(noticeId='N2', active='No', description_snippet='Administrative cancellation')
            latest['api_url'] = 'https://sam.gov/opp/N2/view'
            sweep['results']['sam.gov'].append(latest)
            sweep['results']['sam_census']['matched'] = 2
        sweep = original_fixture(root, mutate)
        records, _ = run_l1_from_sweep(sweep, ['packet capture'])
        # Deliberately retain the search-hit older posting; the complete original sweep has latest N2.
        rows = [r.model_dump(mode='json') for r in records if r.record_id == 'N1']
        pack = dict(client_name='Testco', generated_at=NOW.isoformat(), records=rows)
        write(root / 'pack.json', pack)
        context = NoticeReadContext(root, 'Testco', 'testco', NOW)
        _, graph = build_corrected_pack('testco', 'Testco', root=root,
            pressed_pack_path=root / 'pack.json', pack_dir=root / 'output', notice_context=context)
        doc = document(root, context, graph)
        save('omitted_latest.document.json', doc)
        return dict(native_source_ids=[r['source_id'] for r in sweep['results']['sam.gov']],
            saved_pack_ids=[r['record_id'] for r in rows], context_gaps=context.gaps,
            qualified=graph['qualified_opportunities'],
            graph_rows=[dict(record_id=r['record_id'], canonical_record_id=r.get('canonical_record_id'),
                title=r['title'], family_member_ids=r.get('family_member_ids')) for r in graph['records']],
            external_rows=slots(doc)['federal-opportunities']['records'])
    case('latest_closed_no_term_absent_from_pack', omitted_latest)
except Exception:
    save('bootstrap_error.json', dict(traceback=traceback.format_exc()))
finally:
    modules = {}
    for name, module in list(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if path and Path(path).resolve().is_relative_to(SRC):
            p = Path(path).resolve()
            modules[str(p.relative_to(SRC))] = hashlib.sha256(p.read_bytes()).hexdigest()
    save('run_receipt.json', dict(at_utc=datetime.now(timezone.utc).isoformat(),
        python=sys.version, executable=sys.executable, source_commit='23bfb920df1cda3861f96142cde0e413d27537bd',
        source_root=str(SRC), write_root=str(RUN), offline=True, subprocesses_forbidden=True,
        synthetic_only=True, stored_approval_is_not_independent_authentication=True,
        blocked_operations=blocked, loaded_source_hashes=modules,
        probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
print(json.dumps(results, indent=2, default=str))
