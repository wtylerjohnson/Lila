# Step6 bounded draft review

REPAIR-STEP6-REVIEW-051. Review complete with open findings; this is not acceptance, publication, Fable review, operating-version proof or Step7 authorization.

Reviewed immutable draft `23bfb920df1cda3861f96142cde0e413d27537bd` and coordinator delta `d767922b5f462308d2e62d2cff42c052e26f6a7e`. Both were exported with `git archive` from the existing checkout. All executable imports came from owned exports. The coordinator's mutable tree was not tested. Synthetic original sweeps, taxonomy/profile, bound requirement reviews, native Assess pointers/artifacts, constructor packs and graph outputs are retained per attempt. Stored synthetic approvals model the review input; they do not authenticate the source independently.

## Findings

### LILA-051-R1 — P1: saved LeadGen tiers restore priorities after source admission fails

Confirmed on both drafts. In `agents/golden_press/external_product_projection.py:327-335`, a rejected/missing current context empties the qualified lists but retains prior positive fields on diagnostic rows. Lines 403-412 and 436-451 attach supplied companion children by parent notice ID; lines 593-598 rank those rows whenever a child says `LEAD_T1` or `LEAD_T2`. The new forecast-priority change does not close this path.

Repro: build the native source-shaped N1 positive fixture, then change only its original sweep's `raw_payload.active` to `No`. Pass the already-built graph and context plus a synthetic saved companion containing a Testco parent for N1 and a `LEAD_T1` child to `build_external_product_document`. The context rejects the graph and `attach_v2_targets` returns zero. The external document nevertheless contains one ranked pursuit. Removing the context also produces one priority; removing the companion produces zero. The retained row still says `current_opportunity`, `live`, `direct`, and `LEAD_T1`, with the prior response deadline.

Evidence: `initial-01/results.json`, `delta-01/results.json`, and `delta-01/saved_leadgen.{input,before,stale,missing,no_leadgen}.json`. The fixture deliberately supplies a minimal companion projection, not a fabricated claim that a complete persisted LeadGen run passed validation. The ordinary bundle passes the companion and context separately (`product_bundle.py:273-314`); the companion is constructed before the graph context. Thus this confirms the consumer boundary failure, not a complete released-bundle exploit or live market result.

Minimal repair: require current admitted notice identity and matching current Assess provenance before companion T1/T2 can create a notice priority. Clear active qualifications, routes, lead tier claims and target authority when admission expires; retain the diagnostic row with explicit stale/unverified status. Preserve separately authorized parent-only research as research, without promoting it to current notice qualification. Add this stale/missing-context companion case beside the forecast and saved-graph refusal tests. Check validity again after projection, so a changed input cannot leave a positive return.

### LILA-051-R2 — P1: original notice admission does not bind material contact/value fields

Independently confirmed on `23bfb920`; overlaps coordinator `S6-LOCAL-001`. No duplicate delta test was run after the coordinator reported the same issue on `d767922` and took ownership of its repair.

Only the saved constructor pack was changed: contact name/email/phone, sub-agency and `ceiling_dollars=990000000`. The original sweep, source transport, Assess run and requirement review remained intact. Graph admission stayed true and N1 remained qualified. Its qualified record reported the invented value and sub-agency; the native Market Map and external document carried `unsourced@example.invalid`. The target is labeled `published_contact`/`sourced` with SAM notice provenance even though the original has no such contact.

Cause: `notice_bridge.py:208-219` checks title, agency, office, URL and description only. `evidence_route.py:711-747` retains other supplied fields. `evidence_pack_v2.py:102-115` treats supplied contact fields as published, and lines 405-421 copy sub-agency/value into qualified facts. `external_product_projection.py:417-424` also restores contacts directly from the pack when target rows are empty.

Evidence: `initial-01/display_injection.original_constructor.json`, its mutated `display_injection/pack.json`, unchanged original `data/cleaned/searches_testco.json`, `display_injection/output/testco.evidence_pack.v2.json`, `display_injection.market_map.json`, and `display_injection.document.json`.

Attempt disclosure: the case's final summary serialization raised `TypeError: Decimal is not JSON serializable` after all product outputs had been written. The error is preserved in `initial-01/results.json`; the on-disk product artifacts establish the finding. `DISPLAY_INJECTION_RECOVERY.json` records a read-only extraction from them. The harness serialization was fixed for subsequent work, without rerunning this case or editing product code.

Minimal repair: derive every positive material display field from the currently bound original/source depth or separately checked source evidence, including secondary contacts, small-business POC, buyer components, amounts, access display and incumbent claims. Missing source facts stay missing. Sanitize the external pack-contact fallback too. Keep enrichment identity evidence distinct from published notice contact evidence.

### LILA-051-R3 — P2: external assessment loses the current closed family representative

Confirmed on both drafts. Original source has N1 followed by newer closed N2, with the same complete solicitation/agency/office namespace. The selected pack contains only lexical-hit N1. Qualification is correctly zero. The graph retains both original members and sets `canonical_record_id=N2`, while retaining N1 as its selected row. The external assessment shows only N1's title/link/deadline and `window_state=live`; it drops the current representative and member history, leaving a generic superseded-or-unresolved hold reason.

Evidence: `delta-01/omitted_latest/output/testco.evidence_pack.v2.json`, `delta-01/omitted_latest.document.json`, and the corresponding result entry. Source locations: `evidence_pack_v2.py:51-73` and `external_product_projection.py:378-400`. Coordinator's new no-term case intentionally retains one selected record; this review agrees with preserving that slice. This is a diagnostic/display omission, not a failed closed-notice qualification guard or a request to replace/backfill native results.

Minimal repair: keep N1 and its native position, but attach/display the current family representative ID/title/source URL/status plus the retained member/suppression history. Distinguish N1's historical response window from the current family's closed status. Do not fabricate unavailable revisions or add N2 as a replacement search result.

## Controls, delta and limits

On each draft, the original source-shaped positive produced N1 and one native Market Map row. Editing the saved graph title produced zero Market Map rows. Missing current context with no companion produced zero external priorities while retaining one raw assessment row. Making the original inactive invalidated the existing context and removed the Market Map positive. A newer closed/no-term sibling suppressed the older positive on both drafts. There were no blocked network, subprocess or out-of-owned-run write attempts.

The delta changed original namespace handling, generic adapter compatibility, absent SQL active-column behavior, cache route overlay, forecast priorities and parent clock copy. Their specific regression closures were not independently rerun here: coordinator owns its 24 focused tests and broad regression. Our three relevant delta probe groups completed; R1 and R3 remain open. R2 is independently reproduced on the initial draft and separately coordinator-confirmed on the delta. The coordinator also owns `S6-LOCAL-002` (legacy triage cross-post collapse); it is not counted as an independently reproduced finding here.

Static risks, not reproduced failures:

- `NoticeReadContext._load` compares the Assess projection manifest once (`notice_bridge.py:146-155`), but `unchanged()` rehashes only `self.files`. Vehicle-reference/entity-crosswalk inputs included by `ledger.py:2260-2306` are not added to that tracked set, and their paths are still module/default-root based. A reference drift during a warm context was not exercised; its effect on current notice qualification is not established. Include those dependencies in a root-explicit manifest/recheck if the context claims to bind them.
- The external raw-assessment path can use pack `generated_at` as `source_as_of` (`external_product_projection.py:397-398`). The renderer calls this “Evidence date” when no acquisition status exists. Do not reinterpret it as native acquisition. Parent-only HTML now explicitly marks acquisition as unestablished; no current-clock or source-authentication proof follows from that copy change.
- Access vocabulary is intentionally conservative. Missing/unrecognized/conflicting access is not direct eligibility; contacts/incumbents do not supply eligibility. No new access policy, certification, independent source authentication or live clock result was established by this review.

No full regression, live query, browser acceptance, real source replay, seller-ready yield, root/NETSCOUT schema3 import, production operation or frozen-case mutation was performed. Prior Step1 R1-R7 and accepted Step3/4/5 residuals remain. No product patch, branch creation or service operation occurred. One actionable progress notification was sent for R1; the completion receipt is the checkpoint handoff.

## Reproduction

Initial invocation: existing `/Users/wtjohnson/Lila/.venv/bin/python`, `probe_review.initial-01.py initial-01` (the preserved script is the exact version invoked under its original `probe_review.py` name). `initial-01` already exists; use a new owned attempt directory to reproduce without overwriting evidence.

Delta invocation: `probe_review.py delta-01 source-d767922 d767922b5f462308d2e62d2cff42c052e26f6a7e positive_and_saved_graph_controls,saved_leadgen_after_source_invalidation,latest_closed_no_term_absent_from_pack` using the same existing Python environment. Source exports must remain unchanged. Both scripts enforce offline execution, reject subprocesses and writes outside their new owned attempt directory, and disable bytecode writes. Exact script/import/archive hashes and attempt outcomes are in `VERIFICATION.json`, run receipts and `SOURCE_HASHES.json`.
