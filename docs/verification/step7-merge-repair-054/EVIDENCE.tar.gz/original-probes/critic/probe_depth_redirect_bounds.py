"""Critic probe: bound the N-05 / F-22 depth-origin residual, and close the
admitted LeadRow gap for receipt-only fields.

Part 1 - when exactly does the keyed depth path adopt another notice's text?
  a) redirect target serves an id-less description body  -> adopted?
  b) redirect target serves a body carrying ITS OWN notice id -> refused?
  c) redirect target serves a body carrying the requested id -> adopted (control)
  d) same three shapes for the keyless resources leg inside fetch_notice_depth.
Part 2 - a receipt-only field (diagnostic_text) planted in the sweep row is
  checked for arrival in the Assess run and in drafted LeadRows.
"""
import json, os, pathlib, shutil, sys

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'bounds'
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'nc')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
sys.path.insert(0, str(ROOT))

import socket
socket.socket.connect = lambda self, a, *x, **k: (_ for _ in ()).throw(OSError('blocked'))

import httpx
from tools.api import _http, sam_notice_detail as detail, sam_quota
sam_quota.note_call = lambda *a, **k: None

A = 'a' * 32
B = 'b' * 32
FOREIGN = 'The contractor shall provide lawn maintenance. NOTICE B TEXT.'
out = {}


def depth_redirect(tag, desc_body):
    cd = TMP / f'd_{tag}'; cd.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cd)
    def handler(request):
        url = str(request.url)
        if 'noticedesc' in url and f'noticeid={A}' in url:
            return httpx.Response(302, headers={'location':
                f'https://api.sam.gov/prod/opportunities/v1/noticedesc?noticeid={B}&api_key=KEY'})
        if 'noticedesc' in url:
            return httpx.Response(200, json=desc_body)
        return httpx.Response(200, json={'_links': {}})
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    d = detail.fetch_notice_depth(A, api_key='KEY')
    return {'adopted_foreign_description': 'NOTICE B TEXT' in (d.get('description') or ''),
            'description_checked': d.get('description_checked'),
            'errors': d.get('errors'),
            'persisted': (cd / f'{A}.json').exists()}


out['1_depth_description_redirect'] = {
    'a_idless_body': depth_redirect('idless', {'description': FOREIGN}),
    'b_body_carries_own_foreign_id': depth_redirect(
        'ownid', {'noticeId': B, 'description': FOREIGN}),
    'c_body_carries_requested_id': depth_redirect(
        'reqid', {'noticeId': A, 'description': FOREIGN}),
}


def resources_leg(tag, res_body):
    """The keyless resources leg inside fetch_notice_depth, over a redirect."""
    cd = TMP / f'r_{tag}'; cd.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cd)
    def handler(request):
        url = str(request.url)
        if 'noticedesc' in url:
            return httpx.Response(200, json={'description': 'own description'})
        if url.endswith(f'/{A}/resources'):
            return httpx.Response(302, headers={'location':
                f'https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources'})
        return httpx.Response(200, json=res_body)
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    d = detail.fetch_notice_depth(A, api_key='KEY')
    names = [a.get('name') for a in (d.get('attachments') or [])]
    return {'resources_checked': d.get('resources_checked'),
            'attachment_names': names,
            'adopted_foreign_rows': 'B SOW.pdf' in names,
            'errors': d.get('errors')}


row_idless = {'opportunityAttachmentList': [{'attachments': [
    {'resourceId': 'c' * 32, 'name': 'B SOW.pdf', 'accessLevel': 'public'}]}]}
row_ownid = {'opportunityAttachmentList': [{'attachments': [
    {'resourceId': 'c' * 32, 'name': 'B SOW.pdf', 'accessLevel': 'public',
     'opportunityId': B}]}]}
out['2_depth_resources_redirect'] = {
    'a_idless_rows': resources_leg('idless', row_idless),
    'b_rows_carry_foreign_id': resources_leg('ownid', row_ownid),
}

# ---- Part 2: receipt-only canary into Assess and LeadRow -------------------
from agents.assess.contracts import LiveClassification
from agents.leadgen.from_assess import draft_lead_rows
from tests.test_assess_ledger import _sweep, _depth_record, _build_with_requirement_review

CANARY = 'ZZCANARYDIAGNOSTICTEXTZZ'
sweep = _sweep()
sweep['results']['dossiers'] = {'depth_records': [_depth_record()]}
sweep['results']['sam.gov'][0]['raw_payload'].update({
    'attachment_record_receipts_leak': {'files': [{'diagnostic_text': CANARY,
                                                   'retention_errors': [CANARY]}]}})
run, _dg, _ix = _build_with_requirement_review(sweep)
rec = next(r for r in run.live.records if r.notice_id == 'N1')
drafts = draft_lead_rows(run)
lead_blob = drafts.model_dump_json()
out['3_receipt_field_canary'] = {
    'classification': rec.classification.value,
    'canary_in_assess_record': CANARY in rec.model_dump_json(),
    'canary_in_assess_run': CANARY in run.model_dump_json(),
    'lead_rows': len(drafts.leads),
    'canary_in_leadrows': CANARY in lead_blob,
}

status = 'INFO'
if out['3_receipt_field_canary']['canary_in_leadrows'] or \
        out['3_receipt_field_canary']['canary_in_assess_record']:
    status = 'FAIL'
print(json.dumps({'status': status, 'observed': out}, indent=1, ensure_ascii=False))
