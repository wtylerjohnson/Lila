"""Critic probe: F-10 (withdrawn attachments counted) on the TRUSTED depth
surface, using real captured SAM bodies.

Writes a genuine 052-era depth cache with base 67f644b code, then reads it with
the candidate fetch_notice_depth, keyless and keyed, and reports whether the
withdrawn rows are still counted as live and whether any refetch happens.
"""
import json, os, pathlib, shutil, subprocess, sys, importlib.util

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
BODIES = pathlib.Path('/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/'
                      'extracted/source-proof/public-inventory-001')
TMP = PROBE / '_tmp' / 'f10depth'
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'nc')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
sys.path.insert(0, str(ROOT))

import socket
socket.socket.connect = lambda self, a, *x, **k: (_ for _ in ()).throw(OSError('blocked'))

import httpx
from tools.api import _http, sam_notice_detail as detail, sam_quota
sam_quota.note_call = lambda *a, **k: None


def load_base(rel, name):
    src = subprocess.run(['git', '-C', str(ROOT), 'show', f'67f644b:{rel}'],
                         capture_output=True, text=True, check=True).stdout
    p = PROBE / f'_base_{name}.py'; p.write_text(src)
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec); sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


base = load_base('tools/api/sam_notice_detail.py', 'b_detail_f10')
base.sam_quota.note_call = lambda *a, **k: None

out = {'bodies': {}}
DESC = 'The contractor shall provide services.'

for body_path in sorted(BODIES.glob('*.body')):
    nid = body_path.stem
    raw = body_path.read_bytes()
    # which rows does the CANDIDATE consider withdrawn?
    try:
        parsed = json.loads(raw)
    except ValueError:
        continue
    active, recognized = detail._attachment_inventory(parsed, nid)
    withdrawn = detail._withdrawn_inventory(parsed, nid)
    if not recognized or not withdrawn:
        continue
    cd = TMP / f'cache_{nid}'; cd.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cd)
    calls = []
    def handler(request, raw=raw):
        calls.append(str(request.url))
        url = str(request.url)
        if 'noticedesc' in url:
            return httpx.Response(200, json={'description': DESC})
        return httpx.Response(200, content=raw)
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    # base imports get_json from tools.api._http, so patching _http._client covers both
    # 1. base writes the 052-era depth cache
    base_depth = base.fetch_notice_depth(nid, api_key='KEY')
    base_calls = len(calls)
    saved = json.loads((cd / f'{nid}.json').read_text())
    # 2. candidate reads it, keyless (no SAM key at all)
    calls.clear()
    os.environ.pop('SAM_GOV_API_KEY', None)
    def dead(request):
        calls.append('NET ' + str(request.url))
        raise httpx.ConnectError('offline')
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(dead), follow_redirects=True)
    cand = detail.fetch_notice_depth(nid)
    keyless_calls = list(calls)
    disk_after = json.loads((cd / f'{nid}.json').read_text())
    withdrawn_names = {w.get('name') for w in withdrawn}
    listed_names = {a.get('name') for a in (cand.get('attachments') or [])}
    out['bodies'][nid] = {
        'active_rows_fresh_053': len(active),
        'withdrawn_rows_053': len(withdrawn),
        'base_written_count': saved.get('attachment_inventory_count'),
        'base_written_hash': (saved.get('attachment_inventory_hash') or '')[:12],
        'candidate_cached_count': cand.get('attachment_inventory_count'),
        'candidate_cached_hash': (cand.get('attachment_inventory_hash') or '')[:12],
        'candidate_from_cache': cand.get('from_cache'),
        'withdrawn_still_listed_live': sorted(withdrawn_names & listed_names),
        'withdrawn_attachments_key': cand.get('withdrawn_attachments'),
        'keyless_network_calls': keyless_calls,
        'disk_count_after_read': disk_after.get('attachment_inventory_count'),
        'fresh_053_hash': detail._manifest_hash(active)[:12],
    }

leaked = {k: v for k, v in out['bodies'].items() if v['withdrawn_still_listed_live']}
out['notices_with_withdrawn_rows'] = len(out['bodies'])
out['notices_where_052_depth_still_counts_withdrawn_as_live'] = len(leaked)
print(json.dumps({'status': 'FAIL' if leaked else 'PASS', 'observed': out},
                 indent=1, ensure_ascii=False))
