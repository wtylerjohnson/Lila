"""Critic probe (blocking question b): can wrong-notice evidence be attributed
as THIS notice's research through a production path on the candidate?

Three production chains, all over httpx.MockTransport, no live socket:
  A. keyless inventory: foreign notice id carried only in a query string /
     fragment of a row download URL -> does run_searches bind B's text to A?
  B. metered depth: 302 from A's noticedesc route to B's noticedesc route
     serving an id-less description -> adopted as A's description, persisted,
     and projected by run_dossiers into source_depth.description.
  C. does that adopted description reach a BID_NOW requirement excerpt in the
     production Assess ledger?
Base 67f644b is loaded side by side for B to classify pre_existing vs new.
"""
import json, os, pathlib, sys, hashlib, importlib.util, subprocess, copy

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'wrongnotice'
if TMP.exists():
    import shutil; shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'notice_cache')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'text_cache')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'sam_ledger.json')
sys.path.insert(0, str(ROOT))

import socket
_BLOCKED = []
def _no_connect(self, addr, *a, **k):
    _BLOCKED.append(str(addr)); raise OSError('probe: network blocked')
socket.socket.connect = _no_connect

import httpx
from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail
from tools.api import sam_quota
sam_quota.note_call = lambda *a, **k: None

A = 'a' * 32
B = 'b' * 32
out = {}


def bind(handler):
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)


# ---------------- A. keyless inventory: foreign id in query / fragment -------
def inventory_case(label, row_extra):
    cache = TMP / f'inv_{label}'
    cache.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cache)
    body = {'opportunityAttachmentList': [{
        'attachments': [dict({'resourceId': 'c' * 32, 'name': 'B SOW.txt',
                              'accessLevel': 'public'}, **row_extra)]}]}
    seen = []
    def handler(request):
        seen.append(str(request.url))
        return httpx.Response(200, content=json.dumps(body).encode())
    bind(handler)
    res = detail.fetch_notice_resources(A)
    return {'collection_status': res.get('collection_status'),
            'resources_checked': res.get('resources_checked'),
            'rows': len(res.get('attachments') or []),
            'requests': seen}


out['A_query_and_fragment_carriers'] = {
    'query_noticeid': inventory_case('q', {
        'downloadUrl': f'https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{"c"*32}/download?noticeid={B}'}),
    'fragment_id': inventory_case('f', {
        'downloadUrl': f'https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{"c"*32}/download#{B}'}),
    'path_id_control': inventory_case('p', {
        'downloadUrl': f'https://sam.gov/api/prod/opps/v3/opportunities/{B}/resources/download'}),
}

# end to end: does the query-carrier body's text become A's research?
import run_searches as searches
from agents.schemas import RawOpportunity
from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm

cache = TMP / 'e2e'; cache.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(cache)
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'e2e_text')
(TMP / 'e2e_text').mkdir(parents=True, exist_ok=True)
body = {'opportunityAttachmentList': [{'attachments': [{
    'resourceId': 'c' * 32, 'name': 'B SOW.txt', 'accessLevel': 'public',
    'downloadUrl': f'https://sam.gov/api/prod/opps/v3/opportunities/resources/files/{"c"*32}/download?noticeid={B}'}]}]}
def handler(request):
    return httpx.Response(200, content=json.dumps(body).encode())
bind(handler)
sat._download_bytes = lambda rid, **k: b'Notice B buyer requires network visibility for another solicitation.'
sam_quota.calls_today = lambda: 0
candidate = RawOpportunity(source='sam.gov', source_id=A, title='Notice A',
                           agency='NASA', raw_payload={'type': 'Solicitation'})
class Source:
    last_attachment_census = {'selected': 1}
    def attachment_candidates(self, *a, **k):
        return [candidate]
rows, stats = searches._enrich_sam_public_attachments(
    [], Source(), object(),
    CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21',
                       core=[TaxonomyTerm(term='network visibility')]), None, limit=8)
raw = rows[0]['raw_payload'] if rows else {}
coll = raw.get('attachment_collection_v1') or {}
out['A_end_to_end_query_carrier'] = {
    'rows': len(rows),
    'collection_notice_id': coll.get('notice_id'),
    'b_text_bound_to_a': 'Notice B buyer requires' in json.dumps(raw, ensure_ascii=False),
    'record_status': (stats.get('attachment_record_receipts', {}).get(A, {}) or {}).get('status'),
}

# ---------------- B. metered depth over a redirect --------------------------
DESC_TEXT = ('The contractor shall provide an enterprise packet capture '
             'platform for CISA network operations. THIS IS NOTICE B TEXT.')

def depth_case(module, tag, cachedir, redirect_to, res_body=None):
    cachedir.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cachedir)
    seen = []
    def handler(request):
        url = str(request.url)
        seen.append(url)
        if 'noticedesc' in url and f'noticeid={A}' in url:
            return httpx.Response(302, headers={'location': redirect_to})
        if 'noticedesc' in url:
            return httpx.Response(200, json={'description': DESC_TEXT})
        if url.endswith('/resources'):
            return httpx.Response(200, json=(res_body or {'_links': {}}))
        return httpx.Response(404, content=b'{}')
    bind(handler)
    depth = module.fetch_notice_depth(A, api_key='KEY')
    saved = (cachedir / f'{A}.json')
    return {'id': depth.get('id'),
            'description': (depth.get('description') or '')[:80],
            'description_checked': depth.get('description_checked'),
            'adopted_foreign_description': 'NOTICE B TEXT' in (depth.get('description') or ''),
            'errors': depth.get('errors'),
            'requests': seen,
            'persisted': saved.exists(),
            'persisted_has_foreign_text': (
                'NOTICE B TEXT' in saved.read_text() if saved.exists() else None)}

# base module side by side
base_src = subprocess.run(['git', '-C', str(ROOT), 'show',
                           '67f644b:tools/api/sam_notice_detail.py'],
                          capture_output=True, text=True, check=True).stdout
base_path = PROBE / '_base_sam_notice_detail.py'
base_path.write_text(base_src)
spec = importlib.util.spec_from_file_location('base_sam_notice_detail', base_path)
base_mod = importlib.util.module_from_spec(spec)
sys.modules['base_sam_notice_detail'] = base_mod
spec.loader.exec_module(base_mod)
base_mod.sam_quota.note_call = lambda *a, **k: None

for tag, target in [
        ('redirect_to_other_notice', f'https://api.sam.gov/prod/opportunities/v1/noticedesc?noticeid={B}&api_key=KEY'),
        ('redirect_off_host', 'https://attachments.example.net/noticedesc?noticeid=zzz')]:
    out.setdefault('B_depth_redirect', {})[tag] = {
        'candidate': depth_case(detail, tag, TMP / f'depth_cand_{tag}', target),
        'base': depth_case(base_mod, tag, TMP / f'depth_base_{tag}', target),
    }

# ---------------- C. does the adopted description reach BID_NOW? ------------
from agents.assess.contracts import LiveClassification
from tests.test_assess_ledger import _sweep, _depth_record, _build_with_requirement_review

adopted = out['B_depth_redirect']['redirect_to_other_notice']['candidate']
sweep = _sweep()
d = _depth_record()
# exactly what run_dossiers.py projects: depth['description'] verbatim
d['source_depth']['description'] = DESC_TEXT
sweep['results']['dossiers'] = {'depth_records': [d]}
try:
    run, _dg, _ix = _build_with_requirement_review(sweep)
    rec = next(r for r in run.live.records if r.notice_id == 'N1')
    out['C_foreign_description_to_bid_now'] = {
        'classification': rec.classification.value,
        'is_bid_now': rec.classification == LiveClassification.BID_NOW,
        'requirement_excerpt': rec.requirement_excerpt,
        'excerpt_is_foreign_text': (rec.requirement_excerpt or '') in DESC_TEXT,
    }
except Exception as exc:
    out['C_foreign_description_to_bid_now'] = {'error': f'{type(exc).__name__}: {exc}'}

out['network_connect_attempts'] = len(_BLOCKED)

wrong_notice_reachable = (
    out['A_end_to_end_query_carrier']['b_text_bound_to_a']
    or out['B_depth_redirect']['redirect_to_other_notice']['candidate']['adopted_foreign_description'])
print(json.dumps({'status': 'FAIL' if wrong_notice_reachable else 'PASS',
                  'observed': out}, indent=1, ensure_ascii=False))
