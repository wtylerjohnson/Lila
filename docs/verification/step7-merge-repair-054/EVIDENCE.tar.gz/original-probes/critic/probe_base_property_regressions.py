"""Critic probe (blocking question c): did any property that HELD at the
accepted base 67f644b regress at the candidate?

R1 read-only cache tree: a valid retained object is read at base and refused
   at the candidate because read_retained now takes a writing advisory lock.
R2 unencodable extracted text: base = unreadable with no text; candidate =
   retention_failed carrying the raw unencodable text into the receipt, which
   the JSON sweep writer then cannot serialize.
R3 own-notice inventory yield: a body whose self href spells THIS notice id in
   uppercase, and a body with an unparseable href, are captured at base and
   refused wholesale at the candidate (identity_mismatch, zero rows).
Base modules are loaded side by side from git show 67f644b.
"""
import json, os, pathlib, sys, shutil, subprocess, importlib.util, stat

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'regress'
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'nc')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
sys.path.insert(0, str(ROOT))

import socket
_BLOCKED = []
socket.socket.connect = lambda self, a, *x, **k: (_BLOCKED.append(str(a)),
                                                  (_ for _ in ()).throw(OSError('blocked')))[1]

import httpx
from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail
from tools.api import sam_capture, sam_quota
sam_quota.note_call = lambda *a, **k: None

out = {}


def load_base(rel, name):
    src = subprocess.run(['git', '-C', str(ROOT), 'show', f'67f644b:{rel}'],
                         capture_output=True, text=True, check=True).stdout
    path = PROBE / f'_base_{name}.py'
    path.write_text(src)
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


base_capture = load_base('tools/api/sam_capture.py', 'base_sam_capture')
base_text = load_base('tools/api/sam_attachment_text.py', 'base_sam_attachment_text')
base_detail = load_base('tools/api/sam_notice_detail.py', 'base_sam_notice_detail2')
base_detail.sam_quota.note_call = lambda *a, **k: None

# -------------------- R1 read-only cache tree -------------------------------
ro = TMP / 'readonly_cache'
(ro / 'objects').mkdir(parents=True)
payload = b'retained inventory bytes'
receipt = sam_capture.retain_bytes(ro, payload)
# drop the lock dir the write created so the tree is a clean 052-era cache
if (ro / 'object_locks').exists():
    shutil.rmtree(ro / 'object_locks')
for d in (ro / 'objects', ro):
    os.chmod(d, stat.S_IRUSR | stat.S_IXUSR)
r1 = {}
for label, mod in (('base', base_capture), ('candidate', sam_capture)):
    try:
        got = mod.read_retained(ro, dict(receipt))
        r1[label] = {'read': True, 'bytes_equal': got == payload, 'error': None}
    except Exception as exc:
        r1[label] = {'read': False, 'bytes_equal': None,
                     'error': f'{type(exc).__name__}: {exc}'}
os.chmod(ro, stat.S_IRWXU); os.chmod(ro / 'objects', stat.S_IRWXU)
r1['regressed'] = bool(r1['base']['read'] and not r1['candidate']['read'])
out['R1_readonly_cache_tree'] = r1

# consequence: does a read-only cache turn a cached inventory into a refetch?
def inventory_offline(mod, cachedir, prepare_with):
    cachedir.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cachedir)
    body = json.dumps({'opportunityAttachmentList': [{'attachments': [
        {'resourceId': 'c' * 32, 'name': 'SOW.txt', 'accessLevel': 'public',
         'opportunityId': 'a' * 32}]}]}).encode()
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(200, content=body)
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    prepare_with.fetch_notice_resources('a' * 32)
    if (cachedir / 'object_locks').exists():
        shutil.rmtree(cachedir / 'object_locks')
    for d in [cachedir / 'objects', cachedir]:
        os.chmod(d, stat.S_IRUSR | stat.S_IXUSR)
    def dead(request):
        calls.append('REFETCH ' + str(request.url))
        raise httpx.ConnectError('offline')
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(dead), follow_redirects=True)
    try:
        res = mod.fetch_notice_resources('a' * 32)
    finally:
        os.chmod(cachedir, stat.S_IRWXU); os.chmod(cachedir / 'objects', stat.S_IRWXU)
    return {'collection_status': res.get('collection_status'),
            'from_cache': res.get('from_cache'),
            'rows': len(res.get('attachments') or []),
            'refetch_attempted': any(c.startswith('REFETCH') for c in calls)}


out['R1b_readonly_cache_offline_inventory'] = {
    'base': inventory_offline(base_detail, TMP / 'ro_inv_base', base_detail),
    'candidate': inventory_offline(detail, TMP / 'ro_inv_cand', detail),
}

# -------------------- R2 unencodable extracted text -------------------------
BAD = 'Requirement \ud800 text'


def text_case(mod, cachedir):
    cachedir.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(cachedir)
    mod._download_bytes = lambda *a, **k: b'pdf bytes'
    mod._text_from_bytes = lambda *a, **k: BAD
    res = mod.extract_public_attachment_text(
        {'resource_id': 'b' * 32, 'name': 'SOW.pdf', 'access_level': 'public',
         'access_status': 'public', 'export_controlled': '0', 'explicit_access': '0'})
    serializable = True
    ser_error = None
    try:
        json.dumps(res)
    except Exception as exc:
        serializable = False
        ser_error = f'{type(exc).__name__}: {exc}'
    return {'collection_status': res.get('collection_status'),
            'text': res.get('text'),
            'has_diagnostic_text': 'diagnostic_text' in res,
            'diagnostic_text_is_raw_unencodable': res.get('diagnostic_text') == BAD,
            'error': (res.get('error') or '')[:120],
            'receipt_json_serializable': serializable,
            'serialize_error': ser_error}


r2 = {'base': text_case(base_text, TMP / 'txt_base'),
      'candidate': text_case(sat, TMP / 'txt_cand')}
r2['regressed'] = bool(r2['base']['receipt_json_serializable']
                       and not r2['candidate']['receipt_json_serializable'])
out['R2_unencodable_text'] = r2

# -------------------- R3 own-notice inventory yield -------------------------
def inv_body_case(mod, cachedir, links):
    cachedir.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cachedir)
    body = {'opportunityAttachmentList': [{'attachments': [
        {'resourceId': 'c' * 32, 'name': 'SOW.txt', 'accessLevel': 'public',
         'opportunityId': 'a' * 32}]}], '_links': links}
    def handler(request):
        return httpx.Response(200, content=json.dumps(body).encode())
    _http._client = lambda timeout: httpx.Client(
        transport=httpx.MockTransport(handler), follow_redirects=True)
    res = mod.fetch_notice_resources('a' * 32)
    return {'collection_status': res.get('collection_status'),
            'rows': len(res.get('attachments') or [])}


cases = {
    'self_href_same_id_uppercase': {'self': {'href': f'https://sam.gov/opp/{"A"*32}/resources'}},
    'self_href_unparseable': {'self': {'href': 'https://sam.gov/opp/%zz/resources'}},
    'self_href_same_id_lowercase_control': {'self': {'href': f'https://sam.gov/opp/{"a"*32}/resources'}},
}
r3 = {}
for label, links in cases.items():
    r3[label] = {
        'base': inv_body_case(base_detail, TMP / f'r3_base_{label}', links),
        'candidate': inv_body_case(detail, TMP / f'r3_cand_{label}', links)}
    r3[label]['yield_lost'] = (r3[label]['base']['rows'] > 0
                               and r3[label]['candidate']['rows'] == 0)
out['R3_own_notice_inventory_yield'] = r3

out['network_connect_attempts'] = len(_BLOCKED)
regressed = (out['R1_readonly_cache_tree']['regressed']
             or out['R2_unencodable_text']['regressed']
             or any(v.get('yield_lost') for v in r3.values()))
print(json.dumps({'status': 'FAIL' if regressed else 'PASS', 'observed': out},
                 indent=1, ensure_ascii=False))
