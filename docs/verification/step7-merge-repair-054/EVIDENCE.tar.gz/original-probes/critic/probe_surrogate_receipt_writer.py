"""Critic probe: the R2 claim, tested at the real artifact writer.

json.dumps with default ensure_ascii=True tolerates a lone surrogate, so a
plain serializability check does not show the defect. The production writer
tools.artifacts.atomic_write_json uses ensure_ascii=False + encode('utf-8'),
which refuses lone surrogates. Question: does the candidate's retention_failed
receipt (which carries diagnostic_text = the raw unencodable text) make the
sweep receipt unwritable where the base receipt was writable?
"""
import json, os, pathlib, shutil, sys, subprocess, importlib.util

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'surrogate'
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'nc')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
sys.path.insert(0, str(ROOT))

import socket
socket.socket.connect = lambda self, a, *x, **k: (_ for _ in ()).throw(OSError('blocked'))

import httpx
from tools.api import _http, sam_attachment_text as sat, sam_notice_detail as detail
from tools.api import sam_quota
from tools.artifacts import atomic_write_json
sam_quota.note_call = lambda *a, **k: None
sam_quota.calls_today = lambda: 0

BAD = 'Buyer requires network visibility \ud800 truncated'
out = {}


def load_base(rel, name):
    src = subprocess.run(['git', '-C', str(ROOT), 'show', f'67f644b:{rel}'],
                         capture_output=True, text=True, check=True).stdout
    p = PROBE / f'_base_{name}.py'; p.write_text(src)
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec); sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


base_text = load_base('tools/api/sam_attachment_text.py', 'b_sat')


def run_collector(text_mod, tag):
    """Drive the real run_searches collector with a surrogate-bearing extract."""
    cachedir = TMP / f'nc_{tag}'; cachedir.mkdir(parents=True, exist_ok=True)
    textdir = TMP / f'tc_{tag}'; textdir.mkdir(parents=True, exist_ok=True)
    os.environ['LILA_NOTICE_CACHE_DIR'] = str(cachedir)
    os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(textdir)
    import run_searches as searches
    from agents.schemas import RawOpportunity
    from tools.relevance.taxonomy import CapabilityTaxonomy, TaxonomyTerm
    files = [{'resource_id': 'b' * 32, 'name': 'SOW.pdf', 'access_level': 'public',
              'access_status': 'public', 'export_controlled': '0', 'explicit_access': '0'}]
    detail.fetch_notice_resources = lambda *a, **k: {
        'id': 'a' * 32, 'resources_checked': True, 'attachments': files,
        'attachment_inventory_hash': detail._manifest_hash(files)}
    text_mod._download_bytes = lambda *a, **k: b'pdf bytes'
    text_mod._text_from_bytes = lambda *a, **k: BAD
    searches.sat = text_mod
    import tools.api.sam_attachment_text as live
    searches_sat_backup = sys.modules['tools.api.sam_attachment_text']
    sys.modules['tools.api.sam_attachment_text'] = text_mod
    candidate = RawOpportunity(source='sam.gov', source_id='a' * 32, title='Notice',
                               agency='NASA', raw_payload={'type': 'Solicitation'})
    class Source:
        last_attachment_census = {'selected': 1}
        def attachment_candidates(self, *a, **k):
            return [candidate]
    try:
        rows, stats = searches._enrich_sam_public_attachments(
            [], Source(), object(),
            CapabilityTaxonomy(client_name='Testco', version=1, updated='2026-07-21',
                               core=[TaxonomyTerm(term='network visibility')]), None, limit=8)
    finally:
        sys.modules['tools.api.sam_attachment_text'] = searches_sat_backup
        searches.sat = live
    receipts = stats.get('attachment_record_receipts', {})
    blob = {'attachment_record_receipts': receipts}
    written = True; err = None
    try:
        atomic_write_json(TMP / f'receipt_{tag}.json', blob)
    except Exception as exc:
        written = False; err = f'{type(exc).__name__}: {exc}'
    rec = receipts.get('a' * 32, {})
    file_receipt = (rec.get('files') or [{}])[0]
    return {'record_status': rec.get('status'),
            'file_status': file_receipt.get('status'),
            'file_reason': (file_receipt.get('reason') or '')[:120],
            'receipt_carries_raw_surrogate_text': BAD in json.dumps(
                receipts, ensure_ascii=True),
            'sweep_receipt_written': written,
            'writer_error': err}


# base: run_searches at 67f644b imported fewer names, so the base leg calls the
# base extractor directly and writes the same receipt shape the collector
# persists (file_receipt.update(result)).
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc_baseonly')
(TMP / 'tc_baseonly').mkdir(parents=True, exist_ok=True)
base_text._download_bytes = lambda *a, **k: b'pdf bytes'
base_text._text_from_bytes = lambda *a, **k: BAD
base_result = base_text.extract_public_attachment_text(
    {'resource_id': 'b' * 32, 'name': 'SOW.pdf', 'access_level': 'public',
     'access_status': 'public', 'export_controlled': '0', 'explicit_access': '0'})
base_blob = {'attachment_record_receipts': {'a' * 32: {'files': [dict(base_result)]}}}
base_written = True; base_err = None
try:
    atomic_write_json(TMP / 'receipt_baseonly.json', base_blob)
except Exception as exc:
    base_written = False; base_err = f'{type(exc).__name__}: {exc}'
out['base'] = {'collection_status': base_result.get('collection_status'),
               'receipt_carries_raw_surrogate_text': BAD in repr(base_result),
               'sweep_receipt_written': base_written, 'writer_error': base_err}
out['candidate'] = run_collector(sat, 'cand')
out['regressed'] = bool(out['base']['sweep_receipt_written']
                        and not out['candidate']['sweep_receipt_written'])
print(json.dumps({'status': 'FAIL' if out['regressed'] else 'INFO',
                  'observed': out}, indent=1, ensure_ascii=True))
