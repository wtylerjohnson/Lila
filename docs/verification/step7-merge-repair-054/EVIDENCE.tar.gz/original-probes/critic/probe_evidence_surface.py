"""Critic probe (blocking question a, second path): does collected attachment
text ever become AUTHORITATIVE evidence, a requirement excerpt, or a capability
term source in the strict Assess ledger on this candidate?

Not a copied-review attack: this asks whether the enrichment itself puts the
attachment text on any evidence surface the ledger reads.
"""
import json, os, pathlib, shutil, sys, copy

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'evsurface'
if TMP.exists():
    shutil.rmtree(TMP)
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'nc')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'tc')
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'ledger.json')
(TMP / 'nc').mkdir(); (TMP / 'tc').mkdir()
sys.path.insert(0, str(ROOT))

import socket
socket.socket.connect = lambda self, a, *x, **k: (_ for _ in ()).throw(OSError('blocked'))

import pytest  # noqa: F401
from agents.assess.contracts import LiveClassification
from tests.test_assess_ledger import _sweep, _depth_record, _build, _build_with_requirement_review
from tests.test_step7_evidence_collection import native_collection


class MP:
    def setenv(self, k, v): os.environ[k] = v
    def setattr(self, t, n, v=None):
        if v is None and isinstance(t, str):
            import importlib
            mod, _, attr = t.rpartition('.')
            setattr(importlib.import_module(mod), attr, n)
        else:
            setattr(t, n, v)


mp = MP()
row, stats, inventory, texts = native_collection(TMP / 'native', mp,
                                                 notice_id='N1', term='packet capture')
ATTACH_SENTENCES = [texts['b' * 32], texts['c' * 32]]
out = {}

# Case 1: enriched sweep whose DEPTH still supports the requirement (control)
sweep = _sweep()
sweep['results']['dossiers'] = {'depth_records': [_depth_record()]}
enriched = copy.deepcopy(sweep)
enriched['results']['sam.gov'][0]['raw_payload'].update(row['raw_payload'])
run, _dg, _ix = _build(enriched)
rec = next(r for r in run.live.records if r.notice_id == 'N1')
ev = [{'evidence_id': e.evidence_id, 'authority': getattr(e, 'authority', None),
       'excerpt_head': (e.excerpt or '')[:70]} for e in rec.authoritative_evidence]
out['1_enriched_with_supporting_depth'] = {
    'classification': rec.classification.value,
    'requirement_excerpt': rec.requirement_excerpt,
    'authoritative_evidence': ev,
    'attachment_text_in_any_evidence': any(
        s in json.dumps([e.model_dump(mode='json') for e in rec.authoritative_evidence],
                        ensure_ascii=False) for s in ATTACH_SENTENCES),
    'attachment_text_anywhere_in_record': any(
        s in rec.model_dump_json() for s in ATTACH_SENTENCES),
}

# Case 2: attachment text is the ONLY carrier of the capability term
only = copy.deepcopy(sweep)
d = _depth_record()
d['source_depth']['description'] = 'The contractor shall provide lawn maintenance.'
only['results']['dossiers'] = {'depth_records': [d]}
only['results']['sam.gov'][0]['title'] = 'Lawn maintenance'
only['results']['sam.gov'][0]['raw_payload']['description_snippet'] = 'Lawn maintenance'
only['results']['sam.gov'][0]['raw_payload'].update(row['raw_payload'])
run2, _dg2, _ix2 = _build(only)
rec2 = next(r for r in run2.live.records if r.notice_id == 'N1')
out['2_attachment_is_only_term_carrier'] = {
    'classification': rec2.classification.value,
    'is_bid_now': rec2.classification == LiveClassification.BID_NOW,
    'requirement_excerpt': rec2.requirement_excerpt,
    'attachment_gap': bool(rec2.attachment_gap),
    'attachment_text_anywhere_in_record': any(
        s in rec2.model_dump_json() for s in ATTACH_SENTENCES),
    'evidence_count': len(rec2.authoritative_evidence),
}

bad = (out['1_enriched_with_supporting_depth']['attachment_text_in_any_evidence']
       or out['1_enriched_with_supporting_depth']['attachment_text_anywhere_in_record']
       or out['2_attachment_is_only_term_carrier']['is_bid_now']
       or out['2_attachment_is_only_term_carrier']['attachment_text_anywhere_in_record'])
print(json.dumps({'status': 'FAIL' if bad else 'PASS', 'observed': out},
                 indent=1, ensure_ascii=False))
