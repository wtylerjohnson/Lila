"""Critic probe: is the independently supported BID_NOW control LIVE on the
candidate, and does the copied-review negative stay held?

Runs the production build_assess_run with tests/test_assess_ledger helpers.
No network (MockTransport only inside native_collection), no LLM.
"""
import json, os, pathlib, sys, tempfile, copy, hashlib

ROOT = pathlib.Path('/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
PROBE = pathlib.Path(__file__).resolve().parent
TMP = PROBE / '_tmp' / 'bid_now'
TMP.mkdir(parents=True, exist_ok=True)
os.environ['LILA_NOTICE_CACHE_DIR'] = str(TMP / 'notice_cache')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = str(TMP / 'text_cache')
(TMP / 'notice_cache').mkdir(parents=True, exist_ok=True)
(TMP / 'text_cache').mkdir(parents=True, exist_ok=True)
os.environ['LILA_SAM_LEDGER'] = str(TMP / 'sam_ledger.json')
sys.path.insert(0, str(ROOT))

import socket
_BLOCKED = []
def _no_connect(self, addr, *a, **k):
    _BLOCKED.append(str(addr))
    raise OSError('probe: network blocked')
socket.socket.connect = _no_connect

import pytest  # noqa: F401  (helpers import pytest)
from agents.assess.contracts import LiveClassification
from agents.assess.ledger import build_assess_run
from tests.test_assess_ledger import (
    _sweep, _build, _depth_record, _profile, _build_with_requirement_review,
    BINDING, NOW)
from tests.test_step7_evidence_collection import native_collection

out = {}


class MP:
    """Minimal monkeypatch stand-in with undo."""
    def __init__(self):
        self._undo = []
    def setenv(self, k, v):
        old = os.environ.get(k)
        self._undo.append(lambda: (os.environ.__setitem__(k, old) if old is not None
                                   else os.environ.pop(k, None)))
        os.environ[k] = v
    def setattr(self, target, name, value=None):
        if value is None and isinstance(target, str):
            mod, _, attr = target.rpartition('.')
            import importlib
            obj = importlib.import_module(mod)
            name_, value_ = attr, name
            old = getattr(obj, name_)
            self._undo.append(lambda: setattr(obj, name_, old))
            setattr(obj, name_, value_)
            return
        old = getattr(target, name)
        self._undo.append(lambda: setattr(target, name, old))
        setattr(target, name, value)
    def undo(self):
        for fn in reversed(self._undo):
            fn()
        self._undo = []


mp = MP()
tmp_text = TMP / 'native'
tmp_text.mkdir(parents=True, exist_ok=True)
row, stats, inventory, texts = native_collection(tmp_text, mp,
                                                 notice_id='N1', term='packet capture')
ATTACH_MARK = 'Café data'
out['attachment_text_present_in_row'] = ATTACH_MARK in json.dumps(row['raw_payload'], ensure_ascii=False)

# ---- 1. POSITIVE CONTROL, LIVE: plain vs enriched both reach BID_NOW -------
plain = _sweep()
plain['results']['dossiers'] = {'depth_records': [_depth_record()]}
enriched = copy.deepcopy(plain)
enriched['results']['sam.gov'][0]['raw_payload'].update(row['raw_payload'])
recs = []
for sweep in (plain, enriched):
    run, _d, _i = _build_with_requirement_review(sweep)
    recs.append(next(r for r in run.live.records if r.notice_id == 'N1'))
out['1_positive_control'] = {
    'plain_classification': recs[0].classification.value,
    'enriched_classification': recs[1].classification.value,
    'both_bid_now': all(r.classification == LiveClassification.BID_NOW for r in recs),
    'excerpt_identical': recs[0].requirement_excerpt == recs[1].requirement_excerpt,
    'recommendation_identical': recs[0].recommendation == recs[1].recommendation,
    'excerpt_is_depth_description': (
        recs[1].requirement_excerpt or '') in _depth_record()['source_depth']['description'],
    'attachment_mark_in_enriched_record': ATTACH_MARK in recs[1].model_dump_json(),
}

# ---- 1b. DISCRIMINATION: remove the independent support, control must drop --
broken = copy.deepcopy(plain)
bd = _depth_record()
bd['source_depth']['description'] = 'The contractor shall provide lawn maintenance.'
broken['results']['dossiers'] = {'depth_records': [bd]}
try:
    run_b, _d, _i = _build_with_requirement_review(broken)
    rec_b = next(r for r in run_b.live.records if r.notice_id == 'N1')
    broken_class = rec_b.classification.value
    broken_err = None
except Exception as exc:  # helper asserts requirement_excerpt exists
    broken_class = None
    broken_err = f'{type(exc).__name__}: {exc}'
out['1b_control_discriminates'] = {
    'classification_without_independent_support': broken_class,
    'helper_error': broken_err,
    'discriminating': broken_class != 'bid_now',
}

# ---- 2. NEGATIVE: copied review over an irrelevant trusted depth -----------
neg = _sweep()
original = neg['results']['sam.gov'][0]
original['source_id'] = row['source_id']
original['raw_payload'].update(row['raw_payload'])
original['title'] = 'Lawn maintenance'
original['raw_payload']['description_snippet'] = 'Lawn maintenance'
d = _depth_record()
d['source_depth']['description'] = 'The contractor shall provide lawn maintenance.'
neg['results']['dossiers'] = {'depth_records': [d]}
run0, _dg, _ix = _build(neg)
parent0 = next(r for r in run0.live.records if r.notice_id == row['source_id'])
reviews = {'schema_version': 1, 'client': 'Testco', 'binding': dict(BINDING), 'reviews': [{
    'notice_id': 'N1',
    'evidence_id': parent0.authoritative_evidence[-1].evidence_id,
    'excerpt': row['raw_payload']['text'].split('\n\n')[0],
    'capability_terms': ['packet capture'], 'decision': 'approved',
    'attachment_inventory_count': parent0.attachment_inventory_count,
    'attachment_inventory_hash': parent0.attachment_inventory_hash,
    'attachments_reviewed': True, 'reviewed_by': 'operator',
    'reviewed_at': NOW.isoformat()}]}
run1, _dg1, _ix1 = build_assess_run('Testco', neg, _profile(), BINDING,
                                    requirement_reviews_payload=reviews, as_of=NOW)
parent1 = next(r for r in run1.live.records if r.notice_id == 'N1')
out['2_copied_review_negative'] = {
    'classification': parent1.classification.value,
    'is_bid_now': parent1.classification == LiveClassification.BID_NOW,
    'requirement_reviewed_at': parent1.requirement_reviewed_at,
    'requirement_excerpt': parent1.requirement_excerpt,
    'attachment_gap': bool(parent1.attachment_gap),
    'attachment_mark_in_record': ATTACH_MARK in parent1.model_dump_json(),
    'held': (parent1.classification != LiveClassification.BID_NOW
             and parent1.requirement_reviewed_at is None
             and not parent1.requirement_excerpt
             and ATTACH_MARK not in parent1.model_dump_json()),
}

# ---- 3. LeadRow leak check on the enriched BID_NOW run ---------------------
from agents.leadgen.from_assess import draft_lead_rows
run_e, _d, _i = _build_with_requirement_review(enriched)
drafts = draft_lead_rows(run_e)
blob = json.dumps(json.loads(drafts.model_dump_json()), ensure_ascii=False)
attach_terms = [ATTACH_MARK, 'Buyer requires packet capture', 'Further packet capture deliverables']
out['3_leadrow'] = {
    'lead_rows': len(drafts.leads),
    'classifications': sorted({r.live_classification.value for r in drafts.parents
                               if r.live_classification}),
    'attachment_text_in_leadrows': {t: (t in blob) for t in attach_terms},
    'any_attachment_text_in_leadrows': any(t in blob for t in attach_terms),
}
# same for the copied-review negative run
drafts_n = draft_lead_rows(run1)
blob_n = json.dumps(json.loads(drafts_n.model_dump_json()), ensure_ascii=False)
out['3_leadrow_negative'] = {
    'lead_rows': len(drafts_n.leads),
    'attachment_text_in_leadrows': {t: (t in blob_n) for t in attach_terms},
    'any_attachment_text_in_leadrows': any(t in blob_n for t in attach_terms),
}

mp.undo()
out['network_connect_attempts'] = len(_BLOCKED)

status = 'PASS' if (out['1_positive_control']['both_bid_now']
                    and out['1_positive_control']['excerpt_identical']
                    and not out['1_positive_control']['attachment_mark_in_enriched_record']
                    and out['1b_control_discriminates']['discriminating']
                    and out['2_copied_review_negative']['held']
                    and not out['3_leadrow']['any_attachment_text_in_leadrows']
                    and not out['3_leadrow_negative']['any_attachment_text_in_leadrows']) else 'FAIL'
print(json.dumps({'status': status, 'observed': out}, indent=1, ensure_ascii=False))
