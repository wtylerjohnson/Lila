"""Lead check: the independently supported BID_NOW control is live on the candidate, and the copied-review negative stays held."""
import json, os, sys, tempfile
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
os.environ['LILA_NOTICE_CACHE_DIR'] = tempfile.mkdtemp(prefix='bidnow-n-')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = tempfile.mkdtemp(prefix='bidnow-t-')
import socket
socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(AssertionError('no network'))
from agents.assess.contracts import LiveClassification
from tests.test_assess_ledger import _sweep, _depth_record, _build_with_requirement_review
import copy

plain = _sweep(); plain['results']['dossiers'] = {'depth_records': [_depth_record()]}
run, _, _ = _build_with_requirement_review(plain)
rec = next(r for r in run.live.records if r.notice_id == 'N1')
out = {'probe': 'BID_NOW control live on the candidate',
       'observed': {'classification': str(rec.classification),
                    'is_bid_now': rec.classification == LiveClassification.BID_NOW,
                    'requirement_excerpt_present': bool(rec.requirement_excerpt),
                    'requirement_reviewed_at_present': rec.requirement_reviewed_at is not None,
                    'recommendation': (rec.recommendation or '')[:120]}}
out['status'] = 'PASS' if out['observed']['is_bid_now'] else 'FAIL'
print(json.dumps(out, indent=1))
