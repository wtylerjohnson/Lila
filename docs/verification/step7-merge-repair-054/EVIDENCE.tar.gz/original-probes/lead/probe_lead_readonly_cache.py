"""Lead check of N-03: does a valid cache on a read-only tree still serve offline on the candidate, as it did at base?"""
import json, os, sys, tempfile, shutil, subprocess, importlib.util, stat
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
import httpx
from tools.api import _http, sam_notice_detail as cand
A = 'a' * 32
BODY = json.dumps({'_embedded': {'opportunityAttachmentList': [{'opportunityId': A, 'attachments': [
    {'attachmentId': 'x'*32, 'resourceId': 'c'*32, 'name': 'SOW.pdf', 'type': 'file', 'accessLevel': 'public',
     'accessStatus': 'public', 'exportControlled': '0', 'explicitAccess': '0', 'mimeType': '.pdf', 'size': 10,
     'deletedFlag': '0', 'deletedDate': '', 'fileExists': '1'}]}]}}).encode()

base_src = subprocess.check_output(['git', '-C', '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054', 'show',
                                    '67f644bc31bf19eadec628b738855e7b6c152a4e:tools/api/sam_notice_detail.py'], text=True)
bp = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/_base_sam_notice_detail.py'
open(bp, 'w').write(base_src.replace('—', '-'))
spec = importlib.util.spec_from_file_location('base_detail4', bp); base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

def run(mod, drop_locks):
    d = tempfile.mkdtemp(prefix='ro-')
    os.environ['LILA_NOTICE_CACHE_DIR'] = d
    calls = []
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(
        lambda r: calls.append(str(r.url)) or httpx.Response(200, content=BODY)))
    mod.fetch_notice_resources(A)           # populate
    if drop_locks and os.path.isdir(os.path.join(d, 'object_locks')):
        shutil.rmtree(os.path.join(d, 'object_locks'))
    for root, dirs, files in os.walk(d):    # make the tree read-only
        for p in files: os.chmod(os.path.join(root, p), stat.S_IRUSR)
        os.chmod(root, stat.S_IRUSR | stat.S_IXUSR)
    calls.clear()
    try:
        res = mod.fetch_notice_resources(A)
        out = {'from_cache': res.get('from_cache'), 'status': res.get('collection_status', 'n/a'),
               'network_calls_after_readonly': len(calls), 'attachments': len(res.get('attachments') or [])}
    except Exception as exc:
        out = {'error': type(exc).__name__, 'network_calls_after_readonly': len(calls)}
    for root, dirs, files in os.walk(d):    # restore so temp cleanup can run
        os.chmod(root, 0o755)
        for p in files: os.chmod(os.path.join(root, p), 0o644)
    shutil.rmtree(d, ignore_errors=True)
    return out

obs = {'candidate_locks_removed': run(cand, True), 'base_locks_removed': run(base, True),
       'candidate_locks_present': run(cand, False)}
cand_delivers = bool(obs['candidate_locks_removed'].get('attachments'))
base_delivers = bool(obs['base_locks_removed'].get('attachments'))
print(json.dumps({'probe': 'N-03 lead check: read-only cache tree',
    'status': 'FAIL' if (base_delivers and not cand_delivers) else 'PASS',
    'observed': {**obs, 'candidate_delivers_cached_inventory': cand_delivers, 'base_delivers_cached_inventory': base_delivers,
                 'note': 'Criterion is whether the cached inventory is still delivered. Whether the base also avoids a network call depends on how the read-only tree is built; in this harness the base refetched, failed to rewrite the cache and fell back to its validated stale projection, while the candidate returned retention_failed with no inventory at all.'}}, indent=1))
