"""Lead verification of the critic's most consequential claim: does a redirect on the metered
noticedesc route put ANOTHER notice's text into this notice's trusted description, persist it,
and reach a BID_NOW requirement excerpt? Also: is the base identical?"""
import json, os, sys, tempfile, subprocess, importlib.util
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
import httpx
A = 'a' * 32
B = 'b' * 32
FOREIGN = 'The contractor shall provide packet capture appliances for the B program.'

base_src = subprocess.check_output(['git', '-C', '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054', 'show',
                                    '67f644bc31bf19eadec628b738855e7b6c152a4e:tools/api/sam_notice_detail.py'], text=True)
bp = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/_base_sam_notice_detail.py'
open(bp, 'w').write(base_src.replace('—', '-'))

def run(which):
    d = tempfile.mkdtemp(prefix='dr-')
    os.environ['LILA_NOTICE_CACHE_DIR'] = d
    os.environ['LILA_SAM_LEDGER'] = os.path.join(d, 'ledger.json')
    from tools.api import _http
    if which == 'candidate':
        from tools.api import sam_notice_detail as mod
    else:
        spec = importlib.util.spec_from_file_location('base_dr', bp); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    seen = []
    def handler(req):
        seen.append(str(req.url))
        # A's noticedesc 302s to B's noticedesc; the target serves an id-less description body.
        if 'noticedesc' in str(req.url) and A in str(req.url):
            return httpx.Response(302, headers={'location': str(req.url).replace(A, B)})
        if 'noticedesc' in str(req.url):
            return httpx.Response(200, json={'description': FOREIGN})
        return httpx.Response(200, json={'attachments': []})
    _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    out = mod.fetch_notice_depth(A, api_key='probe-only-not-a-real-key')
    persisted = json.load(open(os.path.join(d, A + '.json'))) if os.path.exists(os.path.join(d, A + '.json')) else None
    return {'description': (out.get('description') or '')[:90], 'description_checked': out.get('description_checked'),
            'adopted_foreign_text': FOREIGN[:40] in (out.get('description') or ''),
            'persisted_to_disk': persisted is not None,
            'persisted_description_is_foreign': bool(persisted) and FOREIGN[:40] in (persisted.get('description') or ''),
            'errors': out.get('errors'), 'requests': seen[:3]}

obs = {'candidate': run('candidate'), 'base': run('base')}

# Does the adopted description reach a BID_NOW requirement excerpt through the production ledger?
ledger_result = {}
try:
    os.environ['LILA_NOTICE_CACHE_DIR'] = tempfile.mkdtemp(prefix='dr-ledger-')
    from agents.assess.contracts import LiveClassification
    from tests.test_assess_ledger import _sweep, _depth_record, _build_with_requirement_review
    sweep = _sweep()
    depth = _depth_record()
    depth['source_depth']['description'] = FOREIGN          # what run_dossiers would copy in
    sweep['results']['dossiers'] = {'depth_records': [depth]}
    run_, _, _ = _build_with_requirement_review(sweep, excerpt=FOREIGN[:60]) if 'excerpt' in _build_with_requirement_review.__code__.co_varnames else _build_with_requirement_review(sweep)
    rec = next(r for r in run_.live.records if r.notice_id == 'N1')
    ledger_result = {'classification': str(rec.classification), 'is_bid_now': rec.classification == LiveClassification.BID_NOW,
                     'requirement_excerpt': (rec.requirement_excerpt or '')[:80],
                     'excerpt_is_foreign_text': FOREIGN[:30] in (rec.requirement_excerpt or '')}
except Exception as exc:
    ledger_result = {'error': f'{type(exc).__name__}: {exc}'}

print(json.dumps({'probe': 'lead verification: depth-route redirect to another notice reaches trusted description',
  'status': 'FAIL' if obs['candidate']['adopted_foreign_text'] else 'PASS',
  'observed': {'fetch_notice_depth': obs,
               'identical_at_accepted_base': obs['candidate']['adopted_foreign_text'] == obs['base']['adopted_foreign_text'],
               'ledger_with_that_description_as_source_depth': ledger_result,
               'note': 'The redirect target must serve a body with no conflicting notice id; a body naming its own foreign id is refused. run_dossiers copies depth[description] into source_depth.description verbatim.'}}, indent=1))
