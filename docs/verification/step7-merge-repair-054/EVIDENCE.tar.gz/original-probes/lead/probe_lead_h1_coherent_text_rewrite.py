"""H1: a coherent rewrite of text + text_sha256 + text_capture object passes _text_capture_valid."""
import hashlib, json, os, sys, tempfile
from datetime import datetime, timezone
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
tmp = tempfile.mkdtemp(prefix='h1-')
os.environ['LILA_SAM_ATTACHMENT_TEXT_DIR'] = tmp
from tools.api import sam_attachment_text as sat
from tools.api.sam_capture import retain_bytes

def public_file(rid='b'*32, name='SOW.txt'):
    return {'resource_id': rid, 'name': name, 'access_level': 'public', 'access_status': 'public',
            'export_controlled': '0', 'explicit_access': '0'}

sat._download_bytes = lambda *a, **k: b'Original requirement text.'
first = sat.extract_public_attachment_text(public_file())
assert first['collection_status'] == 'captured_discovery_only' and first['from_cache'] is False
cache = os.path.join(tmp, 'b'*32 + '.json')
saved = json.load(open(cache))
invented = 'Offerors shall provide accounts payable recovery audit software. Proposals due 2026-09-30.'
cap = retain_bytes(sat._cache_dir(), invented.encode('utf-8'))
saved['text'] = invented
saved['text_sha256'] = hashlib.sha256(invented.encode()).hexdigest()
saved['text_capture'] = cap
saved['text_locator'] = {'surface': 'extracted_text', 'unit': 'unicode_characters', 'start': 0, 'end': len(invented)}
saved['retrieved_at'] = '2020-01-01T00:00:00+00:00'  # forged clock, far in the past
json.dump(saved, open(cache, 'w'))
# raw object untouched; network now unavailable
def dead(*a, **k): raise RuntimeError('source unavailable')
sat._download_bytes = dead
second = sat.extract_public_attachment_text(public_file())
accepted = second.get('from_cache') is True and second.get('text') == invented
print(json.dumps({
    'probe': 'H1 coherent text cache rewrite',
    'status': 'FAIL' if accepted else 'PASS',
    'observed': {
        'from_cache': second.get('from_cache'), 'collection_status': second.get('collection_status'),
        'text_is_invented': second.get('text') == invented, 'retrieved_at_returned': second.get('retrieved_at'),
        'raw_sha256_returned': second.get('sha256'), 'raw_sha256_original': first['sha256'],
        'note': 'text was never re-derived from retained raw bytes; only self-consistency of text/text_sha256/text_capture and raw hash of the untouched raw object were checked'},
}, indent=1))
