"""Lead check of N-02: is a base-written (052-era) depth cache migrated or refetched by the candidate?"""
import json, os, sys, tempfile, subprocess, importlib.util, hashlib
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
cache = tempfile.mkdtemp(prefix='depth-')
os.environ['LILA_NOTICE_CACHE_DIR'] = cache
os.environ.pop('SAM_GOV_API_KEY', None)
import socket
socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(AssertionError('no network'))
from tools.api import sam_notice_detail as cand

# Build a 052-era depth record with the BASE projection of the real IHS body (5 rows, incl. the withdrawn SOW).
base_src = subprocess.check_output(['git', '-C', '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054', 'show',
                                    '67f644bc31bf19eadec628b738855e7b6c152a4e:tools/api/sam_notice_detail.py'], text=True)
bp = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/_base_sam_notice_detail.py'
open(bp, 'w').write(base_src.replace('—', '-'))
spec = importlib.util.spec_from_file_location('base_detail2', bp); base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

NID = '0caab6e53d8b47d7850692b7684610bf'
body = json.load(open('/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001/%s.body' % NID))
base_items, _ = base._attachment_inventory(body, NID)
record = {'id': NID, 'description': 'Revenue enhancement services.', 'attachments': base_items,
          'from_cache': False, 'retrieved_at': '2026-09-10T12:00:00+00:00', 'description_checked': True,
          'resources_checked': True, 'resources_schema': 'recognized_v1',
          'attachment_inventory_count': len(base_items), 'attachment_inventory_hash': base._manifest_hash(base_items), 'errors': []}
open(os.path.join(cache, NID + '.json'), 'w').write(json.dumps(record))

calls = []
cand.get_json = lambda *a, **k: calls.append(a) or {}
out = cand.fetch_notice_depth(NID)
after = json.load(open(os.path.join(cache, NID + '.json')))
cand_active, _ = cand._attachment_inventory(body, NID)
withdrawn_ids = {a['resource_id'] for a in cand._withdrawn_inventory(body, NID)}
served_ids = {a.get('resource_id') for a in (out.get('attachments') or [])}
obs = {'served_from_cache': out.get('from_cache'), 'network_calls': len(calls),
       'served_count': out.get('attachment_inventory_count'),
       'fresh_active_count': len(cand_active),
       'withdrawn_still_served_as_live': sorted(withdrawn_ids & served_ids),
       'withdrawn_attachments_key_present': 'withdrawn_attachments' in out,
       'served_hash': out.get('attachment_inventory_hash'),
       'fresh_hash': cand._manifest_hash(cand_active),
       'hash_matches_fresh_sweep': out.get('attachment_inventory_hash') == cand._manifest_hash(cand_active),
       'disk_record_changed': after != record}
print(json.dumps({'probe': 'N-02 lead check: 052-era depth cache migration',
                  'status': 'FAIL' if obs['withdrawn_still_served_as_live'] else 'PASS', 'observed': obs}, indent=1))
