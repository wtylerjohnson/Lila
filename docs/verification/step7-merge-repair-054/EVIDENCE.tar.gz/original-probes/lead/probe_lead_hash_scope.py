"""Lead check of the N-01 claim: does the 053 active-inventory hash differ from the 052 receipt hash on real bodies that have NO withdrawn rows?"""
import json, glob, os, sys, subprocess, importlib.util
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
from tools.api import sam_notice_detail as cand

# load the accepted-base module from git show, as an isolated module
base_src = subprocess.check_output(['git', '-C', '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054', 'show',
                                    '67f644bc31bf19eadec628b738855e7b6c152a4e:tools/api/sam_notice_detail.py'], text=True)
base_path = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/_base_sam_notice_detail.py'
open(base_path, 'w').write(base_src.replace('—', '-'))
spec = importlib.util.spec_from_file_location('base_detail', base_path)
base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

S = '/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001'
rows = []
for b in sorted(glob.glob(S + '/*.body')):
    nid = os.path.basename(b)[:-5]
    receipt = json.load(open(b[:-5] + '.json'))
    payload = json.load(open(b))
    active, recognized = cand._attachment_inventory(payload, nid)
    if not recognized:
        rows.append({'notice': nid, 'recognized': False}); continue
    withdrawn = cand._withdrawn_inventory(payload, nid)
    base_items, base_recognized = base._attachment_inventory(payload, nid)
    rows.append({'notice': nid, 'recognized': True,
                 'base_hash': base._manifest_hash(base_items or []),
                 'cand_hash': cand._manifest_hash(active or []),
                 'receipt_hash_equals_base': base._manifest_hash(base_items or []) == cand._manifest_hash(base_items or []) if False else None,
                 'withdrawn_rows': len(withdrawn), 'base_count': len(base_items or []), 'cand_count': len(active or []),
                 'new_keys_on_live_rows': sorted({k for it in (active or []) for k in it if k in ('deleted_flag', 'deleted_date', 'file_exists')})})
rec = [r for r in rows if r.get('recognized')]
changed = [r for r in rec if r['base_hash'] != r['cand_hash']]
changed_no_withdrawn = [r for r in changed if r['withdrawn_rows'] == 0]
print(json.dumps({
    'probe': 'N-01 lead check: hash change scope on the 21 real bodies',
    'status': 'FAIL' if changed_no_withdrawn else 'PASS',
    'observed': {'recognized': len(rec), 'hash_changed': len(changed), 'hash_changed_with_zero_withdrawn_rows': len(changed_no_withdrawn),
                 'notices_with_withdrawn_rows': sum(1 for r in rec if r['withdrawn_rows']),
                 'count_unchanged_but_hash_changed': sum(1 for r in changed if r['base_count'] == r['cand_count']),
                 'new_keys_seen_on_live_rows': sorted({k for r in rec for k in r['new_keys_on_live_rows']}),
                 'sample': changed_no_withdrawn[:2],
                 'doc_sentence': 'CONTRACT_SURFACES 053: "This intentionally changes prior live-file hashes when withdrawn rows were previously counted"'}}, indent=1))
