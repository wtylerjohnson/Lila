"""H3: a resources body for another notice that omits explicit opportunityId/noticeId keys is accepted."""
import json, os, sys, tempfile
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
tmp = tempfile.mkdtemp(prefix='h3-')
os.environ['LILA_NOTICE_CACHE_DIR'] = tmp
import httpx
from tools.api import _http, sam_notice_detail as detail
requested = 'a'*32; other = 'b'*32
real = json.load(open('/Users/wtjohnson/lila-step7-052-review/FABLE-STEP7-052/extracted/source-proof/public-inventory-001/0caab6e53d8b47d7850692b7684610bf.body'))
# Rebuild the real SAM shape for the OTHER notice, but strip the explicit opportunityId key.
entry = dict(real['_embedded']['opportunityAttachmentList'][0]); entry.pop('opportunityId', None)
body = {'_embedded': {'opportunityAttachmentList': [entry]},
        '_links': {'self': {'href': f'https://sam.gov/api/prod/opps/v3/opportunities/{other}/resources'}}}
raw = json.dumps(body).encode()
calls = []
def handler(request):
    calls.append(str(request.url)); return httpx.Response(200, content=raw)
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(handler))
res = detail.fetch_notice_resources(requested)
accepted = res.get('resources_checked') is True and res.get('collection_status') == 'inventory_captured'
# control: with the explicit key present the mismatch is caught
entry2 = dict(entry); entry2['opportunityId'] = other
raw2 = json.dumps({'_embedded': {'opportunityAttachmentList': [entry2]}, '_links': body['_links']}).encode()
tmp2 = tempfile.mkdtemp(prefix='h3b-'); os.environ['LILA_NOTICE_CACHE_DIR'] = tmp2
_http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=raw2)))
res2 = detail.fetch_notice_resources(requested)
print(json.dumps({'probe': 'H3 links-only wrong notice body', 'status': 'FAIL' if accepted else 'PASS',
                  'observed': {'links_only_body': {'collection_status': res.get('collection_status'), 'resources_checked': res.get('resources_checked'), 'inventory_count': res.get('attachment_inventory_count'), 'requested_url': calls[:1]},
                               'explicit_key_control': {'collection_status': res2.get('collection_status'), 'resources_checked': res2.get('resources_checked')},
                               'note': '_resource_identity_matches inspects only opportunityId/noticeId/notice_id keys; _links.self.href and per-file URLs are not compared'}}, indent=1))
