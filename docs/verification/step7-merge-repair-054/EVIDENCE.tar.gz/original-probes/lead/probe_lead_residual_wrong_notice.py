"""Lead check: what wrong-notice carriers remain accepted on the candidate, and were they accepted at base too?"""
import json, os, sys, tempfile, subprocess, importlib.util
sys.path.insert(0, '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054')
import httpx
from tools.api import _http, sam_notice_detail as cand
A = 'a' * 32; B = 'b' * 32

base_src = subprocess.check_output(['git', '-C', '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054', 'show',
                                    '67f644bc31bf19eadec628b738855e7b6c152a4e:tools/api/sam_notice_detail.py'], text=True)
bp = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/_base_sam_notice_detail.py'
open(bp, 'w').write(base_src.replace('—', '-'))
spec = importlib.util.spec_from_file_location('base_detail3', bp); base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

ROW = {'attachmentId': 'x' * 32, 'resourceId': 'c' * 32, 'name': 'Foreign SOW.pdf', 'type': 'file',
       'accessLevel': 'public', 'accessStatus': 'public', 'exportControlled': '0', 'explicitAccess': '0',
       'mimeType': '.pdf', 'size': 100, 'deletedFlag': '0', 'deletedDate': '', 'fileExists': '1'}
CASES = {
  'body_names_B_explicitly': {'_embedded': {'opportunityAttachmentList': [{'opportunityId': B, 'attachments': [ROW]}]}},
  'body_links_self_names_B': {'_embedded': {'opportunityAttachmentList': [{'attachments': [ROW]}]},
                              '_links': {'self': {'href': 'https://sam.gov/api/prod/opps/v3/opportunities/%s/resources' % B}}},
  'body_id_less_no_links': {'_embedded': {'opportunityAttachmentList': [{'attachments': [ROW]}]}},
  'body_foreign_id_in_query_only': {'_embedded': {'opportunityAttachmentList': [{'attachments': [ROW]}]},
                                    '_links': {'self': {'href': 'https://sam.gov/resources?noticeid=%s' % B}}},
}
out = {}
for name, body in CASES.items():
    raw = json.dumps(body).encode()
    for tag, mod in (('candidate', cand), ('base', base)):
        d = tempfile.mkdtemp(prefix='wn-')
        os.environ['LILA_NOTICE_CACHE_DIR'] = d
        _http._client = lambda timeout: httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=raw)))
        try:
            res = mod.fetch_notice_resources(A)
            out.setdefault(name, {})[tag] = {'status': res.get('collection_status', 'n/a'),
                                             'resources_checked': res.get('resources_checked'),
                                             'rows_attributed_to_A': len(res.get('attachments') or [])}
        except Exception as exc:
            out.setdefault(name, {})[tag] = {'error': type(exc).__name__}
accepted_cand = [k for k, v in out.items() if v['candidate'].get('rows_attributed_to_A')]
print(json.dumps({'probe': 'residual wrong-notice carriers on the candidate versus base',
    'status': 'INFO',
    'observed': {'cases': out, 'still_accepted_by_candidate': accepted_cand,
                 'accepted_by_base': [k for k, v in out.items() if v['base'].get('rows_attributed_to_A')],
                 'note': 'An id-less body with no identity carrier anywhere is indistinguishable from the notice own inventory by any receipt-time check; a foreign id in a query string is not parsed (path segments only).'}}, indent=1))
