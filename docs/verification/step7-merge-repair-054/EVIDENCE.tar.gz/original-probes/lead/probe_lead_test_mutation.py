"""Lead check: do the 053 tests actually pin the repairs? Mutate each repair in a COPY of the tree and run the focused module."""
import json, os, shutil, subprocess, tempfile, sys

SRC = '/Users/wtjohnson/Documents/Codex/2026-09-08/lila-benchmark-coordinator/work/step7-merge-repair-054'
OUT = '/Users/wtjohnson/lila-step7-053-review/FABLE-STEP7-FOLLOWUPS-053/probes/lead/mutants'
MUTANTS = {
 'withdrawn_always_false': ('tools/api/sam_notice_detail.py',
    "def attachment_withdrawn(item: dict) -> bool:\n    open_flags",
    "def attachment_withdrawn(item: dict) -> bool:\n    return False\n    open_flags"),
 'notice_link_always_matches': ('tools/api/sam_notice_detail.py',
    "def _notice_link_matches(value: Any, notice_id: str) -> bool:\n    if not isinstance(value, str):",
    "def _notice_link_matches(value: Any, notice_id: str) -> bool:\n    return True\n    if not isinstance(value, str):"),
 'origin_always_valid': ('tools/api/sam_notice_detail.py',
    "def _capture_origin_valid(capture: dict, notice_id: str) -> bool:\n    requested",
    "def _capture_origin_valid(capture: dict, notice_id: str) -> bool:\n    return True\n    requested"),
 'stale_fallback_unvalidated': ('tools/api/sam_notice_detail.py',
    "and cached.get('id') == notice_id and _resource_capture_valid(cached) \\",
    "\\"),
 'gate_after_slots': ('run_searches.py',
    "                elif len(selected) < 3:\n                    selected.append((attachment, receipt))",
    "                elif len(selected) < 3 or True:\n                    selected.append((attachment, receipt))"),
}
TESTS = ['tests/test_step7_followups.py', 'tests/test_step7_evidence_collection.py', 'tests/test_sam_attachment_text.py']
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'LILA_SUITE_OFFLINE': '1', 'LILA_SUITE_STRICT': '1'}
results = {}
for name, (relpath, needle, replacement) in MUTANTS.items():
    work = tempfile.mkdtemp(prefix='mut-', dir=OUT)
    for item in ('tools', 'run_searches.py', 'tests', 'agents', 'conftest.py', 'pipeline', 'data', 'clients', 'docs', 'assets', 'fixtures', 'intake'):
        s = os.path.join(SRC, item)
        if os.path.isdir(s): shutil.copytree(s, os.path.join(work, item), symlinks=True, ignore=shutil.ignore_patterns('__pycache__'))
        elif os.path.exists(s): shutil.copy2(s, os.path.join(work, item))
    p = os.path.join(work, relpath)
    src = open(p).read()
    if needle not in src:
        results[name] = {'applied': False, 'reason': 'needle not found'}; shutil.rmtree(work, ignore_errors=True); continue
    open(p, 'w').write(src.replace(needle, replacement, 1))
    cp = subprocess.run([os.path.join(SRC, '.venv/bin/python'), '-m', 'pytest', *TESTS, '-q', '-p', 'no:cacheprovider'],
                        cwd=work, env=env, capture_output=True, text=True, timeout=900)
    tail = (cp.stdout + cp.stderr).strip().splitlines()[-1] if (cp.stdout + cp.stderr).strip() else ''
    failed = [l.split('::')[-1].split(' ')[0] for l in (cp.stdout + cp.stderr).splitlines() if l.startswith('FAILED')]
    results[name] = {'applied': True, 'exit': cp.returncode, 'killed': cp.returncode != 0, 'summary': tail[:160], 'failed_tests': sorted(set(failed))[:6]}
    shutil.rmtree(work, ignore_errors=True)
survived = [k for k, v in results.items() if v.get('applied') and not v.get('killed')]
print(json.dumps({'probe': 'do the 053 tests pin the repairs (mutation check on a copied tree)',
                  'status': 'FAIL' if survived else 'PASS',
                  'observed': {'mutants': results, 'survived_unkilled': survived,
                               'note': 'Run in a throwaway copy of the tree; the review clone is never modified.'}}, indent=1))
